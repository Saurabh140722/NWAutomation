package com.o2.models.csrd;

import com.nttdata.cinnamon.driver.controls.PageElement;

public class BoltOn {
    public PageElement title;
    public PageElement price;
    public PageElement addToPlanButton;
}
