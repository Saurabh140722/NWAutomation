package com.o2.pages.csrd.navigation;

import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.nttdata.cinnamon.driver.controls.PageElementCollection;
import com.o2.pages.BasePage;

public class CancelOrder extends BasePage {

    @Find(by = By.XPath, locator = "//button[text()='Cancel Order']")
    public PageElement cancelOrderLink;

    @Find(by = By.XPath, locator = "//table[@class='TableCtrl nc-table-content-zebra']/tbody/tr")
    public PageElementCollection tableRows;

    @Find(by = By.XPath, locator = "//textarea[@id='9140104793613089160']")
    public PageElement textBoxAreaForReasonDesc;

    @Find(by = By.XPath, locator = "//textarea[@id='-2']")
    public PageElement textBoxAreaForInteractionDesc;

    @Find(by = By.XPath, locator = "//button[contains(text(),'Continue')]")
    public PageElement continueBtn;

    @Find(by = By.CssSelector, locator = "#backToCSRD")
    public PageElement backtoCsrDesktopButton;


}
