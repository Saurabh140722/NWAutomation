package com.o2.models.ecomm;

import java.text.MessageFormat;
import java.util.List;

public class EcommNewUser {
    public String userType;
    public String email;
    public String password;
    public String title;
    public String firstName;
    public String lastName;
    public String mobile;
    public String dob;
    public String postalCode;
//added below data from ecare user

    public String planType;
    public String username;
    public String securityCode;




    @Override
    public String toString() {
        return MessageFormat.format("New eCare User:" +
                        "\n\tUser Type:\t\t\t{0}" +
                         "\n\tEmail:\t\t\t{1}" +
                        "\n\tPassword:\t\t{2}" +
                        "\n\tTitle:\t\t{3}" +
                        "\n\tFirst Name:\t\t\t{4}" +
                        "\n\tLast Name:\t\t\t{5}" +
                        "\n\tMobile:\t\t{6}" +
                        "\n\tDOB:\t\t{7}" +
                        "\n\tPostal Code:\t\t\t{8}",
                this.userType,
                this.email,
                this.password,
                this.title,
                this.firstName,
                this.lastName,
                this.mobile,
                this.dob,
                this.postalCode


        );
    }
}
