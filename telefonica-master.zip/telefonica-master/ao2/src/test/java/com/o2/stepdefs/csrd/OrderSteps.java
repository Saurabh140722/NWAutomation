package com.o2.stepdefs.csrd;

import com.google.inject.Inject;
import com.o2.pages.csrd.OrderPage;
import com.o2.stepdefs.BaseStep;
import io.cucumber.java.en.When;

import static com.nttdata.cinnamon.wait.ElementConditions.displayed;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;

public class OrderSteps extends BaseStep {
    private final OrderPage orderPage;

    @Inject
    public OrderSteps(final OrderPage orderPage) {
        this.orderPage = orderPage;
    }

    @When("^my order is for '(.*)'$")
    public void my_order_is_for(String orderType) {
        assertThat(this.orderPage.isPageDisplayed())
                .withFailMessage("New Order page not displayed!")
                .isTrue();
        assertEquals(orderType, this.orderPage.getDistributionChannelByIndex(1));
        this.orderPage.getBtn_createOrder().waitUntil(displayed).click();
    }
}
