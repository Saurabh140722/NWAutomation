package com.o2.stepdefs.ecomm;

import com.google.inject.Inject;
import com.nttdata.cinnamon.cache.Context;
import com.nttdata.cinnamon.driver.Browser;
import com.nttdata.cinnamon.webdriver.util.ReadyState;
import com.o2.models.ecomm.Extra;
import com.o2.models.ecomm.Tariffs;
import com.o2.pages.ecomm.BuildYourPackagePage;
import com.o2.pages.ecomm.EcommBasePage;
import com.o2.pages.ecomm.PhonePage;

import com.o2.util.Common;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import org.assertj.core.api.Assertions;

import java.text.MessageFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.nttdata.cinnamon.wait.ElementConditions.*;
import static com.nttdata.cinnamon.wait.conditions.Conditions.ajaxFinished;
import static com.nttdata.cinnamon.wait.conditions.Conditions.readyState;
import static org.assertj.core.api.Assertions.assertThat;

public class BuildYourPackageSteps extends BaseStep {
    private final Browser browser;
    private final BuildYourPackagePage buildYourPackagePage;
    private final EcommBasePage ecommBasePage;
    private final Context context;
    private final PhonePage phonePage;
    private final Common common;

    @Inject
    public BuildYourPackageSteps(Browser browser, BuildYourPackagePage buildYourPackagePage, EcommBasePage ecommBasePage, Context context, Common common, PhonePage phonePage) {

        this.browser = browser;
        this.buildYourPackagePage = buildYourPackagePage;
        this.ecommBasePage = ecommBasePage;
        this.context = context;
        this.common = common;
        this.phonePage = phonePage;
    }

    @And("^I build my package '(with|without)' extra:$")
    public void iBuildMyPackageWithoutExtra(String extra, DataTable table) {
        this.common.wait(8);
        Map<String, Object> currentPackage = new HashMap<>();
        logger.info("** Attempt to build the package tariff  " + extra + " extra ...");
        browser.waitUntil(readyState(ReadyState.COMPLETE));
        Assertions.assertThat(buildYourPackagePage.pageTitle.isDisplayed(5))
                .withFailMessage("Build your package not loaded")
                .isTrue();

        List<Map<String, String>> data = table.asMaps(String.class, String.class);
        String simtype = data.get(0).get("simType");
        String phonetype = data.get(0).get("phoneType");
        Tariffs selectedTariff = (Tariffs) context.get("Plan");

        this.logger.info("Get Tariffs" + selectedTariff);
        currentPackage.put("Tariff", selectedTariff);
        currentPackage.put("SimType", simtype);
        currentPackage.put("PhoneType", phonetype);

        String planName= (String) this.context.get("PlanName");
         Assertions.assertThat(buildYourPackagePage.getAddedPlanTitle(planName.trim()).isDisplayed()).withFailMessage(
                        MessageFormat.format(
                                "Could not find ''{0}'' plan in build your package page..", planName))
                 .isTrue();

        buildYourPackagePage.getSim(simtype).clickJs();
        buildYourPackagePage.getDevice(phonetype).clickJs();

        if (extra.equalsIgnoreCase("with")) {
            String extraName = data.get(0).get("extraName");
            Extra ex = buildYourPackagePage.addeExtra(extraName);
            Assertions.assertThat(ex).withFailMessage(
                    MessageFormat.format(
                            "Could not find ''{0}'' extra..", extraName)).isNotNull();
            ex.addExtra.clickJs();
            currentPackage.put("Extra", ex);
        }
        context.set("Package", currentPackage);
        browser.waitUntil(ajaxFinished);
        common.wait(8);
        buildYourPackagePage.addToBasket.waitUntil(displayed.and(enabled).and(present).and(clickable)).clickJs();
        buildYourPackagePage.waitForjustaMomentLoadingToComplete(3, 2, 6);
        logger.info("**Successfully Build the package with " + simtype + " , " + phonetype + " and " + extra + " extra....");
    }


    @And("^I build my plan with '(.*)' Sim type$")
    public void iBuildMyPackageWithSimtype(String simType) {
        this.logger.info(MessageFormat.format("** Attempt to build the plane with ''{0}'' ...", simType));
        String selectedPhone = (String) context.get("phone");
        phonePage.closeChatPopup();
        Assertions.assertThat(phonePage.selectedPhoneDetails.isDisplayed(5)).withFailMessage(
                        "Device Details not loaded")
                .isTrue();

        Assertions.assertThat(phonePage.selectedPhoneDetails.getText().replace("\n", " "))
                .withFailMessage(
                        MessageFormat.format("Selected Device ''{0}'' not displayed!", selectedPhone))
                .isEqualTo(selectedPhone);

        Assertions.assertThat(phonePage.stockAvailability.getText().trim())
                .withFailMessage(
                        MessageFormat.format("Selected Device ''{0}'' is out of stock!", selectedPhone))
                .isEqualTo("In stock");

        String monthly = this.phonePage.monthlyPayment.getText();
        String upfornt = this.phonePage.upfrontPayment.getText();
        this.context.set("monthly", monthly);
        this.context.set("upfornt", upfornt);

        this.ecommBasePage.getButton("Select this plan").waitUntil(displayed.and(enabled).and(present).and(clickable)).clickJs();
        this.browser.waitUntil(readyState(ReadyState.COMPLETE));

        Assertions.assertThat(this.buildYourPackagePage.pageTitle.isDisplayed(5)).withFailMessage(
                        "Build your package not loaded")
                .isTrue();
        this.browser.waitUntil(readyState(ReadyState.COMPLETE));
        buildYourPackagePage.addToBasket.waitUntil(displayed.and(enabled).and(present).and(clickable)).clickJs();
        buildYourPackagePage.waitForjustaMomentLoadingToComplete(5, 2, 5);

        logger.info("**Successfully Build the package with " + simType);
    }
}
