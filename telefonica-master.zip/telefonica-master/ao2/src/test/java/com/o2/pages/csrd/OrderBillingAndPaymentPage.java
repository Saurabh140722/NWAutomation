package com.o2.pages.csrd;

import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.o2.pages.BasePage;

public class OrderBillingAndPaymentPage extends BasePage {
    @Find(by = By.CssSelector, locator = ".center_col.center_col_billing_and_payment_tab")
    public PageElement formBlock;

    @Override
    public PageElement getPageCheckElement() {
        return this.formBlock;
    }
}
