package com.o2.stepdefs.ecare;

import com.google.inject.Inject;
import com.nttdata.cinnamon.driver.Browser;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.o2.models.ecare.BillingHistoryPaymentSuccessDetails;
import com.o2.pages.ecare.BillingHistoryPage;
import com.o2.pages.ecare.BillingHistoryPaymentSuccessDetailsPage;
import com.o2.stepdefs.BaseStep;
import com.o2.util.Common;
import io.cucumber.java.en.And;
import io.cucumber.java.en.When;

import java.util.List;

import static com.nttdata.cinnamon.wait.ElementConditions.displayed;
import static org.assertj.core.api.Assertions.assertThat;

public class BillingHistorySteps extends BaseStep {
    private final Common common;
    private final BillingHistoryPage billingHistoryPage;
    private final BillingHistoryPaymentSuccessDetailsPage billingHistoryPaymentSuccessDetailsPage;
    private final Browser browser;

    @Inject
    public BillingHistorySteps(BillingHistoryPaymentSuccessDetailsPage billingHistoryPaymentSuccessDetailsPage, final Common common, final BillingHistoryPage billingHistoryPage, final Browser browser) {
        this.billingHistoryPage = billingHistoryPage;
        this.billingHistoryPaymentSuccessDetailsPage = billingHistoryPaymentSuccessDetailsPage;
        this.common = common;
        this.browser = browser;
    }

    @When("^Page should navigate to bill history page and should see billing detail$")
    public void bill_histoty_page() {
        this.logger.info("** Waiting for Bill hostory page to open ...");

        assertThat(this.billingHistoryPage.pageTitle.isDisplayed(5)).withFailMessage("Bill history page not displayed!")
        		.isTrue();
        this.browser.setImplicitWait(5);
        if(this.billingHistoryPage.noBill.isDisplayed()) {
            this.logger.info("**"+this.billingHistoryPage.noBill.getText().trim()+" ...");
            assertThat(this.billingHistoryPage.noBill.isDisplayed(5)).withFailMessage("Bill history page not displayed!")
                    .isTrue();
        }
    //TODO :Once we get the data ,will add code to verify generated bill.
    }

    @And("I select {string} from {string} section displays")
    public void i_Verify_Payments_Paid_Section_Displays(String billingHistorySubSection, String billingHistoryMainSection) {
        browser.setImplicitWait(20);
        billingHistoryPage.clickBillingHistorySections(billingHistorySubSection);
//        billingHistoryPage.billingMethodHeader.waitUntil(displayed);
//        if(!(billingHistoryPage.billTypeHistoryHeader.isDisplayed())){
//            billingHistoryPage.clickBillingHistorySections("Bill type");
//        }
//        billingHistoryPage.billTypeHistoryHeader.waitUntil(displayed);
//        billingHistoryPage.clickBillingHistorySections(billingHistorySubSection);
    }

    @And("I verify PaymentType {string}")
    public void iVerifyOrderPayments(String PaymentType) {
        billingHistoryPage.paymentType.waitUntil(displayed);
        billingHistoryPage.paymentType.clickJs();
        billingHistoryPage.billPaymentpaymentTypeOption.waitUntil(displayed);
        billingHistoryPage.orderPaymentpaymentTypeOption.waitUntil(displayed);
        PageElement pe = billingHistoryPage.paymentTypeOptions.asList().stream()
                .filter(p->p.getText().trim().equalsIgnoreCase(PaymentType))
                .findFirst()
                .orElse(null);
        pe.clickJs();
    }

    @And("I verify Payment Details")
    public void iVerifyPaymentDetails() {
        billingHistoryPage.paymentSuccess.waitUntil(displayed);
        billingHistoryPage.paymentSuccess.clickJs();
        billingHistoryPage.additionalInformation.waitUntil(displayed);
        List<BillingHistoryPaymentSuccessDetails> bpdList  =billingHistoryPaymentSuccessDetailsPage.getBillingHistoryPaymentDetails();
        bpdList.stream().forEach(p -> this.logger.info("PaymentDetails:- "+p.paymentDate.getText() + " :: " + p.paymentMethod.getText() + " :: " + p.amount.getText() + " :: " + p.frequency.getText() + " :: "+p.channel.getText()+" :: "+p.transactionID));
    }

    public void sortPaymentsBy(String sortByValue, String sortByAscDescValue){
        billingHistoryPage.sortBy.clickJs();
        billingHistoryPage.sortByDate.waitUntil(displayed);
        billingHistoryPage.sortByAmount.waitUntil(displayed);
        if(sortByValue.equalsIgnoreCase("Date")){
            billingHistoryPage.sortByOptions.asList().stream()
                    .filter(p->p.getText().trim().equalsIgnoreCase(sortByAscDescValue))
                    .findFirst()
                    .orElse(null);
        }else if(sortByValue.equalsIgnoreCase("Amount")){
            PageElement pe = billingHistoryPage.sortByOptions.asList()
                    .stream()
                    .filter(p->p.getText().trim().equalsIgnoreCase(sortByAscDescValue))
                    .findFirst()
                    .orElse(null);
            pe.clickJs();
            billingHistoryPage.sortBy.clickJs();
        }
    }

    public void filterPaymentsBy(String filterByValue){
        billingHistoryPage.filterBy.clickJs();
        billingHistoryPage.filterByStatusCaption.waitUntil(displayed);
        if (!(billingHistoryPage.filterByClearAll.isDisplayed() && billingHistoryPage.filterBySelectAll.isDisplayed())) {
            billingHistoryPage.filterByStatusCaption.clickJs();
        }
        PageElement pe = billingHistoryPage.filterByOptions.asList().stream()
                .filter(p->p.getText().trim().equalsIgnoreCase("filterByValue"))
                .findFirst()
                .orElse(null);
        pe.clickJs();
        billingHistoryPage.filterBy.clickJs();
    }



}
