package com.o2.feature_file_appender.unit_tests.config.pojo.sample_data_tab;

public class SampleData {

    private String[][] sampleData;

    public SampleData() {}

    public String[][] getSampleData() {
        return sampleData;
    }

    public void setSampleData(String[][] sampleData) {
        this.sampleData = sampleData;
    }
}
