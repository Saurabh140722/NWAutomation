package com.o2.stepdefs.ecare;

import com.google.inject.Inject;
import com.nttdata.cinnamon.cache.Context;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.o2.core.util.Common;
import com.o2.models.ecare.EcareUser;
import com.o2.pages.ecare.NotificationEmailPage;
import com.o2.stepdefs.BaseStep;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

import java.util.Random;

import static org.assertj.core.api.Assertions.assertThat;

public class NotificationEmailSteps extends BaseStep {
    private final NotificationEmailPage notificationEmailPage;
    private final Context context;
    private final Common common;

    @Inject
    public NotificationEmailSteps(final NotificationEmailPage notificationEmailPage, final Context context, final Common common) {
        this.notificationEmailPage = notificationEmailPage;
        this.context = context;
        this.common = common;
    }

    @Then("^I Verify the email under notification email section$")
    public void i_verify_the_email_under_notification_tab() {
        this.logger.info("*** Check if notification email section is loaded ...");
        assertThat(this.notificationEmailPage.isPageDisplayed())
                .withFailMessage("Contact Details section has not loaded!").isTrue();
        this.logger.info("** Email address displayed under Notification Email section!\n");

    }

    @When("^I click on edit button of Email under notification email section$")
    public void i_click_on_edit_button_under_notification_Email_Section() {
        PageElement edit = this.notificationEmailPage.getEditEmailLink();
        assertThat(edit).withFailMessage("Could not find Edit link for My Personal Details block!").isNotNull();
        edit.click();
    }

    @When("^I enter valid email address and click on save and close button$")
    public void i_enter_valid_emailaddress_and_click_on_saveandclose_button() {
        this.logger.info("*** Email Notifcation title is not displayed..." + this.notificationEmailPage.emailNotificationTitle.isDisplayed());
        EcareUser ecareUser = (EcareUser) this.context.get("ecareLoginData");
        Random randomGenerator = new Random();
        int randomInt = randomGenerator.nextInt(1000);
        this.notificationEmailPage.emailNotificationTxtBox.setValue(ecareUser.firstName + randomInt + "@yopmail.com");
        this.notificationEmailPage.emailNotificationTitle.click();
        this.notificationEmailPage.saveAndCloseBtn.click();
        this.common.wait(5);

    }


    @Then("^I can see authentication email use for notifcation email and contact is different$")
    public void i_can_see_warning_message_contactemail_different_from_notfication_email() {
        assertThat(this.notificationEmailPage.warningMessageForDifferentEmailUsed.isDisplayed())
                .withFailMessage("Email use in notification section is different from Contact email is not displayed!").isTrue();
        assertThat(this.notificationEmailPage.warningMessageForDifferentEmailUsedTxt.getText())
                .withFailMessage("Email use for authentication is different from conatct email is not displayed!").isEqualTo("Just so you know, the email address you've used for this authentication is different to the one we usually use to contact you.");


    }

}
