package com.o2.stepdefs.ecomm;

import com.google.inject.Inject;
import com.o2.pages.ecomm.ReviewPage;
import io.cucumber.java.en.And;

import java.util.logging.Logger;

public class ReviewSteps extends BaseStep {
    private final Logger logger;
    private final ReviewPage reviewPage;

    @Inject
    public ReviewSteps(final Logger logger, final ReviewPage reviewPage) {
        this.reviewPage = reviewPage;
        this.logger = logger;

    }

    @And("^Continue to Review page and review the order$")
    public void i_verify_review_Page() {
        this.logger.info("** Clicking on the checkbox...");
        this.reviewPage.termsCheckBox.clickJs();
        this.logger.info("** Clicked the Insurance Checkbox in Terms...");
        this.reviewPage.termsInsurance.clickJs();
        this.logger.info("** Clicking on Pay now CTA...");
        this.reviewPage.payNow.clickJs();

    }

}
