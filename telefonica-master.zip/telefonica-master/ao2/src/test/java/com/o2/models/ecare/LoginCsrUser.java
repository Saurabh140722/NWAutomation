package com.o2.models.ecare;

import java.text.MessageFormat;

public class LoginCsrUser {
    public String role;
    public String username;
    public String password;

    @Override
    public String toString() {
        return MessageFormat.format("Login User:" +
                        "\n\tUsername:\t\t{0}" +
                        "\n\tPassword:\t\t{1}" +
                        "\n\tRole:\t\t\t{2}",
                this.username,
                this.password,
                this.role);
    }
}
