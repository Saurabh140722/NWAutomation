package com.o2.models.ecare;

import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.controls.PageElementCollection;

import java.text.MessageFormat;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static org.assertj.core.api.Assertions.assertThat;

public class AdjustmentRow {
    public String name;
    public String status;
    public String amount;
    public String adjustmentType;
    public String approvalDate;
    public String description;

    public AdjustmentRow() {
    }

    public AdjustmentRow(PageElementCollection tableRow) {
        this.name = tableRow.asList().get(1).findChild(By.Tag, "a").getText();
        this.status = tableRow.asList().get(2).getText();
        this.amount = tableRow.asList().get(3).getText();
        this.adjustmentType = tableRow.asList().get(4).getText();
        this.approvalDate = tableRow.asList().get(7).getText();
        this.description = tableRow.asList().get(8).getText();
    }

    public int getAdjustmentId() {
        Pattern pattern = Pattern.compile("ADJ-A([0-9]+)", Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(this.name);
        boolean matchFound = matcher.find();

        assertThat(matchFound)
                .withFailMessage(
                        MessageFormat.format(
                                "Could not retrieve Adjustment ID from: ''{0}''", this.name))
                .isTrue();

        return Integer.parseInt(matcher.group(1));
    }

    @Override
    public String toString() {
        return MessageFormat.format("Adjustment:\nStatus: {0}\nAmount: {1}\nType: {2}\nApproval date: {3}\nDescription: {4}",
                this.status,
                this.amount,
                this.adjustmentType,
                this.approvalDate,
                this.description);
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == this) return true;

        if (!(obj instanceof AdjustmentRow)) return false;

        AdjustmentRow that = (AdjustmentRow) obj;

        return this.status.equals(that.status) && this.amount.equals(that.amount)
                && this.adjustmentType.equals(that.adjustmentType) && this.approvalDate.equals(that.approvalDate)
                && this.description.equals(that.description);
    }
}
