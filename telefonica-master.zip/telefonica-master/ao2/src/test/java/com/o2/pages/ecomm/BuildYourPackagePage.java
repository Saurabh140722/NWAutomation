package com.o2.pages.ecomm;

import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.nttdata.cinnamon.driver.controls.PageElementCollection;
import com.o2.models.ecomm.Extra;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

public class BuildYourPackagePage extends BasePage{
    @Find(by = By.XPath, locator = "//h1[text()=' Build your package ']")
    public PageElement pageTitle;

    @Find(by = By.XPath, locator = "//*[@class='extra-card ng-star-inserted']")
    public PageElementCollection allExtras;

    @Find(by = By.XPath, locator = "//div[contains(@class,'order-configuration-total-cost__footer')]//button")
    public PageElement addToBasket;


    public PageElement getAddedPlanTitle(String Title) {
        return this.browser.findBy(By.XPath, "//p[@class='h3 font_bold order-configuration-plan__title' and text()='" + Title + "']");
    }

   /* public PageElement getSim(String simType) {
        return this.browser.findBy(By.XPath, "//option-type[@id='simTypeSelection']//*[text()='" + simType + "']");
    }*/
    //chnage forphone
    public PageElement getSim(String simType) {
        return this.browser.findBy(By.XPath, "//option-type[@id='simTypeSelection']//*[contains(text(),'"+simType+"')]");
    }


    public PageElement getDevice(String deviceType) {
        return this.browser.findBy(By.XPath, "//option-type[@id='phoneTypeSelection']//*[contains(text(),'"+ deviceType+ "')]");
    }

    public List<Extra> getAllExtras() {
        if (allExtras == null) {
            this.logger.warn("No Extra found on the page! Is this a negative scenario?");
            return null;
        }

        List<Extra> allextras = new ArrayList<>();
        this.logger.info(MessageFormat.format("Found {0} Extrason the page. Continue ...",
                (long) allExtras.asList().size()));

        this.browser.setImplicitWait(3);
        for (PageElement ex : allExtras.asList()) {
            Extra extra = new Extra(ex.findChild(By.CssSelector, (".add-on__info>b")),
                    ex.findChild(By.CssSelector, "div[class*='o2uk-price']"),
                    ex.findChild(By.CssSelector, ".o2uk-primary-button"));
            allextras.add(extra);
        }
        this.browser.restoreImplicitWait();
        this.logger.info("****Total extra count***:" + allextras.size());
        return allextras;
    }

    public Extra addeExtra(String extraName) {
        String amount = "£";
        Extra extra;
        if (extraName.equalsIgnoreCase("Free")) {
            extra = this.getAllExtras().stream()
                    .filter(u -> u.price.getText().trim().equals(extraName.toString().toUpperCase()))
                    .findFirst()
                    .orElse(null);
        } else if (extraName.equalsIgnoreCase("Paid")) {
            extra = this.getAllExtras().stream()
                    .filter(u -> u.price.getText().trim().startsWith(amount))
                    .findFirst()
                    .orElse(null);
        } else if (extraName.equalsIgnoreCase("Any")) {
            extra = this.getAllExtras().get(0);

        } else {
            extra = this.getAllExtras().stream()
                    .filter(u -> u.title.getText().trim().equals(extraName.toString()))
                    .findFirst()
                    .orElse(null);
        }
        return extra;
    }
}
