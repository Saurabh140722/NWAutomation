package com.o2.pages.ecare;

import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.nttdata.cinnamon.driver.controls.PageElementCollection;

public class ChangeTariffStepsPage extends EcareBasePage {

    @Find(by = By.CssSelector, locator = ".o2uk-tariff-card__wrapper")
    public PageElementCollection tariffCardOptions;

    @Find(by = By.CssSelector, locator = ".o2uk-tariff-card__info-content>p")
    public PageElementCollection tariffCardOptionsText;

    @Find(by = By.Id, locator = "logoutBtn")
    public PageElement signOutBtn;


}
