package com.o2.pages.ecomm;

import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.nttdata.cinnamon.driver.controls.PageElementCollection;
import com.o2.models.ecomm.Basket;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.nttdata.cinnamon.wait.ElementConditions.displayed;

public class YourBasketPage extends EcommBasePage {
    @Find(by = By.XPath, locator = "//h1[contains(@class,'o2uk-header-curve__text-title')]")
    public PageElement pageTitle;

    @Find(by = By.XPath, locator = "//basket-section-cta//o2uk-link/button")
    public PageElement emptyBasket;

    @Find(by = By.XPath, locator = "//o2uk-common-dialog//div[@class='o2uk-dialog-title']//h3[text()='Empty basket']")
    public PageElement emptyBasketDialog;

    @Find(by = By.XPath, locator = "//o2uk-dialog-actions//button[@aria-label='Cancel the order']")
    public PageElement cancelOrderEmptyBasket;

    @Find(by = By.XPath, locator = "//customers-basket/o2uk-header-curve//h1[text()=' Your basket is empty ']")
    public PageElement yourBasketIsEmpty;

    @Find(by = By.XPath, locator = "//input[@placeholder='e.g. O2UK123']")
    public PageElement promoCodeTxtBox;

    @Find(by = By.XPath, locator = "//span[contains(text(),' Update ')]")
    public PageElement updateButton;

    @Find(by = By.CssSelector, locator = ".o2uk-notification-message__title")
    public PageElement promoCodeErrorMessage;

    @Find(by = By.XPath, locator = "//div[contains(@class,' basket-section')]//*[contains(text(),'Checkout')]")
    public PageElement checkoutBtn;


//    @Find(by = By.XPath, locator = "//o2uk-basket-card[contains(@class,'basket-card')]")
//    public PageElementCollection allPackages;
    @Find(by = By.XPath, locator = "//o2uk-basket-card")
    public PageElementCollection allPackages;

    @Find(by = By.XPath, locator = "///*[contains(text(),'You have an order in progress')]\"")
    public PageElement orderInProgressPopup;

    @Find(by = By.XPath, locator = "//button[contains(text(),'Empty basket and cancel order')]")
    public PageElement emptyBasketAndcancelLink;

    @Find(by = By.XPath, locator = "//*[text()=' Empty basket ']")
    public PageElement emptyBasketLink;

    @Find(by = By.XPath, locator =  "//button[@aria-label='Empty basket']")
    public PageElement emptyBasketButton;

    @Find(by = By.XPath, locator = "//button[@aria-label='Cancel the order']")
    public PageElement cancelOrderBtn;

    @Find(by = By.XPath, locator = "//button[contains(@aria-label,'cancel my order')]")
    public PageElement cancelMyOrderBtn;

    @Find(by = By.XPath, locator = "//button[@aria-label='close dialog']//span[contains(text(),'Empty basket')] ")
    public PageElement closeDialogEmptyBasketBtn;

    @Find(by = By.XPath, locator = "//button[contains(@aria-label,'basket')]")
    public PageElement basketBtn;

    @Find(by = By.XPath, locator = "//b[contains(@class,'device-info__brand-name')]")
    public PageElement selectedPhone;

    @Find(by = By.XPath, locator = "//o2uk-buttons//basket-state/button/span")
    public PageElement basketCountButton;

    public int getBasketCount(){
        int basketItemsCount=0;
        browser.setImplicitWait(20);
        this.logger.info("getting count of Basket Items...");

        basketBtn.waitUntil(displayed);
        if(basketCountButton.isDisplayed()) {
            basketItemsCount=Integer.valueOf(basketCountButton.getText());
        }
        this.logger.info("basketItemsCount:- "+basketItemsCount);
        return basketItemsCount;
    }

    public List<Basket> getItemAddedInBasket() {
        String upfrontCost=null,monthlyCost=null;
        if ((allPackages.asList().isEmpty()) || (allPackages.asList().size() == 0)){
            this.logger.warn("No Item found on the Your Basket page! Is this a negative scenario?");
            return null;
        }

        this.logger.info(MessageFormat.format("Found {0} Items on the Your Basket page. Continue ...",
                (long) allPackages.asList().size()));
        List<Basket> addAllItems = new ArrayList<>();

        for (PageElement item : allPackages.asList()) {
            Map<String, String> card = new HashMap<>();

          //  if (item.findChild(By.CssSelector, ".accordion-button o2uk-svg-resolver").isDisplayed()) {
           //     item.findChild(By.CssSelector, ".accordion-button o2uk-svg-resolver").click();
            //}

                String simPlan = item.findChild(By.CssSelector, "[class*='tariff-info']>p[class='tariff-info__duration-text']").getText();
            String tariffName = item.findChild(By.CssSelector, "[class='tariff-info__data']").getText();
//            String tariffPrice = item.findChild(By.CssSelector, "o2uk-tariff-info o2uk-price-new> div>span.sr-only").getText();
                String tariffPrice = item.findChild(By.XPath, "//o2uk-basket-cards-wrapper//div[1]//o2uk-basket-card//div[2]/o2uk-price-item[1]//o2uk-price-new/div/span").getText();


            PageElementCollection items = item.findChildren(By.CssSelector, "o2uk-card");
            int size = items.asList().size();

            for (int i = 0; i < size - 2; i++) {
                String sectionHeader = items.asList().get(i).findChild(By.CssSelector, "o2uk-card o2uk-card-title  div[class='ng-star-inserted']").getText();
                String name = items.asList().get(i).findChild(By.CssSelector, "o2uk-basket-card-item div[class='basket-card-item__control']>b ").getText();
                card.put(sectionHeader, name);
            }
            if((size-1)>0) {
                PageElementCollection payment = items.asList().get(size - 1).findChildren(By.CssSelector, ("o2uk-total-price div[class='price-item__price']"));
                int paymentSize = payment.asList().size();
                if (payment.size() > 2) {
                    upfrontCost = payment.asList().get(paymentSize - 2).getText();
                    monthlyCost = payment.asList().get(paymentSize - 1).getText();
                }
            }
            Basket basket = new Basket(simPlan, tariffName, tariffPrice, card, upfrontCost, monthlyCost);
            addAllItems.add(basket);
        }
        return addAllItems;
    }

    @Override
    public boolean isPageDisplayed() {
        return pageTitle.getText().equals("Your basket");
    }
}
