package com.o2.models.ecomm;

import com.google.inject.Inject;
import com.nttdata.cinnamon.cache.Context;
import com.nttdata.cinnamon.file.json.JsonParser;
import com.nttdata.cinnamon.file.reader.Reader;
import com.nttdata.cinnamon.logging.Logger;

import java.text.MessageFormat;
import java.util.List;
import java.util.Objects;

import static org.assertj.core.api.Assertions.assertThat;

public class PhoneBrandValues {
    private final Logger logger;
    private final List<PhoneBrandVal> phoneBrands;
    private final Context context;

    @Inject
    public PhoneBrandValues(final Logger logger,
                            final Reader reader,
                            final JsonParser jsonParser, Context context) {
        this.logger = logger;
        this.context = context;
        // TODO Move this logic in to common function
        String env = System.getProperty("env");
        this.context.set("env", env);
        this.logger.info("env-----------"+env);
        String dataLoginFilePath = System.getProperty("user.dir") + "\\src\\test\\resources\\data\\ecomm\\" + env + "\\PhoneBrandNValues.json";
        String data = reader.readFileAsString(dataLoginFilePath, false);
        this.phoneBrands = jsonParser.toObjList(data, PhoneBrandVal.class);
    }

    public PhoneBrandVal getPhoneBrandNValueDetails(PhoneBrand phoneBrand) {
        PhoneBrandVal phoneBrandVal = this.phoneBrands.stream()
                .filter(u -> u.phoneBrand.equals(phoneBrand))
                .findFirst()
                .orElse(null);
        assertThat(phoneBrandVal).withFailMessage(
                        MessageFormat.format(
                                "Could not find a Login eComm User data with Plan Type: ''{0}''", phoneBrand))
                .isNotNull();

        this.logger.info(MessageFormat.format("eComm Login details for plan type: {0}:\n{1}",
                phoneBrand.toString(), Objects.requireNonNull(phoneBrandVal).toString()));

        return phoneBrandVal;
    }
}

