package com.o2.pages.ecare;
import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.nttdata.cinnamon.driver.controls.PageElementCollection;
import com.o2.models.ecare.Extra;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;
public class YourExtraPage extends EcareBasePage{
    @Find(by = By.XPath, locator = "//h1[text()=' Your Extras ']")
    public PageElement yourExtrasPageTitle;

    @Find(by = By.CssSelector, locator = ".o2uk-dialog-title__heading")
    public PageElement cancelThisExtraPopup;

    @Find(by = By.CssSelector, locator = ".o2uk-dialog-title__content")
    public PageElement redeemYourExtraPopup;

    @Find(by = By.CssSelector, locator = ".add-on")
    public PageElementCollection extraAddOnList;

    @Override
    public boolean isPageDisplayed() {
        if (!yourExtrasPageTitle.isDisplayed())
            return false;

        return yourExtrasPageTitle.getText().trim().equalsIgnoreCase("Your Extras");
    }

    public boolean isCancelPopupDisplayed() {
        if (!cancelThisExtraPopup.isDisplayed())
            return false;

        return cancelThisExtraPopup.getText().trim().equalsIgnoreCase("Cancel this Extra");
    }

    public List<Extra> getAllExtra() {
        if (extraAddOnList == null) {
            this.logger.warn("No Extra found on the Add Extra page! Is this a negative scenario?");
            return null;
        }

        List<Extra> allExtraAddOn = new ArrayList<>();
        this.logger.info(MessageFormat.format("Found {0} Extra   on the page. Continue ...",
                (long) extraAddOnList.asList().size()));

        /*
         * We know the extra are already displayed on the page at this step, therefore
         * we'll wait for just 3 seconds to get all needed children If something will be
         * null then it is for sure because the locators have changed
         */
        this.browser.setImplicitWait(3);
        for (PageElement extra : extraAddOnList.asList()) {

            Extra addextra = new Extra(extra.findChild(By.CssSelector, ".add-on__info-title"),
                    extra.findChild(By.CssSelector, ".o2uk-price__amount"),
                    extra.findChild(By.CssSelector, ".o2uk-price__free"),
                    extra.findChild(By.CssSelector, ".mat-button-wrapper"));
            allExtraAddOn.add(addextra);
        }
        this.browser.restoreImplicitWait();

        return allExtraAddOn;
    }

    public List<Extra> getAllReadyToRedeemExtra() {
        if (extraAddOnList == null) {
            this.logger.warn("No Extra found on the Ready to Redeem page! Is this a negative scenario?");
            return null;
        }

        List<Extra> allAddedExtra = new ArrayList<>();
        this.logger.info(MessageFormat.format("Found {0} Extra on the ready to redeem page. Continue ...",
                (long) extraAddOnList.asList().size()));

        /*
         * We know the extra are already displayed on the page at this step, therefore
         * we'll wait for just 3 seconds to get all needed children If something will be
         * null then it is for sure because the locators have changed
         */
        this.browser.setImplicitWait(3);
        for (PageElement extra : extraAddOnList.asList()) {

            Extra addedExtra = new Extra(extra.findChild(By.CssSelector, ".add-on__info-title"),
                    extra.findChild(By.CssSelector, ".o2uk-price__amount"),
                    extra.findChild(By.CssSelector, ".o2uk-price__free").getText(),
                    extra.findChild(By.CssSelector, ".mat-button-wrapper"),
                    extra.findChild(By.XPath, "//button[@role='button' and text()=' Cancel ']"));
            allAddedExtra.add(addedExtra);
        }
        this.browser.restoreImplicitWait();

        return allAddedExtra;
    }
}
