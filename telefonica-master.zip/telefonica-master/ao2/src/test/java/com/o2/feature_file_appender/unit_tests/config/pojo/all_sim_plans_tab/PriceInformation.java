package com.o2.feature_file_appender.unit_tests.config.pojo.all_sim_plans_tab;

public class PriceInformation {

    private double price;

    public PriceInformation(double price) {
        this.price = price;
    }

    public PriceInformation() {}

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }
}
