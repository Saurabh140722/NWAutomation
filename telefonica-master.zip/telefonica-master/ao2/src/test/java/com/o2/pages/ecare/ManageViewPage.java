package com.o2.pages.ecare;

import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.nttdata.cinnamon.driver.controls.PageElementCollection;

public class ManageViewPage extends EcareBasePage{
    @Find(by = By.XPath, locator = "//span[contains(text(),' Manage and view ')]")
    public PageElement manageViewBtn;

    @Find(by = By.CssSelector, locator = ".add-on__wrapper")
    public PageElementCollection allActivePlanInAllExtrasTab;


}
