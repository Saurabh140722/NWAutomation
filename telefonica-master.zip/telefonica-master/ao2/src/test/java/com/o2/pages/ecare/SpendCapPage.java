package com.o2.pages.ecare;

import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;

public class SpendCapPage extends EcareBasePage {

	@Find(by = By.XPath, locator = "//h1[text()=' Spend Cap ']")
	public PageElement spandCapPageTitle;

	@Override
	public boolean isPageDisplayed() {
		if (!spandCapPageTitle.isDisplayed())
			return false;
		return spandCapPageTitle.getText().trim().equalsIgnoreCase("Spend Cap");//Spend caps

	}

}
