package com.o2.models.ecomm;

import com.nttdata.cinnamon.driver.controls.PageElement;
import com.nttdata.cinnamon.driver.controls.PageElementCollection;

public class TariffPlan {
    public PageElementCollection tariffPlanTitle;
    public PageElement mobileBroadBand;
    public PageElement boltOns;


    public TariffPlan(PageElementCollection tariffPlanTitle) {
        this.tariffPlanTitle = tariffPlanTitle;
    }

    @Override
    public boolean equals(Object classobject) {
        if (classobject == this)
            return true;
        if (!(classobject instanceof TariffPlan))
            return false;

        TariffPlan plan = (TariffPlan) classobject;
        return plan.tariffPlanTitle.equals(this.tariffPlanTitle);

    }
}
