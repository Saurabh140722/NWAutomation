package com.o2.pages.ecomm;

import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.nttdata.cinnamon.driver.controls.PageElementCollection;
import com.o2.models.ecomm.AccesoriesBasket;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

public class AccesoriesBaksetPage extends EcommBasePage {
    @Find(by = By.XPath, locator = "//h1[@class='h1-text']")
    public PageElement pageTitle;

    @Find(by = By.CssSelector, locator = ".portlet-content-container")
    public PageElementCollection accessoriesBasketComponent;

    @Find(by = By.XPath, locator = "//span[contains(text(),' Checkout ')]")
    public PageElement checkoutBtn;


    @Find(by = By.XPath, locator = "//*[@id='o2uk-basket-component']/customers-basket//h1[contains(text(),' items in your basket')]")
    public PageElement basketPageHeader;


    public List<AccesoriesBasket> getItemAddedInBasket() {
        if (accessoriesBasketComponent == null) {
            logger.warn("No Item found on the Your Basket page! Is this a negative scenario?");
            return null;
        }

        List<AccesoriesBasket> allAccessoriesBasketList = new ArrayList<>();
        logger.info(MessageFormat.
                format("Found {0} Accessories   on the page. Continue ...",
                        (long) accessoriesBasketComponent.asList().size()));
        browser.setImplicitWait(3);
        AccesoriesBasket accesoriesBasketList = new AccesoriesBasket(
                accessoriesBasketComponent.asList().get(4).findChild(By.CssSelector, ".device-info__brand-name"),
                accessoriesBasketComponent.asList().get(4).findChild(By.CssSelector, ".device-info__brand-info"), accessoriesBasketComponent.asList().get(4).findChildren(By.CssSelector, ".o2uk-price__amount"));
        allAccessoriesBasketList.add(accesoriesBasketList);

        browser.restoreImplicitWait();

        return allAccessoriesBasketList;

    }

    @Override
    public boolean isPageDisplayed() {
        return pageTitle.getText().equals("Your basket");
    }
}
