package com.o2.stepdefs.csrd;

import com.google.inject.Inject;
import com.nttdata.cinnamon.cache.Context;
import com.nttdata.cinnamon.driver.Browser;
import com.nttdata.cinnamon.logging.Logger;
import com.o2.core.util.Retry;
import com.o2.models.csrd.LoginCsrUser;
import com.o2.pages.csrd.login.NttLoginPage;
import com.o2.util.Common;
import io.cucumber.java.en.When;

import static com.nttdata.cinnamon.wait.ElementConditions.displayed;
import static org.assertj.core.api.Assertions.assertThat;

public class CsrLoginSteps {
    private final Logger logger;
    private final Retry retry;
    private final Browser browser;
    private final NttLoginPage nttLoginPage;
    private final Context context;
    private final Common common;

    @Inject
    public CsrLoginSteps(final Logger logger,
                         final Retry retry,
                         final Browser browser,
                         final NttLoginPage nttLoginPage,
                         final Context context, final Common common) {
        this.logger = logger;
        this.retry = retry;
        this.browser = browser;
        this.nttLoginPage = nttLoginPage;
        this.context = context;
        this.common = common;
    }

    @When("^I log into CSR$")
    public void i_log_into_csr() {
        this.logger.info("*** Log into CSR application ...");

        LoginCsrUser loginCsrUser = (LoginCsrUser) this.context.get("loginUser");

        assertThat(loginCsrUser)
                .withFailMessage("Could not found any user login data stored in Context!")
                .isNotNull();
        try {
            Thread.sleep(10000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

//        assertThat(this.nttLoginPage.isPageDisplayed())
//                .withFailMessage("Login page not displayed!")
//                .isTrue();


        String usr = loginCsrUser.username;
        if(this.nttLoginPage.loginUserName.isDisplayed())
        {
            this.nttLoginPage.loginUserName.waitUntil(displayed).setValue(usr);
            this.nttLoginPage.loginPassword.setValue(loginCsrUser.password);
            this.nttLoginPage.loginBtn.click();
        }
        this.nttLoginPage.lanId.waitUntil(displayed).setValue(usr);
        this.nttLoginPage.loginNextButton.click();
        this.nttLoginPage.password.setValue(loginCsrUser.password);
        this.nttLoginPage.loginButton.click();
        if (this.nttLoginPage.searchIcon.isDisplayed()) {
            this.nttLoginPage.searchIcon.click();
            String env = (String) this.context.get("env");
            this.nttLoginPage.searchTextBox.setValue("TOMS-" + env);
            this.common.wait(6);
            this.nttLoginPage.environmentDashboard.asList().get(0).click();
            this.browser.switchToTab(1);
        }

        this.logger.info("*** Log in credentials sent!\n");
    }

    @When("I log into CSR as {string}")
    public void i_log_into_csr_as_NTUser(String nt_Or_o2User) {
        this.logger.info("*** Log into CSR application ...");

        LoginCsrUser loginCsrUser = (LoginCsrUser) this.context.get("loginUser");

        assertThat(loginCsrUser)
                .withFailMessage("Could not found any user login data stored in Context!")
                .isNotNull();
        try {
            Thread.sleep(10000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }


        switch(nt_Or_o2User){
            case "NTUSer" : {
            this.nttLoginPage.NTUserLogin.clickJs();
            this.nttLoginPage.lanId.waitUntil(displayed);
            this.nttLoginPage.lanId.waitUntil(displayed).setValue(loginCsrUser.username);
            this.nttLoginPage.loginNextButton.click();
            this.nttLoginPage.password.setValue(loginCsrUser.password);
            this.nttLoginPage.NTUserLoginSubmitButton.clickJs();
            break;
        }
            case "O2USER" : {
                this.nttLoginPage.lanId.waitUntil(displayed).setValue(loginCsrUser.username);
                this.nttLoginPage.loginNextButton.click();
                this.nttLoginPage.password.setValue(loginCsrUser.password);
                this.nttLoginPage.loginButton.click();
                break;
            }
        }
        this.logger.info("*** Log in credentials sent!\n");
    }
}
