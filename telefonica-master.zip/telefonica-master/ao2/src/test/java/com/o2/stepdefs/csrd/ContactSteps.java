package com.o2.stepdefs.csrd;

import com.google.inject.Inject;
import com.nttdata.cinnamon.cache.Context;
import com.nttdata.cinnamon.driver.Browser;
import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.nttdata.cinnamon.driver.controls.PageElementCollection;
import com.o2.core.data.UserDataModel;
import com.o2.pages.csrd.navigation.ContactPage;
import com.o2.stepdefs.BaseStep;
import com.o2.util.Common;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import org.assertj.core.api.SoftAssertions;

import java.text.DateFormat;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;

import static com.nttdata.cinnamon.wait.ElementConditions.displayed;
import static org.assertj.core.api.Assertions.assertThat;

public class ContactSteps extends BaseStep {
    private final Browser browser;
    private final Context context;
    private final ContactPage contactPage;
    private final Common common;

    @Inject
    public ContactSteps(final Browser browser, final Common common,
                        final Context context, final ContactPage contactPage) {
        this.browser = browser;
        this.common = common;
        this.context = context;
        this.contactPage = contactPage;
    }

    @And("^I create Add Contact$")
    public void i_create_add_contact() {
        this.logger.info("*** Click on Add Contact Link ...");
        this.contactPage.addContactLink.click();

        this.logger.info("*** Landing to add account dialog box ...");
        assertThat(this.contactPage.dialogWindowTitle.waitUntil(displayed).isDisplayed())
                .withFailMessage("Add Contact form page not loaded!")
                .isTrue();

        UserDataModel userData = (UserDataModel) this.context.get("residentialUserAccountData");
        assertThat(this.contactPage.dialogWindowTitle.getText())
                .isEqualTo("Add Contact");

        String newEmaillId = userData.userEmail;
        String uuid = UUID.randomUUID().toString().replaceAll("-", "");
        String modifiedEmail = uuid.concat(newEmaillId);
        this.logger.info("*** New Email..." + modifiedEmail);
        this.contactPage.emailAuthentication.setValue(modifiedEmail);
        this.contactPage.contactPlusIcon.click();
        assertThat(this.contactPage.dialogWindowTitle.waitUntil(displayed).isDisplayed())
                .withFailMessage("New Contact form page not loaded!")
                .isTrue();

        this.contactPage.title.asSelect().selectByText(userData.title);
        this.contactPage.firstName.setValue(userData.firstName);
        this.contactPage.lastName.setValue(userData.lastName);
        this.contactPage.dob.setValue("11/10/1990");
        this.contactPage.mobileNumberRadioBtn.click();
        this.contactPage.mobileNumber.waitUntil(displayed).setValue(userData.contactMobile.replace(" ", ""));
        PageElement contactRole = this.contactPage.contactRole.asList().get(1);
        contactRole.click();
        PageElement powerOfAttorney = this.contactPage.contactRoleOptions.asList().get(1);
        powerOfAttorney.click();
        this.contactPage.addAddressButton.click();
        this.contactPage.postCode.setValue(userData.postcode);
        this.contactPage.streetNo.waitUntil(displayed).setValue("537"); // TODO: can add street no to UserData
        this.contactPage.addressLookupButton.click();
        this.contactPage.addresses.waitUntil(displayed);
        this.browser.setImplicitWait(5);
        this.contactPage.addresses.asSelect().selectByIndex(1);
        userData.address = this.contactPage.addresses.asSelect().getSelectedValue();
        this.contactPage.addresses.asSelect().selectByIndex(1);
        userData.address = this.contactPage.addresses.asSelect().getSelectedValue();
        this.contactPage.confirmAddress.click();
        this.common.waitForLoadingToComplete(60, 2, true);
        this.common.wait(2);

        int cnt = 2;
        this.logger.info("Attempt to save the form ...");

        // TODO: @Rahul: this loop is wrong - continue does nothing; why do we set implicit to 1 at the end?; please review
        while (--cnt > 0) {
            this.logger.info(MessageFormat.format("Retry #{0} ...", cnt));

            this.logger.info("Click Create button ...");
            this.contactPage.createButton.waitUntil(displayed).click();
            this.common.waitForLoadingToComplete(60, 2, true);
            this.browser.setImplicitWait(1);
            this.common.wait(2);
            continue;
        }

        this.logger.info("Click Save button ...");
        PageElement saveButton = this.contactPage.saveButton.asList().get(1);
        saveButton.waitUntil(displayed).click();
        this.common.waitForLoadingToComplete(60, 2, true);
    }

    @And("^third party contact role should displayed as (.*) under Customer Contacts and Roles$")
    public void i_can_see_thirdparty_contactrole_on_customercontact_and_roles_page(String role) {
        this.logger.info("*** Customer Contacts and Roles is displayed ...");

        assertThat(this.contactPage.customerContactRolesPage.waitUntil(displayed).isDisplayed())
                .withFailMessage("Customer Contacts and Roles is displayed!")
                .isTrue();
        assertThat(this.contactPage.contactRoleValue.getText())
                .isEqualToIgnoringCase(role);
    }

    @Then("^ticket is created successfully$")
    public void i_can_see_ticket_is_created_on_Access_for_you() {
        this.logger.info("*** Access for you ticket is displayed ...");

        SoftAssertions softly = new SoftAssertions();
        this.contactPage.anchorLinkOnAccessForYouTicket.hover();
        this.contactPage.anchorLinkOnAccessForYouTicket.waitUntil(displayed).scrollIntoView().click();
        this.contactPage.listofRowIteam.asList().get(3).click();
        UserDataModel userData = (UserDataModel) this.context.get("residentialUserAccountData");

        // TODO: @Rahul: this loop is not right as it will fail on 1st iteration. please review whole test from where this step belongs to
        for (PageElement ticketNoStatus : this.contactPage.accessForYouTicketTableList.asList()) {
            this.browser.restoreImplicitWait();
            PageElementCollection tableHeaderDetail = ticketNoStatus.findChildren(By.Tag, "td");
            PageElement ticketNo = tableHeaderDetail.asList().get(1);
            PageElement status = tableHeaderDetail.asList().get(5);
            PageElement date = tableHeaderDetail.asList().get(6);
            if (status.getText().contains("Created")) {
                assertThat(status.waitUntil(displayed).isDisplayed())
                        .withFailMessage("Ticket Number is not displayed")
                        .isTrue();
                this.context.set("accessForYouTicketNo", ticketNo.getText());
                this.context.set("createdDate", date.getText());
                break;
            }
        }

        PageElement customerName = this.contactPage.accessForYouTicketRow.asList().get(1);
        softly.assertThat(customerName.getText()).as("Customer name").isEqualToIgnoringCase(MessageFormat.format("{0} {1} {2}",
                userData.title, userData.firstName, userData.lastName));
        for (PageElement status : this.contactPage.accessForYouTicketStatusOlaRow.asList()) {
            if (status.getText().equals("Created")) {
                this.context.set("status", status.getText());
                softly.assertThat(status.getText()).as("Created Status").isEqualToIgnoringCase(MessageFormat.format("{0}", "Created"));
                break;
            }
        }

        Date date = new Date();
        DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
        String formatedDate = formatter.format(date);
        for (PageElement expectedDate : this.contactPage.accessForYouTicketDate.asList())
            if (expectedDate.getText().contains(formatedDate)) {
                this.context.set("createdDate", expectedDate.getText());
                softly.assertThat(expectedDate.getText()).as("Created Date").contains(MessageFormat.format("{0}", formatedDate));
                break;
            }
        PageElement olaLevel = this.contactPage.accessForYouTicketStatusOlaRow.asList().get(1);
        this.context.set("olaLevel", olaLevel.getText());
        softly.assertThat(olaLevel.getText()).as("OLA level").isEqualToIgnoringCase(MessageFormat.format("{0}", "In-OLA"));
        softly.assertAll();

    }

    @Then("^I close the access for you ticket$")
    public void i_am_able_to_close_accessFor_You_ticket() {
        this.logger.info("*** Attempting to close the access for ticket ...");

        this.contactPage.leftNavigationMenu.click();
        this.contactPage.listOfNetCrackerModules.click();
        this.contactPage.customerImpactAnalysis.hover();
        this.contactPage.troubleTicketsRepository.hover();
        this.contactPage.troubleTicketsRepository.click();
        this.browser.switchToTab(1);
        this.contactPage.accessForYouLink.click();
        this.common.waitForLoadingToComplete(60, 2, true);
        String accessForYouTicketNo = (String) this.context.get("accessForYouTicketNo");
        String status = (String) this.context.get("status");
        String olaLevel = (String) this.context.get("olaLevel");

        // TODO: @Rahul: we need to get some of this logic away from here
        for (PageElement accessForYouRow : this.contactPage.accessForYouTicketTableList.asList()) {
            PageElementCollection tableHeaderDetail = accessForYouRow.findChildren(By.Tag, "td");
            String ticketName = tableHeaderDetail.asList().get(0).getText();
            String ticketStatus = tableHeaderDetail.asList().get(1).getText();
            String ticketOlaLevel = tableHeaderDetail.asList().get(3).getText();
            if ((ticketName.contains(accessForYouTicketNo)) && (ticketStatus.contains(status)) && (ticketOlaLevel.contains(olaLevel))) {
                tableHeaderDetail.asList().get(0).click();
                break;
            }
        }

        this.common.waitForLoadingToComplete(60, 2, true);
        this.contactPage.cancelLink.click();
        this.common.waitForLoadingToComplete(60, 2, true);
        this.contactPage.cancellationReasonTxtBox.click();
        this.contactPage.cancellationReasonOptions.asList().get(0).click();
        this.contactPage.commentDesciption.setValue("Inavalid Ticket");
        this.contactPage.okBtn.click();
        this.common.waitForLoadingToComplete(60, 2, true);
        this.browser.switchToDefault();

        // TODO: @Rahul: where is the assertion that the access has been closed?
    }

    @And("^I can successfully delete the  new contact$")
    public void i_am_able_to_delete_newContact() {
        this.contactPage.deleteIcon.click();
        this.contactPage.deleteConatct.click();

        // TODO: @Rahul: how do you know the contact has been deleted?
    }
}