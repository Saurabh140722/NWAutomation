package com.o2.stepdefs.ecare;
import com.google.inject.Inject;
import com.nttdata.cinnamon.cache.Context;
import com.o2.models.ecare.EcareUser;
import com.o2.pages.ecare.ControlCentrePage;
import com.o2.stepdefs.BaseStep;
import io.cucumber.java.en.Then;

import static org.assertj.core.api.Assertions.assertThat;

public class ControlCentreSteps extends BaseStep {
    private final ControlCentrePage controlcentrePage;
    private final Context context;

    @Inject
    public ControlCentreSteps(final ControlCentrePage controlcentrePage, final Context context) {
        this.controlcentrePage = controlcentrePage;
        this.context = context;
    }

    @Then("Control central page opens successfully")
    public void control_central_page_opens_successfully() {
        this.logger.info("** Attempt to check Control Central page has been reached ...");

        assertThat(this.controlcentrePage.isPageDisplayed()).withFailMessage("Control Central page has not opened!")
                .isTrue();

        this.logger.info("** Control Central page displayed!\n");
    }

    @Then("^'(.*)' is displayed under Contact details section$")
    public void Contact_Field_is_displayed_under_contact_details_section(String contactFieldName) {
        this.logger.info("*** Check if Contact Details section has been loaded in the Control Central page...");
        assertThat(this.controlcentrePage.contactDetailsHeader.isDisplayed())
                .withFailMessage("Contact Details section has not loaded in the Control Central page..!").isTrue();

        this.logger.info(
                "** Attempt to check Email address under Contact Details section in the Control Central page....");
        EcareUser ecareUser = (EcareUser) this.context.get("ecareLoginData");

        assertThat(this.controlcentrePage.getContactValue(contactFieldName).equals(ecareUser.username.toString()))
                .withFailMessage(
                        "Email address is not present under Contact Details section in the Control Central page.!")
                .isTrue();

        this.logger.info("** Email address displayed under Contact Details section in the Control Central page.!\n");
    }
}
