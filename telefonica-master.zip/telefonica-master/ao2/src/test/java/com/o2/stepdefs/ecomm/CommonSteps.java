package com.o2.stepdefs.ecomm;

import com.google.inject.Inject;
import com.nttdata.cinnamon.cache.Context;
import com.nttdata.cinnamon.logging.Logger;
import com.o2.core.util.Common;

import com.o2.models.ecomm.EcommUser;
import com.o2.models.ecomm.EcommUserData;

import io.cucumber.java.en.Given;
import org.apache.commons.lang.NotImplementedException;

import java.text.MessageFormat;

public class CommonSteps extends BaseStep {

    private final Logger logger;
    private final EcommUserData ecommUserData;
    private final Context context;
    private final Common common;

    @Inject
    public CommonSteps(final EcommUserData ecommUserData, final Context context, final Logger logger, Common common) {
        this.ecommUserData = ecommUserData;
        this.context = context;
        this.logger = logger;
        this.common = common;
    }

    @Given("^I have login details for an eComm '(new|existing)' user$")
    public void i_have_eComm_login_details(String userType) {
        logger.info("** Attempt to retrieve eComm login test data ...");
        EcommUser ecommUser;
        context.set("userType", userType);
        switch (userType) {
            case "existing":
                ecommUser = this.ecommUserData.getEcommLoginDetails("Exist");
                context.set("eCommUserData", ecommUser);
                logger.info("** eComm Login test data retrieved!\n");
                break;

            case "new":
                String currentDate = this.common.getCurrentDateTime("yyyyMMddHHmmss");
                String env = System.getProperty("env");
                String email = env + "ecommsanity-" + currentDate + "@yopmail.com";
                ecommUser = this.ecommUserData.getEcommLoginDetails("NEW");
                ecommUser.email = email;
                ecommUser.username = email;
                context.set("eCommUserData", ecommUser);
                logger.info("**New Registered Email:" + ecommUser.email);
                logger.info("** eComm New user test data retrieved!\n");
                break;

            default:
                throw new NotImplementedException(MessageFormat
                        .format("Option ''{0}'' for eComm login details has not been implemented yet!", userType));
        }

    }
}
