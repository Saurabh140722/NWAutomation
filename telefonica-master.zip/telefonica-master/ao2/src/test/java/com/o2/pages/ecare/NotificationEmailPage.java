package com.o2.pages.ecare;

import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.nttdata.cinnamon.driver.controls.PageElementCollection;

public class NotificationEmailPage extends EcareBasePage {
    @Find(by = By.XPath, locator = "//h1[@class='o2uk-header-curve__text-title']")
    public PageElement pageTitle;
    @Find(by = By.XPath, locator = "//div[@class='o2uk-manage-my-details-card__value']")
    public PageElementCollection notificationEmailValue;

    @Find(by = By.CssSelector, locator = ".text-link")
    public PageElementCollection editEmailLink;

    @Find(by = By.XPath, locator = "//div[@class='o2uk-form-field-infix ng-tns-c153-1']//input")
    public PageElement emailNotificationTxtBox;

    @Find(by = By.XPath, locator = "//span[contains(text(),' Save and close ')]")
    public PageElement saveAndCloseBtn;

    @Find(by = By.XPath, locator = "//div[@class='o2uk-dialog-title__content']/h3")
    public PageElement emailNotificationTitle;

    @Find(by = By.CssSelector, locator = ".o2uk-notification-message")
    public PageElement emailWarningMessage;

    @Find(by = By.CssSelector, locator = ".o2uk-notification-message__body-template>p")
    public PageElement emailWarningMessageTxt;

    @Find(by = By.CssSelector, locator = ".o2uk-manage-my-details__different-email-notification")
    public PageElement warningMessageForDifferentEmailUsed;

    @Find(by = By.CssSelector, locator = ".o2uk-notification-message__body-template>p")
    public PageElement warningMessageForDifferentEmailUsedTxt;






    @Override
    public boolean isPageDisplayed() {
        if (!pageTitle.isDisplayed())
            return false;

        return pageTitle.getText().trim().equalsIgnoreCase("Manage your details");
    }

    public PageElement getEditEmailLink() {
        if (this.editEmailLink.size() != 5)
            return null;

        return this.editEmailLink.asList().get(4);
    }

}
