package com.o2.pages.csrd;

import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.nttdata.cinnamon.driver.controls.PageElementCollection;
import com.o2.pages.BasePage;

public class TodoItemPopupPage extends BasePage {
    @Find(by = By.Id, locator = "ui-id-2")
    public PageElement title;

    @Find(by = By.CssSelector, locator = "#-\\31")
    public PageElement subject;

    @Find(by = By.Id, locator = "9134256020013155874")
    public PageElement type;

    @Find(by = By.Id, locator = "9134256020013155863")
    public PageElement status;

    @Find(by = By.Id, locator = "9134256020013155835")
    public PageElement priority;

    @Find(by = By.CssSelector, locator = ".refsel_arrow")
    public PageElementCollection arrowLink;

    @Find(by = By.CssSelector, locator = "#nc_refsel_list_table .refsel_name")
    public PageElementCollection assignedToGroupOption;


    @Find(by = By.CssSelector, locator = ".gwt-Button.button_action_id_9136113942513665033_9136113942513665037_compositepopup_1.TableCtrl-button.ParCtrl-editButton")
    public PageElement createButton;

    @Override
    public boolean isPageDisplayed() {
        return title.isDisplayed() && title.getText().equals("New To-Do Item");
    }

}
