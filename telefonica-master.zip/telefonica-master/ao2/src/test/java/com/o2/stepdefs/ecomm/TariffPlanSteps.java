package com.o2.stepdefs.ecomm;

import com.google.inject.Inject;
import com.nttdata.cinnamon.driver.Browser;
import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.controls.PageElementCollection;
import com.o2.core.util.Common;
import com.o2.models.ecomm.EcommUser;
import com.o2.models.ecomm.TariffPlan;
import com.o2.pages.ecomm.EcommBasePage;
import com.o2.pages.ecomm.TariffPlanPage;
import io.cucumber.java.en.And;
import com.nttdata.cinnamon.cache.Context;
import io.cucumber.java.en.When;
import org.apache.commons.lang.NotImplementedException;
import org.assertj.core.api.Assertions;

import static com.nttdata.cinnamon.wait.ElementConditions.displayed;
import static org.assertj.core.api.Assertions.assertThat;

import java.text.MessageFormat;
import java.util.List;

public class TariffPlanSteps extends BaseStep {

    private final TariffPlanPage tariffPlan;
    private final EcommBasePage ecommBasePage;
    private final Browser browser;
    private final Common common;
    private final Context context;

    @Inject
    public TariffPlanSteps(final TariffPlanPage tariffPlan, EcommBasePage ecommBasePage, final Browser browser, final Common common, Context context) {
        this.tariffPlan = tariffPlan;
        this.ecommBasePage = ecommBasePage;

        this.browser = browser;
        this.common = common;
        this.context = context;
    }

    @And("^I add tariff '(.*)' plan to basket$")
    public void i_select_tariff_plan_to_basket(String tariffPlan) {
        this.logger.info("*Traiff Plan page is opened ...");
        Assertions.assertThat(this.tariffPlan.isPageDisplayed()).withFailMessage("02 TariffPage is not displayed!")
                .isTrue();
        this.tariffPlan.manageCookiesbtn.click();
        this.browser.setImplicitWait(3);
        this.tariffPlan.acceptAllCookiesbtn.click();
        assertThat(this.tariffPlan.getAllPlans().size() > 0).withFailMessage("Tariff Plan are not displayed!").isTrue();
        List<TariffPlan> tariffPlansList = this.tariffPlan.getAllPlans();
        for (TariffPlan planList : tariffPlansList) {
            if (planList.tariffPlanTitle.asList().get(0).getText().equalsIgnoreCase(tariffPlan)) {
                planList.tariffPlanTitle.asList().get(0).click();
                break;

            }
        }

        this.logger.info("*Tariff Plan page is ended ...");

    }

    @And("^I select '(.*)' sim cards to basket$")
    public void i_select_sim_cards_plan_to_basket(String simCardType) {
        this.logger.info("*Sim cards page is opened ...");
        assertThat(this.tariffPlan.getAllPlans().size() > 0).withFailMessage("Sim Cards Page are not displayed!").isTrue();
        List<TariffPlan> tariffPlansList = this.tariffPlan.getAllPlans();
        for (TariffPlan planList : tariffPlansList) {
            if (planList.tariffPlanTitle.asList().get(0).getText().equalsIgnoreCase(simCardType)) {
                planList.tariffPlanTitle.asList().get(0).click();
                break;

            }
        }
        this.browser.setImplicitWait(5);
        this.tariffPlan.choosePlanBtn.asList().get(0).click();
        this.tariffPlan.deviceTypeYesNoOptionBtn.asList().get(0).clickJs();
        this.tariffPlan.deviceType5gYesNoOptionBtn.asList().get(0).clickJs();
        this.ecommBasePage.getButton("Confirm Spend Cap").clickJs();
        this.ecommBasePage.getButton("Choose later").clickJs();
        this.ecommBasePage.getButton("Go to basket").clickJs();
        this.tariffPlan.checkoutBtn.click();
        this.logger.info("*Checkout page is ended...");


    }

    @When("^I create '(new|existing)' customer account$")
    public void i_create_new_customer_account(String accountType) {
        this.logger.info("*Are you already with O2? is opened...");
        EcommUser ecommUser = (EcommUser) this.context.get("eCommUserData");
        switch (accountType) {
            case "new":
                this.tariffPlan.o2CustomerAccountBtn.asList().get(1).clickJs();
                this.tariffPlan.email.setValue(ecommUser.username);
                this.tariffPlan.titleArrow.click();
                this.browser.setImplicitWait(3);
                this.tariffPlan.titleOptionsParent.click();
                this.tariffPlan.firstName.setValue(ecommUser.firstName);
                this.tariffPlan.lastName.setValue(ecommUser.firstName);
                this.tariffPlan.contactNbr.setValue(ecommUser.mobile);
                this.tariffPlan.password.setValue(ecommUser.password.replace("@", ""));
                this.tariffPlan.securityQuestionArrow.click();
                this.tariffPlan.securityQuestionDropDown.click();
                this.tariffPlan.securityAnswer.setValue(ecommUser.firstName);
                this.tariffPlan.dob.setValue("13/03/1992");
                this.tariffPlan.customCheckBox.asList().get(0).click();
                this.tariffPlan.customCheckBox.asList().get(1).click();
                this.tariffPlan.customCheckBox.asList().get(2).click();
                this.tariffPlan.confirmBtn.asList().get(0).click();
                break;
            case "existing":
                this.tariffPlan.o2CustomerAccountBtn.asList().get(0).clickJs();
                this.tariffPlan.userName.setValue(ecommUser.username);
                this.tariffPlan.existingUserpassword.setValue(ecommUser.password);
                this.tariffPlan.signInBtn.click();
                break;
            default:
                throw new NotImplementedException(MessageFormat
                        .format("Option ''{0}'' for eComm login details has not been implemented yet!", accountType));
        }
    }

    @When("^I verify delivery address$")
    public void i_verify_delivery_address() {
        String addressSelected=null,deliveryAddressSaved=null;
        this.tariffPlan.houseNbr.setValue("B33 8TH");
        this.tariffPlan.postCode.setValue("SL1 4ED");
        this.tariffPlan.findBtn.clickJs();
        this.tariffPlan.selectAddressArrow.click();
        PageElementCollection selectAddressOptions = this.tariffPlan.selectAddress.findChildren(By.Tag, "li");
        addressSelected=selectAddressOptions.asList().get(1).getText();
        context.set("deliveryAddressSelected",addressSelected);
        this.logger.info("Delivery Address Selected:- "+addressSelected);
        selectAddressOptions.asList().get(1).click();
        this.browser.setImplicitWait(8);
        this.tariffPlan.confirmBtnDeliveryAddress.waitUntil(displayed).clickJs();
        deliveryAddressSaved=this.tariffPlan.deliveryAddressSaved.getText();
        this.logger.info("Delivery Address Saved:- "+deliveryAddressSaved);
        assertThat(addressSelected.equalsIgnoreCase(deliveryAddressSaved)).withFailMessage("Delivery address is not Saved!").isEqualTo(this.tariffPlan.collapseAddress.getText());
    }

    @When("^I verify download order confirmation on submit page$")
    public void i_verify_download_order_confirmation_option_on_submit_page() {
        EcommUser ecommUser = (EcommUser) this.context.get("eCommUserData");
        this.browser.setImplicitWait(5);
        this.tariffPlan.confirmBtnOnDelivery.asList().get(0).clickJs();
        this.tariffPlan.pacCodeBtn.click();
        this.tariffPlan.currentMobileNbr.setValue(ecommUser.mobile);
        this.tariffPlan.pacCodeTxtBox.setValue("");
        this.tariffPlan.confirmBtn.asList().get(2).click();
        this.tariffPlan.goToPaymentBtn.click();

    }


}