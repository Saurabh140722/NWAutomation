package com.o2.pages.csrd;

import com.google.inject.Inject;
import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.o2.core.util.Common;
import com.o2.pages.BasePage;
import org.openqa.selenium.Keys;

import static com.o2.Constants.ONE_SEC;
import static com.o2.Constants.TWO_SECS;

public class OrderPage extends BasePage {
    private Common common;

    // Violates the OOP encapsulation principle but is necessary to initialise the Page Object Element as per the Framework's design
    @Find(by = By.XPath, locator = CON_ORDER_POPUP_LOCATOR_XPATH)
    public PageElement con_orderPopup;
    public static final String CON_ORDER_POPUP_LOCATOR_XPATH = "//*[@class='nc-composite-layout nc-composite-layout-horizontal']";

    @Find(by = By.CssSelector, locator = BTN_CREATEORDER_LOCATOR_CSS)
    public PageElement btn_createOrder;
    public static final String BTN_CREATEORDER_LOCATOR_CSS = "button[class*='button_action_id_9145150692013871400_9145150713613871405_compositepopup_";

    @Find(by = By.CssSelector, locator = ".refsel_table_holder.ps-container.ps-theme-defaulte")
    private PageElement ddl_distributionChannel;

    // NOTE: this id is not unique as the numeric postfix is changing everytime a new session starts e.g. id_refsel1430362223_input
    private PageElement txt_distributionChannel;

    @Inject
    public OrderPage(final Common common) {
        this.common = common;
    }

    @Override
    public PageElement getPageCheckElement() {
        return this.con_orderPopup;
    }

    public PageElement getCon_orderPopup() {
        return this.con_orderPopup;
    }

    public PageElement getBtn_createOrder() {
        return this.btn_createOrder;
    }

    public PageElement getTxt_distributionChannel() {
        return txt_distributionChannel = this.getCon_orderPopup().findChild(By.ClassName, "refsel_input");
    }

    public PageElement getDistributionChannel() {
        PageElement element = getCon_orderPopup().findChild(By.ClassName, "refsel_input");
        element.click();
        //TODO FIX OR REMOVE AS THIS CODE DOES NOT WORK
        return this.ddl_distributionChannel.findAllBy(By.CssSelector, ".refsel_name").asList().get(1);
    }

    public String getDistributionChannelByIndex(int index) {
        String ddl_value = "";
        if (index > 1) {
            throw new RuntimeException("The index must be less than two for the Distribution Channel Drop-down");
        }
        txt_distributionChannel = getTxt_distributionChannel();
        common.wait(TWO_SECS);
        txt_distributionChannel.click();
        common.wait(ONE_SEC);
        for (int i = 0; i <= index; i++) {
            txt_distributionChannel.setValue(Keys.ARROW_DOWN);
            common.wait(ONE_SEC);
            ddl_value = (i == 0) ? "Retail" : "Voice and IVR"; //TODO retrieve dynamically from DOM structure
        }
        txt_distributionChannel.setValue(Keys.ENTER);
        return ddl_value;
    }
}
