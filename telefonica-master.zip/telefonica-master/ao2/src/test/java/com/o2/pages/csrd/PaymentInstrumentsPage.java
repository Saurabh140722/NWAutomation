package com.o2.pages.csrd;

import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.FindByKey;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.o2.pages.BasePage;

public class PaymentInstrumentsPage extends BasePage {
    @Find(by = By.Id, locator = "9153493802013161822")
    public PageElement sortCode;

    @Find(by = By.Id, locator = "9153538650913155156")
    public PageElement bankAccountNumber;

    @Find(by = By.Id, locator = "9153493802013161855")
    public PageElement bankAccountHolder;

    @Find(by = By.CssSelector, locator = "button[class*='button_action_id_9153487586013160649_9147024095513824936_lightparctrl_']")
    public PageElement createButton;

    @FindByKey(key ="createButton")
    public PageElement paymentInstrumentcreateButton;

    @Find(by = By.XPath, locator = "//button[contains(text(),'Confirm')]")
    public PageElement confirmBtn;

}
