package com.o2.pages.ecare;

import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.nttdata.cinnamon.driver.controls.PageElementCollection;

public class YourDocumentPage extends EcareBasePage{

    @Find(by = By.XPath, locator = "//h1[contains(@class,'o2uk-header-curve__text-title')]")
    public PageElement pageTitle;

    @Find(by = By.XPath, locator = "//button[@aria-label='Download document']")
    public PageElementCollection downloadDocuments;
}
