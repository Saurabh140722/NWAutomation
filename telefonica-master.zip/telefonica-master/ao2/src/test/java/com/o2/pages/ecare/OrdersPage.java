package com.o2.pages.ecare;

import com.google.inject.Inject;
import com.nttdata.cinnamon.driver.Browser;
import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.nttdata.cinnamon.driver.controls.PageElementCollection;
import com.o2.models.ecare.OrderDetailsAdditionalInfo;
import com.o2.models.ecare.OrdersDetails;
import com.o2.pages.BasePage;

import java.util.ArrayList;
import java.util.List;

import static com.nttdata.cinnamon.wait.ElementConditions.displayed;

public class OrdersPage extends BasePage {

    @Inject
    private Browser browser;

    public String selectedOrderNumber=null;

    @Find(by = By.XPath, locator = "//o2uk-order-history//o2uk-header-curve//h1[text()=' Your orders ']")
    public PageElement yourOrders;

    @Find(by = By.XPath, locator = "//o2uk-order-history//o2uk-header-curve//p[text()=' Manage your orders ']")
    public PageElement manageOrders;

    @Find(by = By.XPath, locator = "//div[@class='o2uk-order-history-main__orders-wrapper']//div[@class='o2uk-order-history-main__order']")
    public PageElementCollection orderCards;

    @Find(by = By.XPath, locator = "//div[@class='o2uk-order-history-main__orders-wrapper']")
    public static PageElement orderDetailCards;

    @Find(by = By.XPath, locator = "//dl//dd")
    public PageElement orderCardsDetails;

    @Find(by = By.XPath, locator = "//o2uk-sort//o2uk-radio-group/p[text()=' Date ']")
    public PageElement ordersSortByDate;

    @Find(by = By.XPath, locator = "//o2uk-sort//o2uk-radio-group/p[text()=' Price ']")
    public PageElement ordersSortByPrice;

    @Find(by = By.XPath, locator = "//o2uk-order-history//o2uk-card//div[contains(@title,'Order')]")
    public PageElement selectedOrderInOrderDetailPage;

    @Find(by = By.XPath, locator = "//o2uk-order-history//h1[text()=' Your order ']")
    public PageElement yourOrderHeader;

    // OrderAdditionalInfo

    @Find(by = By.XPath, locator = "//o2uk-order-history//o2uk-order-history-details//o2uk-card")
    public PageElement OrderDetailAdditionalInfo;

    public List<OrdersDetails> getOrderDetails() {
        List<OrdersDetails> od = new ArrayList<>();
        if (orderCards.asList().isEmpty()) {
            this.logger.info("OrderCards not available");
        }
        this.logger.info("OrderCards size :- "+orderCards.asList().size());

        for (int i = 1; i <= orderCards.asList().size(); i++) {
            int k = i;
            OrdersDetails odt = new OrdersDetails(
                    browser.findBy(By.XPath,"//div[@class='o2uk-order-history-main__orders-wrapper']/div["+k+"]//o2uk-card/o2uk-card-title//div[contains(@title,'Order number')]"),
                    browser.findBy(By.XPath,"//div[@class='o2uk-order-history-main__orders-wrapper']/div["+k+"]//o2uk-card//dl/div[1]/div[1]/dd"),
                    browser.findBy(By.XPath,"//div[@class='o2uk-order-history-main__orders-wrapper']/div["+k+"]//o2uk-card//dl/div[1]/div[2]/dd"),
                    browser.findBy(By.XPath,"//div[@class='o2uk-order-history-main__orders-wrapper']/div["+k+"]//o2uk-card//dl/div[2]/div[1]/dd"),
                    browser.findBy(By.XPath,"//div[@class='o2uk-order-history-main__orders-wrapper']/div["+k+"]//o2uk-card//dl/div[2]/div[2]/dd"),
                    browser.findBy(By.XPath,"//div[@class='o2uk-order-history-main__orders-wrapper']/div["+k+"]//o2uk-card/dl/div[2]/div[3]/dd"),
                    browser.findBy(By.XPath,"//div[@class='o2uk-order-history-main__orders-wrapper']/div["+k+"]//o2uk-card//o2uk-price/div/div/span"),
                    browser.findBy(By.XPath,"//div[@class='o2uk-order-history-main__orders-wrapper']/div["+k+"]//div[@class='o2uk-order-history-main__order']/o2uk-card//button"));
            od.add(odt);
        }
//        this.logger.info("OrderDetails Size :- "+od.size());
//        if(od.size()>0){
//               od.stream().forEach(p -> this.logger.info(p.orderNumber.getText() + " :: " + p.orderDescription.getText() + " :: " + p.orderType.getText() + " :: " + p.totalPrice.getText() + " :: " + p.status.getText()));
//        }
        return od;
    }


    public List<OrderDetailsAdditionalInfo> getOrderDetailsAdditionalInfo(){
        List<OrderDetailsAdditionalInfo> od = new ArrayList<>();
        browser.setImplicitWait(20);
        OrderDetailAdditionalInfo.waitUntil(displayed);
        if(!OrderDetailAdditionalInfo.isDisplayed()){
            this.logger.info("OrderCards Additinal Info not available");
        }
        OrderDetailsAdditionalInfo ordderADDNLINFO = new OrderDetailsAdditionalInfo(
                this.browser.findBy(By.XPath, "//o2uk-order-history//o2uk-card//div[contains(@title,'Order')]"),
                this.browser.findBy(By.XPath, "//o2uk-order-history//o2uk-card//div[@class='o2uk-order-history-details__order-type']"),
                this.browser.findBy(By.XPath,"//o2uk-order-history//o2uk-card//div[@class='o2uk-order-history-details__main-info']/div/div[1]"),
                this.browser.findBy(By.XPath,"//o2uk-order-history//o2uk-card//div[@class='o2uk-order-history-details__main-info']/div/div[2]"),
                this.browser.findBy(By.XPath,"//o2uk-order-history//o2uk-card//div[@class='o2uk-order-history-details__main-info']/div/div[3]"),
                this.browser.findBy(By.XPath,"//o2uk-order-history//o2uk-card//div[@class='o2uk-order-history-details__main-info']/div/div[4]"),
                this.browser.findBy(By.XPath,"//o2uk-order-history//o2uk-card//div[@class='o2uk-order-history-details__items-container']//div[2]"),
                this.browser.findBy(By.XPath,"//div[@class='o2uk-order-history-details__price-container']/div[1]//o2uk-price//div[@class='o2uk-price__amount ng-star-inserted']"),
                this.browser.findBy(By.XPath,"//div[@class='o2uk-order-history-details__price-container']/div[2]//o2uk-price//div[@class='o2uk-price__amount ng-star-inserted']"),
                this.browser.findBy(By.XPath,"//div[@class='o2uk-order-history-details__price-container']/div[3]//o2uk-price//div[@class='o2uk-price__amount ng-star-inserted']"));

        od.add(ordderADDNLINFO);
//        od.stream().forEach(p-> this.logger.info(p.orderNumberMain.getText()+"::"+p.orderType.getText()+"::"+p.status.getText()+"::"+p.items.getText()));
        return od;
    }
}

