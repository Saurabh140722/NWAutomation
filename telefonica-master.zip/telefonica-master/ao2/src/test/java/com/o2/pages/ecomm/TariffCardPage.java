package com.o2.pages.ecomm;

import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.nttdata.cinnamon.driver.controls.PageElementCollection;
import com.o2.models.ecomm.TariffCard;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

public class TariffCardPage extends EcommBasePage {

    @Find(by = By.XPath, locator = "//h1[@class='o2uk-header-curve__text-title']")
    public PageElement pageTitle;

    @Find(by = By.XPath, locator = "//div[@class='tariff-card__wrapper']")
    public PageElementCollection tariffCardParent;

    @Find(by = By.XPath, locator = "//button[@role='tab']")
    public PageElementCollection tariffCardTabLabel;



    public List<TariffCard> getAllTariffCard() {
        if (tariffCardParent == null) {
            this.logger.warn("No Tarrif Card found on the page! Is this a negative scenario?");
            return null;
        }

        List<TariffCard> allTariffCard = new ArrayList<>();
        this.logger.info(MessageFormat.format("Found {0} tariff card on the page. Continue ...",
                (long) tariffCardParent.asList().size()));

        /*
         * We know the Tariff Card  are already displayed on the page at this step,
         * therefore we'll wait for just 3 seconds to get all needed children If
         * something will be null then it is for sure because the locators have changed
         */
        this.browser.setImplicitWait(3);
        for (PageElement tariffcard : tariffCardParent.asList()) {
            TariffCard tariff = new TariffCard(tariffcard.findChild(By.CssSelector, ".o2uk-data p"), tariffcard.findChild(By.CssSelector, ".o2uk-data__label"), tariffcard.findChild(By.CssSelector, ".tariff-card__info_text"), tariffcard.findChild(By.CssSelector, ".o2uk-price"), tariffcard.findChild(By.CssSelector, ".mat-button-wrapper"));
            allTariffCard.add(tariff);
        }
        this.browser.restoreImplicitWait();

        return allTariffCard;
    }

    @Override
    public boolean isPageDisplayed() {
        if (!pageTitle.isDisplayed())
            return false;

        return pageTitle.getText().trim().equalsIgnoreCase("Pay Monthly sim deals");
    }

}
