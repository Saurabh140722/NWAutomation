package com.o2.pages.ecare;

import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;

public class PaymentPage extends EcareBasePage{

    @Find(by = By.XPath, locator = "//div[contains(@class,'o2uk-dialog-title__content')]")
    public PageElement addNewCardPopUp;

    @Find(by = By.CssSelector, locator ="#cardName")
    public PageElement cardName;

    @Find(by = By.CssSelector, locator = "#cardNumber")
    public PageElement cardNumber;

    @Find(by = By.CssSelector, locator = "#expiryDateMonthInput")
    public PageElement expiryDateMonthInput;

    @Find(by = By.CssSelector, locator = "#expiryDateYearInput")
    public PageElement expiryDateYearInput;

    @Find(by = By.CssSelector, locator = "#csc")
    public PageElement cvv;

    @Find(by = By.CssSelector, locator = "#bConfirmPaymentButton")
    public PageElement registerCard;

    //Added card

    @Find(by = By.CssSelector, locator = ".o2uk-card")
    public PageElement addedCardSection;

    @Find(by = By.XPath, locator = "//*[contains(text(),'4546 38')]")
    public PageElement addedCardNumber;

    @Find(by = By.XPath, locator = "//*[contains(text(),'2025')]")
    public PageElement addedCardExpireDate;

    @Find(by = By.XPath, locator = "//*[contains(@class,'o2uk-bank-card__remove-text')]")
    public PageElement removeCardLink;

    @Find(by = By.XPath, locator = "//h3[contains(text(),'Card removed')]")
    public PageElement removeCardPopUp;

    @Find(by = By.XPath, locator = "//*[@class='o2uk-direct-debit-card']")
    public PageElement addedDirectDebitCard;

    @Find(by = By.XPath, locator = "//*[contains(@id,'expansion-panel-header')]")
    public PageElement expansionDirectDebitCard;

    @Find(by = By.XPath, locator = "//*[contains(@class,'direct-debit-card__remove-text')]")
    public PageElement removeDirectDebitCard;

    @Find(by = By.XPath, locator = "//*[contains(text(),'This will be deactivated')]")
    public PageElement deactivatedDirectDebitText;





    //Set up your Direct Debit
    @Find(by = By.XPath, locator = "//button[@aria-label='New account']")
    public PageElement newAccountTab;

    @Find(by = By.XPath, locator = "//button[@aria-label='Existing account']")
    public PageElement existingAccountTab;

    @Find(by = By.XPath, locator = "//input[@formcontrolname='accountHolder']")
    public PageElement accountHolder;

    @Find(by = By.XPath, locator = "//input[@formcontrolname='accountNumber']")
    public PageElement accountNumber;

    @Find(by = By.XPath, locator = "//input[@formcontrolname='sortCode']")
    public PageElement sortCode;

    @Find(by = By.XPath, locator = "//div[contains(text(),'Amount')]")
    public PageElement billableAmount;

    @Find(by = By.XPath, locator = "//o2uk-dropdown-card[@class='o2uk-dropdown-card ng-star-inserted']")
    public PageElement paymentStatus;

    @Find(by = By.XPath, locator = "//div[contains(text(),' Non-billable amount ')]")
    public PageElement nonBillableAmount;

    @Find(by = By.XPath, locator = "//input[contains(@class,'checkbox-input')]")
    public PageElement directDebitCheckBox;

    @Find(by = By.XPath, locator = "//*[text()='New Direct Debit']")
    public PageElement newDirectDebitPopup;





}