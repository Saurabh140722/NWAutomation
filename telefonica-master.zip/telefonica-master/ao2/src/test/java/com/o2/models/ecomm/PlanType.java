package com.o2.models.ecomm;

public enum PlanType {
    CUSTOM_PLAN,
    DETAIL_ADDRESS_CHECK,
    WATCH_DEVICE,
    SIM_ONLY
}
