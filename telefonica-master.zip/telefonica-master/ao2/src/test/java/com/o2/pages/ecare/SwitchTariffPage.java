package com.o2.pages.ecare;

import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;

public class SwitchTariffPage extends EcareBasePage {

	@Find(by = By.XPath, locator = "//h1[text()=' Change tariff ']")
	public PageElement pageTitle;

	@Override
	public boolean isPageDisplayed() {
		if (!pageTitle.isDisplayed())
			return false;

		return pageTitle.getText().trim().equalsIgnoreCase("Change tariff");
	}

}
