package com.o2.pages.csrd;

import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.FindByKey;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.o2.pages.BasePage;

public class AccountLandingPage extends BasePage {
    @Find(by = By.CssSelector, locator = ".customer-name.csrd-tooltip-field")
    public PageElement accountName;

    @Find(by = By.LinkName, locator = "Billing Accounts")
    public PageElement billingAccounts;

    @Find(by = By.Id, locator = "9135386130713487803_lightparctrl_3_9135584008513286551")
    public PageElement billingAccountsName;

    @Find(by = By.CssSelector, locator = "button[class*='button_action_id_9153486186713158414_9153588740013161809_']")
    public PageElement paymentInstrumentsButton;

    @Find(by = By.CssSelector, locator = ".GEGUAMFDAJ.GEGUAMFDCJ.nc-table-cell.nc-table-cell-ta.readonly")
    public PageElement paymentInstrumentsName;

    @Find(by = By.CssSelector, locator = "button[class*='button_action_id_9153788880613143246_9153789007813143467_cbmreloaddependingtablectrl_']")
    public PageElement paymentMandateButton;

    @Find(by = By.XPath, locator = "//*[@id='9153788880613143246']/div/table/tbody[1]/tr/td[3]/div/div")
    public PageElement paymentMandateName;
    @FindByKey(key ="newOrder")
    public PageElement newOrderButton;

    @Find(by = By.PartialLinkName, locator = "Pay Monthly")
    public PageElement payMonthlyBillingAccount;
}
