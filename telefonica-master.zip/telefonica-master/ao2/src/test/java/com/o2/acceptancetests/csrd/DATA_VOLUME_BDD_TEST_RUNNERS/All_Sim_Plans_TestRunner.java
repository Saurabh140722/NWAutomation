package com.o2.acceptancetests.csrd.DATA_VOLUME_BDD_TEST_RUNNERS;

import com.o2.feature_file_appender.config.AppendDataToFeatureFile_Utility;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;

import static org.junit.Assert.assertTrue;

@RunWith(Cucumber.class)
@CucumberOptions(
        plugin = { "com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:", "summary" },
        glue = { "com.o2.stepdefs", "com.o2.hooks" },
        features = "src/test/resources/features/BDD_TESTS_DATA_VOLUME/All_Sim_Plans_Tab/Data_Vol_All_Sim_Plans.feature",
        tags = "@all_sim_plans"
)
public class All_Sim_Plans_TestRunner {
    private AppendDataToFeatureFile_Utility asp_utility;

    public All_Sim_Plans_TestRunner() {
        asp_utility = new AppendDataToFeatureFile_Utility();
        asp_utility.setExcelTab("All_Sim_Plans_Tab");
        asp_utility.readCleanseDataSourceFileInto2DArray_AllSimPlans("All_Sim_Plans.csv", true);
        Object[] range = { 1, 12 };
        assertTrue(asp_utility.copyFeatureFile("All_Sim_Plans.feature"));
        assertTrue(asp_utility.appendDataToNewFeatureFile("outline","colrange", range));
    }

    @BeforeClass
    public static void setup() {
        //         Any BeforeAll logic ...
    }

    @AfterClass
    public static void teardown() {
//         DriverUtil.getDriver().close();
//        BrowserUtil.getBrowser().close();
    }
}
