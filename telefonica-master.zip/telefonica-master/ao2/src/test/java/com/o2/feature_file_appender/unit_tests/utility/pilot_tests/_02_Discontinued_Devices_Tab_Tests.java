package com.o2.feature_file_appender.unit_tests.utility.pilot_tests;

import com.o2.feature_file_appender.config.AppendDataToFeatureFile_Utility;
import org.junit.Test;

import java.util.function.Predicate;

import static org.junit.Assert.assertTrue;

public class _02_Discontinued_Devices_Tab_Tests {
    private AppendDataToFeatureFile_Utility dd_utility;

    public _02_Discontinued_Devices_Tab_Tests() {
        dd_utility = new AppendDataToFeatureFile_Utility();
        dd_utility.setExcelTab("Discontinued_Devices_Tab");
    }

    @Test
    public void filterResultsByMapUsingPredicate_StringEquals_PhonesAndroid() {
        dd_utility.readCleanseDataSourceFileInto2DArray("Discontinued_Devices.csv", false);
        String value = "Android";
        Predicate<String> predStringEquals = s -> (s.equalsIgnoreCase(value));
        Object[] args = {  predStringEquals, 0, 1 };
        assertTrue(dd_utility.copyFeatureFile("Phones_Android.feature"));
        assertTrue(dd_utility.appendDataToNewFeatureFile("scenario","filtered_map_by_col", args));
    }

    @Test
    public void filterResultsByMapUsingPredicate_StringEquals_PhonesApple() {
        dd_utility.readCleanseDataSourceFileInto2DArray("Discontinued_Devices.csv", false);
        String value = "Iphone";
        Predicate<String> predStringEquals = s -> (s.equalsIgnoreCase(value));
        Object[] args = {  predStringEquals, 0, 1 };
        assertTrue(dd_utility.copyFeatureFile("Phones_Apple.feature"));
        assertTrue(dd_utility.appendDataToNewFeatureFile("scenario","filtered_map_by_col", args));
    }

    @Test
    public void filterResultsByMapUsingPredicate_StringEquals_TabletsAndroid() {
        dd_utility.readCleanseDataSourceFileInto2DArray("Discontinued_Devices.csv", false);
        String value = "Android Tablets";
        Predicate<String> predStringEquals = s -> (s.equalsIgnoreCase(value));
        Object[] args = {  predStringEquals, 0, 1 };
        assertTrue(dd_utility.copyFeatureFile("Tablets_Android.feature"));
        assertTrue(dd_utility.appendDataToNewFeatureFile("scenario","filtered_map_by_col", args));
    }

    @Test
    public void filterResultsByMapUsingPredicate_StringEquals_TabletsApple() {
        dd_utility.readCleanseDataSourceFileInto2DArray("Discontinued_Devices.csv", false);
        String value = "IPAD";
        Predicate<String> predStringEquals = s -> (s.equalsIgnoreCase(value));
        Object[] args = {  predStringEquals, 0, 1 };
        assertTrue(dd_utility.copyFeatureFile("Tablets_Apple.feature"));
        assertTrue(dd_utility.appendDataToNewFeatureFile("scenario","filtered_map_by_col", args));
    }

    @Test
    public void filterResultsByMapUsingPredicate_StringEquals_TabletsWindows() {
        dd_utility.readCleanseDataSourceFileInto2DArray("Discontinued_Devices.csv", false);
        String value = "Windows";
        Predicate<String> predStringEquals = s -> (s.equalsIgnoreCase(value));
        Object[] args = {  predStringEquals, 0, 1 };
        assertTrue(dd_utility.copyFeatureFile("Tablets_Windows.feature"));
        assertTrue(dd_utility.appendDataToNewFeatureFile("scenario","filtered_map_by_col", args));
    }

    @Test
    public void filterResultsByMapUsingPredicate_StringEquals_WatchesAndroid() {
        dd_utility.readCleanseDataSourceFileInto2DArray("Discontinued_Devices.csv", false);
        String value = "Android Watch";
        Predicate<String> predStringEquals = s -> (s.equalsIgnoreCase(value));
        Object[] args = {  predStringEquals, 0, 1 };
        assertTrue(dd_utility.copyFeatureFile("Watches_Android.feature"));
        assertTrue(dd_utility.appendDataToNewFeatureFile("scenario","filtered_map_by_col", args));
    }

    @Test
    public void filterResultByMapsUsingPredicate_StringEquals_WatchesApple() {
        dd_utility.readCleanseDataSourceFileInto2DArray("Discontinued_Devices.csv", false);
        String value = "Apple Watch";
        Predicate<String> predStringEquals = s -> (s.equalsIgnoreCase(value));
        Object[] args = {  predStringEquals, 0, 1 };
        assertTrue(dd_utility.copyFeatureFile("Watches_Apple.feature"));
        assertTrue(dd_utility.appendDataToNewFeatureFile("scenario","filtered_map_by_col", args));
    }

}
