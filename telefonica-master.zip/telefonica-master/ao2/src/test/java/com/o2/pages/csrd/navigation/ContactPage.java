package com.o2.pages.csrd.navigation;

import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.nttdata.cinnamon.driver.controls.PageElementCollection;
import com.o2.pages.BasePage;

public class ContactPage extends BasePage {
    @Find(by = By.XPath, locator = "//button[contains(text(),'Add Contact')]")
    public PageElement addContactLink;

    @Find(by = By.Id, locator = "ui-id-2")
    public PageElement dialogWindowTitle;

    @Find(by = By.Id, locator = "ui-id-1")
    public PageElement contactFormRoot;

    @Find(by = By.Id, locator = "9134309035813188126")
    public PageElement emailAuthentication;

    @Find(by = By.CssSelector, locator = ".nc-reference-selector-add-button")
    public PageElement contactPlusIcon;

    @Find(by = By.Id, locator = "9134290720513164175")
    public PageElement title;

    @Find(by = By.Id, locator = "9134256876313157625")
    public PageElement firstName;

    @Find(by = By.Id, locator = "9134256876313157627")
    public PageElement lastName;

    @Find(by = By.Id, locator = "9134308937713187961")
    public PageElement dob; // dd/MM/yyyy

    @Find(by = By.Id, locator = "button_9154229439513153983")
    public PageElement addAddressButton;

    @Find(by = By.Id, locator = "9153345485613159362")
    public PageElement postCode;

    @Find(by = By.Id, locator = "9153345485613159424")
    public PageElement streetNo;

    @Find(by = By.CssSelector, locator = ".ParCtrl-editButton.addressLookupButton")
    public PageElement addressLookupButton;

    @Find(by = By.Id, locator = "9153345507813159589")
    public PageElement addresses;

    @Find(by = By.XPath, locator = "//button[contains(text(),'Confirm Address')]")
    public PageElement confirmAddress;

    @Find(by = By.XPath, locator = "//input[@aria-label='Contact method. Preferred is Phone Number - Mobile']")
    public PageElement mobileNumberRadioBtn;

    @Find(by = By.XPath, locator = "//input[@class='gwt-TextBox jbss-empty-textbox jbss_text_box jbss_invalid_text_box']")
    public PageElement mobileNumber;


    @Find(by = By.CssSelector, locator = "i.refsel_arrow")
    public PageElementCollection contactRole;

    @Find(by = By.CssSelector, locator = ".refsel_name")
    public PageElementCollection contactRoleOptions;

    @Find(by = By.XPath, locator = "//button[contains(text(),'Create')]")
    public PageElement createButton;

    @Find(by = By.XPath, locator = "//button[contains(text(),'Save')]")
    public PageElementCollection saveButton;

    @Find(by = By.XPath, locator = "//label[contains(text(),'Customer Contacts and Roles')]")
    public PageElement customerContactRolesPage;

    @Find(by = By.XPath, locator = "//a[contains(text(),'Power of Attorney')]")
    public PageElement contactRoleValue;

    @Find(by = By.XPath, locator = "//a[@aria-label='Delete']")
    public PageElement deleteIcon;

    @Find(by = By.XPath, locator = "//button[contains(text(),'Delete')]")
    public PageElement deleteConatct;

    @Find(by = By.XPath, locator = "//div[@class='nc-field-text-readonly nc-field-reference-readonly']//a[@tabindex='-1']")
    public PageElementCollection accessForYouTicketRow;

    @Find(by = By.XPath, locator = "//div[@class='nc-field-list-color ']//span[2]")
    public PageElementCollection accessForYouTicketStatusOlaRow;

    @Find(by = By.XPath, locator = "//td[@class='readonly nc-table-dateTime-cell'][2]")
    public PageElementCollection accessForYouTicketDate;

    @Find(by = By.CssSelector, locator = ".gwt-Button.left-panel-collapse-button.collapsed")
    public PageElement leftNavigationMenu;

    @Find(by = By.XPath, locator = "//a[@title='List of NetCracker modules']")
    public PageElement listOfNetCrackerModules;

    @Find(by = By.XPath, locator = "//span[contains(text(),'Customer Impact Analysis')]")
    public PageElement customerImpactAnalysis;

    @Find(by = By.XPath, locator = "//span[contains(text(),'Trouble Tickets Repository')]")
    public PageElement troubleTicketsRepository;

    @Find(by = By.XPath, locator = "//a[contains(text(),'Access For You')]")
    public PageElement accessForYouLink;

    @Find(by = By.XPath, locator = "//table[@class='TableCtrl nc-table-content-zebra']//tbody//tr")
    public PageElementCollection accessForYouTicketTableList;

    @Find(by = By.XPath, locator = "//div[@class='ui-pager-gwt-cell-table']")
    public PageElementCollection paginationList;

    @Find(by = By.XPath, locator = "//button[contains(text(),'Cancel')]")
    public PageElement cancelLink;

    @Find(by = By.XPath, locator = "//input[@class='refsel_input']")
    public PageElement cancellationReasonTxtBox;

    @Find(by = By.XPath, locator = "//div[@class='refsel_name']")
    public PageElementCollection cancellationReasonOptions;

    @Find(by = By.XPath, locator = "//textarea[@class='nc-memo-field']")
    public PageElement commentDesciption;

    @Find(by = By.XPath, locator = "//button[contains(text(),'Ok')]")
    public PageElement okBtn;

    @Find(by = By.XPath, locator = "//div[@class='ui-pager-gwt-container-page-number']")
    public PageElement anchorLinkOnAccessForYouTicket;

    @Find(by = By.XPath, locator = "//div[@role='listitem']")
    public PageElementCollection listofRowIteam;
}
