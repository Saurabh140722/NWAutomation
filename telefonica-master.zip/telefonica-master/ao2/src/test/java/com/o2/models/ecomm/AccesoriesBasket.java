package com.o2.models.ecomm;

import com.nttdata.cinnamon.driver.controls.PageElement;
import com.nttdata.cinnamon.driver.controls.PageElementCollection;


public class AccesoriesBasket {
    public PageElement accessoriesName;
    public PageElement accessoriesColour;
    public PageElementCollection price;

    public AccesoriesBasket(PageElement accessoriesName, PageElement accessoriesColour, PageElementCollection price) {
        this.accessoriesName = accessoriesName;
        this.accessoriesColour = accessoriesColour;
        this.price = price;
    }
}
