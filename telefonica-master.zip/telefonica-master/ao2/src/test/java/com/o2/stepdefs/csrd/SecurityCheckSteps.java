package com.o2.stepdefs.csrd;

import com.google.inject.Inject;
import com.nttdata.cinnamon.cache.Context;
import com.nttdata.cinnamon.driver.Browser;
import com.nttdata.cinnamon.logging.Logger;
import com.o2.core.data.UserDataModel;
import com.o2.pages.csrd.SecurityCheckPage;
import com.o2.stepdefs.BaseStep;
import io.cucumber.java.en.When;
import org.apache.commons.lang.NotImplementedException;

import static com.nttdata.cinnamon.wait.ElementConditions.displayed;
import static org.assertj.core.api.Assertions.assertThat;

public class SecurityCheckSteps extends BaseStep {
    private final Context context;
    private final Logger logger;
    private final Browser browser;
    private final SecurityCheckPage securityCheckPage;

    @Inject
    public SecurityCheckSteps(final Context context,
                              final Logger logger,
                              final Browser browser,
                              final SecurityCheckPage securityCheckPage) {
        this.context = context;
        this.logger = logger;
        this.browser = browser;
        this.securityCheckPage = securityCheckPage;
    }

    @When("^the OTAC '(does|does not)' pass Security Check$")
    public void i_open_residential_account_form(String passesOrNot) {
        this.logger.info("*** Security Check page loading ...");

        assertThat(this.securityCheckPage.isPageDisplayed())
                .withFailMessage("Security Check page not displayed!")
                .isTrue();

        UserDataModel userData = (UserDataModel) this.context.get("residentialUserAccountData");
        boolean isPassingSecurityCheck = passesOrNot.equals("does");

        // TODO: store this 999999 value in user details
        String securityCode = isPassingSecurityCheck ? "999999" : "246800";
        this.securityCheckPage.otac.waitUntil(displayed).setValue(securityCode);
        // TODO: when negative scenarios will be implemented add the assertions needed here
        if (!isPassingSecurityCheck) {
            throw new NotImplementedException("Test case when Security Check does not pass is not implemented yet!");
        }

        this.securityCheckPage.submitButton.click();

        this.browser.setImplicitWait(1);

        if (this.securityCheckPage.houseNumber.isDisplayed(2)) {
            this.securityCheckPage.houseNumber.setValue("539");
            this.securityCheckPage.postCode.setValue(userData.postcode);
            this.securityCheckPage.continueButton.click();
        }

        if (this.securityCheckPage.bankAccount.isDisplayed(2)) {
            String bankAccount = userData.userPaymentModel.bankAccount;
            this.securityCheckPage.bankAccount.setValue(bankAccount.substring(bankAccount.length() - 3));
            this.securityCheckPage.submitExtraCheckButton.click();
        }

        this.browser.restoreImplicitWait();
        this.securityCheckPage.skipPhoneNumber.click();

        this.logger.info("*** Security Check completed!\n");
    }
}
