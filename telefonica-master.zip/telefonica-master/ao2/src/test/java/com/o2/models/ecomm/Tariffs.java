package com.o2.models.ecomm;

import com.nttdata.cinnamon.driver.controls.PageElement;
import com.nttdata.cinnamon.driver.controls.PageElementCollection;

public class Tariffs {
    public PageElement title;
    public PageElementCollection description;
    public PageElement price;
    public PageElement addBasket;

    public Tariffs() {
    }

    public Tariffs(PageElement title, PageElementCollection description, PageElement price, PageElement addBasket) {
        this.title = title;
        this.description = description;
        this.price = price;
        this.addBasket = addBasket;
    }

    @Override
    public boolean equals(Object classobject) {
        if (classobject == this) {
            return true;
        }
        if (!(classobject instanceof Tariffs)) {
            return false;
        }
        Tariffs plan = (Tariffs) classobject;
        return plan.title.equals(this.title);

    }


}
