package com.o2.stepdefs.csrd;

import com.google.inject.Inject;
import com.o2.pages.csrd.AccountLandingPage;
import com.o2.pages.csrd.PaymentMandatePage;
import com.o2.stepdefs.BaseStep;
import io.cucumber.java.en.When;

import static com.nttdata.cinnamon.wait.ElementConditions.displayed;
import static org.assertj.core.api.Assertions.assertThat;

public class PaymentMandateSteps extends BaseStep {
    private final AccountLandingPage accountLandingPage;
    private final PaymentMandatePage paymentMandatePage;

    @Inject
    public PaymentMandateSteps(final AccountLandingPage accountLandingPage,
                               final PaymentMandatePage paymentMandatePage) {
        this.accountLandingPage = accountLandingPage;
        this.paymentMandatePage = paymentMandatePage;
    }

    @When("^I add a Payment Mandate$")
    public void i_add_a_payment_mandate() {
        this.accountLandingPage.paymentMandateButton.waitUntil(displayed).click();

        assertThat(this.paymentMandatePage.createButton.waitUntil(displayed).isDisplayed())
                .withFailMessage("Payment Mandate page not displayed!")
                .isTrue();
        this.paymentMandatePage.createButton.click();
    }

}
