package com.o2.pages.ecomm;

import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;

import static org.assertj.core.api.Assertions.assertThat;

public class BasketPage extends BasePage {

    @Find(by = By.XPath, locator = "//*[@id='portlet_GlobalHeaderPortlet']//basket-state/button")
    public PageElement basketCartButton;

    @Find(by = By.XPath, locator = "//o2uk-buttons//basket-state/button/span")
    public PageElement basketCountButton;

    @Find(by = By.XPath, locator = "//o2uk-buttons//basket-state/button/span")
    public PageElement youHaveOrderInProgressCloseDialog;

    @Find(by = By.XPath, locator = "//customers-basket//basket-section-cta//o2uk-link/button")
    public PageElement emptyBasket;

    @Find(by = By.XPath, locator = "//o2uk-common-dialog//button[@aria-label='close dialog']")
    public PageElement emptyBasketCloseDialog;

    @Find(by = By.XPath, locator = "//o2uk-dialog-content//o2uk-link/button")
    public PageElement emptyBasketCancelOrder;

    @Find(by = By.XPath, locator = "//o2uk-common-dialog//button[@aria-label='Cancel the order']")
    public PageElement cancelOrderBasket;

    @Find(by = By.XPath, locator = "//div[contains(@class,'basket-section-cta__checkout-button')]//span")
    public PageElement checkoutBasket;

    @Find(by = By.XPath, locator = "//*[@id='cdk-step-label-0-0']/div/div[1]")
    public PageElement userDetails;

        @Find(by = By.XPath, locator = "//div/label[contains(text(),'Address')]")
    public PageElement userAddress;

    @Find(by = By.XPath, locator = "//div[4]//div[2]/b[contains(@class,'your-details__field-value')]")
    public PageElement userAddressLine;

   // UserDetails NO Chang  e Continue Home Delivery

    @Find(by = By.XPath, locator = "//button[@type='button']/span[text()=' Continue ']")
    public PageElement userDetailsNOChangeContinue;

    @Find(by = By.XPath, locator = "//h2[text()=' Delivery or collection ']")
    public PageElement deliverNCollectionHeader;

    @Find(by = By.XPath, locator = "//button//span[text()='Home delivery']")
    public PageElement homeDelivery;

    @Find(by = By.XPath, locator = "//delivery//o2uk-notification-message")
    public PageElement deliveryOutOfStockDialog;

    @Find(by = By.XPath, locator = "//delivery//p[contains(string(),'order is now out of stock')]")
    public PageElement deliveryOutOfStockmessage;

    @Find(by = By.XPath, locator = "//button[@type='button']/span[text()=' Confirm and continue ']")
    public PageElement homeDeliveryContinue;

    @Find(by = By.XPath, locator = "//h2[text()='Eligibility check ']")
    public PageElement EligibilityCheckHeader;

    @Find(by = By.XPath, locator = "//select[@formcontrolname='currentAddressDurationField']")
    public PageElement timeAtAddress;

    @Find(by = By.XPath, locator = "//select[@formcontrolname='employmentStatusField']")
    public PageElement employmentStatus;

    @Find(by = By.XPath, locator = "//select[@formcontrolname='annualIncomeField']")
    public PageElement personalAnnualIncome;

    @Find(by = By.XPath, locator = "//*[@id='mat-checkbox-1-input']")
    public PageElement EligibilityCheckAgree;

    @Find(by = By.XPath, locator = "//additional-details//button//span")
    public PageElement EligibilityCheckContinue;

    @Find(by = By.XPath, locator = "//div[contains(@class,'your-details__field')]//label[text()=' YEARS AT YOUR ADDRESS ']")
    public PageElement yearsAtYourAddressConfirmationHeader;

    @Find(by = By.XPath, locator = "//div[@class='checkout__indent ng-star-inserted']/div[1]//div[2]")
    public PageElement yearsAtYourAddressConfirmation;

    @Find(by = By.XPath, locator = "//div[contains(@class,'your-details__field')]//label[text()=' EMPLOYMENT STATUS ']")
    public PageElement employmentStatusConfirmationHeader;

    @Find(by = By.XPath, locator = "//div[@class='checkout__indent ng-star-inserted']/div[2]//div[2]")
    public PageElement employmentStatusConfirmation;

    @Find(by = By.XPath, locator = "//div[contains(@class,'your-details__field')]//label[text()=' PERSONAL ANNUAL INCOME ']")
    public PageElement anuualIncomeConfirmationHeader;

    @Find(by = By.XPath, locator = "//div[@class='checkout__indent ng-star-inserted']/div[3]//div[2]")
    public PageElement anuualIncomeConfirmation;

    @Find(by = By.XPath, locator = "//button[@aria-label='Edit Eligibility check step']")
    public PageElement editEligibilityCheck;

    @Find(by = By.XPath, locator = "//div[contains(@class,'checkout-registration')]//button[@type='button']/span[text()=' Continue ']")
    public PageElement eligibiltyCheckCompleteContinue;

    @Find(by = By.XPath, locator = "//p[text()=' The eligibility check is complete ']")
    public PageElement eligibiltyCheckCompleteHeader;

      // UserDetails NO Change Continue Home Delivery

    // UserDetails NO Change Continue Click N Collect

        @Find(by = By.XPath, locator = "//button//span[text()='Click and collect']")
    public PageElement clickNCollect;

    @Find(by = By.XPath, locator = "//button//span[text()=' Select a store ']")
    public PageElement selectStore;

    @Find(by = By.XPath, locator = "//o2uk-click-and-collect-dialog")
    public PageElement clickNCollectDialog;

    @Find(by = By.XPath, locator = "//button[contains(@class,'o2uk-dialog-title__button')]")
    public PageElement clickNCollectClose;

    @Find(by = By.XPath, locator = "//div[@class='click-and-collect-dialog__control-town']//input")
    public PageElement clickNCollectPostCode;

    @Find(by = By.XPath, locator = "//button[@role='button']//span[text()=' Find ']")
    public PageElement findByPostcodeButton;

    @Find(by = By.XPath, locator = "//o2uk-click-and-collect-dialog//o2uk-tabs/div/button[1]")
    public PageElement listViewOfClickNCollectStores;

    @Find(by = By.XPath, locator = "//o2uk-click-and-collect-dialog//o2uk-tabs/div/button[2]")
    public PageElement mapViewOfClickNCollectStores;

    @Find(by = By.XPath, locator = "//div[1]/o2uk-retail-shop-card/div[1]//button")
    public PageElement chooseFirstStore;

    @Find(by = By.XPath, locator = "//div[contains(@class,'click-and-collect-dialog__list-item')]//o2uk-retail-shop-card/div[1]//button")
    public PageElement chooseMultiStore;

    @Find(by = By.XPath, locator = "//o2uk-notification-message//p")
    public PageElement collectOrderNotificationMessage;

    @Find(by = By.XPath, locator = "//*[@id='o2uk-dialog-0']//o2uk-retail-shop-card/div[2]/button")
    public PageElement storeDetailsMultiple;

    @Find(by = By.XPath, locator = "//*[@id='o2uk-dialog-0']//div[1]//o2uk-retail-shop-card/div[2]/button")
    public PageElement storeDetailsFirst;

    @Find(by = By.XPath, locator = "//delivery//div[contains(@class,'delivery__button')]//button/span")
    public PageElement deliveryConfirm;

    @Find(by = By.XPath, locator = "//button[@aria-label='close dialog']")
    public PageElement someThingWentWrongMessageClose;



    // continue  wiht eligibility check

    // user details change

    @Find(by = By.XPath, locator = "//button[contains(text(),' Need to change any of these details? Update them in My O2 ')]")
    public PageElement userDetailsChangeOption;

    @Find(by = By.XPath, locator = "//*[@id='o2uk-dialog-0']//address-change-dialog")
    public PageElement addressChangeDialog;

    @Find(by = By.XPath, locator = "//*[@id='o2uk-dialog-title-3']//button")
    public PageElement addressChangeDialogClose;

    @Find(by = By.XPath, locator = "//*[@id='o2uk-dialog-0']//address-change-dialog//div[3]/div/button")
    public PageElement addressChangeDialogConfirm;

    @Find(by = By.XPath, locator = "//*[@id='o2uk-dialog-0']//address-change-dialog//div[3]/div/div/button")
    public PageElement addressChangeDialogCancel;

    @Find(by = By.Id, locator = "//*[@id='msisdnValue']")
    public PageElement msisdnValuePhoneNo;

    @Find(by = By.Id, locator = "//*[@id='continueButton']")
    public PageElement msisdnValueSubmit;

    @Find(by = By.Id, locator = "/*[@id='header']")
    public PageElement verifyPhoneNumberHeader;

    @Find(by = By.Id, locator = "//*[@id='otacDigitOne']")
    public PageElement otacDigitCode1;

    @Find(by = By.Id, locator = "//*[@id='otacDigitTwo']")
    public PageElement otacDigitCode2;

    @Find(by = By.Id, locator = "//*[@id='otacDigitThree']")
    public PageElement otacDigitCode3;

    @Find(by = By.Id, locator = "//*[@id='otacDigitFour']")
    public PageElement otacDigitCode4;

    @Find(by = By.Id, locator = "//*[@id='otacDigitFive']")
    public PageElement otacDigitCode5;

    @Find(by = By.Id, locator = "//*[@id='otacDigitSix']")
    public PageElement otacDigitCode6;

    @Find(by = By.Id, locator = "//*[@id='continueButton']")
    public PageElement continueButton;








    // user details change






}
