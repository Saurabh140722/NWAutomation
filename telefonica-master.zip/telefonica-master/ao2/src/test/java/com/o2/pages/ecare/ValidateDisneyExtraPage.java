package com.o2.pages.ecare;

import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.nttdata.cinnamon.driver.controls.PageElementCollection;

public class ValidateDisneyExtraPage extends EcareBasePage {

    @Find(by = By.CssSelector, locator = ".o2uk-tabs__tab-label")
    public PageElementCollection allExtraOptions;

    @Find(by = By.CssSelector, locator = ".add-on__wrapper")
    public PageElement disneyplusExtraPanel;

    @Find(by = By.XPath, locator = " //div[@class='mat-slide-toggle-thumb-container']")
    public PageElement cancelBtnToogle;

    @Find(by = By.CssSelector, locator = ".o2uk-extra-card__active-note")
    public PageElement cancelActiveNote;

    @Find(by = By.CssSelector, locator = ".mat-slide-toggle-thumb__svg")
    public PageElement toggleBtn;




}
