package com.o2.pages.ecare;

import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;

public class WantToLeavePage extends EcareBasePage {

	@Find(by = By.XPath, locator = "//h1[text()=' Want to leave? ']") // h1[@class='o2uk-header-curve__text-title
																		// ng-star-inserted']")
	public PageElement pageTitle;

	@Override
	public boolean isPageDisplayed() {
		if (!pageTitle.isDisplayed())
			return false;

		return pageTitle.getText().trim().equalsIgnoreCase("Want to leave?");
	}
}
