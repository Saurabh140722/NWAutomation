package com.o2.models.csrd;

public class AccountUserData {
}
