package com.o2.stepdefs.ecare;

import com.google.inject.Inject;
import com.nttdata.cinnamon.driver.Browser;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.o2.pages.ecare.OrderDetailPage;
import com.o2.stepdefs.BaseStep;
import io.cucumber.java.en.Then;

import static org.assertj.core.api.Assertions.assertThat;

public class OrderDetailPageStepDef extends BaseStep {
    private final OrderDetailPage orderDetailPage;
    private final Browser browser;
    @Inject
    public OrderDetailPageStepDef(final OrderDetailPage orderDetailPage, Browser browser) {

        this.orderDetailPage = orderDetailPage;
        this.browser = browser;
    }
    @Then("^I can see order detail$")
    public void i_verify_the_email_under_notification_tab() {
        this.logger.info("*** Order Detail Section is loaded ...");
        assertThat(orderDetailPage.orderDetailTitle.isDisplayed())
                .withFailMessage("Order Detail Page has not loaded!").isTrue();
        browser.setImplicitWait(5);
        for(PageElement orderDetail:orderDetailPage.orderDetailContainer.asList()) {
            assertThat(orderDetail.isDisplayed())
                    .withFailMessage("Order Detail container has not loaded!").isTrue();
        }
        browser.restoreImplicitWait();

    }

}
