package com.o2.pages.ecomm;

import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;


public class EcommBasePage extends BasePage {
    @Find(by = By.XPath, locator = "//span[contains(@class,'global-header__username')]")
    public PageElement hiUserName;

    @Find(by = By.XPath, locator = "//div[@id='k2cDynamicSkinContainer']")
    public PageElement chatBot;

   // @Find(by = By.XPath, locator = "//a[@id='k2c_closePopup_0']")
    //public PageElement chatBotClose;

    @Find(by = By.XPath, locator = "//img[@title='Close' and contains(@id,'accept')]")
    private PageElement chatBotClose;

    @Find(by = By.XPath, locator ="//img[@alt='Just a moment']")
    private PageElement justAMomentLoader;


    public PageElement getTab(String tabName) {
        return this.browser.findBy(By.XPath, "//*[@role='tab']//*[text()='" + tabName + "']");
    }

    public PageElement getButton(String buttonName) {
        return this.browser.findBy(By.XPath, "//*[@role='button']//*[contains(text(),'" + buttonName + "')]");
    }

    @Find(by = By.Id, locator = "email")
    public PageElement email;

    @Find(by = By.XPath, locator = "//*[@id='logoutBtn']")
    public PageElement signOut;

    public PageElement getLink(String linkName) {
        return this.browser.findBy(By.LinkName,linkName);
    }
    public PageElement getMenuLink(String linkName) {
        return this.browser.findBy(By.XPath,"//a[@title='"+linkName+"']");
    }

    private boolean isPageElementDisplayed(PageElement pageElement) {
        browser.setImplicitWait(2);
        boolean condition = retry.retryAction(
                () -> pageElement.isDisplayed(),
                3,
                1);
        browser.restoreImplicitWait();

        return condition;
    }

    public void closeChatBot() {
        browser.setImplicitWait(2);

        logger.info("Check if chat bot pop up is displayed ...");
        if (isPageElementDisplayed(chatBotClose)) {
            logger.info("Chat bot pop up found! Attempt to close chat bot pop up ...");
            try {
                chatBotClose.clickJs();

            } catch (Exception e) {
                logger.warn("Error retrieving chat bot pop up!");
            }
        } else {
            logger.warn("chat bot pop up is not displayed! ...");
        }

    }
}
