package com.o2.stepdefs.ecare;

import com.google.inject.Inject;
import com.nttdata.cinnamon.driver.Browser;
import com.o2.stepdefs.BaseStep;
import io.cucumber.java.en.When;

import static com.nttdata.cinnamon.wait.ElementConditions.*;
import static org.assertj.core.api.Assertions.assertThat;

public class VerifyMobileSteps extends BaseStep {
    private final VerifyPage verifyPage;
    private final Browser browser;

    @Inject
    public VerifyMobileSteps(final VerifyPage verifyPage, Browser browser) {
        this.verifyPage = verifyPage;
        this.browser = browser;
    }

    @When("^I verify my mobile$")
    public void i_verify_my_mobile() {
        this.logger.info("** Attempt to verify mobile ...");

        //TODO: added below if block for UAT

        if (verifyPage.phoneNumberDropDown.isDisplayed(5)) {
            logger.info("***Select mobile number***");
            int listSize = verifyPage.phoneNumberList.asList().size();

            logger.info("***Mobile number***" + listSize);

            assertThat(listSize > 1)
                    .withFailMessage("Phone number is not present in drop down!")
                    .isTrue();

            verifyPage.phoneNumberDropDownArrow.waitUntil(displayed.and(enabled).and(clickable)).clickJs();
            //TODO: index 0 is 'Select mobile number' text and actual mobile number start form index 1
            verifyPage.phoneNumberList.asList().get(1).hover();
            verifyPage.phoneNumberList.asList().get(1).click();
            assertThat(verifyPage.continueButton.isEnabled())
                    .withFailMessage("Phone number is not selected from!")
                    .isTrue();
            verifyPage.continueButton.waitUntil(displayed.and(enabled).and(clickable)).clickJs();

            this.verifyPage.digitOne.click();
            this.verifyPage.digitOne.setValue("999999");
            this.verifyPage.continueButton.click();

            this.logger.info("** Mobile verified!\n");

        } else {
            this.verifyPage.digitOne.click();
            this.verifyPage.digitOne.setValue("999999");
            this.verifyPage.continueButton.click();

            this.logger.info("** Mobile verified!\n");
        }

    }
}
