package com.o2.pages.ecomm;

import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.nttdata.cinnamon.driver.controls.PageElementCollection;
import com.o2.models.ecomm.Accessories;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

public class AccessoriesPage extends EcommBasePage {

    @Find(by = By.XPath, locator = "//h1[contains(text(),'Accessories')]")
    public PageElement pageTitle;

    @Find(by = By.XPath, locator = "//input[@placeholder='Search accessories']")
    public PageElement searchTxtBox;

    @Find(by = By.CssSelector, locator = ".device-card__wrapper")
    public PageElementCollection accessoriesPlanElements;

    @Find(by = By.XPath, locator = "//span[contains(text(),'View all products')]")
    public PageElement viewAllProductsBtn;

    @Find(by = By.XPath, locator = "//device-option/o2uk-stock-availability//p[@class='o2uk-stock-availability__info-title']")
    public PageElement iStockOROutOfStock;

    @Override
    public boolean isPageDisplayed() {
        if (!pageTitle.isDisplayed())
            return false;

        return pageTitle.getText().trim().equalsIgnoreCase("Accessories");
    }

    public List<Accessories> getAllAccessories() {
        if (accessoriesPlanElements == null) {
            this.logger.warn("No Accessories found on the Accesorries page! Is this a negative scenario?");
            return null;
        }

        List<Accessories> allAccessories = new ArrayList<>();
        this.logger.info(MessageFormat.format("Found {0} Accessories   on the page. Continue ...",
                (long) accessoriesPlanElements.asList().size()));

        this.browser.setImplicitWait(3);
        for (PageElement accessories : accessoriesPlanElements.asList()) {

            Accessories accessoriesList = new Accessories(accessories.findChild(By.CssSelector, ".device-card__brand"),
                    accessories.findChild(By.CssSelector, ".device-card__name"),
                    accessories.findChild(By.CssSelector, ".o2uk-price__amount"));
            allAccessories.add(accessoriesList);
        }
        this.browser.restoreImplicitWait();

        return allAccessories;

    }

    public List<Accessories> getAccessories() {
        if (accessoriesPlanElements == null) {
            this.logger.warn("No Accessories found on the Accesorries page! Is this a negative scenario?");
            return null;
        }

        List<Accessories> allAccessories = new ArrayList<>();
        this.logger.info(MessageFormat.format("Found {0} Accessories   on the page. Continue ...",
                (long) accessoriesPlanElements.asList().size()));

        this.browser.setImplicitWait(3);
        for (PageElement accessories : accessoriesPlanElements.asList()) {

            Accessories accessoriesList = new Accessories(accessories.findChild(By.CssSelector, ".device-card__brand"),
                    accessories.findChild(By.CssSelector, ".device-card__name"),
                    accessories.findChild(By.CssSelector, ".o2uk-price__amount"),
                    accessories.findChild(By.XPath, "//span[contains(text(),'Add Accessory')]"));
            allAccessories.add(accessoriesList);
        }
        this.browser.restoreImplicitWait();

        return allAccessories;

    }

}
