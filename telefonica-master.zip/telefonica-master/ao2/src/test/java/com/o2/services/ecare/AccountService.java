package com.o2.services.ecare;

import com.google.inject.Inject;
import com.nttdata.cinnamon.cache.Context;
import com.nttdata.cinnamon.file.json.JsonParser;
import com.nttdata.cinnamon.file.reader.Reader;
import com.nttdata.cinnamon.logging.Logger;
import com.o2.models.ecare.EcareUser;

import java.text.MessageFormat;
import java.util.List;
import java.util.Objects;

import static org.assertj.core.api.Assertions.assertThat;

public class AccountService {

    private final Logger logger;
    private final Reader reader;
    private final JsonParser jsonParser;
    private final List<EcareUser> loginUsers;
    private final Context context;

    @Inject
    public AccountService(final Logger logger,
                          final Reader reader,
                          final JsonParser jsonParser,
                          Context context) {
        this.logger = logger;
        this.reader = reader;
        this.jsonParser = jsonParser;
        this.context = context;
        String env=System.getProperty("env");
        System.out.println("Env"+env);
        this.context.set("env",env);
        String dataLoginFilePath = System.getProperty("user.dir") + "\\src\\test\\resources\\data\\ecare\\"+env+"\\ecare_login_accounts.json";
        String data = this.reader.readFileAsString(dataLoginFilePath, false);

        this.loginUsers = this.jsonParser.toObjList(data, EcareUser.class);
    }

    public EcareUser getAccount() {
        // TODO: probably worth to move assertions out of here and keep it in test
        assertThat(this.loginUsers.size())
                .withFailMessage("Could not find an eCare Login User data")
                .isGreaterThanOrEqualTo(1);

        EcareUser ecareUser = this.loginUsers.get(0);

        this.logger.info(MessageFormat.format("Login eCare details:\n{0}",
                Objects.requireNonNull(ecareUser).toString()));

        return ecareUser;

    }
}
