package com.o2.stepdefs.ecare;

import com.google.inject.Inject;
import com.nttdata.cinnamon.cache.Context;
import com.nttdata.cinnamon.driver.Browser;
import com.o2.core.util.Common;
import com.o2.pages.ecare.YourDocumentPage;
import com.o2.stepdefs.BaseStep;
import io.cucumber.java.en.When;

import static com.nttdata.cinnamon.wait.ElementConditions.*;
import static org.assertj.core.api.Assertions.assertThat;

public class YourDocumentSteps  extends BaseStep {
    private final Common common;
    private final Browser browser;
    private final YourDocumentPage yourDocumentPage;

    @Inject
    public YourDocumentSteps(final Browser browser, final Common common, final Context context,final YourDocumentPage yourDocumentPage) {
        this.yourDocumentPage = yourDocumentPage;
        this.browser = browser;
        this.common = common;
    }

    @When("^'(.*)' page opens successfully$")
    public void i_click_the_tab(String pageName) {
        this.logger.info("** Waiting for Your Extra page to open ...");
        this.browser.setImplicitWait(10);
        assertThat(yourDocumentPage.pageTitle.getText().trim()).
                withFailMessage(pageName +" page not displayed!")
                .isEqualTo(pageName);

        this.logger.info("**+"+pageName+" page opens!");
    }

    @When("I click  a file to download")
    public void i_click_a_file_to_download() {
        this.logger.info("*Attemp to download a file...");

        assertThat(yourDocumentPage.downloadDocuments.size())
                .withFailMessage("Could not find any document to download in My O2 file page!")
                .isPositive();
        String browsertitle=browser.title().toString();

        yourDocumentPage.downloadDocuments.get(0).waitUntil(displayed.and(enabled).and(clickable)).clickJs();
        yourDocumentPage.waitForProcessLoadingToComplete(3,2,10);
        logger.info("total"+browser.getAllTabs());
        browser.switchToTab(1);
        this.logger.info("ecare tile"+browsertitle);
        this.logger.info("current tile"+browser.title());
       assertThat(browser.title().equalsIgnoreCase(browsertitle))
               .withFailMessage("Could not open the downloaded file in new tab!")
                .isFalse();

        browser.switchToDefault();

    }
}
