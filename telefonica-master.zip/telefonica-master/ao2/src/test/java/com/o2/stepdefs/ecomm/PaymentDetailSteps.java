package com.o2.stepdefs.ecomm;

import com.google.inject.Inject;
import com.nttdata.cinnamon.cache.Context;
import com.nttdata.cinnamon.driver.Browser;
import com.nttdata.cinnamon.webdriver.util.ReadyState;
import com.o2.core.util.Retry;
import com.o2.models.ecomm.BankAccountType;
import com.o2.models.ecomm.EcommUser;
import com.o2.models.ecomm.PaymentDetail;
import com.o2.models.ecomm.PaymentDetailData;
import com.o2.pages.ecomm.PaymentDetailPage;
import com.o2.util.Common;
import io.cucumber.java.en.And;
import org.apache.commons.lang.NotImplementedException;
import org.assertj.core.api.Assertions;

import java.text.MessageFormat;
import java.util.logging.Logger;

import static com.nttdata.cinnamon.wait.ElementConditions.*;
import static com.nttdata.cinnamon.wait.conditions.Conditions.ajaxFinished;
import static com.nttdata.cinnamon.wait.conditions.Conditions.readyState;
import static org.assertj.core.api.Assertions.assertThat;

public class PaymentDetailSteps extends BaseStep {
    private final Logger logger;
    private final Context context;
    private final PaymentDetailPage paymentDetailPage;
    private final PaymentDetailData paymentDetailData;
    private final Browser browser;
    private final Common common;
    private final Retry retry;

    @Inject
    public PaymentDetailSteps(final Logger logger, final Context context, final PaymentDetailPage paymentDetailPage, final PaymentDetailData paymentDetailData, final Browser browser, final Common common, Retry retry) {
        this.logger = logger;
        this.paymentDetailPage = paymentDetailPage;
        this.context = context;
        this.paymentDetailData = paymentDetailData;
        this.browser = browser;
        this.common = common;
        this.retry = retry;
    }

    @And("^I validate '(new|existing)' bank detail for '(.*)' of customer$")
    public void i_validate_payment_detail(String bankAccountDetail, String bankAccountType) {
        this.browser.waitUntil(readyState(ReadyState.COMPLETE));
        EcommUser ecommUser = (EcommUser) this.context.get("eCommUserData");
        String userType= (String) context.get("userType");

         Assertions.assertThat(paymentDetailPage.pageTitle.getText().trim().equals("Secure checkout")).withFailMessage(
                        " Secure checkout page not loaded.")
                .isTrue();
        this.logger.info("*** Attempt to complete  Step 2 of 5:Payment details and credit check ....");
//        String accountType = bankAccountType.toUpperCase().replace(" ", "_");
        String accountType = bankAccountType.toUpperCase();
        BankAccountType bankAccount = com.nttdata.cinnamon.util.Common.convertToEnum(accountType, BankAccountType.class);
        PaymentDetail paymentDetail = paymentDetailData.getPaymentDetails(bankAccount);
        context.set("paymentDetail", paymentDetail);
        if(paymentDetailPage.sendContractInfoBtn.isDisplayed(5))
        {
            Assertions.assertThat(paymentDetailPage.getEnableSectionHeader("Contract Information & Summary").isDisplayed()).withFailMessage(
                            "  Contract Information & Summary not didsplayed.")
                    .isTrue();
            paymentDetailPage.sendContractInfoBtn.clickJs();
            paymentDetailPage.waitForjustaMomentLoadingToComplete(30, 2, 2);
            common.wait(2);
        }else {
            Assertions.assertThat(paymentDetailPage.getEnableSectionHeader("Set up your Direct Debit for").isDisplayed()).withFailMessage(
                            "  Set up your Direct Debit section not didsplayed.")
                    .isTrue();
        }

        switch (bankAccountDetail) {
            case "existing":
                if (paymentDetailPage.addedBankAccountDetails.isDisplayed()) {
                    this.logger.info("paymnet");
                    browser.setImplicitWait(5);
                    if(paymentDetailPage.validateButton.isEnabled())
                    {
                        paymentDetailPage.validateButton.waitUntil(clickable).clickJs();
                    }
                    boolean result = retry.retryAction(
                            () -> {
                                boolean checked = paymentDetailPage.checkBox.isDisplayed(2);
                                logger.info(" >> Check box found: " + checked);
                                return checked;
                            },
                            3, 2);
                    common.wait(2);
                     if(result)
                     {
                         paymentDetailPage.checkBox.waitUntil(enabled).clickJs();
                         paymentDetailPage.saveContinueBtn.waitUntil(displayed.and(enabled).and(present).and(clickable)).clickJs();
                         paymentDetailPage.waitForjustaMomentLoadingToComplete(30, 2, 2);
                     }
                     if(paymentDetailPage.validateButton.isEnabled())
                     {
                         paymentDetailPage.validateButton.waitUntil(clickable).clickJs();
                     }
                    paymentDetailPage.waitForjustaMomentLoadingToComplete(30, 2, 2);
                }

                if (paymentDetailPage.existingAccount.isDisplayed()) {
                    common.wait(2);
                    paymentDetailPage.validateButton.waitUntil(displayed.and(enabled).and(present).and(clickable)).clickJs();
                    paymentDetailPage.waitForjustaMomentLoadingToComplete(30, 2, 2);
                    paymentDetailPage.checkBox.waitUntil(displayed.and(enabled)).clickJs();
                    paymentDetailPage.saveContinueBtn.waitUntil(displayed.and(enabled).and(present).and(clickable)).clickJs();
                    paymentDetailPage.waitForjustaMomentLoadingToComplete(30, 2, 2);
                }
                if(paymentDetailPage.bankAccountHolder.isDisplayed()){
                    paymentDetailPage.bankAccountHolder.setValue(paymentDetail.accountHolderName);
                    paymentDetailPage.bankAccountNumber.setValue(paymentDetail.bankAccount);
                    paymentDetailPage.bankAccountHolderNickName.setValue(paymentDetail.accountNickName);
                    paymentDetailPage.sortCode.setValue(paymentDetail.bankSortCode);
                    paymentDetailPage.validateButton.waitUntil(displayed.and(enabled).and(present).and(clickable)).clickJs();
                    paymentDetailPage.checkBox.waitUntil(displayed.and(enabled)).clickJs();
                    paymentDetailPage.saveContinueBtn.waitUntil(displayed.and(enabled).and(present).and(clickable)).clickJs();
                }
                break;
            case "new":
                paymentDetailPage.bankAccountHolder.setValue(paymentDetail.accountHolderName);
                paymentDetailPage.bankAccountNumber.setValue(paymentDetail.bankAccount);
                paymentDetailPage.bankAccountHolderNickName.setValue(paymentDetail.accountNickName);
                paymentDetailPage.sortCode.setValue(paymentDetail.bankSortCode);
                paymentDetailPage.validateButton.click();
                paymentDetailPage.checkBox.click();
                paymentDetailPage.saveContinueBtn.click();
                break;
            default:
                throw new NotImplementedException(MessageFormat
                        .format("Option ''{0}'' for bank detail has not been implemented yet!", bankAccountType));
        }

        paymentDetailPage.waitForProcessLoadingToComplete(20, 2, 2);
        if(userType.equals("new")) {
            Assertions.assertThat(paymentDetailPage.getEnableSectionHeader(" ID check and upfront payment reservation ").isDisplayed()).withFailMessage(
                            " Could NOT save Set up your Direct Debit for data.")
                    .isTrue();
        }else{
            Assertions.assertThat(paymentDetailPage.getEnableSectionHeader("Credit check").isDisplayed()).withFailMessage(
                            " Could NOT save Set up your Direct Debit for data.")
                    .isTrue();
        }
        logger.info("** Bank Detail Retrieved!\n");
    }

    @And("^I verify all the payment information are correct$")
    public void i_verify_payment_information() {
        logger.info("** Payment detail page is loaded...");

        paymentDetailPage.waitForjustaMomentLoadingToComplete(30, 2, 2);
        browser.waitUntil(ajaxFinished);
        //new user: ID check and upfront payment reservation
        //  assertThat(paymentDetailPage.getEnableSectionHeader("Credit check").isDisplayed()).withFailMessage(
        //               " Credit check section not didsplayed.")
        //     .isTrue();
        if (paymentDetailPage.paymentDetailHeader.isDisplayed(5)) {
            PaymentDetail paymentDetail = (PaymentDetail) context.get("paymentDetail");
            browser.displayIframesInfo();
            browser.switchTo("Interface");
            common.waitForLoadingToComplete(5, 1);
            common.wait(4);
            paymentDetailPage.CardHolderName.waitUntil(displayed).setValue(paymentDetail.cardHolderName);
            paymentDetailPage.CardNumber.waitUntil(displayed).setValue(paymentDetail.cardPan);
            common.wait(6);
            paymentDetailPage.CardMonth.waitUntil(displayed).click();
            common.wait(2);
            paymentDetailPage.CardMonth.waitUntil(displayed).asSelect().selectByText(paymentDetail.cardExpiryMonth);
            common.wait(2);
            paymentDetailPage.CardYear.waitUntil(displayed).click();
            paymentDetailPage.CardYear.waitUntil(displayed).asSelect().selectByText(paymentDetail.cardExpiryYear);
            paymentDetailPage.SecurityCode.waitUntil(displayed).setValue(paymentDetail.cardCvv);
            common.wait(2);
            paymentDetailPage.onlineVerificationBtn.waitUntil(displayed.and(enabled).and(present).and(clickable)).click();
            browser.switchToDefault();

        }

        browser.waitUntil(ajaxFinished);
        paymentDetailPage.waitForProcessLoadingToComplete(30, 2, 2);
        common.wait(3);
        if (paymentDetailPage.confirmCostOfPlanCheckbox.isDisplayed(5)) {
            paymentDetailPage.confirmCostOfPlanCheckbox.waitUntil(displayed.and(enabled).and(clickable)).clickJs();
            paymentDetailPage.confirmNoChangesInCircumstancesCheckbox.waitUntil(displayed.and(enabled).and(clickable)).clickJs();
           common.wait(2);
            paymentDetailPage.creditCheckBtn.waitUntil(displayed.and(enabled).and(clickable)).clickJs();
        }
        if (paymentDetailPage.creditCheckBtn.isDisplayed(5)) {
            paymentDetailPage.creditCheckBtn.waitUntil(displayed.and(enabled).and(clickable)).clickJs();
        }
        paymentDetailPage.waitForProcessLoadingToComplete(30, 2, 2);
        paymentDetailPage.continueBtnAfterCreditCheck.waitUntil(displayed.and(enabled).and(clickable)).clickJs();

        boolean result = retry.retryAction(
                () -> {
                    int confirmBtns = paymentDetailPage.ConfirmBtn.asList().size();
                    logger.info(" >> Confirm Buttons found: " + confirmBtns);
                    return (confirmBtns == 3);
                },
                5, 2);
        common.wait(2);
        if (result) {
            paymentDetailPage.ConfirmBtn.asList().get(0).clickJs();
            common.wait(2);
            paymentDetailPage.ConfirmBtn.asList().get(1).clickJs();
            common.wait(2);
            paymentDetailPage.ConfirmBtn.asList().get(2).clickJs();
            common.wait(2);
        }
        common.wait(2);
        paymentDetailPage.waitForProcessLoadingToComplete(30, 2, 2);
        paymentDetailPage.moreOptionContinueBtn.waitUntil(displayed.and(enabled).and(clickable)).clickJs();
        paymentDetailPage.waitForProcessLoadingToComplete(30, 2, 2);
        

        if( paymentDetailPage.moreOptionContinueBtn.isDisplayed()) {
            paymentDetailPage.moreOptionContinueBtn.waitUntil(displayed.and(enabled).and(clickable)).clickJs();
            paymentDetailPage.waitForProcessLoadingToComplete(30, 2, 2);
        }
        if( paymentDetailPage.confirmContinueBtn.isDisplayed()) {
            paymentDetailPage.confirmContinueBtn.waitUntil(displayed.and(enabled).and(clickable)).clickJs();
        }
        paymentDetailPage.waitForProcessLoadingToComplete(30, 2, 2);

    }
}
