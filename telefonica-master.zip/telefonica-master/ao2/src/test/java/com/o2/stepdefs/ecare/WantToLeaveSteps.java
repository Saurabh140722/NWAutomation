package com.o2.stepdefs.ecare;

import static org.assertj.core.api.Assertions.assertThat;

import com.google.inject.Inject;
import com.nttdata.cinnamon.driver.Browser;
import com.o2.pages.ecare.WantToLeavePage;
import com.o2.stepdefs.BaseStep;
import com.o2.core.util.Common;

import io.cucumber.java.en.Then;

public class WantToLeaveSteps extends BaseStep {
	private final WantToLeavePage wantToLeavePage;
	private final Browser browser;
	private final Common common;

	@Inject
	public WantToLeaveSteps(final WantToLeavePage wantToLeavePage, final Browser browser, final Common common) {
		this.wantToLeavePage = wantToLeavePage;
		this.browser = browser;
		this.common = common;
	}

	@Then("Want to leave page opens successfully")
	public void want_to_leave_page_opens_successfully() {
		this.logger.info("** Waiting for Want to leave page to open ...");

		assertThat(this.wantToLeavePage.isPageDisplayed(90)).withFailMessage("Want to leave page not displayed!")
				.isTrue();

		this.logger.info("** Want to leave page opens!");
	}

}
