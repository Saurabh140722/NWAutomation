package com.o2.stepdefs.ecare;

import static org.assertj.core.api.Assertions.assertThat;

import com.google.inject.Inject;
import com.nttdata.cinnamon.driver.Browser;
import com.o2.pages.ecare.SwitchTariffPage;
import com.o2.stepdefs.BaseStep;
import com.o2.core.util.Common;

import io.cucumber.java.en.Then;

public class SwitchTariffSteps extends BaseStep {
	private final SwitchTariffPage switchTariffPage;
	private final Browser browser;
	private final Common common;

	@Inject
	public SwitchTariffSteps(final SwitchTariffPage switchTariffPage, final Browser browser, final Common common) {
		this.switchTariffPage = switchTariffPage;
		this.browser = browser;
		this.common = common;
	}

	@Then("Switch Tariff  page opens successfully")
	public void switch_tariff_page_opens_successfully() {
		this.logger.info("** Waiting for Switch Tariff page to open ...");

		assertThat(this.switchTariffPage.isPageDisplayed(90)).withFailMessage(" Switch Tariff page not displayed!")
				.isTrue();

		this.logger.info("** Switch Tariff page opens!");
	}

}
