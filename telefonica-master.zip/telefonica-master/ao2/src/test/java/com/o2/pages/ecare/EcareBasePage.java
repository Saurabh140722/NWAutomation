package com.o2.pages.ecare;

import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.o2.pages.BasePage;

public class EcareBasePage extends BasePage {
	public PageElement getTab(String tabName) {
		return this.browser.findBy(By.XPath, "//*[@role='tab']//*[text()='" + tabName + "']");
	}

	public PageElement getButton(String buttonName) {
		return this.browser.findBy(By.XPath, "//*[@role='button']//*[text()=' " + buttonName + " ']");
	}

	public PageElement getHeader(String pageHeader) {
		return this.browser.findBy(By.XPath, "//h1[text()=' " + pageHeader + " ']");
	}

	@Find(by = By.XPath, locator = "//h1[contains(@class,'o2uk-header-curve__text-title')]")
	public PageElement pageTitle;
}
