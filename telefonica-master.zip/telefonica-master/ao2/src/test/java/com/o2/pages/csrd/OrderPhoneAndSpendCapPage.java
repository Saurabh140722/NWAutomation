package com.o2.pages.csrd;

import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.FindByKey;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.nttdata.cinnamon.driver.controls.PageElementCollection;
import com.o2.pages.BasePage;

import java.text.MessageFormat;

import static com.nttdata.cinnamon.wait.ElementConditions.displayed;

public class OrderPhoneAndSpendCapPage extends BasePage {
    private String phoneNumberPageElementLocator = "gwt-uid-{0}_input";
    private String phoneNumberContainerLocator = "gwt-uid-{0}_div";
    private String id = "NOT_PROCESSED_BY_AUTOMATION";

//    @Find(by = By.Id, locator = "gwt-uid-1905_input")
//    public PageElement phoneNumberPageElement;
//
//    @Find(by = By.Id, locator = "gwt-uid-1905_div")
//    public PageElement phoneNumberContainer;

    @Find(by = By.CssSelector, locator = ".characteristicValues.characteristic-invalid-change")
    public PageElement phoneNumberInputText;

    @Find(by = By.CssSelector, locator = "#nc_refsel_list > div.refsel_table_holder.ps-container.ps-theme-default")
    public PageElement phoneNumbersListRoot;

    @Find(by = By.Id, locator = "listCharacteristicsSelect_9156572418065211705")
    public PageElement spendCap;

    @Find(by = By.Id, locator = "gwt-uid-4054_input")
    public PageElement sim;

    @Find(by = By.CssSelector, locator = ".gwt-PopupPanel.loader")
    public PageElement processIcon;

    @Find(by = By.XPath, locator = "//span[contains(text(),'Show')]")
    public PageElement showIcon;

    @FindByKey(key ="monthInputBox")
    public PageElement monthInputBox;

    @Find(by = By.XPath, locator = "//span[@class='ui-spinner ui-corner-all ui-widget ui-widget-content']/input")
    public PageElementCollection avilablePerksCount;

    @Find(by = By.XPath, locator = "//div[@class='offer_tree_wrapper']//div[@class='offer_tree_wrapper']//div[@class='roe-table-body offer_tree_tbody']//tr[@class='no_top_border roe-table-row child-element-firstrow']//td[@class='roe-table-cell']//div[@class='expand-btn-container']//input[@class='checkbox']")
    public PageElementCollection allCheckBox;

    @Find(by = By.CssSelector, locator = ".ui-dialog-content")
    public PageElement dialogError;

    

    @Override
    public PageElement getPageCheckElement() {
        /*
        It seems this id keeps changing from 1887 to 1905. We'll try when checking if page has loaded to see
        which one is displayed on the page
         */

//        List<String> list = Arrays.asList("1887", "1905", "1907", "1906");
//        PageElement pe = null;
//        for (String elem : list) {
//            this.browser.setImplicitWait(5);
//
//            pe = this.browser.findBy(By.Id,
//                    MessageFormat.format(phoneNumberPageElementLocator, elem));
//            if (pe != null) {
//                this.id = elem;
//                break;
//            }
//        }
//
//        this.browser.restoreImplicitWait();
//        return pe;
        return this.spendCap;
    }

    public PageElement getPhoneNumberPageElement() {
        PageElementCollection divList = this.browser.findAllBy(By.CssSelector, ".refsel_single");
       //ad2
        // PageElement divParent = divList.asList().get(4);
       //ad1
        PageElement divParent = divList.asList().get(5);
        PageElement dp = divParent;

        return divParent.findChild(By.Tag, "input");
//        return this.browser.findBy(By.Id, MessageFormat.format(phoneNumberPageElementLocator, this.id));
    }

    public PageElement getPhoneNumberPageElementonpaym4uat() {
        PageElementCollection divList = this.browser.findAllBy(By.CssSelector, ".refsel_single");
        //ad2
        // PageElement divParent = divList.asList().get(4);
        //ad1
        PageElement divParent = divList.asList().get(1);
        PageElement dp = divParent;

        return divParent.findChild(By.Tag, "input");
//        return this.browser.findBy(By.Id, MessageFormat.format(phoneNumberPageElementLocator, this.id));
    }

    public PageElement getPhoneNumberContainer() {
        return this.browser.findBy(By.Id, MessageFormat.format(phoneNumberContainerLocator, this.id));
    }

    public PageElement getPhoneNumber() {
        PageElementCollection divList = this.browser.findAllBy(By.CssSelector, ".refsel_single");
        //ad2
        // PageElement divParent = divList.asList().get(4);

        //ad1
        PageElement divParent = divList.asList().get(5);
        // 5th element

//        PageElement phoneNoArrow = this.getPhoneNumberContainer().findChild(By.CssSelector, ".refsel_arrow");
        PageElement phoneNoArrow = divParent.findChild(By.CssSelector, ".refsel_arrow");
        phoneNoArrow.click();

        return this.phoneNumbersListRoot.waitUntil(displayed).findChild(By.CssSelector, ".refsel_row");
    }

    public PageElement getPhoneNumberonPaym4Uat() {
        PageElementCollection divList = this.browser.findAllBy(By.CssSelector, ".refsel_single");
        //ad2
        // PageElement divParent = divList.asList().get(4);

        //ad1
        PageElement divParent = divList.asList().get(1);
        // 5th element

//        PageElement phoneNoArrow = this.getPhoneNumberContainer().findChild(By.CssSelector, ".refsel_arrow");
        PageElement phoneNoArrow = divParent.findChild(By.CssSelector, ".refsel_arrow");
        phoneNoArrow.click();

        return this.phoneNumbersListRoot.waitUntil(displayed).findChild(By.CssSelector, ".refsel_row");
    }
}
