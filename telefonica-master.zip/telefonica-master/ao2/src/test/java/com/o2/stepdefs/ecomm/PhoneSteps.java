package com.o2.stepdefs.ecomm;

import com.google.inject.Inject;
import com.nttdata.cinnamon.cache.Context;
import com.nttdata.cinnamon.driver.Browser;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.nttdata.cinnamon.webdriver.util.ReadyState;
import com.o2.pages.ecomm.PhonePage;

import com.o2.util.Common;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.assertj.core.api.Assertions;
import org.openqa.selenium.Keys;

import java.text.MessageFormat;
import java.util.List;
import java.util.Map;

import static com.nttdata.cinnamon.wait.ElementConditions.*;
import static com.nttdata.cinnamon.wait.conditions.Conditions.ajaxFinished;
import static com.nttdata.cinnamon.wait.conditions.Conditions.readyState;
import static org.assertj.core.api.Assertions.assertThat;

public class PhoneSteps extends BaseStep {

    private final Context context;
    private final PhonePage phonePage;
    private final Browser browser;
    private final Common common;
    public static List<PageElement> devicePhoneCardsPE;


    @Inject
    public PhoneSteps(final Context context, final PhonePage phonePage, Browser browser, Common common) {
        this.context = context;
        this.phonePage = phonePage;
        this.browser = browser;
        this.common = common;

    }

    @When("I filter by {string} Phone and list of ApplePhones are displayed")
    public void I_Filter_By_Phone_And_List_Of_ApplePhones_Are_Displayed(String phoneBrand) {
        browser.setImplicitWait(15);
        phonePage.shopButton.hover();
        phonePage.phoneButton.click();
        Assertions.assertThat(phonePage.phoneHeader.isDisplayed())
                .withFailMessage("Phone Header not displayed")
                .isTrue();
        phonePage.phoneNAirtimeTab.clickJs();
        filterPhoneByBrand(phoneBrand);
    }

    public void filterPhoneByBrand(String phoneBrandTemp) {
        browser.setImplicitWait(20);
        phonePage.filterByTab.waitUntil(displayed).clickJs();
        phonePage.filterByBrand.clickJs();
        phonePage.filterByBrandApple.clickJs();
        browser.restoreImplicitWait();
        browser.setImplicitWait(30);
        phonePage.filterByTab.waitUntil(displayed).clickJs();
        logger.info("Phone Brand Filtered: " + phoneBrandTemp);
    }

    @When("I select ApplePhone with {string}, {string}, {string} and {string}")
    public void I_Select_Apple_Phone_With(String phoneModel, String upfrontCost, String upfrontCostPlusCharge, String amountInfoMonthly) {
        browser.setImplicitWait(20);
        devicePhoneCardsPE = phonePage.deviceCardItems.asList();
        for (int i = 0; i < devicePhoneCardsPE.size(); i++) {
            String deviceModelTemp = phonePage.deviceCardBrandModel.asList().get(i).getText().trim();
            String devieUpfrontCosttemp = phonePage.devicePriceUpfront.asList().get(i).getText().trim();
            String deviceUpfrontCostPlusChargeTemp = phonePage.devicePriceUpfrontCost.asList().get(i).getText().trim();
            String deviceAmtInfoMonthlyTemp = phonePage.deviceAmountInfoMonthly.asList().get(i).getText().trim();
            if (deviceModelTemp.equalsIgnoreCase(phoneModel) && (devieUpfrontCosttemp.equalsIgnoreCase(upfrontCost)) &&
                    (deviceUpfrontCostPlusChargeTemp.equalsIgnoreCase(upfrontCostPlusCharge)) &&
                    (deviceAmtInfoMonthlyTemp.equalsIgnoreCase(amountInfoMonthly))) {
                phonePage.deviceCardBrandModel.get(i).click();
                break;
            }
        }
    }

    @When("I check whether selected phone is in stock or not")
    public void ICheck_Whether_Selected_Phone_Is_In_Stock_Or_Not() {
        if (phonePage.stockStatusInStock.isDisplayed()) {
            logger.info("Phone Stock Message:- Selected Phone is in Stock.");
        }
    }

    @And("If phone is in stock, I select required plan for the phone")
    public void If_Phone_Is_In_Stock_I_Select_Required_Plan_For_The_Phone() {
    }


    @Then("^I add the phone with:$")
    public void i_add_the_phone_With(DataTable table) {
        logger.info("** Attempt to select Phone  ...");
        List<Map<String, String>> data = table.asMaps(String.class, String.class);
        String phoneBrand = data.get(0).get("phoneBrand").toUpperCase();
        String phoneModel = data.get(0).get("phoneModel");
        phonePage.waitForProcessLoadingToComplete(20, 2, 2);
        browser.refresh();
        this.browser.waitUntil(readyState(ReadyState.COMPLETE));
        String searchText = phoneBrand + " " + phoneModel;
        browser.setImplicitWait(2);
        if (phonePage.searchBox.waitUntil(displayed).isDisplayed()) {
            logger.info(" ++++++++++++ PHONE SEARCH BOX DISPLAYED!");
        } else {
            logger.info(" ++++++++++++ PHONE SEARCH BOX NOT DISPLAYED!");
        }
        if (phonePage.searchBox.isEnabled()) {
            logger.info(" ++++++++++++ PHONE SEARCH BOX ENABLED!");
        } else {
            logger.info(" ++++++++++++ PHONE SEARCH BOX NOT ENABLED!");
        }
        if (phonePage.searchBox.isPresent()) {
            logger.info(" ++++++++++++ PHONE SEARCH BOX PRESENT!");
        } else {
            logger.info(" ++++++++++++ PHONE SEARCH BOX NOT PRESENT!");
        }
        phonePage.searchBox.waitUntil(displayed.and(enabled).and(present).and(clickable)).clickJs();
        phonePage.searchBox.setValue(searchText);
        phonePage.searchBox.setValue(Keys.ENTER);
        browser.waitUntil(ajaxFinished);
        browser.setImplicitWait(5);
        browser.refresh();
        this.browser.waitUntil(readyState(ReadyState.COMPLETE));
        boolean found = false;
        List<PageElement> phone = phonePage.phoneDetails.asList();
        assertThat(phone.size())
                .withFailMessage("Could not find any matching phone!")
                .isPositive();

        int totalPhone = phone.size();
        this.logger.info("totalPhone:" + totalPhone);

        for (int i = 0; i < totalPhone; i++) {
            if (phone.get(i).getText().replace("\n", " ").equals(searchText)) {
                logger.info(MessageFormat.format("Phone found: {0}", searchText));
                phone.get(i).clickJs();
                found = true;
                break;
            }
        }

        assertThat(found).withFailMessage(
                        MessageFormat.format(
                                "Could not find a phone with : ''{0}''", searchText))
                .isTrue();
        this.context.set("phone", searchText);
        this.browser.waitUntil(readyState(ReadyState.COMPLETE));
        this.browser.setImplicitWait(3);
        this.logger.info(MessageFormat.format(
                "*** Select the ''{0}'' phone is completed.... ", searchText));
        this.common.wait(8);
    }
}



