package com.o2.pages.csrd;

import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.o2.pages.BasePage;

public class ResidentialAccountPage extends BasePage {
	@Find(by = By.Id, locator = "ui-id-2")
	public PageElement dialogWindowTitle;

	@Find(by = By.Id, locator = "ui-id-1")
	public PageElement residentialAccountFormRoot;

	@Find(by = By.Id, locator = "7030151465013152905")
	public PageElement title;

	@Find(by = By.Id, locator = "9134308937713187961")
	public PageElement dob; // dd/MM/yyyy

	@Find(by = By.XPath, locator = "//*[@id=\"ui-id-1\"]/div/div[3]/table/tbody/tr/td/div/form/table/tbody/tr/td/table/tbody/tr[9]/td[2]/div/table/tbody/tr/td/div/div/table/tbody/tr[2]/td/table/tbody/tr/td[3]/div")
	public PageElement mobileContainer;

	@Find(by = By.CssSelector, locator = ".gwt-TextBox.jbss_text_box.focused-content")
	public PageElement mobile;

	@Find(by = By.Id, locator = "button_9134601663813204193")
	public PageElement addAddressButton;

	@Find(by = By.CssSelector, locator = ".gwt-Button.button_action_id_9136012684613239620_9136014890013240258_compositepopup_1.TableCtrl-button.ParCtr-saveButton")
	public PageElement createButton;

	public PageElement getFirstName() {
		return this.residentialAccountFormRoot.findChild(By.Id, "9134256876313157625");
	}

	public PageElement getLastName() {
		return this.residentialAccountFormRoot.findChild(By.Id, "9134256876313157627");
	}
}
