package com.o2.models.ecomm;

import com.nttdata.cinnamon.driver.controls.PageElement;

public class Extra {
    public PageElement title;
    public PageElement price;
    public PageElement addExtra;

    public Extra(PageElement title, PageElement price, PageElement addExtra) {
        this.title = title;
        this.price = price;
        this.addExtra = addExtra;
    }
}
