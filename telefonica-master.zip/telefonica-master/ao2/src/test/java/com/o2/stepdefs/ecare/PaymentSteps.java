package com.o2.stepdefs.ecare;

import com.google.inject.Inject;
import com.nttdata.cinnamon.cache.Context;
import com.nttdata.cinnamon.driver.Browser;
import com.o2.core.util.Common;
import com.o2.core.util.Retry;
import com.o2.pages.ecare.EcareBasePage;
import com.o2.pages.ecare.PaymentPage;
import com.o2.stepdefs.BaseStep;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

import static com.nttdata.cinnamon.wait.ElementConditions.*;
import static com.nttdata.cinnamon.wait.conditions.Conditions.readyState;
import static org.assertj.core.api.Assertions.assertThat;

import com.nttdata.cinnamon.webdriver.util.ReadyState;

public class PaymentSteps  extends BaseStep {
    private final Common common;
    private final Browser browser;
    private final PaymentPage paymentPage;
    private final EcareBasePage ecareBasePage;
    private final Retry retry;

    @Inject
    public PaymentSteps(final Browser browser, final Common common, final Context context, final PaymentPage paymentPage, final EcareBasePage ecareBasePage,final Retry retry) {
        this.paymentPage = paymentPage;
        this.browser = browser;
        this.common = common;
        this.ecareBasePage = ecareBasePage;
        this.retry = retry;
    }
    @When("I add payment card and setup direct debit")
    public void i_add_payment_card_and_setup_direct_debit() {
        this.logger.info("*Attempt to add payment card and setup direct debit...");
        this.browser.waitUntil(readyState(ReadyState.COMPLETE));

        //remove the added card
        if(paymentPage.addedCardSection.isDisplayed(5))
        {
            paymentPage.removeCardLink.waitUntil(displayed.and(clickable)).clickJs();
            paymentPage.waitForProcessLoadingToComplete(20,3,3);
            assertThat(paymentPage.removeCardPopUp.isDisplayed()).withFailMessage("Remove card pop up is  not displayed!")
                    .isTrue();

            ecareBasePage.getButton("Remove card").waitUntil(displayed.and(clickable)).clickJs();
            paymentPage.waitForProcessLoadingToComplete(20,3,3);
            assertThat(!(paymentPage.removeCardLink.isDisplayed())).withFailMessage("Could not Remove the added card !")
                    .isTrue();

        }
       /* ecareBasePage.getButton("Add a payment card").waitUntil(displayed.and(clickable)).clickJs();
        if(paymentPage.addNewCardPopUp.isDisplayed(5))
        {

            browser.displayIframesInfo();
            browser.switchTo("Interface");
            paymentPage.waitForProcessLoadingToComplete(20,5,5);
            common.wait(2);
            paymentPage.cardName.waitUntil(displayed.and(enabled)).setValue("Test");
            paymentPage.cardNumber.waitUntil(displayed.and(enabled)).setValue("4546380000000009");
            common.wait(2);
            paymentPage.expiryDateMonthInput.waitUntil(displayed.and(enabled)).asSelect().selectByText("03");
            common.wait(2);
            paymentPage.expiryDateYearInput.waitUntil(displayed.and(enabled)).asSelect().selectByText("2025");
            common.wait(2);
            paymentPage.cvv.waitUntil(displayed.and(enabled)).setValue("242");
            common.wait(2);
            paymentPage.registerCard.waitUntil(displayed.and(enabled).and(clickable)).clickJs();
            browser.switchToDefault();

            paymentPage.waitForProcessLoadingToComplete(20,3,3);

            ecareBasePage.getButton("Go back to payment preferences").waitUntil(displayed.and(enabled).and(clickable)).clickJs();
            paymentPage.waitForProcessLoadingToComplete(20,3,3);
            assertThat(paymentPage.addedCardNumber.isDisplayed()).withFailMessage("Remove card pop up is  not displayed!")
                    .isTrue();

        }*/
        if(paymentPage.addedDirectDebitCard.isDisplayed())
        {
            if(!(paymentPage.deactivatedDirectDebitText.isDisplayed(5))) {
                paymentPage.expansionDirectDebitCard.waitUntil(displayed.and(clickable)).clickJs();
                paymentPage.removeDirectDebitCard.clickJs();
                paymentPage.waitForProcessLoadingToComplete(5, 3, 3);
                ecareBasePage.getButton("Continue").waitUntil(displayed.and(clickable)).clickJs();

                assertThat(paymentPage.deactivatedDirectDebitText.isDisplayed(5)).withFailMessage(" Deactivated Direct Debit text is  not displayed!")
                        .isTrue();
            }

        }

        ecareBasePage.getButton("Set up a Direct Debit").waitUntil(displayed.and(clickable)).clickJs();
        if(paymentPage.newAccountTab.isDisplayed(5))
        {
            paymentPage.newAccountTab.clickJs();
        }
        if( paymentPage.accountHolder.isDisplayed())
        {
            paymentPage.accountHolder.setValue("Sanity test");
            paymentPage.accountNumber.setValue("10207136");
            paymentPage.sortCode.setValue("201596");

            //if no card added previously

            if(ecareBasePage.getButton("Validate account").isEnabled())
            {
                ecareBasePage.getButton("Validate account").clickJs();
            }

            if(paymentPage.directDebitCheckBox.isDisplayed())
            {
                paymentPage.directDebitCheckBox.clickJs();
                ecareBasePage.getButton("Save and continue").waitUntil(displayed.and(clickable)).clickJs();

            }

            paymentPage.waitForProcessLoadingToComplete(5,3,3);
            assertThat(paymentPage.newDirectDebitPopup.isDisplayed()).withFailMessage("New Direct Debit pop up is  not displayed!")
                    .isTrue();
            ecareBasePage.getButton("Go back to payment preferences").waitUntil(displayed.and(clickable)).clickJs();


        }
    }

    @Then("I can see payment detail of non billable and billable amount")
    public void i_can_see_payment_detail_of_non_billable_and_billable_amount() {
        assertThat(paymentPage.billableAmount.isDisplayed())
                .withFailMessage("Payment detail for billable amount is not displayed!").isTrue();
        paymentPage.paymentStatus.waitUntil(displayed).click();
        this.common.wait(5);
        assertThat(paymentPage.nonBillableAmount.isDisplayed())
                .withFailMessage("Payment detail for Non billable amount is not displayed!").isTrue();
    }
    }