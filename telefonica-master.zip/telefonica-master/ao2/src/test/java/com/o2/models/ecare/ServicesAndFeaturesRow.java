package com.o2.models.ecare;

import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.controls.PageElement;

import static org.assertj.core.api.Assertions.assertThat;

public class ServicesAndFeaturesRow {
    public PageElement name;

    public ServicesAndFeaturesRow(PageElement tableRow) {
        PageElement element = tableRow.findChild(By.CssSelector, ".roe-table-cell.name");

        assertThat(element)
                .withFailMessage("Could not find the element that holds option name!")
                .isNotNull();

        this.name = element;
    }
}
