package com.o2.pages.ecare;

import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;

public class EditContactDetailsPage extends EcareBasePage {
	@Find(by = By.Id, locator = "account_change_contact_mobile")
	public PageElement changeMobile;

	@Find(by = By.Id, locator = "msisdn")
	public PageElement newMobileNumber;

	@Find(by = By.Id, locator = "sendOTAC")
	public PageElement sendOTAC;

	@Find(by = By.Id, locator = "otac")
	public PageElement otacInputBox;

	@Find(by = By.Id, locator = "continue")
	public PageElement continueBtn;

	@Override
	protected PageElement getPageCheckElement() {
		return this.changeMobile;
	}
}
