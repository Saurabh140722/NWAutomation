package com.o2.stepdefs.ecomm;

import com.google.inject.Inject;
import com.nttdata.cinnamon.cache.Context;
import com.nttdata.cinnamon.driver.Browser;
import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.nttdata.cinnamon.driver.controls.PageElementCollection;
import com.nttdata.cinnamon.webdriver.util.ReadyState;
import com.o2.models.ecomm.Tariffs;
import com.o2.pages.ecomm.EcommBasePage;
import com.o2.pages.ecomm.TariffsPage;
import com.o2.util.Common;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Then;
import org.apache.commons.lang.NotImplementedException;
import org.assertj.core.api.Assertions;

import java.text.MessageFormat;
import java.util.List;
import java.util.Map;

import static com.nttdata.cinnamon.wait.ElementConditions.*;
import static com.nttdata.cinnamon.wait.ElementConditions.clickable;
import static com.nttdata.cinnamon.wait.conditions.Conditions.ajaxFinished;
import static com.nttdata.cinnamon.wait.conditions.Conditions.readyState;
import static org.assertj.core.api.Assertions.assertThat;

public class TraffisSteps extends BaseStep {
    private final Browser browser;
    private final TariffsPage tariffsPage;
    private final EcommBasePage ecommBasePage;
    private final Context context;
    private final Common common;

    @Inject
    public TraffisSteps(Browser browser, TariffsPage tariffsPage, EcommBasePage ecommBasePage, Context context, Common common) {
        this.browser = browser;
        this.tariffsPage = tariffsPage;
        this.ecommBasePage = ecommBasePage;
        this.context = context;
        this.common = common;
    }


    @Then("^I add the Sim only plan with :$")
    public void i_add_the_sim_only_plan_withheSimOnlyPlanWith(DataTable table) {
        this.logger.info("** Attempt to select Tarrif  ...");
        List<Map<String, String>> data = table.asMaps(String.class, String.class);

        String dviceType = data.get(0).get("deviceType");
        String plan = data.get(0).get("choosePlan");
        browser.refresh();
        this.browser.waitUntil(readyState(ReadyState.COMPLETE));
        Assertions.assertThat(this.tariffsPage.pageTitle.isDisplayed(2))
                .withFailMessage("Pay Monthly sim deals page NOT loaded..")
                .isTrue();

       // this.ecommBasePage.getTab(dviceType).waitUntil(displayed.and(enabled).and(clickable)).clickJs();
      //  this.browser.waitUntil(ajaxFinished);

        if (this.tariffsPage.viewAllResultsBtn.isDisplayed()) {
           this.tariffsPage.viewAllResultsBtn.clickJs();
        }
        this.browser.waitUntil(ajaxFinished);

        Tariffs tarrif = this.tariffsPage.getAllTariffs().stream()
                .filter(u -> u.title.getText().trim().equals(plan))
                .findFirst()
                .orElse(null);

        Assertions.assertThat(tarrif).withFailMessage(
                        MessageFormat.format(
                                "Could not find a Tarrif with name: ''{0}''", plan))
                .isNotNull();

        this.context.set("Plan", tarrif);
        this.context.set("PlanName", plan);
        tarrif.addBasket.waitUntil(displayed.and(enabled).and(present).and(clickable)).clickJs();
        this.tariffsPage.waitForjustaMomentLoadingToComplete(3,2,6);
        this.logger.info("** traffi***" + tarrif.title.toString());
        //TODO check build package page is displayed, extra's, instead of extra page directly going to your details page
        if(tariffsPage.haveOrderInProgress.isDisplayed()){
//            tariffsPage.haveOrderInProgressCloseButton.clickJs();
            tariffsPage.finishCheckingout.clickJs();
        }
    }

    @Then("^I add the Sim only plan with  plan description:$")
    public void i_add_the_sim_only_plan_with_desciptionheSimOnlyPlanWith(DataTable table) {
        this.logger.info("** Attempt to select Tarrif  ...");
        List<Map<String, String>> data = table.asMaps(String.class, String.class);
        String dviceType = data.get(0).get("deviceType");
        String plan = data.get(0).get("choosePlan");

        String planDescription = data.get(0).get("planDescription");
        Assertions.assertThat(this.ecommBasePage.getTab(dviceType).isDisplayed())
                .withFailMessage(
                        MessageFormat.format("Could not find a  dive Type  On whose name is: ''{0}''!",
                                dviceType)).isTrue();

        this.ecommBasePage.getTab(dviceType).waitUntil(displayed.and(clickable)).clickJs();
        this.browser.setImplicitWait(10);

        if (this.tariffsPage.viewAllResultsBtn.isDisplayed()) {
            tariffsPage.viewAllResultsBtn.waitUntil(clickable).clickJs();
        }
        browser.refresh();
        this.browser.waitUntil(readyState(ReadyState.COMPLETE));
        Tariffs tarrif;
        if(planDescription.equals("All of our tariffs are 5G ready"))
        {
            tarrif = this.tariffsPage.getAll5GTariffs().stream()
                    .filter(u -> u.title.getText().trim().equals(plan) && u.description.get(0).getText().trim().contains(planDescription))
                    .findFirst()
                    .orElse(null);

        }else{
            tarrif = this.tariffsPage.getAllTariffs().stream()
                    .filter(u -> u.title.getText().trim().equals(plan) && u.description.get(1).getText().trim().contains(planDescription))
                    .findFirst()
                    .orElse(null);

        }


        Assertions.assertThat(tarrif).withFailMessage(
                        MessageFormat.format(
                                "Could not find a Tarrif with name: ''{0}' '{1}''", plan, planDescription))
                .isNotNull();
        this.context.set("Plan", tarrif);
        this.context.set("PlanName", plan);
        tarrif.addBasket.click();
        this.browser.waitUntil(readyState(ReadyState.COMPLETE));
        this.logger.info("**" + plan + "tarrif plan selected...");
    }

    @Then("^I sort data  as (.*)$")
    public void i_sort_data_by(String sortBy) {
        this.common.wait(3);
        this.tariffsPage.sortByLinkUAT2.waitUntil(displayed).click();
        PageElementCollection titleName = this.tariffsPage.sortByRadioBtnGroup.findChildren(By.CssSelector, "o2uk-sort__option-title");
        PageElementCollection radioBtnGroup = this.tariffsPage.sortByRadioBtnGroup.findChildren(By.CssSelector, ".o2uk-radio-button");
        for (PageElement title : titleName.asList()) {
            if (title.getText().contains(sortBy)) {
                switch (sortBy) {
                    case "Top picks":
                        radioBtnGroup.asList().get(1).waitUntil(displayed).scrollIntoView().click();
                        this.common.wait(2);
                        this.tariffsPage.sortByLink.waitUntil(displayed).click();
                        this.tariffsPage.traffiCards.size();
                        break;
                    case "Contract length":
                        radioBtnGroup.asList().get(2).waitUntil(displayed).scrollIntoView().clickJs();
                        this.common.wait(2);
                        this.tariffsPage.sortByLink.waitUntil(displayed).click();
                        this.tariffsPage.traffiCards.size();
                        radioBtnGroup.asList().get(3).waitUntil(displayed).scrollIntoView().clickJs();
                        break;
                    case "Monthly cost":
                        radioBtnGroup.asList().get(4).scrollIntoView().clickJs();
                        this.common.wait(2);
                        this.tariffsPage.sortByLink.waitUntil(displayed).scrollIntoView().clickJs();
                        radioBtnGroup.asList().get(5).click();
                        break;

                    case "Monthly data":
                        radioBtnGroup.asList().get(6).scrollIntoView().clickJs();
                        this.common.wait(2);
                        this.tariffsPage.sortByLink.waitUntil(displayed).scrollIntoView().clickJs();
                        radioBtnGroup.asList().get(7).click();
                        break;

                    default:
                        throw new NotImplementedException(MessageFormat
                                .format("Option ''{0}'' sort by is not found!", sortBy));
                }
            }
        }

    }

}
