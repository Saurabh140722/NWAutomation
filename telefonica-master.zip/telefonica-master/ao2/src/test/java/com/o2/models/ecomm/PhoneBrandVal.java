package com.o2.models.ecomm;

import java.text.MessageFormat;

public class PhoneBrandVal {
    public String phoneBrand;
    public String phoneModel;
    public String amountCurrency;
    public String phoneUpfrontcost;
    public String phoneUpfrontcostPlusCharge;
    public String phoneAmountInfoMonthly;
    public String deviceCardPlan1;
    public String deviceCardPlan2;


    @Override
    public String toString() {
        return MessageFormat.format("Login eComm User:" +
                        "\n\tPhoneBrand:\t\t\t{0}" +
                        "\n\tPhoneModel:\t\t{1}" +
                        "\n\tAmountCurrency:\t\t{2}" +
                        "\n\tPhoneUpfrontcost:\t\t\t{3}" +
                        "\n\tPhoneUpfrontcostPlusCharge:\t\t\t{4}" +
                        "\n\tPhoneAmountInfoMonthly:\t\t{5}" +
                        "\n\tDeviceCardPlan1:\t\t{6}" +
                        "\n\tDeviceCardPlan2:\t\t\t{7}",

                this.phoneBrand,
                this.phoneModel,
                this.amountCurrency,
                this.phoneUpfrontcost,
                this.phoneUpfrontcostPlusCharge,
                this.phoneAmountInfoMonthly,
                this.deviceCardPlan1,
                this.deviceCardPlan2
        );
    }
}

