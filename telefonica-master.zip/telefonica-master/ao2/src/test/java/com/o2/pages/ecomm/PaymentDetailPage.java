package com.o2.pages.ecomm;

import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.nttdata.cinnamon.driver.controls.PageElementCollection;

public class PaymentDetailPage extends BasePage {
    @Find(by = By.XPath, locator = "//h1[contains(@class,'checkout-header__title_text')]")
    public PageElement pageTitle;


    public PageElement getEnableSectionHeader(String sectionName) {
        return this.browser.findBy(By.XPath, "//o2uk-step-header[@aria-selected='true']//*[contains(text(),'" + sectionName + "')]");
    }


    @Find(by = By.XPath, locator = "//o2uk-step-header[@aria-selected='true']//h2//p")
    public PageElement enableSectionHeader;

    @Find(by = By.XPath, locator = "//*[@class='monthly-bank-info']")
    public PageElement addedBankAccountDetails;

    public PageElement getEditButton(String sectionName) {
        return this.browser.findBy(By.XPath, "//button[contains(@aria-label,'Edit '" + sectionName + "')]");
    }

    @Find(by = By.XPath, locator = "//span[contains(text(),'Existing account')]")
    public PageElement existingAccount;

    @Find(by = By.XPath, locator = "//span[contains(text(),'Send Contract Info & Summary')]")
    public PageElement sendContractInfoBtn;

    @Find(by = By.XPath, locator = "//h2[contains(text(),' Credit check ')]")
    public PageElement creditCheckHeader;

    @Find(by = By.XPath, locator = " //button[@type='button']//span[contains(text(),' Continue with credit check ')]")
    public PageElement creditCheckBtn;

    @Find(by = By.XPath, locator = "//div[contains(@class,'payment__button')]//button//span[contains(text(),' Continue ')]")
    public PageElement continueBtnAfterCreditCheck;

    @Find(by = By.XPath, locator = "//span[contains(text(),' Confirm ')]")
    public PageElementCollection ConfirmBtn;

    @Find(by = By.XPath, locator = "//span[contains(text(),' Continue ')]")
    public PageElement moreOptionContinueBtn;

    @Find(by = By.XPath, locator = "//button[@type='button']/span[contains(text(),' Confirm and continue ')]")
    public PageElement confirmContinueBtn;

    @Find(by = By.XPath, locator = "//input[@placeholder='As displayed on your account']")
    public PageElement bankAccountHolder;

    @Find(by = By.XPath, locator = "//input[@placeholder='00-00-00']")
    public PageElement sortCode;

    @Find(by = By.XPath, locator = "//input[@placeholder='8 numbers long']")
    public PageElement bankAccountNumber;

    @Find(by = By.XPath, locator = "//input[@placeholder='A nickname for this account']")
    public PageElement bankAccountHolderNickName;

    @Find(by = By.XPath, locator = "//span[contains(text(),'Validate')]")
    public PageElement validateButton;

    @Find(by = By.XPath, locator = "//div[contains(@for,'mat-checkbox')]")
//".o2uk-checkbox-frame")//o2uk-checkbox")//comment out got uat2: ".o2uk-checkbox-inner-container")
    public PageElement checkBox;

    @Find(by = By.XPath, locator = "//span[contains(text(),' Save and continue ')]")
    public PageElement saveContinueBtn;

    //for new h1 contains(text(),'Payment data')]")
    @Find(by = By.XPath, locator = "//*[contains(text(),' Credit check ') or contains(text(),'Payment data')]")
//"//h2[contains(text(),' Credit check ')]")
    public PageElement paymentDetailHeader;

    @Find(by = By.XPath, locator = "//*[@id='cardName']")
    public PageElement CardHolderName;

    @Find(by = By.XPath, locator = "//*[@id='cardNumber']")
    public PageElement CardNumber;

    @Find(by = By.XPath, locator = "//*[@id='expiryDateMonthInput']")
    public PageElement CardMonth;

    @Find(by = By.XPath, locator = "//*[@id='expiryDateYearInput']")
    public PageElement CardYear;

    @Find(by = By.XPath, locator = "//*[@id='csc']")
    public PageElement SecurityCode;

    @Find(by = By.XPath, locator = "//button[@id='bConfirmPaymentButton']")
    public PageElement onlineVerificationBtn;

    @Find(by = By.CssSelector, locator = "#mat-checkbox-3 > div > div > label > div > div.o2uk-checkbox-inner-container")
    public PageElement confirmCostOfPlanCheckbox;

    @Find(by = By.CssSelector, locator = "#mat-checkbox-4 > div > div > label > div > div.o2uk-checkbox-inner-container")
    public PageElement confirmNoChangesInCircumstancesCheckbox;
}
