package com.o2.guice;

import com.google.inject.AbstractModule;
import com.google.inject.Singleton;
import com.o2.acceptancetests.ecare.BrowserUtil;
import com.o2.pages.ecare.*;
import com.o2.core.util.Common;
import com.o2.models.ecare.LoginCsrUserData;
import com.o2.stepdefs.ecare.BuyBoltOnSteps;
import com.o2.stepdefs.ecare.ControlCentreSteps;
import com.o2.stepdefs.ecare.EcareBaseSteps;
import com.o2.stepdefs.ecare.SpendCapSteps;
import com.o2.stepdefs.ecare.SwitchToO2Steps;
import com.o2.stepdefs.ecare.WantToLeaveSteps;
import com.o2.stepdefs.ecare.YourExtrasSteps;

import io.cucumber.guice.ScenarioScoped;

public final class EcareProjectModule extends AbstractModule {
	@Override
	public void configure() {
		try {
			// Bindings for classes that are shared for the lifetime of the
			// scenario.
			bind(AccountLandingPage.class).in(ScenarioScoped.class);
			bind(AccountLandingPage.class).in(ScenarioScoped.class);
			bind(EditContactDetailsPage.class).in(ScenarioScoped.class);
			bind(MyDetailsPage.class).in(ScenarioScoped.class);
			bind(SignInPage.class).in(ScenarioScoped.class);
			bind(YourContactWithUsPage.class).in(ScenarioScoped.class);

			bind(BrowserUtil.class).toInstance(BrowserUtil.instance());
			bind(Common.class).in(Singleton.class);
			bind(LoginCsrUserData.class).in(Singleton.class);
			bind(ControlCentrePage.class).in(ScenarioScoped.class);
			bind(ControlCentreSteps.class).in(ScenarioScoped.class);
			bind(EcareBasePage.class).in(ScenarioScoped.class);
			bind(EcareBaseSteps.class).in(ScenarioScoped.class);
			bind(BuyBoltOnSteps.class).in(Singleton.class);
			bind(BuyBoltOnPage.class).in(Singleton.class);

			bind(WantToLeavePage.class).in(Singleton.class);
			bind(WantToLeaveSteps.class).in(Singleton.class);

			bind(SpendCapSteps.class).in(Singleton.class);
			bind(SpendCapPage.class).in(Singleton.class);

			bind(SwitchToO2Steps.class).in(Singleton.class);
			bind(SwitchToO2Page.class).in(Singleton.class);

			bind(YourExtrasSteps.class).in(Singleton.class);
			bind(YourExtrasPage.class).in(Singleton.class);
			bind(NotificationEmailPage.class).in(ScenarioScoped.class);
			bind(BillingHistoryPage.class).in(ScenarioScoped.class);
			bind(BillingHistoryPaymentSuccessDetailsPage.class).in(ScenarioScoped.class);
			bind(OrdersPage.class).in(ScenarioScoped.class);

		} catch (Exception e) {
			addError(e.getMessage());
		}
	}
}
