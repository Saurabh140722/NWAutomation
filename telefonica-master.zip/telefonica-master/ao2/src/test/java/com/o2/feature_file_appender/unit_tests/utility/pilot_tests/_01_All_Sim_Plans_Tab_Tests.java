package com.o2.feature_file_appender.unit_tests.utility.pilot_tests;

import com.o2.feature_file_appender.config.AppendDataToFeatureFile_Utility;
import com.o2.feature_file_appender.unit_tests.config.TestBase;
import org.junit.Test;

import java.util.Arrays;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class _01_All_Sim_Plans_Tab_Tests extends TestBase {
    private AppendDataToFeatureFile_Utility asp_utility;

    public _01_All_Sim_Plans_Tab_Tests() {
        asp_utility = new AppendDataToFeatureFile_Utility();
        asp_utility.setExcelTab("All_Sim_Plans_Tab");
        asp_utility.readCleanseDataSourceFileInto2DArray_AllSimPlans("All_Sim_Plans.csv", true);
    }

    @Test
    public void happyPath_RetrieveColumnRange_WithCleansing() {
        Object[] range = { 1, 12 };
        assertTrue(asp_utility.copyFeatureFile("All_Sim_Plans.feature"));
        assertTrue(asp_utility.appendDataToNewFeatureFile("outline","colrange", range));
    }

    @Test
    public void happyPath_RetrieveRow_WithCleansing() {
        Object[] range = { 2 };
        assertTrue(asp_utility.copyFeatureFile("All_Sim_Plans.feature"));
        assertTrue(asp_utility.appendDataToNewFeatureFile("outline","row", range));
    }

    // Demo this one
    @Test
    public void happyPath_RetrieveRowRange_WithCleansing() {
        Object[] range = { 2, 7 };
        assertTrue(asp_utility.copyFeatureFile("All_Sim_Plans.feature"));
        assertTrue(asp_utility.appendDataToNewFeatureFile("outline","rowrange", range));
    }

}
