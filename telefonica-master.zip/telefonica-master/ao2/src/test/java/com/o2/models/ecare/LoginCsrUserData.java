package com.o2.models.ecare;

import com.google.inject.Inject;
import com.nttdata.cinnamon.cache.Context;
import com.nttdata.cinnamon.file.json.JsonParser;
import com.nttdata.cinnamon.file.reader.Reader;
import com.nttdata.cinnamon.logging.Logger;

import java.text.MessageFormat;
import java.util.List;
import java.util.Objects;

import static org.assertj.core.api.Assertions.assertThat;

public class LoginCsrUserData {
    private final Logger logger;
    private final List<LoginCsrUser> loginCsrUsers;
    private final Context context;

    @Inject
    public LoginCsrUserData(final Logger logger,
                            final Reader reader,
                            final JsonParser jsonParser, Context context) {
        this.logger = logger;
        this.context = context;
        // TODO Move this logic in to common function
        String env=System.getProperty("env");
        this.context.set("env",env);
        String dataLoginFilePath = System.getProperty("user.dir") + "\\src\\test\\resources\\data\\ecare\\"+env+"\\ecare_login_accounts.json";
        String data = reader.readFileAsString(dataLoginFilePath, false);

        this.loginCsrUsers = jsonParser.toObjList(data, LoginCsrUser.class);
    }

    public LoginCsrUser getLoginDetailsByRole(Role role) {
        LoginCsrUser loginCsrUser = this.loginCsrUsers.stream()
                .filter(u -> u.role.equals(role.toString()))
                .findFirst()
                .orElse(null);

        // TODO: probably worth to move assertions out of here and keep it in test
        assertThat(loginCsrUser)
                .withFailMessage(
                        MessageFormat.format(
                                "Could not find a Login CSR User data with role: ''{0}''", role))
                .isNotNull();

        this.logger.info(MessageFormat.format("CSR Login details for role: {0}:\n{1}",
                role.toString(), Objects.requireNonNull(loginCsrUser).toString()));

        return loginCsrUser;
    }
}
