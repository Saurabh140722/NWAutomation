package com.o2.pages.ecare;

import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;

public class SignInPage extends EcareBasePage {
    @Find(by = By.Id, locator = "email")
    public PageElement email;

    @Find(by = By.Id, locator = "login-password")
    public PageElement password;

    @Find(by = By.Id, locator = "continueButton")
    public PageElement continueButton;

    @Find(by = By.XPath, locator = "//button[contains(text(),'Manage cookies')]")
    public PageElement manageCookiesBtn;

    @Find(by = By.XPath, locator = "//a[contains(text(),'Accept all cookies')]")
    public PageElement acceptAllCookiesBtn;

    @Find(by = By.Id, locator = "logoutBtn")
    public PageElement signOutLink;

    @Find(by = By.XPath, locator = "//h1[contains(@class,'o2uk-header-curve__text-title')]")
    public PageElement  signOutPageTitle;

    @Override
    protected PageElement getPageCheckElement() {
        return this.email;
    }
}
