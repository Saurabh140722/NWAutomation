package com.o2.pages.ecare;

import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.nttdata.cinnamon.driver.controls.PageElementCollection;

import static com.nttdata.cinnamon.wait.ElementConditions.enabled;

public class DataUsageLatestBillDetailDevicePlanPage extends EcareBasePage {

    @Find(by = By.XPath, locator = "//div[@class='usage-graph__text']")
    public PageElementCollection dataMinutesMessageGraphDetail;

    @Find(by = By.XPath, locator = "//h2[contains(text(),'Current extra charges')]")
    public PageElement lblcurrentExtraCharges;

    @Find(by = By.CssSelector, locator = ".o2uk-notification-message__title")
    public PageElement currentExtraChanrgesText;

    @Find(by = By.XPath, locator = "//button[@aria-label='View charges']")
    public PageElement viewChargesBtn;

    @Find(by = By.XPath, locator = "//div[@class='o2uk-line-selector__left-block']")
    public PageElementCollection currentChargesPanel;

    @Find(by = By.CssSelector, locator = ".o2uk-account-airtime-bill__title")
    public PageElement LatestBillTitle;

    @Find(by = By.XPath, locator = " //button[@class='mat-focus-indicator o2uk-account-airtime-bill__button mat-button-base o2uk-primary-button']")
    public PageElement viewLatestBillBtn;

    @Find(by = By.CssSelector, locator = ".bill-charges__title")
    public PageElement billChargeSummaryTtitle;

    @Find(by = By.CssSelector, locator = ".device-plan__card-button")
    public PageElement manageDevicePlanBtn;

    @Find(by = By.CssSelector, locator = ".container-left")
    public PageElement manageDevicePageContainerLeft;

    @Find(by = By.CssSelector, locator = ".container-right")
    public PageElement manageDevicePageContainerRight;


    @Find(by = By.XPath, locator = "//div[@class='insurance-policy-link ng-star-inserted']")
    public PageElement insurancePolicyLink;

    @Find(by = By.XPath, locator = "//span[contains(text(),'Exchange')]")
    public PageElement exchangeBtn;

    @Find(by = By.XPath, locator = "//h3[text()='Exchanging a device?']")
    public PageElement lblExchangeDevice;

    @Find(by = By.XPath, locator = "//span[contains(text(),' Cancel ')]")
    public PageElement cancelBtn;


    @Find(by = By.XPath, locator = "//span[contains(text(),'Return')]")
    public PageElement returnBtn;

    @Find(by = By.CssSelector, locator = ".o2uk-line-selector__wrapper>o2uk-svg-resolver")
    public PageElementCollection currentChanrgesArrowLink;

    @Find(by = By.Id, locator = "mat-input-1")
    public PageElement billingPeriod;

    @Find(by = By.CssSelector, locator = ".o2uk-card")
    public PageElement usageGraphCard;

    @Find(by = By.CssSelector, locator = ".svg-usage-graph__link")
    public PageElement dataRoamingZoneLink;

    @Find(by = By.CssSelector, locator = ".o2uk-charges__card-title")
    public PageElementCollection chargesCardTitleForEverythingTab;

    @Find(by = By.CssSelector, locator = ".o2uk-line-selector__wrapper")
    public PageElementCollection chargeSummaryHeaderDetail;

    @Find(by = By.CssSelector, locator = ".o2uk-charges__card-wrapper")
    public PageElementCollection chargesCardWrapper;

    @Find(by = By.XPath, locator = "//o2uk-device-plan-card//o2uk-card/div[@class='device-plan__card-content']//button")
    public PageElement ManageDevicePlan;

    @Find(by = By.XPath, locator = "//o2uk-device-plan//div[@class='header__content']")
    public PageElement ManageDevicePlanHeaderDetails;

    @Find(by = By.XPath, locator = "//o2uk-device-plan//h1[text()=' My Device Plan ']")
    public PageElement ManageDevicePlanHeader;

    @Find(by = By.XPath, locator = "//o2uk-link[contains(@class,'dropdown-chevron')]//button")
    public PageElement proofOfPurchase;

    @Find(by = By.XPath, locator = "//o2uk-link[@wrapperclass='view-proof-dropdown__download-button']/button")
    public PageElement proofOfPurchaseDownload;

    @Find(by = By.XPath, locator = "//div[@class='container-right']//o2uk-link/button")
    public PageElement creditAgreeent;

    @Find(by = By.XPath, locator = "//o2uk-link[contains(@class,'recycle-device')]//a")
    public PageElement recycleDevice;

    public void getDevicePlanOptionsButtons(String deviceOption){
        switch(deviceOption){
            case "View proof of purchase" : {
                proofOfPurchase.clickJs();
                proofOfPurchaseDownload.waitUntil(enabled).clickJs();
                break;
            }
            case "View credit agreement" : {
                creditAgreeent.clickJs();
                break;
            }
            case "Want to recycle?" : {
                recycleDevice.clickJs();
                break;
            }

        }

    }




}
