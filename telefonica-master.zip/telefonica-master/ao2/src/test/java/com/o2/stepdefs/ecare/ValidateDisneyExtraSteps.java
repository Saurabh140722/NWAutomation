package com.o2.stepdefs.ecare;

import com.google.inject.Inject;
import com.nttdata.cinnamon.driver.Browser;
import com.o2.core.util.Common;
import com.o2.pages.ecare.ValidateDisneyExtraPage;
import com.o2.stepdefs.BaseStep;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

import static org.assertj.core.api.Assertions.assertThat;

public class ValidateDisneyExtraSteps extends BaseStep {

    private final ValidateDisneyExtraPage validateDisneyExtraPage;
    private final Common common;
    private final Browser browser;

    @Inject
    public ValidateDisneyExtraSteps(final ValidateDisneyExtraPage validateDisneyExtraPage,final Browser browser, final Common common) {
        this.validateDisneyExtraPage = validateDisneyExtraPage;
        this.browser = browser;
        this.common = common;

    }

    @And("I click on active extras option and check disney plus is available")
    public void i_click_on_extra_option() {
        common.wait(5);
        assertThat(this.validateDisneyExtraPage.allExtraOptions.asList().get(2).isDisplayed()).withFailMessage(" Active extra option not opened!")
                .isTrue();
        this.validateDisneyExtraPage.allExtraOptions.asList().get(0).click();
        assertThat(this.validateDisneyExtraPage.disneyplusExtraPanel.isDisplayed()).withFailMessage("Disney Plus extra panel is not opened!")
                .isTrue();
    }

    @When("I click on cancel button toggle")
    public void i_click_cancel_button_toggle() {
        this.validateDisneyExtraPage.cancelBtnToogle.click();
    }

    @Then("I can see the warning message of Cancel request")
    public void i_can_see_warning_message_of_cancel_request() {
        assertThat(this.validateDisneyExtraPage.cancelActiveNote.getText())
                .isEqualTo("We’re processing your request to cancel auto-enrolment for this Extra. Its status will be updated soon.");
    }

    @And("I checked the auto enrollment toggle option is turned on")
    public void i_can_see_toogle_button_is_turn_on() {
        String color=this.validateDisneyExtraPage.toggleBtn.getCssValue("background-color");
        System.out.println("Background color is"+color);
        this.validateDisneyExtraPage.toggleBtn.click();
    }



}
