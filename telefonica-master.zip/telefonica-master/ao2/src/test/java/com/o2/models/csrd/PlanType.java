package com.o2.models.csrd;

public enum PlanType {
	CUSTOM_PLAN,
	SIMO_PLAN,
	ALTERNATE_EMAIL_ADDRESS,
	EXTRAS
}
