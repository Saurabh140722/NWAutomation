package com.o2.stepdefs.ecare;

import com.google.inject.Inject;
import com.o2.pages.ecare.ChangeTariffPage;
import com.o2.pages.ecare.ChangeTariffStepsPage;
import com.o2.stepdefs.BaseStep;
import com.o2.util.Common;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;


import static org.assertj.core.api.Assertions.assertThat;

public class ChangeTariffSteps extends BaseStep {
    private final ChangeTariffStepsPage changeTariffStepsPage;
    private final ChangeTariffPage changeTariffPage;
    private final Common common;

    @Inject
    public ChangeTariffSteps(final ChangeTariffStepsPage changeTariffStepsPage, ChangeTariffPage changeTariffPage, Common common) {
        this.changeTariffStepsPage = changeTariffStepsPage;
        this.changeTariffPage = changeTariffPage;
        this.common = common;
    }

    @Then("^I verify simo 12 plan in your tariff page$")
    public void i_verify_simo12_plan() {
        this.logger.info("** Your Tariff plan is not displayed...");
        assertThat(this.changeTariffStepsPage.tariffCardOptions.asList().get(0).isDisplayed()).withFailMessage("Tariff card of 12 month simo is not displayed!")
                .isTrue();

        assertThat(this.changeTariffStepsPage.tariffCardOptionsText.asList().get(1).getText()).withFailMessage("Tariff card of 12 month simo is not displayed!").isEqualTo("12 months Airtime Plan");
        assertThat(this.changeTariffStepsPage.tariffCardOptions.asList().get(1).isDisplayed()).withFailMessage("Tariff card of 50gb is not displayed!")
                .isTrue();
        assertThat(this.changeTariffStepsPage.tariffCardOptions.asList().get(2).isDisplayed()).withFailMessage("Tariff card of Unlimited Data is not displayed!")
                .isTrue();

    }

    @Then("^I verify 30 days plan in your tariff page$")
    public void i_verify_30_days_simo_plan() {
        this.logger.info("** Your Tariff plan is not displayed...");
        assertThat(this.changeTariffStepsPage.tariffCardOptions.asList().get(0).isDisplayed()).withFailMessage("30 days Airtime Plan is not displayed!")
                .isTrue();

        assertThat(this.changeTariffStepsPage.tariffCardOptionsText.asList().get(1).getText()).withFailMessage("30 days Airtime Plan is not displayed!").isEqualTo("30 days Airtime Plan");
        assertThat(this.changeTariffStepsPage.tariffCardOptions.asList().get(1).isDisplayed()).withFailMessage("O2 Sim Only Airtime Plan of 50 gb is not displayed!")
                .isTrue();
        assertThat(this.changeTariffStepsPage.tariffCardOptions.asList().get(2).isDisplayed()).withFailMessage("O2 Sim Only Airtime Plan of Unlimited Data is not displayed!")
                .isTrue();

    }

    @And("^I click on usageSummary and changeTariff Button$")
    public void i_click_on_usagesummary_change_tariff_button() {
        this.common.waitForLoadingToComplete(2, 1);
        this.changeTariffPage.usageSummaryBtn.click();
        this.changeTariffPage.changeTariffBtn.click();

    }

    @And("^I select change to tariff option and click on confirm change button$")
    public void i_click_on_changeTo_Tarrif_option_click_on_confirm_change() {
        this.changeTariffPage.changeToThisTariffBtn.asList().get(2).click();
        this.changeTariffPage.checkBoxForTermAndCondition.click();
        this.changeTariffPage.confirmChangeBtn.click();

    }

    @And("^I select change traiff$")
    public void i_select_change_tariff(){
        this.changeTariffPage.changeToThisTariffBtn.asList().get(2).click();

    }

    @Then("^I click on signout button$")
    public void i_click_signout_button() {
        this.changeTariffStepsPage.signOutBtn.click();
    }

}
