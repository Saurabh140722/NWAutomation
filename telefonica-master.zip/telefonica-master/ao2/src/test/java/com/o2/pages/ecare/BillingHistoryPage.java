package com.o2.pages.ecare;

import com.google.inject.Inject;
import com.nttdata.cinnamon.driver.Browser;
import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.nttdata.cinnamon.driver.controls.PageElementCollection;

import static com.nttdata.cinnamon.wait.ElementConditions.*;

public class BillingHistoryPage extends EcareBasePage{

    @Inject
    public BillingHistoryPage(Browser browser) {
        this.browser = browser;
    }

    @Find(by = By.XPath, locator = "//h1[text()=' Billing History ']")
    public PageElement pageTitle;

    @Find(by = By.XPath, locator = "//*[contains(@class,'o2uk-billing-history-details__no-bills')]")
    public PageElement noBill;



    public void clickBillingHistorySections(String buttonName){
        //  Make payment,  View payment wallet, Bills,Payments
        if(buttonName.equalsIgnoreCase("Bill type")){
            PageElement button = browser.findBy(By.XPath, "//o2uk-billing-history//accordion-button//button[@aria-label='Bill type']");
            button.clickJs();
        }else if(buttonName.equalsIgnoreCase("View payments wallet")){
            PageElement button = browser.findBy(By.XPath, "//o2uk-billing-history/o2uk-billing-history-main//button[string()=' "+buttonName+" ']");
            button.waitUntil(displayed.and(enabled.and(present)));
            button.hover().clickJs();
        } else if(buttonName.equalsIgnoreCase("Payments")){
            PageElement button = browser.findBy(By.XPath, "//o2uk-billing-history/o2uk-billing-history-main//button[string()='"+buttonName+"']");
            button.waitUntil(displayed.and(enabled.and(present)));
            button.hover().clickJs();
        }
    }

    // PaymentsSection

    @Find(by = By.XPath, locator ="//o2uk-billing-history//accordion-button//button[@aria-label='Bill type']")
    public PageElement billTypeChevron;

    @Find(by = By.XPath, locator ="//div[contains(@class,'o2uk-billing-history-details__payments')]//o2uk-select")
    public PageElement paymentType;

    @Find(by = By.XPath, locator = "//o2uk-option")
    public PageElementCollection paymentTypeOptions;

    @Find(by = By.XPath, locator = "//o2uk-option/span[text()=' Bill payments ']")
    public PageElement billPaymentpaymentTypeOption;

    @Find(by = By.XPath, locator = "//o2uk-option/span[text()=' Order payments ']")
    public PageElement orderPaymentpaymentTypeOption;

    @Find(by = By.XPath, locator ="//o2uk-billing-history//o2uk-billing-history-details//h2[text()='History']")
    public PageElement billTypeHistoryHeader;

    @Find(by = By.XPath, locator ="//div/o2uk-billing-history-card-header//p")
    public PageElement paymentSuccess;

    @Find(by = By.XPath, locator = "//o2uk-billing-history//h2[text()=' Billing method ']")
    public PageElement billingMethodHeader;

    @Find(by = By.XPath, locator = "//o2uk-sort//button")
    public PageElement sortBy;

    @Find(by = By.XPath, locator = "//o2uk-billing-history-details//o2uk-sort//o2uk-radio-group/p[text()=' Date ']")
    public PageElement sortByDate;

    @Find(by = By.XPath, locator = "//o2uk-billing-history-details//o2uk-sort//o2uk-radio-group/p[text()=' Amount ']")
    public PageElement sortByAmount;

    @Find(by = By.XPath, locator = "//o2uk-radio-group//o2uk-radio-button//input")
    public PageElementCollection sortByOptions;

    @Find(by = By.XPath, locator = "//o2uk-filter//button")
    public PageElement filterBy;

    @Find(by = By.XPath, locator = "//o2uk-checkbox//label//div[3]")
    public PageElementCollection filterByOptions;

    @Find(by = By.XPath, locator = "//o2uk-billing-history-details//o2uk-filter//div[@class='o2uk-filter__expansion-content']//p[text()='Status']")
    public PageElement filterByStatusCaption;

    @Find(by = By.XPath, locator = "//o2uk-link/button[text()=' Clear all ']")
    public PageElement filterByClearAll;

    @Find(by = By.XPath, locator = "//o2uk-link/button[text()=' Select all ']")
    public PageElement filterBySelectAll;

    @Find(by = By.XPath, locator = "//o2uk-card-title//div[@title='Additional Information']")
    public PageElement additionalInformation;


}
