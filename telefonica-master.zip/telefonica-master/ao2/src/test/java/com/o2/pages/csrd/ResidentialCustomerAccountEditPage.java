package com.o2.pages.csrd;

import com.google.inject.Inject;
import com.nttdata.cinnamon.cache.Context;
import com.nttdata.cinnamon.driver.Browser;
import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.Checkbox;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.nttdata.cinnamon.driver.controls.PageElementCollection;
import com.o2.core.util.Common;
import com.o2.core.util.Retry;
import com.o2.pages.BasePage;

import java.text.MessageFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;

import static com.nttdata.cinnamon.wait.ElementConditions.displayed;
import static org.assertj.core.api.Assertions.assertThat;

public class ResidentialCustomerAccountEditPage extends BasePage {
    private final Browser browser;
    private final Retry retry;
    private final Context context;
    private final Common common;
    @Find(by = By.CssSelector, locator = "button[class^='gwt-Button button_action_id_'][class$='TableCtrl-button TableCtrl-button-icon EditIco']")
    public PageElement editResidentialAccountButton;

    @Find(by = By.CssSelector, locator = "#\\39 154125830513185011 > div:nth-child(1) > div > span > label > input[type=checkbox]")
    public Checkbox prisonFlagCheckbox;

    @Find(by = By.CssSelector, locator = "button[class^='gwt-Button button_action_id_'][class$='TableCtrl-button button-save']")
    public PageElement saveButton;

    @Find(by = By.CssSelector, locator = ".main-par-layout")
    public PageElement residentialAccountBlockRoot;

    @Find(by = By.CssSelector, locator = ".refsel_textarea")
    public PageElement reasonableAdjustmentDetails;

    @Find(by = By.CssSelector, locator = ".refsel_multiple")
    public PageElement reasonableAdjustmentDetailsRoot;

    @Find(by = By.CssSelector, locator = "#nc_refsel_list_table")
    public PageElement reasonableAdjustmentDetailsOptionsList;

    @Find(by = By.CssSelector, locator = "div[id^='nc_refsel_list_row_']")
    public PageElementCollection reasonableAdjustmentDetailsOptions;

    @Find(by = By.CssSelector, locator = "#id_refsel400425360_div > div > i")
    public PageElement reasonableAdjustmentDetailsOptionsListArrow;

    @Inject
    public ResidentialCustomerAccountEditPage(final Browser browser,
                                              final Retry retry,
                                              final Context context,
                                              final Common common) {
        this.browser = browser;
        this.retry = retry;
        this.context = context;
        this.common = common;
    }

    @Override
    public PageElement getPageCheckElement() {
        return this.editResidentialAccountButton;
    }

    public String getReasonableAdjustmentDetails() {
        return this.residentialAccountBlockRoot
                .waitUntil(displayed)
                .findChild(By.CssSelector, ".nc-field-text-readonly.nc-field-reference-readonly")
                .getText();
    }

    public PageElement getReasonableAdjustmentArrow() {
        return this.reasonableAdjustmentDetailsRoot.waitUntil(displayed).findChild(By.CssSelector, "i[class='refsel_arrow']");
    }

    public void     setFlags(List<Map<String, String>> rows) {
        Map<String, PageElement> flags = getFlags();

        for(Map<String, String> row : rows) {
            String flagName = row.get("flag");
            boolean flagIsActive = Boolean.parseBoolean(row.get("activate"));

            assertThat(flags.containsKey(flagName))
                    .withFailMessage(
                            MessageFormat.format("Could not find a flag defined with name: ''{0}''!", row.get("flag")))
                    .isTrue();
       this.common.wait(5);
            if (flagIsActive) {
                if ((flags.get(flagName).getAttribute("checked") == null) || (flags.get(flagName).getAttribute("checked").equals("false"))) {
                    flags.get(flagName).click();
                }

                if (flagName.equals("Reasonable Adjustment")) {
                    reasonableAdjustmentDetails.click();
                    Supplier<Boolean> processIcon = () -> {
                        this.getReasonableAdjustmentArrow().click();
                        return this.reasonableAdjustmentDetailsOptionsList.waitUntil(displayed).isDisplayed();
                    };
                    Boolean result = this.retry.retryAction(processIcon, 12, 1);

                    assertThat(result)
                            .withFailMessage("Reasonable Adjustment Details options list not displayed!")
                            .isTrue();

                    PageElementCollection options = this.reasonableAdjustmentDetailsOptions;
                    assertThat(options.size())
                            .withFailMessage("No Reasonable Adjustment Details options displayed!")
                            .isGreaterThanOrEqualTo(1);

                    PageElement option = options.asList().get(this.common.randomInt(0, options.size()));
                    this.context.set("reasonableAdjustmentDetails", option.getText());
                    this.logger.warn(">>> " + this.context.get("reasonableAdjustmentDetails"));
                    if(!reasonableAdjustmentDetails.getText().isEmpty()) {
                        option.click();
                    }

                }
            } else {
                if ((flags.get(flagName).getAttribute("checked") != null) && (flags.get(flagName).getAttribute("checked").equals("true"))) {
                    flags.get(flagName).click();
                }
            }

            // Will keep the original values passed in test in case there is any misspelling
            this.logger.info(
                    MessageFormat.format(
                            "Flag ''{0}'' with activate option ''{1}'' is now {2}'!",
                            row.get("flag"),
                            row.get("activate"),
                            row.get("activate").equals("true") ? "active" : "inactive"));
        }
    }

    public Map<String, PageElement> getFlags() {
        Map<String, PageElement> flagCheckboxes = new HashMap<>();

        PageElementCollection checkboxes = this.residentialAccountBlockRoot.findChildren(By.CssSelector, "input[type='checkbox']");
        PageElementCollection labels = this.residentialAccountBlockRoot.findChildren(By.CssSelector, ".gwt-Label.nc-field-label");

        int labelIndex = 13;

        for(int i = 0; i < checkboxes.size(); i++) {
            flagCheckboxes.put(labels.asList().get(labelIndex + i).getText(), checkboxes.asList().get(i));
        }

        return flagCheckboxes;
    }
}
