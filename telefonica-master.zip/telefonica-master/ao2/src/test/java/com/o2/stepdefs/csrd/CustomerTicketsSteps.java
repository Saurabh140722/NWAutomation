package com.o2.stepdefs.csrd;

import com.google.inject.Inject;
import com.nttdata.cinnamon.cache.Context;
import com.nttdata.cinnamon.logging.Logger;
import com.o2.models.csrd.Sort;
import com.o2.pages.csrd.customertickets.GeneralRequestsFragment;
import com.o2.stepdefs.BaseStep;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.lang.NotImplementedException;

import java.text.MessageFormat;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import static com.nttdata.cinnamon.wait.ElementConditions.displayed;
import static org.assertj.core.api.Assertions.assertThat;

public class CustomerTicketsSteps extends BaseStep {
    private final Logger logger;
    private final Context context;
    private final GeneralRequestsFragment generalRequestsFragment;

    @Inject
    public CustomerTicketsSteps(final Logger logger,
                                final Context context,
                                final GeneralRequestsFragment generalRequestsFragment) {
        this.logger = logger;
        this.context = context;
        this.generalRequestsFragment = generalRequestsFragment;
    }

    @When("^I raise a '(.*)' ticket with:$")
    public void i_raise_ticket(String ticketType, DataTable table) {
        this.logger.info(MessageFormat.format("*** Raise a ticket for ''{0}'' ...", ticketType));

        List<Map<String, String>> rows = table.asMaps(String.class, String.class);

        assertThat(this.generalRequestsFragment.isPageDisplayed())
                .withFailMessage(MessageFormat.format(
                        "Block/Table for ''{0}'' is not displayed!", ticketType))
                .isTrue();

        // Sort the table so I can get the newest entry
        this.generalRequestsFragment.filterByName(rows.get(0).get("entry_prefix"));
        this.generalRequestsFragment.sortByName(Sort.DESCENDING);

        // Store values for: total no of rows, entry prefix and last sequence
        this.context.set("entryPrefix", rows.get(0).get("entry_prefix"));
        this.context.set("lastSequenceBefore",
                this.generalRequestsFragment.getGeneralRequestLastSequence(rows.get(0).get("entry_prefix")));
        int totalNoOfTicketsBefore = this.generalRequestsFragment.getTotalNoOfItems();
        this.context.set("totalGeneralRequestsItemsBefore", totalNoOfTicketsBefore);

        // Create General Request
        this.generalRequestsFragment.createGeneralRequestButton.waitUntil(displayed).scrollIntoView().click();
        this.generalRequestsFragment.waitForNcLoadingToComplete();
        switch (rows.get(0).get("category").toLowerCase(Locale.ROOT)) {
            case "subject access request":
            case "right to be forgotten":
            case "right to data portability":
            case "right to objection to processing of personal data":
            case "right to restrict processing":
            case "right to rectification":
            case "right not be subject to decisions based solely on automated processing (including profiling)":
                this.generalRequestsFragment.fillInGdprRequest(table);
                break;
            case "incorrect updates to customer data":
                this.generalRequestsFragment.fillInDataBreachRequest(table);
                break;
            case "payment to trace":
                this.generalRequestsFragment.fillInCashManagementPaymentToTraceRequest(table);
                break;
            case "journal transfer":
                this.generalRequestsFragment.fillInCashManagementJournalTransferRequest(table);
                break;
            case "account takeover":
                this.generalRequestsFragment.fraudAccountTakeover(table);
                break;
            case "special case verification":
            case "long term illness":
                this.generalRequestsFragment.fillInSpecialCaseVerificationRequest(table);
                break;
            case "credit file amend":
                this.generalRequestsFragment.fillInCreditFileRequest(table);
                break;

            default:
                throw new NotImplementedException(MessageFormat.format(
                        "This request ''{0}'' has not been implemented yet!",
                        rows.get(0).get("category")
                ));
        }

         this.logger.info(MessageFormat.format("*** Ticket for ''{0}'' raised!\n", ticketType));
    }

    @Then("^my General Requests information is updated$")
    public void my_general_requests_information_is_updated() {
        this.logger.info("*** Validate General Request table ...");

        String entryPrefix = (String) this.context.get("entryPrefix");
        int totalGeneralRequestsItemsBefore = (int) this.context.get("totalGeneralRequestsItemsBefore");
        int lastSequenceBefore = (int) this.context.get("lastSequenceBefore");
        int totalGeneralRequestsItemsAfter = this.generalRequestsFragment.getTotalNoOfItems();

//        assertThat(totalGeneralRequestsItemsBefore)
//                .withFailMessage(
//                        MessageFormat.format(
//                                "No new general request have been added to General Requests table!\nBefore:{0}\nAfter:{1}",
//                                totalGeneralRequestsItemsBefore, totalGeneralRequestsItemsAfter))
//                .isEqualTo(totalGeneralRequestsItemsAfter);

//        this.generalRequestsFragment.sortByName(Sort.DESCENDING);
       // int lastSequenceCurrent = this.generalRequestsFragment.getGeneralRequestLastSequence(entryPrefix);
//        assertThat(lastSequenceBefore + 1)
//                .withFailMessage(
//                        MessageFormat.format(
//                                "Wrong last sequence for the last ticket generated! Expected: ''{0}'' but was: ''{1}''",
//                                lastSequenceBefore, lastSequenceCurrent))
//                .isEqualTo(lastSequenceCurrent);

        this.logger.info("*** General Request table validation complete!");
    }
}
