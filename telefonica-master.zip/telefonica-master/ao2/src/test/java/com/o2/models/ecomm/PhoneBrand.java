package com.o2.models.ecomm;

public enum PhoneBrand {
    Apple
}
