package com.o2.models.csrd;

public enum Sort {
    ASCENDING,
    DESCENDING
}
