package com.o2.stepdefs.ecomm;

import com.google.inject.Inject;
import com.nttdata.cinnamon.driver.Browser;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.o2.core.util.Retry;
import com.o2.pages.ecomm.AgreementPage;
import com.o2.util.Common;
import io.cucumber.java.en.And;
import org.apache.commons.lang.NotImplementedException;
import org.assertj.core.api.Assertions;

import java.text.MessageFormat;
import java.util.List;
import java.util.logging.Logger;

import static com.nttdata.cinnamon.wait.ElementConditions.*;
import static com.nttdata.cinnamon.wait.conditions.Conditions.ajaxFinished;
import static org.assertj.core.api.Assertions.assertThat;

public class AgreementSteps extends BaseStep {
    private final Logger logger;
    private final AgreementPage agreementPage;
    private final Browser browser;
    private final Retry retry;
    private final Common common;

    @Inject
    public AgreementSteps(final Logger logger,
                          final AgreementPage agreementPage,
                          final Browser browser,
                          final Retry retry, Common common) {
        this.logger = logger;
        this.agreementPage = agreementPage;
        this.browser = browser;
        this.retry = retry;
        this.common = common;
    }

    @And("^Continue to Agreements page for '(.*)' and confirm all the agreement checks$")
    public void i_verify_agreement_confirmation_Checks(String plan) {
        logger.info("** Agreement page is loaded...");
        browser.setImplicitWait(5);
        Assertions.assertThat(agreementPage.popupError.isDisplayed())
                .withFailMessage("Cannot continue due to Backend/internal error!")
                .isFalse();
        boolean result = retry.retryAction(
                () -> {
                    int checkboxes = agreementPage.agreementCheckboxes.asList().size();
                    int buttons = agreementPage.continueButtons.asList().size();
                    logger.info(" >> Checkboxes found: " + checkboxes);
                    logger.info(" >> Buttons found: " + buttons);
                    return (checkboxes > 0 && buttons > 0);
                },
                10, 2);

        browser.restoreImplicitWait();
        assertThat(result)
                .withFailMessage("Could not retrieve all checkboxes and buttons for agreements!")
                .isTrue();
        List<PageElement> checkboxes = agreementPage.agreementCheckboxes.asList();
        List<PageElement> buttons = agreementPage.continueButtons.asList();

        switch (plan.toUpperCase()) {
            case "SIM":
                if (agreementPage.payMobileAgreement.isDisplayed(5)) {
                    checkboxes.get(0).waitUntil(displayed.and(enabled).and(present).and(clickable)).clickJs();
                    checkboxes.get(1).waitUntil(displayed.and(enabled).and(present).and(clickable)).clickJs();
                    checkboxes.get(2).waitUntil(displayed.and(enabled).and(present).and(clickable)).clickJs();
                    buttons.get(0).waitUntil(displayed.and(enabled).and(present).and(clickable)).clickJs();
                    browser.waitUntil(ajaxFinished);
                }
                common.wait(2);
                buttons.get(1).clickJs();
                agreementPage.waitForProcessLoadingToComplete(20, 2, 2);
                break;
            case "PHONE":
                common.wait(2);
                buttons.get(0).clickJs();
                common.wait(2);
                checkboxes.get(0).waitUntil(displayed.and(enabled).and(present).and(clickable)).clickJs();
                buttons.get(1).waitUntil(displayed.and(enabled).and(present).and(clickable)).clickJs();
                browser.waitUntil(ajaxFinished);
                common.wait(2);
                if (agreementPage.creditAgreement.isDisplayed(5)) {
                    checkboxes.get(1).waitUntil(displayed.and(enabled).and(present).and(clickable)).clickJs();
                    buttons.get(2).waitUntil(displayed.and(enabled).and(present).and(clickable)).clickJs();
                    browser.waitUntil(ajaxFinished);
                }
                common.wait(2);
                if (agreementPage.payMobileAgreement.isDisplayed(5)) {
                    checkboxes.get(2).waitUntil(displayed.and(enabled).and(present).and(clickable)).clickJs();
                    checkboxes.get(3).waitUntil(displayed.and(enabled).and(present).and(clickable)).clickJs();
                    checkboxes.get(4).waitUntil(displayed.and(enabled).and(present).and(clickable)).clickJs();
                    buttons.get(3).waitUntil(displayed.and(enabled).and(present).and(clickable)).clickJs();
                    browser.waitUntil(ajaxFinished);
                }
                common.wait(2);
                agreementPage.payNowButton.clickJs();
                agreementPage.waitForProcessLoadingToComplete(20, 2, 2);
                break;

            default:
                throw new NotImplementedException(MessageFormat
                        .format("Invalid plan type ''{0}''!", plan));

        }


    }
}
