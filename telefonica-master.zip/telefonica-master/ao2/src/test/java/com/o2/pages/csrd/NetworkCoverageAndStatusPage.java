package com.o2.pages.csrd;

import com.google.inject.Inject;
import com.nttdata.cinnamon.driver.Browser;
import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.o2.pages.BasePage;

import static com.nttdata.cinnamon.wait.ElementConditions.displayed;

public class NetworkCoverageAndStatusPage extends BasePage {
    private final Browser browser;

    @Find(by = By.CssSelector, locator = ".sbuzz_welcomeHeader")
    public PageElement welcomeText;

    @Inject
    public NetworkCoverageAndStatusPage(final Browser browser) {
        this.browser = browser;
    }

    @Override
    public boolean isPageDisplayed() {
        this.browser.switchToTab(1);
        this.browser.switchTo("sbuzz_hdcv2");

        return this.welcomeText.waitUntil(displayed).getText().contains("Welcome to HDInsight");
    }
}
