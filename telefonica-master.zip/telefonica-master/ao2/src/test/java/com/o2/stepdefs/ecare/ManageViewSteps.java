package com.o2.stepdefs.ecare;

import com.google.inject.Inject;
import com.nttdata.cinnamon.driver.Browser;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.o2.pages.BasePage;
import com.o2.pages.ecare.ManageViewPage;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.WebDriver;

import static org.assertj.core.api.Assertions.assertThat;


public class ManageViewSteps extends BasePage {
    private final Browser browser;
    private final ManageViewPage manageViewPage;

    @Inject
    public ManageViewSteps(final ManageViewPage manageViewPage,Browser browser) {
        this.browser=browser;
        this.manageViewPage = manageViewPage;
    }

    @When("^I click on Manage view button$")
    public void i_click_on_manage_view_button() {
        this.browser.getWebDriver(WebDriver.class).switchTo().defaultContent();
        this.manageViewPage.manageViewBtn.click();

    }

    @Then("^I can see active plans on all the extra tab$")
    public void i_can_see_all_active_plan_in_all_extras() {
        for(PageElement allActivePlan:this.manageViewPage.allActivePlanInAllExtrasTab.asList())
        {
            assertThat(allActivePlan.isDisplayed()).withFailMessage("All active plan is not displayed!").isTrue();
        }


    }

}
