package com.o2.stepdefs.ecomm;

import com.google.inject.Inject;
import com.nttdata.cinnamon.cache.Context;
import com.o2.models.ecomm.EcommUser;
import com.o2.pages.ecomm.EcommBasePage;
import io.cucumber.java.en.Then;
import org.assertj.core.api.Assertions;

import static org.assertj.core.api.Assertions.assertThat;

public class HomeSteps extends BaseStep {
    private final EcommBasePage ecommBasePage;
    private final Context context;

    @Inject
    public HomeSteps(EcommBasePage ecommBasePage, Context context) {
        this.ecommBasePage = ecommBasePage;
        this.context = context;
    }

    @Then("^Home page opens successfully$")
    public void Home_page_opens_successfully() {
        this.logger.info("** Waiting for Home landing page to open ...");
        //TODO assert is commented for e2e and signout is added, this has to be deleted once env locators are set
        //        assertThat(this.ecommBasePage.getLink("Sign out").isDisplayed()).withFailMessage("Home landing page not displayed!")
//                .isTrue();
        Assertions.assertThat(this.ecommBasePage.signOut.isDisplayed()).withFailMessage("Home landing page not displayed!")
                .isTrue();
        EcommUser ecommUser = (EcommUser) this.context.get("eCommUserData");

        // TODO uncomment this
//       assertThat(this.ecommBasePage.hiUserName.getText()).
//                isEqualTo(MessageFormat.format("Hi {0}", ecommUser.firstName));
        this.logger.info("** Home landing page opens!");
    }
}
