package com.o2.stepdefs.csrd;

import com.google.inject.Inject;
import com.nttdata.cinnamon.cache.Context;
import com.nttdata.cinnamon.driver.Browser;
import com.nttdata.cinnamon.logging.Logger;
import com.o2.core.util.Common;
import com.o2.models.csrd.AdjustmentRow;
import com.o2.pages.csrd.billing.AdjustmentsPage;
import com.o2.stepdefs.BaseStep;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.assertj.core.api.SoftAssertions;

import java.text.MessageFormat;
import java.util.List;

import static com.nttdata.cinnamon.wait.ElementConditions.displayed;
import static org.assertj.core.api.Assertions.assertThat;

public class AdjustmentSteps extends BaseStep {
    private final Logger logger;
    private final Common common;
    private final com.o2.util.Common ao2Common;
    private final Context context;
    private final Browser browser;
    private final AdjustmentsPage adjustmentsPage;

    @Inject
    public AdjustmentSteps(final Logger logger,
                           final Common common,
                           final com.o2.util.Common ao2Common,
                           final Context context,
                           final Browser browser,
                           final AdjustmentsPage adjustmentsPage) {
        this.logger = logger;
        this.common = common;
        this.ao2Common = ao2Common;
        this.context = context;
        this.browser = browser;
        this.adjustmentsPage = adjustmentsPage;
    }

    @When("^I add a '(.*)' adjustment of '(.*)' and description '(.*)'$")
    public void page_is_displayed(String type, String amount, String description) {
        this.logger.info(
                MessageFormat.format(
                        "*** Adding adjustment with:\nType - ''{0}''\nAmount - ''{1}''\nDescription - ''{2}''",
                        type, amount, description));

        // Store table information before adding new Adjustment
        List<AdjustmentRow> adjustments = this.adjustmentsPage.getAdjustmentRows();

//        this.adjustmentsPage.sortByName();
//        this.adjustmentsPage.sortByName();
      //  this.context.set("lastAdjustmentBefore", adjustments.get(0));
        String newAdjustmentDescription =
                MessageFormat.format("{0} - {1}", this.common.getCurrentDateTime(), description);
        // ---

        AdjustmentRow newAdjustment = new AdjustmentRow();
        newAdjustment.description = newAdjustmentDescription;
        newAdjustment.adjustmentType = type;
        newAdjustment.amount = "£" + amount;
        newAdjustment.status = "Approved";
        newAdjustment.approvalDate = this.common.getCurrentDateTime("dd/MM/yyyy");
        this.context.set("expectedAdjustment", newAdjustment);

        this.adjustmentsPage.creditAdjustmentButton.click();
        this.adjustmentsPage.adjustmentAmount.waitUntil(displayed).setValue(amount);
        this.adjustmentsPage.selectAdjustmentType(type);
        this.adjustmentsPage.adjustmentDescription.setValue(newAdjustmentDescription);
        this.adjustmentsPage.adjustmentCreateButton.click();
        this.adjustmentsPage.waitForNcLoadingToComplete(4);

        this.logger.info("*** Adjustment added!\n");
    }

    @Then("^my Adjustments table is updated$")
    public void my_adjustments_table_is_updated() {
        AdjustmentRow lastAdjustmentBefore = (AdjustmentRow) this.context.get("lastAdjustmentBefore");

        this.adjustmentsPage.sortByName();
        this.adjustmentsPage.sortByName();
        List<AdjustmentRow> currentAdjustments = this.adjustmentsPage.getAdjustmentRows();
        AdjustmentRow newAdjustment = currentAdjustments.get(0);
        AdjustmentRow expectedAdjustment = (AdjustmentRow) this.context.get("expectedAdjustment");

        // We check that adjustment ID has changed. if it hasn't there is no point in further assertions
        // This checks also the name of adjustment (ADJ-A...) when it retrieved the adjustment ID
        assertThat(lastAdjustmentBefore.getAdjustmentId())
                .withFailMessage(
                        MessageFormat.format(
                                "No new adjustment has been added! Last adjustment before (and that remained the same) is:\n{0}"
                        , lastAdjustmentBefore.toString()))
                .isLessThan(newAdjustment.getAdjustmentId());

        // if it has changed then I can update User in DB as it has a Goodwill
        

        // We have quite few things to assert
        SoftAssertions softAssertions = new SoftAssertions();

        softAssertions.assertThat(expectedAdjustment)
                .as("Adjustment details")
                .withFailMessage(
                        MessageFormat.format("Expected adjustment is wrong!\nExpected:\n{0}\n\nbut was:\n{1}",
                                expectedAdjustment.toString(), newAdjustment.toString()))
                .isEqualTo(newAdjustment);

        softAssertions.assertThat(expectedAdjustment)
                .as("Adjustment details")
                .withFailMessage(
                        MessageFormat.format("Expected adjustment is wrong!\nExpected:\n{0}\n\nbut was:\n{1}",
                                expectedAdjustment.toString(), newAdjustment.toString()))
                .isEqualTo(newAdjustment);

        softAssertions.assertAll();
        //
    }
}
