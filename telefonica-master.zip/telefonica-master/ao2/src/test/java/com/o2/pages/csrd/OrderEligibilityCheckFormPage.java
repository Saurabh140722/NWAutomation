package com.o2.pages.csrd;

import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.FindByKey;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.o2.pages.BasePage;

public class OrderEligibilityCheckFormPage extends BasePage {
//    ui-id-2
     @FindByKey(key ="preferredTitle")
    public PageElement preferredTitle; // Dr

    @FindByKey(key ="preferredTitlephones")
    public PageElement preferredTitlephones; // Dr

    @FindByKey(key ="employmentStatus")
    public PageElement employmentStatus; // Employed

    @FindByKey(key ="employmentStatusphones")
    public PageElement employmentStatusphones; // Employed

    @FindByKey(key ="personalAnnualIncomephones")
    public PageElement personalAnnualIncomephones; // More than £50,000

    @FindByKey(key ="personalAnnualIncome")
    public PageElement personalAnnualIncome; // More than £50,000

    @FindByKey(key ="liveAtAddressPeriodphones")
    public PageElement liveAtAddressPeriodphones; // 7 to 8 years

    @FindByKey(key ="liveAtAddressPeriod")
    public PageElement liveAtAddressPeriod; // 7 to 8 years

    @FindByKey(key ="confirmAndContinueButton")
    public PageElement confirmAndContinueButton;

    @Override
    public PageElement getPageCheckElement() {
        return this.preferredTitle;
    }
}
