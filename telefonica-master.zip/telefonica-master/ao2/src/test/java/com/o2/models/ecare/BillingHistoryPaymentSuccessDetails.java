package com.o2.models.ecare;

import com.nttdata.cinnamon.driver.controls.PageElement;

public class BillingHistoryPaymentSuccessDetails {
    public PageElement paymentDate;
        public PageElement paymentMethod;
    public PageElement amount;
    public PageElement frequency;
    public PageElement nonBillableAmount;
    public PageElement channel;
    public PageElement transactionID;
    public PageElement orderID;

    public BillingHistoryPaymentSuccessDetails(PageElement paymentDate, PageElement paymentMethod, PageElement amount){
        this.paymentDate=paymentDate;
        this.paymentMethod=paymentMethod;
        this.amount=amount;
    }

    public BillingHistoryPaymentSuccessDetails(PageElement paymentDate, PageElement paymentMethod, PageElement amount,
                                               PageElement frequency, PageElement nonBillableAmount, PageElement channel,
                                               PageElement transactionID, PageElement orderID){
        this.paymentDate=paymentDate;
        this.paymentMethod=paymentMethod;
        this.amount=amount;
        this.frequency=frequency;
        this.nonBillableAmount=nonBillableAmount;
        this.channel=channel;
        this.transactionID=transactionID;
        this.orderID=orderID;
    }
}
