package com.o2.pages.csrd;

import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.o2.pages.BasePage;

public class TicketsPage extends BasePage {
    @Find(by = By.CssSelector, locator = ".gwt-Button.button_action_id_9154514342313172124_9154796484413152645_lighttablectrl_2.TableCtrl-button.TableCtrl-button-icon.Add")
    public PageElement createAccessForYourTicketButton;

    @Override
    protected PageElement getPageCheckElement() {
        return this.createAccessForYourTicketButton;
    }
}
