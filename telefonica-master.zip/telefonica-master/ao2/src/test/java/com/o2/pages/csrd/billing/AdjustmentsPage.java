package com.o2.pages.csrd.billing;

import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.FindByKey;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.nttdata.cinnamon.driver.controls.PageElementCollection;
import com.o2.models.csrd.AdjustmentRow;
import com.o2.pages.BasePage;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.stream.Collectors;

import static com.nttdata.cinnamon.wait.ElementConditions.displayed;
import static org.assertj.core.api.Assertions.assertThat;

public class AdjustmentsPage extends BasePage {
    @Find(by = By.CssSelector, locator = "button[class^='gwt-Button button_action_id_9135750323813122866_9135827151313145021_baiptablectrl_']")
    public PageElement creditAdjustmentButton;

    @Find(by = By.Id, locator = "9135500469613532487")
    public PageElement adjustmentAmount;

    @Find(by = By.CssSelector, locator = "input[id^='id_refsel'][id$='_input']")
    public PageElement adjustmentType;

    @Find(by = By.CssSelector, locator = ".refsel_arrow")
    public PageElement adjustmentTypeArrow;

    @Find(by = By.Id, locator = "nc_refsel_list_table")
    public PageElement adjustmentTypeOptionsContainer;

    @FindByKey(key ="adujstmentDesciption")
    public PageElement adjustmentDescription;

    @FindByKey(key ="adujstmentCreateButton")
    public PageElement adjustmentCreateButton;

    // *** Adjustments Table ***
    @Find(by = By.CssSelector, locator = "#\\39 135750323813122866")
    public PageElement adjustmentsTable;

    // *** Adjustments Table ***

    @Override
    public PageElement getPageCheckElement() {
        return this.creditAdjustmentButton;
    }

    public void selectAdjustmentType(String type) {
        this.adjustmentTypeArrow.click();
        assertThat(this.adjustmentTypeOptionsContainer.waitUntil(displayed).isDisplayed(2))
                .withFailMessage("No adjustment options opened while clicking on drop down!")
                .isTrue();

        PageElementCollection options = this.adjustmentTypeOptionsContainer.findChildren(By.Tag, "div");
        PageElement option = options.asList()
                .stream()
                .filter(el -> el.getText().toLowerCase(Locale.ROOT).contains(type.toLowerCase(Locale.ROOT)))
                .findFirst()
                .orElse(null);

        assertThat(option)
                .withFailMessage(
                        MessageFormat.format(
                                "Could not find an option with name: ''{0}''. Existing options are:\n{1}",
                                type,
                                options.asList().stream().map(PageElement::getText).collect(Collectors.joining("\n")))
                )
                .isNotNull();

        Objects.requireNonNull(option).click();
    }

    public void sortByName() {
        // TODO: we can make this more robust to it can be applied for any column
        PageElement nameColumnHeader = this.adjustmentsTable.waitUntil(displayed)
                .findChild(By.CssSelector, "span[aria-label='Name']");
        nameColumnHeader.click();
        waitForNcLoadingToComplete(3);
    }

    public List<AdjustmentRow> getAdjustmentRows() {
        assertThat(this.adjustmentsTable.isDisplayed(2))
                .withFailMessage("Adjustment Table not displayed on Adjustments Page!")
                .isTrue();

        List<AdjustmentRow> adjustmentRows = new ArrayList<>();

        PageElement tbody = this.adjustmentsTable.findChild(By.Tag, "tbody");
        PageElementCollection tableRows = tbody.findChildren(By.Tag, "tr");
        for (PageElement row : tableRows.asList()) {
            adjustmentRows.add(new AdjustmentRow(row.findChildren(By.Tag, "td")));
        }

        return adjustmentRows;
    }
}
