package com.o2.stepdefs.ecare;

import static com.nttdata.cinnamon.wait.ElementConditions.*;
import static com.nttdata.cinnamon.wait.conditions.Conditions.ajaxFinished;
import static com.nttdata.cinnamon.wait.conditions.Conditions.readyState;
import static org.assertj.core.api.Assertions.assertThat;

import com.google.inject.Inject;
import com.nttdata.cinnamon.cache.Context;
import com.nttdata.cinnamon.driver.Browser;
import com.nttdata.cinnamon.webdriver.util.ReadyState;
import com.o2.models.ecare.EcareUser;
import com.o2.pages.ecare.AccountLandingPage;
import com.o2.pages.ecare.SignInPage;
import com.o2.stepdefs.BaseStep;

import com.o2.util.Common;
import io.cucumber.java.en.And;
import io.cucumber.java.en.When;

public class SignInSteps extends BaseStep {
	private final Context context;
	private final SignInPage signInPage;
	private final AccountLandingPage accountLandingPage;
	private final Browser browser;
	private final Common common;

	@Inject
	public SignInSteps(final Context context, final SignInPage signInPage,
					   final AccountLandingPage accountLandingPage, Browser browser, Common common) {
		this.context = context;
		this.signInPage = signInPage;
		this.accountLandingPage = accountLandingPage;
		this.browser = browser;
		this.common = common;
	}

	@When("^I log into eCare$")
	public void i_log_into_ecare() {
		this.logger.info("** Attempt to login into eCare ...");

		EcareUser eCareUser = (EcareUser) this.context.get("ecareLoginData");

		this.signInPage.email.setValue(eCareUser.username);
		this.signInPage.continueButton.click();
		this.signInPage.password.waitUntil(displayed).setValue(eCareUser.password);
		this.signInPage.continueButton.click();

		if (this.signInPage.manageCookiesBtn.isDisplayed()) {
			this.signInPage.manageCookiesBtn.click();
			this.signInPage.acceptAllCookiesBtn.click();
		}
		this.logger.info("** Waiting for Home landing page to open ...");
		this.browser.waitUntil(ajaxFinished);
		this.browser.waitUntil(readyState(ReadyState.COMPLETE));
        this.common.wait(10);
		assertThat(accountLandingPage.isWelcomeMessageDisplayed())
				.withFailMessage("eCare home page not opened!")
				.isTrue();
		/*TODO : need to check
		assertThat(accountLandingPage.getWelcomeMessage())
				.withFailMessage("Wrong welcome message on Home page!")
				.isEqualTo(MessageFormat.format("Welcome, {0}", eCareUser.firstName));*/

		this.logger.info("** Login into eCare complete!");
	}

	@And("^I logout from eCare$")
	public void i_logout_from_eCare() {
		this.logger.info("** Attemp to logout from eCare!");
		assertThat(signInPage.signOutLink.isDisplayed()).withFailMessage(
						"Logout link is not displayed..")
				.isTrue();
		signInPage.signOutLink.waitUntil(enabled.and(clickable)).clickJs();
		signInPage.waitForProcessLoadingToComplete(20, 2, 2);

		assertThat(signInPage.signOutLink.isDisplayed()).withFailMessage(
						"Logout page is not displayed..")
				.isFalse();
		this.logger.info("** Successfully logout from eCare!");

	}
	}
