package com.o2.pages.ecomm;

import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.nttdata.cinnamon.driver.controls.PageElementCollection;
import com.o2.models.ecomm.AccessoriesSelectedDetail;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

public class AccessoriesSelectedDetailPage extends EcommBasePage {


    @Find(by = By.XPath, locator = "//span[contains(text(),' Add to basket ')]")
    public PageElement AddToBasketBtn;

    @Find(by = By.XPath, locator = "//o2uk-device-details-header//o2uk-device-details-header//h1/span")
    public PageElementCollection deviceDetailParent;

    @Find(by = By.XPath, locator = "//o2uk-price/div/div/span")
    public PageElement devicePrice;

    @Find(by = By.XPath, locator = "//device-option/variant-dropdown//div[2]/label[2]")
    public PageElement deviceColor;

    @Find(by = By.XPath, locator = "//o2uk-device-details-header/o2uk-device-details-header//img")
    public PageElement deviceImg;

    @Find(by = By.XPath, locator = "//device-option/o2uk-stock-availability//p[@class='o2uk-stock-availability__info-title']")
    public PageElement iStockOROutOfStock;


    public List<AccessoriesSelectedDetail> getAllAccessoriesSelectedDetail() {
        if (deviceDetailParent == null) {
            this.logger.warn("No Accessories detail found on the Accesorries detail page! Is this a negative scenario?");
            return null;
        }

        List<AccessoriesSelectedDetail> allAccessoriesSelectedDetail = new ArrayList<>();
        this.logger.info(MessageFormat.format("Found {0} Accessories detail  on the page. Continue ...",
                (long) deviceDetailParent.asList().size()));
        this.browser.setImplicitWait(5);

        AccessoriesSelectedDetail accessoriesSelectedDetailList = new AccessoriesSelectedDetail(
                this.browser.findBy(By.XPath,"//o2uk-device-details-header//o2uk-device-details-header//h1/span[1]"),
                this.browser.findBy(By.XPath,"//o2uk-device-details-header//o2uk-device-details-header//h1/span[2]").getText(),
                this.browser.findBy(By.XPath,"//o2uk-price/div/div/span").getText(),
                this.browser.findBy(By.XPath,"//device-option/o2uk-stock-availability//p[@class='o2uk-stock-availability__info-title']").getText(),
                this.browser.findBy(By.XPath,"//o2uk-device-details-header/o2uk-device-details-header//img"),
                this.browser.findBy(By.XPath,"//device-option/variant-dropdown//div[2]/label[2]").getText());

        allAccessoriesSelectedDetail.add(accessoriesSelectedDetailList);
        this.browser.restoreImplicitWait();
        return allAccessoriesSelectedDetail;

    }
}
