package com.o2.pages.ecomm;

import com.google.inject.Inject;
import com.nttdata.cinnamon.driver.Browser;
import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.nttdata.cinnamon.logging.Logger;
import com.o2.core.util.Retry;

import static com.nttdata.cinnamon.wait.ElementConditions.displayed;
import static com.nttdata.cinnamon.wait.ElementConditions.enabled;
import static org.assertj.core.api.Assertions.assertThat;

public abstract class BasePage {
    @Inject
    public Logger logger;
    @Inject
    protected Browser browser;
    @Inject
    Retry retry;

    @Find(by = com.nttdata.cinnamon.driver.By.CssSelector, locator = ".o2uk-buble-loader__gif")
    public PageElement processIconElement;

    @Find(by = By.XPath, locator = "//img[@alt='Just a moment']")
    public PageElement justAMomentLoader;

    @Find(by = By.CssSelector, locator = "#ni_imp_prim_accept")
    public PageElement chatPopupCloseButton;

    protected PageElement getPageCheckElement() {
        this.logger.warn("getPageCheckElement() called from BasePage! This has to be overwritten in the page object that is used/called!");

        return null;
    }

    public boolean isPageDisplayed() {
        return getPageCheckElement() != null && getPageCheckElement().isDisplayed();
    }

    public void waitForProcessLoadingToComplete(int retries, int pollingInterval, int implicitWait) {
        this.logger.info(">>> Wait for Process Loading to complete ...");

        Boolean result = this.retry.untilNotDisplayed(
                () -> processIconElement, retries, pollingInterval, implicitWait);

        assertThat(result)
                .withFailMessage("Process Loading icon still displayed!")
                .isTrue();

        this.logger.info(">>> Process Loading complete!");
    }

    public void waitForjustaMomentLoadingToComplete(int retries, int pollingInterval, int implicitWait) {
        this.logger.info(">>> Wait for Just a Moment Loading to complete ...");

        Boolean result = this.retry.untilNotDisplayed(
                () -> justAMomentLoader, retries, pollingInterval, implicitWait);

        assertThat(result)
                .withFailMessage("Just a Moment Loading icon still displayed!")
                .isTrue();

        this.logger.info(">>> Just a Moment Loading complete!");
    }

    public void closeChatPopup() {
        logger.info("Attempt to close Chat Popup ...");

        try{
            browser.setImplicitWait(1);
            boolean result = retry.retryAction(() -> chatPopupCloseButton.isDisplayed(), 3, 1);

            if (result) {
                logger.info("Chat Popup found. Closing it ...");
                chatPopupCloseButton.waitUntil(displayed.and(enabled)).click();
                assertThat(chatPopupCloseButton.isDisplayed())
                        .withFailMessage("Unable to close Chat Popup!")
                        .isFalse();
                logger.info("Chat Popup successfully closed!");

                result = retry.retryAction(() -> chatPopupCloseButton.isDisplayed(), 4, 1);
                if (result) {
                    logger.info("2nd Chat Popup found. Closing it ...");
                    chatPopupCloseButton.waitUntil(displayed.and(enabled)).click();
                    assertThat(chatPopupCloseButton.isDisplayed())
                            .withFailMessage("Unable to close 2nd Chat Popup!")
                            .isFalse();
                    logger.info("2nd Chat Popup successfully closed!");
                }
            } else {
                logger.info("Chat Popup not found or already closed!");
            }
            browser.restoreImplicitWait();
        } catch(Exception e){
            e.printStackTrace();
        }

    }
}
