package com.o2.stepdefs.ecomm;

import com.google.inject.Inject;
import com.nttdata.cinnamon.cache.Context;
import com.nttdata.cinnamon.driver.Browser;
import com.nttdata.cinnamon.webdriver.util.ReadyState;
import com.o2.models.ecomm.AccesoriesBasket;
import com.o2.pages.ecomm.AccesoriesBaksetPage;
import com.o2.pages.ecomm.TariffsPage;
import io.cucumber.java.en.And;

import java.util.ArrayList;
import java.util.List;

import static com.nttdata.cinnamon.wait.conditions.Conditions.readyState;

public class AccessoriesBasketSteps extends BaseStep {
    private final Browser browser;
    private final AccesoriesBaksetPage accesoriesBaksetPage;
    private final Context context;
    private final TariffsPage tariffsPage;


    @Inject
    public AccessoriesBasketSteps(final Browser browser, final AccesoriesBaksetPage accesoriesBaksetPage, TariffsPage tariffsPage, final Context context) {
        this.browser = browser;
        this.accesoriesBaksetPage = accesoriesBaksetPage;
        this.tariffsPage = tariffsPage;
        this.context = context;
    }

    @And("^I verify accessories item added to basket$")
    public void iVerifyBasket() {

        browser.setImplicitWait(30);
        //accesoriesBaksetPage.basketPageHeader.waitUntil(displayed);
        this.browser.waitUntil(readyState(ReadyState.COMPLETE));
        List<AccesoriesBasket> basket = accesoriesBaksetPage.getItemAddedInBasket();
        List<String> acccessoriesBasketDetail = new ArrayList<>();
        for (int i = 0; i < acccessoriesBasketDetail.size(); i++) {
            acccessoriesBasketDetail.add(basket.get(i).price.asList().get(i).getText());
            acccessoriesBasketDetail.add(basket.get(i).accessoriesColour.getText());
            acccessoriesBasketDetail.add(basket.get(i).price.asList().get(i).getText());
            context.set("BasketDetail", acccessoriesBasketDetail);
        }
        if(tariffsPage.haveOrderInProgress.isDisplayed()){
//            tariffsPage.haveOrderInProgressCloseButton.clickJs();
            tariffsPage.finishCheckingout.clickJs();
        }
        //TODO this is commented to check when have Order in Progress is displaed
        if((accesoriesBaksetPage.checkoutBtn.isDisplayed()))
            accesoriesBaksetPage.checkoutBtn.click();

    }
}
