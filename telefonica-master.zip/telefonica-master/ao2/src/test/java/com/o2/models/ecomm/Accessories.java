package com.o2.models.ecomm;

import com.nttdata.cinnamon.driver.controls.PageElement;

public class Accessories {
    public PageElement title;
    public PageElement name;
    public PageElement price;
    public PageElement  addAccessory;

    public Accessories(PageElement title, PageElement name, PageElement price) {
        this.title = title;
        this.name = name;
        this.price = price;
    }
    public Accessories(PageElement title, PageElement name, PageElement price,PageElement  addAccessory) {
        this.title = title;
        this.name = name;
        this.price = price;
       this.addAccessory=addAccessory;
    }

    @Override
    public boolean equals(Object classobject) {
        if (classobject == this)
            return true;
        if (!(classobject instanceof Accessories))
            return false;

        Accessories extra = (Accessories) classobject;
        return extra.title.equals(this.title);

    }
}
