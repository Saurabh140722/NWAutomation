package com.o2.pages.ecare;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.nttdata.cinnamon.driver.controls.PageElementCollection;
import com.o2.models.ecare.BoltOn;

public class BuyBoltOnPage extends EcareBasePage {
	@Find(by = By.XPath, locator = "//h1[@class='o2uk-header-curve__text-title ng-star-inserted']")
	public PageElement pageTitle;

	@Find(by = By.XPath, locator = "//*[text()='Bolt On type']/following::select//option")
	public PageElementCollection boltOnTypeOptions;

	@Find(by = By.XPath, locator = "//*[text()='Bolt On type']/following::select")
	public PageElement boltOnOptions;

	@Find(by = By.XPath, locator = "//o2uk-option[@role='option']")
	public PageElementCollection boltOnTypeOptions1;

	@Find(by = By.Id, locator = "mat-select-0")
	public PageElement boltOnTypeOption;

	@Find(by = By.XPath, locator ="//*[text()='Bolt On type']/following::select")
	public PageElement selctboltOnTypeOptions;

	@Find(by = By.XPath, locator ="//*[text()='Bolt On type']/following::div[contains(@class,'select-trigger')]")
	public PageElement boltOnTypeDropdown;

	@Find(by = By.XPath, locator ="//*[contains(@class,'o2uk-option-content')]")
	public PageElementCollection boltOnTypeDropdownOptions;

	@Find(by = By.XPath, locator = "//div[@class='add-on__wrapper']")
	public PageElementCollection boltPlanElements;

	@Find(by = By.XPath, locator = "//div[@class='o2uk-checkbox-inner-container']")
	public PageElement termConditionCheckBox;

	@Find(by = By.XPath, locator = "//button[@class='mat-focus-indicator mat-button-base o2uk-primary-button mat-dark-blue']")
	public PageElement addBoltOnBtn;

	@Find(by = By.XPath, locator = "//p[contains(text(), 'Already covered')]")
	public PageElement alreadyCovered;

	@Find(by = By.XPath, locator = "//h3[text()='Order error']")
	public PageElement orderErrorPopUp;

	@Find(by = By.CssSelector, locator = ".notification-dialog.ng-star-inserted")
	public PageElement serverErrorPopup;

	@Find(by = By.XPath, locator = "//div[contains(@class,'o2uk-notification-dialog__content')]")
	public PageElement orderErrorPopUpText;

	@Find(by = By.XPath, locator = "//button[@aria-label='close dialog']")
	public PageElement orderErrorPopUpClose;

	@Override
	public boolean isPageDisplayed() {
		if (!pageTitle.isDisplayed())
			return false;

		return pageTitle.getText().trim().contains("Buy a bolt on");
	}

	public List<BoltOn> getAllBoltOn() {
		if (boltPlanElements == null) {
			this.logger.warn("No Bolt On plans found on the page! Is this a negative scenario?");
			return null;
		}

		List<BoltOn> allBoltOnPlans = new ArrayList<>();
		this.logger.info(MessageFormat.format("Found {0} Bolt ON plans on the page. Continue ...",
				(long) boltPlanElements.asList().size()));

		/*
		 * We know the Bold On cards are already displayed on the page at this step,
		 * therefore we'll wait for just 3 seconds to get all needed children If
		 * something will be null then it is for sure because the locators have changed
		 */
		this.browser.setImplicitWait(3);
		for (PageElement bo : boltPlanElements.asList()) {
			BoltOn boltOn = new BoltOn();
			boltOn.title = bo.findChild(By.CssSelector, ".add-on__info-title");
			boltOn.price = bo.findChild(By.CssSelector, ".o2uk-price.ng-star-inserted");
			boltOn.addToPlanButton = bo.findChild(By.CssSelector, ".mat-button-wrapper");

			allBoltOnPlans.add(boltOn);
		}
		this.browser.restoreImplicitWait();

		return allBoltOnPlans;
	}

}
