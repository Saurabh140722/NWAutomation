package com.o2.api;

import com.google.inject.Inject;
import com.nttdata.cinnamon.MethodType;
import com.nttdata.cinnamon.RequestBuilder;
import com.nttdata.cinnamon.Response;
import com.nttdata.cinnamon.enums.MediaTypeEnum;
import com.nttdata.cinnamon.logging.Logger;
import com.o2.api.model.AuthorisationToken;
import jdk.jshell.spi.ExecutionControl;

import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.text.MessageFormat;
import java.util.UUID;

public class OrderProcess {
    private final Logger logger;
    private final RequestBuilder requestBuilder;
    private final Response response;
    private AuthorisationToken authorisationToken;

    @Inject
    public OrderProcess(final Logger logger,
                        final RequestBuilder requestBuilder,
                        final Response response) {
        this.logger = logger;
        this.requestBuilder = requestBuilder;
        this.response = response;
    }

    public AuthorisationToken getAuthorisationToken() throws MalformedURLException, ExecutionControl.NotImplementedException, URISyntaxException {
        String body = MessageFormat.format("grant_type={0}&client_assertion_type={1}&client_assertion={2}",
                "client_credentials",
                "urn%3Aietf%3Aparams%3Aoauth%3Aclient-assertion-type%3Ajwt-bearer&",
                "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJFMkVfVGVzdGluZyIsInN1YiI6IkUyRSIsImF1ZCI6ImFwaS5yZWYubzIuY28udWsvYXBpL3Rva2VuIiwiZXhwIjoxNjc3NDE3NjYwMDAwLCJpYXQiOjE1ODI3MjMyNjAwMDB9.hqS44NBnyz5vGxplMsijONd23SU9y1j908za9EMM7EapQwtpcdQpWjslezkmqx2a-BeMXupX6auEJdyFJcs8G1OWcBCZ19PT4F9N609TiSrFQyV6XdkOlq_MZnTY3ODdAu3CGptCdwJO1j-F4RUNCglYCdBteIsRH32GuFxBK96Ju1M1G7eeTuIYruI78iar2Ne9Bdj2V8JmsEdxfwvAkTRoGv9iG4MD3XuwzhLCVNhhPKF0AQyxGd2HOHeND9r30sbkuKunD_SpvGCEpQv8OjWBbEpaP__uzLkdHkoshiQn__xcNVLWRavft2xLKmXP2RwLOCBCtamhLRZFMaBrPA"
        );

        this.requestBuilder
                .init()
                .scheme("https")
                .host("api.ref.o2.co.uk/api/token")
                .headers("Authorization", "Basic YWJzLXRlc3Q6cGFzc3cwcmQ")
                .headers("Content-Type", "application/x-www-form-urlencoded")
                .headers("debugFlag", "true")
                .body(body)
                .method(MethodType.POST)
                .send();

        this.authorisationToken = this.requestBuilder.getResponse().response(AuthorisationToken.class);

        this.logger.info("Response Status Code: " + this.requestBuilder.getResponse().statusCode());
        this.logger.info("Raw Response:\n" + this.requestBuilder.getResponse().rawResponse());

        return null;
    }

    public AuthorisationToken sendPlaceOrder() throws MalformedURLException, ExecutionControl.NotImplementedException, URISyntaxException {
        String body = "<soap:Envelope xmlns:soap=\"http://www.w3.org/2003/05/soap-envelope\">\n" +
                "<soap:Header/>\n" +
                "<soap:Body>\n" +
                "<OrderStatusNotification xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" jdeCompany=\"00030\" customerNumber=\"NC01-04\" orderNumber=\"32349548\" customerOrderNumber=\"NC837501\" statusCode=\"8\" statusDetail=\"Order Despatched\" despatchedDate=\"2021-02-08T14:01:03\" orderedDate=\"2021-02-04\" orderType=\"SO\" messageVersion=\"3.1\" xmlns=\"http://xmlns.brightstar.com/ebo/Core/wopa/V3\">\n" +
                "<orderLines>\n" +
                "<orderLine lineNumber=\"1\" productCode=\"25GTRIVN\" description=\"POSTPAY 5G TRIPLE HALF SI\" extendedAmount=\"0.00\" orderedQuantity=\"1\" shippedQuantity=\"1\">\n" +
                "<serialDetails>\n" +
                "<serialDetail>\n" +
                "<serial type=\"SIM\" value=\"8944110068265390737\" mpn=\"\" />\n" +
                "</serialDetail>\n" +
                "</serialDetails>\n" +
                "</orderLine>\n" +
                "</orderLines>\n" +
                "<orderConsignments>\n" +
                "<orderConsignment reference=\"31406760178898\" longReference=\"AB33 831406760178898001\" courierDate=\"2021-02-08T09:05:44\" shippedCourierName=\"UK Mail\" shippedServiceType=\"401\" podStatus=\"Shipped\" />\n" +
                "</orderConsignments>\n" +
                "<deliveryAddress name=\"Ms Noda Poul\" line1=\"533\" line2=\"YARDLEY GREEN RD\" line3=\"BIRMINGHAM\" line4=\"United Kingdom\" postcode=\"B33 8TH\" country=\"United Kingdom\" />\n" +
                "</OrderStatusNotification>\n" +
                "</soap:Body>\n" +
                "</soap:Envelope>";

        this.requestBuilder
                .init()
                .scheme("https")
                .host("api.ref.o2.co.uk/tuk/uat/apic/api/v1/WMS/despatchStatus")
                .headers("X-IBM-Client-Id", "dd83d3decfa30bacc6da539011ad7aae")
                .headers("X-IBM-Client-Secret", "028464dfb81a75b0f473a589f8fb4e84")
                .headers("X-Client-Transaction-Id", UUID.randomUUID().toString())
                .headers("X-Requesting-User", "System")
                .headers("Authorization", "Bearer eyJhbGciOiJSUzI1NiIsImtpZCI6ImlkZyJ9.eyJpc3MiOiJodHRwczovL2FwaS5yZWYubzIuY28udWsiLCJhdWQiOiJhYnMtdGVzdCIsImV4cCI6MTYyMTQyNDY1Ny4xNjR9.Efi8wlueo9OhOBCfOYWhWoNFoNg4feEIz6Iwd9v-IW-cjX62PZGS46KZPwLtNoa0BB-5YzslngOSCBnnnLOfY_1BQ89hHusmwra149P1F_cjMlNbbWdjt8Axn2xz0N6Z3D9TZDFRD3GcTRhnWpnM5Q1P_n13eqfWX7yCcREP1o4Fb6G_7ZlfZwESJy7wGpFX2_htPemSsV13eahObmE-lNbjsZyXT2fTd2_TENCysz10i7BwO8qxsWBJLF6fyKV3gciOhP3qUPbAU_i7TR65kL0iaoJoHIFXbxTaR_7ym4mDN4YQThC7zQ7P-w5idaTOunVLGn4dPg1elfoUGMT7cA")
                .headers("debugFlag", "true")
                .body(body)
                .method(MethodType.PUT)
                .mediaType(MediaTypeEnum.TEXT_XML)
                .send();

        logger.info("Response Status Code: " + this.requestBuilder.getResponse().statusCode());
        logger.info("Raw Response:\n" + this.requestBuilder.getResponse().rawResponse());

        return null;
    }
}
