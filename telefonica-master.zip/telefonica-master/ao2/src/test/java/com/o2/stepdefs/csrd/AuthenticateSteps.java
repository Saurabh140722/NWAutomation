package com.o2.stepdefs.csrd;

import com.google.inject.Inject;
import com.nttdata.cinnamon.logging.Logger;
import com.o2.core.util.Common;
import com.o2.pages.csrd.AuthenticateCustomerPage;
import com.o2.stepdefs.BaseStep;
import io.cucumber.java.en.When;

import java.text.MessageFormat;

import static org.assertj.core.api.Assertions.assertThat;

public class AuthenticateSteps extends BaseStep {
    private final Common common;
    private final Logger logger;
    private final AuthenticateCustomerPage authenticateCustomerPage;

    @Inject
    public AuthenticateSteps(final Common common,
                             final Logger logger,
                             final AuthenticateCustomerPage authenticateCustomerPage) {
        this.common = common;
        this.logger = logger;
        this.authenticateCustomerPage = authenticateCustomerPage;
    }

    @When("^I authenticate them by '(.*)' and user '(is|is not)' account owner$")
    public void i_authenticate_them_by_and_user_is_or_not_account_owner(String authenticateOption, String isOrNotAccountOwner) {
        this.logger.info("*** Agent Authentication Options page loading ...");

        assertThat(this.authenticateCustomerPage.isPageDisplayed())
                .withFailMessage("Agent Authentication Options page not displayed!")
                .isTrue();

        boolean isAccountOwner = isOrNotAccountOwner.equalsIgnoreCase("is");
        if (isAccountOwner) {
            this.authenticateCustomerPage.isAccountOwner.click();
        } else {
            this.authenticateCustomerPage.isNotAccountOwner.click();
        }
        this.authenticateCustomerPage.getAuthenticateOptions(authenticateOption).click();
        this.authenticateCustomerPage.continueButton.click();
//        this.common.waitForLoadingToComplete(12, 1);

        this.logger.info(MessageFormat.format("*** Authentication by ''{0}'' selected!", authenticateOption));
    }

    @When("^I override the authentication$")
    public void i_override_the_authentication() {
        this.logger.info("*** Agent Authentication Options page loading ...");

        this.authenticateCustomerPage.override.click();

        this.logger.info("*** Authentication by overriding complete!\n");
    }

    @When("^I accept the it policy$")
    public void i_accept_it_policy() {
        this.logger.info("*** Agent Authentication Options page loading ...");
        this.authenticateCustomerPage.acceptBtn.click();
        this.logger.info("*** Authentication by overriding complete!\n");
    }

}
