package com.o2.models.ecomm;

import java.text.MessageFormat;
import java.util.List;

public class EcommUser {
    public String userType;
    public String planType;
    public String username;
    public String email;
    public String password;
    public String securityCode;
    public String title;
    public String firstName;
    public String lastName;
    public String mobile;
    public String dob;
    public String postalCode;



    @Override
    public String toString() {
        return MessageFormat.format("Login eCare User:" +
                        "\n\tUsertype:\t\t\t{0}" +
                        "\n\tUsername:\t\t{1}" +
                        "\n\tPassword:\t\t{2}",
                this.userType,
                this.username,
                this.password
        );
    }

    /*
    public String userType;
    public String planType;
    public String username;
    public String password;
    public String securityCode;
    public String title;
    public String firstName;
    public String lastName;
    public String mobile;
    public List<EcommUserAddress> addresses;

    @Override
    public String toString() {
        return MessageFormat.format("Login eCare User:" +
                        "\n\tPlan:\t\t\t{0}" +
                        "\n\tUsername:\t\t{1}" +
                        "\n\tPassword:\t\t{2}" +
                        "\n\tCode:\t\t\t{3}" +
                        "\n\tTitle:\t\t\t{4}" +
                        "\n\tFirst Name:\t\t{5}" +
                        "\n\tLast Name:\t\t{6}" +
                        "\n\tMobile:\t\t\t{7}",
                this.planType,
                this.username,
                this.password,
                this.securityCode,
                this.title,
                this.firstName,
                this.lastName,
                this.mobile
        );
    }*/
}
