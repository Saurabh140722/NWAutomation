package com.o2.stepdefs.ecare;

import com.google.inject.Inject;
import com.nttdata.cinnamon.conf.Env;
import com.nttdata.cinnamon.driver.Browser;
import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.nttdata.cinnamon.driver.controls.PageElementCollection;
import com.nttdata.cinnamon.webdriver.util.ReadyState;
import com.o2.pages.ecare.DataUsageLatestBillDetailDevicePlanPage;
import com.o2.stepdefs.BaseStep;
import com.o2.util.Common;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

import static com.nttdata.cinnamon.wait.ElementConditions.displayed;
import static com.nttdata.cinnamon.wait.conditions.Conditions.readyState;
import static org.assertj.core.api.Assertions.assertThat;

public class DataUsageLatestBillDetailDevicePlanSteps extends BaseStep {
    private final Browser browser;
    private final Common common;
    private final DataUsageLatestBillDetailDevicePlanPage dataUsageLatestBillDetailDevicePlanPage;

    @Inject
    public DataUsageLatestBillDetailDevicePlanSteps(final DataUsageLatestBillDetailDevicePlanPage dataUsageLatestBillDetailDevicePlanPage, final Browser browser, final Common common) {
        this.browser = browser;
        this.dataUsageLatestBillDetailDevicePlanPage = dataUsageLatestBillDetailDevicePlanPage;
        this.common = common;

    }

    @Then("I checked the data usages and current charged along with latest bill")
    public void i_checked_data_usage_current_charges_latest_bill() {
        this.common.waitForLoadingToComplete(5, 2);
        assertThat(this.dataUsageLatestBillDetailDevicePlanPage.dataMinutesMessageGraphDetail.asList().get(0).isDisplayed())
                .withFailMessage("Data usage graph is not displayed!").isTrue();
        assertThat(this.dataUsageLatestBillDetailDevicePlanPage.dataMinutesMessageGraphDetail.asList().get(1).isDisplayed())
                .withFailMessage("Minutes graph is not displayed!").isTrue();
        assertThat(this.dataUsageLatestBillDetailDevicePlanPage.dataMinutesMessageGraphDetail.asList().get(2).isDisplayed())
                .withFailMessage("Messages graph is not displayed!").isTrue();
        this.dataUsageLatestBillDetailDevicePlanPage.viewChargesBtn.click();
        this.browser.setImplicitWait(5);
        assertThat(this.dataUsageLatestBillDetailDevicePlanPage.currentChargesPanel.asList().get(2).isDisplayed())
                .withFailMessage(" Data Current extra charges Panel is not displayed!").isTrue();
        this.browser.restoreImplicitWait();
    }

    @And("I click on view latest bill")
    public void i_click_on_latest_bill() {
        this.common.waitForLoadingToComplete(2, 1);
        assertThat(this.dataUsageLatestBillDetailDevicePlanPage.LatestBillTitle.isDisplayed())
                .withFailMessage("Latest bill title is not displayed!").isTrue();
        this.dataUsageLatestBillDetailDevicePlanPage.viewLatestBillBtn.click();
        assertThat(this.dataUsageLatestBillDetailDevicePlanPage.billChargeSummaryTtitle.isDisplayed())
                .withFailMessage("charge Summary title is not displayed!").isTrue();

    }

    @And("I click on  Manage Device Plan")
    public void i_click_on_manage_device_plan_button() {
        dataUsageLatestBillDetailDevicePlanPage.ManageDevicePlan.scrollIntoView().clickJs();
        dataUsageLatestBillDetailDevicePlanPage.ManageDevicePlanHeaderDetails.waitUntil(displayed);
        dataUsageLatestBillDetailDevicePlanPage.ManageDevicePlanHeader.waitUntil(displayed);
    }

    @Then("I should see the manage device plan detail page")
    public void i_should_see_manage_device_plan_page() {
        assertThat(this.dataUsageLatestBillDetailDevicePlanPage.manageDevicePageContainerLeft.isDisplayed())
                .withFailMessage("Manage device plan container left is not displayed!").isTrue();
        assertThat(this.dataUsageLatestBillDetailDevicePlanPage.manageDevicePageContainerRight.isDisplayed())
                .withFailMessage("Manage device plan container right is not displayed!").isTrue();
    }

    @When("I click on your insurance policy link")
    public void i_click_on_insurance_policy_link() {

        this.dataUsageLatestBillDetailDevicePlanPage.insurancePolicyLink.click();
    }


    @Then("I should see insurance policy should be downloaded")
    public void i_should_see_insurnace_policy_should_downloaded() {
        this.browser.switchToTab(0);
        this.browser.currentUrl().contains(Env.get().envProperty("eCareHost"));
    }


    @And("I click on current charges arrow")
    public void i_click_on_current_extra_charges_arrow_link() {
        this.common.waitForLoadingToComplete(2, 1);
        this.dataUsageLatestBillDetailDevicePlanPage.viewChargesBtn.click();
        this.browser.setImplicitWait(5);
        assertThat(this.dataUsageLatestBillDetailDevicePlanPage.currentChargesPanel.asList().get(2).isDisplayed())
                .withFailMessage(" Data Current extra charges Panel is not displayed!").isTrue();
        this.dataUsageLatestBillDetailDevicePlanPage.currentChanrgesArrowLink.asList().get(2).click();
        this.browser.restoreImplicitWait();
    }

    @And("I select the billing period")
    public void i_select_billing_period() {
        this.dataUsageLatestBillDetailDevicePlanPage.billingPeriod.click();
        PageElementCollection options = this.dataUsageLatestBillDetailDevicePlanPage.billingPeriod.findChildren(By.Tag, "option");
        options.asList().get(1).click();


    }

    @And("I can usee usageGraphCard along with DataRoaming zone")
    public void i_can_see_usage_graph_card_with_data_roaming_zone() {
        assertThat(this.dataUsageLatestBillDetailDevicePlanPage.usageGraphCard.isDisplayed())
                .withFailMessage("Usage Graph Card are not displayed!").isTrue();
        PageElementCollection dataUsageGraphCardRows = this.dataUsageLatestBillDetailDevicePlanPage.usageGraphCard.findChildren(By.Tag, "div");
        assertThat(dataUsageGraphCardRows.asList().get(2).isDisplayed())
                .withFailMessage("Biggest expanse and data roaming Zone3 is not displayed!").isTrue();

    }

    @When("I click on Data roaming zone")
    public void i_click_on_data_roaming_zone_link() {
        this.common.waitForLoadingToComplete(2, 1);
        this.dataUsageLatestBillDetailDevicePlanPage.dataRoamingZoneLink.click();
    }

    @When("I can see Data Roaming zone detail along with other detail in everything tab")
    public void i_can_see_data_roaming_zone() {
        String dataRoamingDataDetail = this.dataUsageLatestBillDetailDevicePlanPage.dataRoamingZoneLink.getText();
        for (PageElement chargeCardTtile : this.dataUsageLatestBillDetailDevicePlanPage.chargesCardTitleForEverythingTab.asList()) {
            if (chargeCardTtile.getText().equalsIgnoreCase(dataRoamingDataDetail)) {
                assertThat(chargeCardTtile.isDisplayed())
                        .withFailMessage("Expected data roaming zone panel is not displayed!").isTrue();
                break;
            }
        }


    }

    @And("I can see monthaly extras header")
    public void i_can_see_mobile_extras_header() {

        for (PageElement chargeSummaryDetail : this.dataUsageLatestBillDetailDevicePlanPage.chargeSummaryHeaderDetail.asList()) {
            PageElement chargesDetailParagraph = chargeSummaryDetail.findChild(By.Tag, "p");
            if (chargesDetailParagraph.getText().equalsIgnoreCase("Monthly extras")) {
                chargesDetailParagraph.click();
                break;

            }

        }

        for (PageElement MonthlyExtraDetail : this.dataUsageLatestBillDetailDevicePlanPage.chargesCardTitleForEverythingTab.asList()) {
            assertThat(MonthlyExtraDetail.isDisplayed())
                    .withFailMessage("Monthly extra charges are not displayed!").isTrue();
        }

    }

    @Then("I can see product detail")
    public void i_can_see_productDetail() {
        for (PageElement chargeSummaryCardDetail : this.dataUsageLatestBillDetailDevicePlanPage.chargesCardWrapper.asList()) {
            PageElement iconLink = chargeSummaryCardDetail.findChild(By.CssSelector, ".o2uk-expansion-indicator");
            PageElement productName = chargeSummaryCardDetail.findChild(By.CssSelector, ".o2uk-charges__card-title");
            PageElement desciption = chargeSummaryCardDetail.findChild(By.CssSelector, ".o2uk-charges__card-description");
            PageElement bodyTitle = chargeSummaryCardDetail.findChild(By.CssSelector, ".o2uk-charges__card-body-title");
            PageElement price = chargeSummaryCardDetail.findChild(By.CssSelector, ".o2uk-price");
            this.browser.setImplicitWait(2);
            PageElement fromToDate = chargeSummaryCardDetail.findChild(By.CssSelector, ".o2uk-charges__card-body").findChild(By.Tag, "div");
            iconLink.click();
            if (productName.getText().equalsIgnoreCase("50 MMS Bolt On")) {
                assertThat(productName.isDisplayed())
                        .withFailMessage("Product Name is displayed!").isTrue();
                assertThat(desciption.isDisplayed())
                        .withFailMessage("desciption is not displayed!").isTrue();
                assertThat(price.isDisplayed())
                        .withFailMessage("price are is displayed!").isTrue();
            } else if (productName.getText().equalsIgnoreCase("O2 Travel Inclusive Zone 12 Months")) {
                assertThat(productName.isDisplayed())
                        .withFailMessage("Product Name is displayed!").isTrue();
                assertThat(desciption.isDisplayed())
                        .withFailMessage("desciption is not displayed!").isTrue();
                assertThat(price.isDisplayed())
                        .withFailMessage("price are is displayed!").isTrue();
                assertThat(bodyTitle.isDisplayed())
                        .withFailMessage("Body tile of extra charges is not displayed!").isTrue();

            } else if (productName.getText().equalsIgnoreCase("O2 Travel Inclusive Zone 12 Months")) {
                assertThat(productName.isDisplayed())
                        .withFailMessage("Product Name is displayed!").isTrue();
                assertThat(desciption.isDisplayed())
                        .withFailMessage("desciption is not displayed!").isTrue();
                assertThat(price.isDisplayed())
                        .withFailMessage("price are is displayed!").isTrue();
                assertThat(bodyTitle.isDisplayed())
                        .withFailMessage("Body tile of extra charges is not displayed!").isTrue();

            } else if (productName.getText().equalsIgnoreCase("Data Roaming Zone 2 1GB")) {
                assertThat(productName.isDisplayed())
                        .withFailMessage("Product Name is displayed!").isTrue();
                assertThat(price.isDisplayed())
                        .withFailMessage("price are is displayed!").isTrue();
                assertThat(bodyTitle.isDisplayed())
                        .withFailMessage("Body tile of extra charges is not displayed!").isTrue();

            }


        }


    }

    @When("I click on exchange button")
    public void i_click_on_exchange_button() {
        assertThat(this.dataUsageLatestBillDetailDevicePlanPage.exchangeBtn.isDisplayed())
                .withFailMessage("Exchange button  is not displayed!").isTrue();
        this.dataUsageLatestBillDetailDevicePlanPage.exchangeBtn.click();
        assertThat(this.dataUsageLatestBillDetailDevicePlanPage.lblExchangeDevice.isDisplayed())
                .withFailMessage("Exchange device label is not displayed!").isTrue();
    }

    @Then("I should see pop with excahing device detail")
    public void i_should_see_exahcnge_device_popUp() {
        assertThat(this.dataUsageLatestBillDetailDevicePlanPage.lblExchangeDevice.isDisplayed())
                .withFailMessage("Exchange device label is not displayed!").isTrue();
        this.dataUsageLatestBillDetailDevicePlanPage.cancelBtn.click();

    }

    @When("I click on return Button")
    public void i_click_on_return_button() {
        assertThat(this.dataUsageLatestBillDetailDevicePlanPage.returnBtn.isDisplayed())
                .withFailMessage("Return button is not displayed!").isTrue();
        this.dataUsageLatestBillDetailDevicePlanPage.returnBtn.click();

    }

    @And("I click on Manage Device Plan")
    public void i_Click_On_ManageDevicePlan() {
        this.browser.setImplicitWait(30);
        this.browser.waitUntil(readyState(ReadyState.COMPLETE));
        dataUsageLatestBillDetailDevicePlanPage.ManageDevicePlan.waitUntil(displayed);
        dataUsageLatestBillDetailDevicePlanPage.ManageDevicePlan.scrollIntoView().clickJs();
        dataUsageLatestBillDetailDevicePlanPage.ManageDevicePlanHeaderDetails.waitUntil(displayed);
        dataUsageLatestBillDetailDevicePlanPage.ManageDevicePlanHeader.waitUntil(displayed);
    }

    @When("I click on {string}")
    public void iClickOnViewProofOfPurchase(String deviceOption) {
        dataUsageLatestBillDetailDevicePlanPage.getDevicePlanOptionsButtons(deviceOption);
    }

    @Then("I should see {string} should be downloaded")
    public void i_Should_See_deviceOption_Should_Be_Downloaded(String deviceOption) {
        this.browser.switchToTab(10);
        this.browser.currentUrl().contains(Env.get().envProperty("eCareHost"));
    }


}
