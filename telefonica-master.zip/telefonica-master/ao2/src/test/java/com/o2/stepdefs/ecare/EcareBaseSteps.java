package com.o2.stepdefs.ecare;

import com.google.inject.Inject;
import com.nttdata.cinnamon.driver.Browser;
import com.nttdata.cinnamon.webdriver.util.ReadyState;
import com.o2.pages.ecare.EcareBasePage;
import com.o2.stepdefs.BaseStep;
import com.o2.util.Common;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

import static com.nttdata.cinnamon.wait.ElementConditions.displayed;
import static com.nttdata.cinnamon.wait.conditions.Conditions.readyState;
import static org.assertj.core.api.Assertions.assertThat;

public class EcareBaseSteps extends BaseStep {
	private final EcareBasePage ecareBasePage;
	private final Common common;
	private final Browser browser;

	@Inject
	public EcareBaseSteps(final EcareBasePage ecareBasePage,final Common common, final Browser browser) {
		this.ecareBasePage = ecareBasePage;
		this.common = common;
		this.browser = browser;
	}

	@When("^I click '(.*)' tab$")
	public void i_click_the_tab(String tabName) {
		this.logger.info("*** Attempt to click on " + tabName + " tab ...");
		this.ecareBasePage.getTab(tabName).waitUntil(displayed).click();
		this.logger.info("*** Actioning on " + tabName + " tab complete!\n");
	}

	@When("^I click '(.*)' button$")
	public void i_click_the_button(String buttonName) {
		this.logger.info("*** Attempt to click on " + buttonName + " button ...");
		this.ecareBasePage.getButton(buttonName).waitUntil(displayed).click();
		this.logger.info("*** Actioning on " + buttonName + " button complete!\n");
	}

	@Given("^I verify '(.*)' page opens successfully$")
	public void i_verify_to_page(String pageName){
		this.logger.info("** Wait to  open "+ pageName +"  page...");
		this.browser.waitUntil(readyState(ReadyState.COMPLETE));
		assertThat(this.ecareBasePage.getHeader(pageName).isDisplayed(5))
				.withFailMessage(" ''{0}'' page has not opened!",pageName).isTrue();

		this.logger.info("** "+ pageName +" page opens successfully ...");
	}
}
