package com.o2.pages;

import com.google.inject.Inject;
import com.nttdata.cinnamon.driver.Browser;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.nttdata.cinnamon.logging.Logger;
import com.o2.core.util.Retry;

import java.util.function.Supplier;

import static org.assertj.core.api.Assertions.assertThat;

public abstract class BasePage {
    @Inject
    public Logger logger;
    @Inject
    protected Browser browser;
    @Inject
    Retry retry;

    @Find(by = com.nttdata.cinnamon.driver.By.CssSelector, locator = ".nc-loading-text")
    public PageElement loadingNcIcon;

    @Find(by = com.nttdata.cinnamon.driver.By.CssSelector, locator = ".progress-text")
    public PageElement processIconElement2;

    @Find(by = com.nttdata.cinnamon.driver.By.CssSelector, locator = ".gwt-PopupPanel.loader")
    public PageElement processIconElement;

    public PageElement pageTitle;

    protected PageElement getPageCheckElement() {
        this.logger.warn("getPageCheckElement() called from BasePage! This has to be overwritten in the page object that is used/called!");

        return null;
    }

    public boolean isPageDisplayed() {
        return getPageCheckElement() != null && getPageCheckElement().isDisplayed();
    }

    // TODO: can add an overload with timeout as well
    public boolean isPageDisplayed(int timeout) {
        this.browser.setImplicitWait(timeout);
        boolean result = this.isPageDisplayed();
        this.browser.restoreImplicitWait();

        return result;
    }

    public void waitForNcLoadingToComplete() {
        waitForNcLoadingToComplete(1);
    }

    public void waitForNcLoadingToComplete(int implicitWait) {
        this.logger.info(">>> Wait for NC Loading to complete ...");

        Supplier<PageElement> processIcon = () -> this.loadingNcIcon;
        Boolean result = this.retry.untilNotDisplayed(processIcon, 12, 1, implicitWait);

        assertThat(result)
                .withFailMessage("NC Loading icon still displayed!")
                .isTrue();

        this.logger.info(">>> NC Loading complete!");
    }

    public void waitForProcessLoadingToComplete(int retries, int pollingInterval, int implicitWait) {
        this.logger.info(">>> Wait for Process Loading to complete ...");

        Boolean result = this.retry.untilNotDisplayed(
                () -> processIconElement, retries, pollingInterval, implicitWait);

        assertThat(result)
                .withFailMessage("Process Loading icon still displayed!")
                .isTrue();

        this.logger.info(">>> Process Loading complete!");
    }
}
