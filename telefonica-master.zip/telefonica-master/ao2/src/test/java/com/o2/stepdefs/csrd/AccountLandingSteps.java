package com.o2.stepdefs.csrd;

import com.google.inject.Inject;
import com.nttdata.cinnamon.cache.Context;
import com.nttdata.cinnamon.driver.Browser;
import com.o2.core.data.UserDataModel;
import com.o2.pages.csrd.AccountLandingPage;
import com.o2.pages.csrd.AccountSummaryPage;
import com.o2.pages.csrd.BillingAccountPage;
import com.o2.stepdefs.BaseStep;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

import java.text.MessageFormat;

import static com.nttdata.cinnamon.wait.ElementConditions.displayed;
import static org.assertj.core.api.Assertions.assertThat;

public class AccountLandingSteps extends BaseStep {
    private final AccountLandingPage accountLandingPage;
    private final BillingAccountPage billingAccountPage;
    private final AccountSummaryPage accountSummaryPage;
    private final Context context;
    private final Browser browser;

    @Inject
    public AccountLandingSteps(final AccountLandingPage accountLandingPage,
                               final BillingAccountPage billingAccountPage,
                               final AccountSummaryPage accountSummaryPage,
                               final Context context, final Browser browser) {
        this.accountLandingPage = accountLandingPage;
        this.billingAccountPage = billingAccountPage;
        this.accountSummaryPage = accountSummaryPage;
        this.context = context;
        this.browser = browser;
    }

    @Then("^account landing page opens successfully$")
    public void account_landing_page_opens_successfully() throws InterruptedException {
        this.logger.info("*** Account landing page is loading ...");

        UserDataModel userData = (UserDataModel) this.context.get("residentialUserAccountData");

        assertThat(this.accountLandingPage.accountName.waitUntil(displayed).isDisplayed())
                .withFailMessage("Account Landing page not displayed!")
                .isTrue();
        assertThat(this.accountLandingPage.accountName.getText())
                .isEqualToIgnoringCase(MessageFormat.format("{0} {1} {2}",
                        userData.title, userData.firstName, userData.lastName));

        this.logger.info("*** Account landing page loaded successfully!\n");
    }

    @Then("^account Billing Address is updated successfully$")
    public void account_billing_address_is_updated_successfully() {
        this.logger.info("*** Waiting for Billing Address information to be displayed ...");

        assertThat(this.accountLandingPage.billingAccountsName.waitUntil(displayed).isDisplayed())
                .withFailMessage("Account Landing page not displayed!")
                .isTrue();
        assertThat(this.accountLandingPage.billingAccountsName.getText())
                .startsWith("Pay Monthly ");

        this.logger.info("*** Billing Address information displayed!\n");
    }

    @Then("^account Payment is updated successfully$")
    public void account_payment_is_updated_successfully() {
        this.logger.info("*** Account Payment Information being displayed and validated ...");

        // TODO: need to smarter this on what we are actually asserting
        assertThat(this.accountLandingPage.billingAccountsName.waitUntil(displayed).isDisplayed())
                .withFailMessage("Account Landing page not displayed!")
                .isTrue();
//        assertThat(this.accountLandingPage.paymentInstrumentsName.getText())
//                .startsWith("Bank Account");

        this.logger.info("*** Account Payment Information displayed and validated!\n");
    }

    @Then("^account Payment Mandate is updated successfully$")
    public void account_payment_mandate_is_updated_successfully() {
        this.logger.info("*** Account Payment Mandate being displayed and validated ...");

        assertThat(this.accountLandingPage.billingAccountsName.waitUntil(displayed).isDisplayed())
                .withFailMessage("Account Landing page not displayed!")
                .isTrue();
        assertThat(this.accountLandingPage.paymentMandateName.waitUntil(displayed).getText())
                .startsWith("Direct Debit");

        this.logger.info("*** Account Payment Mandate displayed and validated!\n");
    }

    @Then("^I open an order for my customer$")
    public void i_open_an_order() throws InterruptedException {
        this.logger.info("*** Attempt to open an order for customer ...");
        this.browser.setImplicitWait(5);
        assertThat(this.accountLandingPage.newOrderButton.waitUntil(displayed).isDisplayed())
                .withFailMessage("New Order button not displayed!")
                .isTrue();
        this.accountLandingPage.newOrderButton.click();
        // TODO: assert order has opened succesfully!
        this.browser.restoreImplicitWait();
        this.logger.info("*** Order opened successfully\n");
    }

    @When("^I access my Account Summary page")
    public void i_access_my_billing_account() {
        this.logger.info("*** Access Account Summary page ...");

        assertThat(this.accountLandingPage.payMonthlyBillingAccount.isDisplayed())
                .withFailMessage("There is no Pay Monthly Billing Account displayed!")
                .isTrue();

        this.accountLandingPage.billingAccounts.click();

        assertThat(this.billingAccountPage.isPageDisplayed())
                .withFailMessage("Billing Accounts page not displayed!")
                .isTrue();

        this.billingAccountPage.payMonthlyBillingAccount.click();
        assertThat(this.accountSummaryPage.isPageDisplayed())
                .withFailMessage("Account Summary page not displayed!")
                .isTrue();

        this.logger.info("*** Account Summary page opened!\n");
    }
}
