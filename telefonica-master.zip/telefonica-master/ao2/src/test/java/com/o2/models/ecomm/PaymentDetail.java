package com.o2.models.ecomm;

import java.text.MessageFormat;

public class PaymentDetail {
    public String bankAccountType;
    public String bankAccount;
    public String bankSortCode;
    public String accountHolderName;
    public String accountNickName;
    public String cardHolderName;
    public String cardPan;
    public String cardExpiryMonth;
    public String cardExpiryYear;
    public String cardCvv;

    @Override
    public String toString() {
        return MessageFormat.format("Payment Detail:" +
                        "\n\tbankAccountType:\t\t\t{0}" +
                        "\n\tbankAccount:\t\t{1}" +
                        "\n\tbankSortCode:\t\t{2}" +
                        "\n\taccountHolderName:\t\t\t{3}" +
                        "\n\taccountNickName:\t\t\t{4}" +
                        "\n\tcardHolderName:\t\t\t{5}" +
                        "\n\tcardPan:\t\t\t{6}" +
                        "\n\tcardExpiryMonth:\t\t\t{7}" +
                        "\n\tcardExpiryYear:\t\t\t{8}" +
                        "\n\tcardCvv:\t\t\t{9}",
                this.bankAccountType,
                this.bankAccount,
                this.bankSortCode,
                this.accountHolderName,
                this.accountNickName,
                this.cardHolderName,
                this.cardPan,
                this.cardExpiryMonth,
                this.cardExpiryYear,
                this.cardCvv
        );
    }
}
