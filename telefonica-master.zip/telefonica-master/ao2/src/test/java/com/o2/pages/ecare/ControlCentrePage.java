package com.o2.pages.ecare;

import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;

public class ControlCentrePage extends EcareBasePage {
    @Find(by = By.XPath, locator = "//h1[@class='o2uk-header-curve__text-title ng-star-inserted']")
    public PageElement pageTitle;

    @Find(by = By.XPath, locator = "//h3[@class='center margin-top_size_m']")
    public PageElement contactDetailsHeader;

    public String getContactValue(String contactFieldName) {
        PageElement contactValue = this.browser.findBy(By.XPath, "//div[@class='contact-details__field' and text()=' "
                + contactFieldName + " ']/following-sibling::div[@class='contact-details__value']");
        return contactValue.getText().trim();
    }

    @Override
    public boolean isPageDisplayed() {
        if (!pageTitle.isDisplayed())
            return false;

        return pageTitle.getText().trim().equalsIgnoreCase("Your sim");
    }

}
