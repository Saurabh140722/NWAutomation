package com.o2.stepdefs.ecare;

import static com.nttdata.cinnamon.wait.ElementConditions.displayed;
import static org.assertj.core.api.Assertions.assertThat;

import java.text.MessageFormat;

import com.google.inject.Inject;
import com.nttdata.cinnamon.cache.Context;
import com.nttdata.cinnamon.driver.Browser;
import com.o2.core.util.Common;
import com.o2.models.ecare.EcareUser;
import com.o2.pages.ecare.EditContactDetailsPage;
import com.o2.pages.ecare.MyDetailsPage;
import com.o2.stepdefs.BaseStep;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class MyDetailsSteps extends BaseStep {
    private final Context context;
    private final Common common;
    private final EditPersonalDetailsPage editPersonalDetailsPage;
    private final EditContactDetailsPage editContactDetailsPage;
    private final MyDetailsPage myDetailsPage;
    private final Browser browser;

    @Inject
    public MyDetailsSteps(final Context context,
                          final Common common,
                          final EditPersonalDetailsPage editPersonalDetailsPage,
                          final EditContactDetailsPage editContactDetailsPage,
                          final MyDetailsPage myDetailsPage,
                          final Browser browser) {
        this.context = context;
        this.common = common;
        this.editPersonalDetailsPage = editPersonalDetailsPage;
        this.editContactDetailsPage = editContactDetailsPage;
        this.myDetailsPage = myDetailsPage;
        this.browser = browser;
    }

    @Then("^I can see all my details$")
    public void i_can_see_all_my_details() {
        this.logger.info("** Attempt to check My Details page has been reached ...");

        assertThat(this.myDetailsPage.isPageDisplayed()).withFailMessage("My Details page has not opened!").isTrue();
        this.browser.setImplicitWait(5);
        EcareUser ecareUser = this.myDetailsPage.getMyDetailsInformation();
        EcareUser ecareUserTestData = (EcareUser) this.context.get("ecareLoginData");
        /* TODO : just fot check other steps
        assertThat(ecareUser)
                .withFailMessage("Could not retrieve my details information from page!")
                .isNotNull();*/
      //  assertThat(ecareUser.firstName.trim()).isEqualTo(ecareUserTestData.firstName.trim());

        this.logger.info("** My Details page displayed!\n");
    }

    @When("^I edit my '(.*)'$")
    public void i_edit_my_personal_details(String myDetail) {
        this.logger.info(MessageFormat.format("** Attempt to open my Personal Details for ''{0}'' ...", myDetail));

        if (myDetail.equals("Contact Details")) {
            //PageElement editContactDetails = this.myDetailsPage.getContactDetailsLink();
            assertThat(this.myDetailsPage.editContactDetails).withFailMessage("Could not find Edit link for Contact Details block!")
                    .isNotNull();

            this.myDetailsPage.editContactDetails.click();
            assertThat(this.editContactDetailsPage.isPageDisplayed())
                    .withFailMessage("Contact Details page has not opened!")
                    .isTrue();

            return;
        }

        //TOOD : PageElement edit = this.myDetailsPage.getEditMyDetailsLink();

        assertThat(this.myDetailsPage.editPersonalDetails)
                .withFailMessage("Could not find Edit link for My Personal Details block!")
                .isNotNull();

        this.myDetailsPage.editPersonalDetails.click();
        assertThat(this.editPersonalDetailsPage.isPageDisplayed())
                .withFailMessage("Edit Personal Details popup has not opened!")
                .isTrue();

        this.logger.info(MessageFormat.format("** Personal Details for ''{0}'' opened!\n", myDetail));
    }

    @When("^I update my '(.*)'$")
    public void i_edit_my_entry(String field) {
        this.logger.info(MessageFormat.format("** Attempt to edit ''{0}'' ...", field));

        String title = this.editPersonalDetailsPage.titleName().getValue();
        String newTitle = title.equals("Mr") ? "Dr" : "Mr";
        this.context.set("newTitle",newTitle);
        this.editPersonalDetailsPage.titleName().click();
        this.editPersonalDetailsPage.titleName().setValue(newTitle);
        this.editPersonalDetailsPage.saveButton().click();
//        this.common.wait(2); // TODO: why hardcoded waiters?
        this.editPersonalDetailsPage.submitChangesButton().click();

        int cnt = 20;
        String processMessage = "";
        this.browser.setImplicitWait(2);
        while (cnt > 0) {
            cnt--;
            processMessage = this.editPersonalDetailsPage.successTitle.waitUntil(displayed).getText();
            if (!processMessage.equals("Change request submitted")) {
                this.common.wait(2);
                continue;
            }

            break;
        }
        this.browser.restoreImplicitWait();
        assertThat(processMessage)
                // .withFailMessage("My details changes have not been saved successfully")
                .isEqualTo("Change request submitted");
        this.editPersonalDetailsPage.closeButton.click();

        this.logger.info(MessageFormat.format("** Entry ''{0}'' updated!\n", field));
    }

    @When("^all my personal details is updated$")
    public void all_my_personal_details_is_updated() {
        String newTitle= (String) this.context.get("newTitle");
        assertThat(this.myDetailsPage.getYourDetailsValue(newTitle).isDisplayed(5))
                .withFailMessage("updated value is not saved!")
                .isTrue();

        this.logger.info("** Updated value is saved!\n");
    }
}
