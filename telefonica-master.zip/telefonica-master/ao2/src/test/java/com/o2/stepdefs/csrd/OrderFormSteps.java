package com.o2.stepdefs.csrd;

import com.google.inject.Inject;
import com.nttdata.cinnamon.cache.Context;
import com.nttdata.cinnamon.conf.Env;
import com.nttdata.cinnamon.db.Db;
import com.nttdata.cinnamon.driver.Browser;
import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.nttdata.cinnamon.driver.controls.PageElementCollection;
import com.nttdata.cinnamon.modules.selenium.browsers.Chrome;
import com.nttdata.cinnamon.webdriver.util.ReadyState;
import com.o2.core.data.UserDataModel;
import com.o2.core.util.Retry;
import com.o2.pages.BasePage;
import com.o2.pages.csrd.*;
import com.o2.stepdefs.BaseStep;
import com.o2.util.Common;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;

import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.function.Supplier;

import static com.nttdata.cinnamon.wait.ElementConditions.*;
import static com.nttdata.cinnamon.wait.conditions.Conditions.readyState;
import static com.o2.Constants.FIVE_SECS;
import static com.o2.Constants.*;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.*;

public class OrderFormSteps extends BaseStep {
    private final Browser browser;
    private final Db db;
    private final Common common;
    private final Retry retry;
    private final Context context;
    private final OrderFormPage orderFormPage;
    private final OrderServicesAndFeaturesPage orderServicesAndFeaturesPage;
    private final OrderDeliveryPage orderDeliveryPage;
    private final OrderPhoneAndSpendCapPage orderPhoneAndSpendCapPage;
    private final OrderEligibilityCheckPage orderEligibilityCheckPage;
    private final OrderEligibilityCheckFormPage orderEligibilityCheckFormPage;
    private final OrderBillingAndPaymentPage orderBillingAndPaymentPage;
    private final OrderReviewPage orderReviewPage;
    private final CreditCheckPage creditCheckPage;
    private final SignInContractPage signInContractPage;
    private final OrderConfirmationPage orderConfirmationPage;
    private final ProcessElements processElements;
    private final OrderNavigationPage orderNavigationPage;
    private final OrderOverviewPage orderOverviewPage;
    private SoftAssertions softAssertion;

    @Inject
    public OrderFormSteps(final Browser browser,
                          final Db db,
                          final Common common,
                          final Retry retry,
                          final Context context,
                          final OrderFormPage orderFormPage,
                          final OrderServicesAndFeaturesPage orderServicesAndFeaturesPage,
                          final OrderDeliveryPage orderDeliveryPage,
                          final OrderPhoneAndSpendCapPage orderPhoneAndSpendCapPage,
                          final OrderEligibilityCheckPage orderEligibilityCheckPage,
                          final OrderEligibilityCheckFormPage orderEligibilityCheckFormPage,
                          final OrderBillingAndPaymentPage orderBillingAndPaymentPage,
                          final OrderReviewPage orderReviewPage,
                          final CreditCheckPage creditCheckPage,
                          final SignInContractPage signInContractPage,
                          final OrderConfirmationPage orderConfirmationPage,
                          final ProcessElements processElements,
                          final OrderNavigationPage orderNavigationPage,
                          final OrderOverviewPage orderOverviewPage) {
        this.browser = browser;
        this.db = db;
        this.common = common;
        this.retry = retry;
        this.context = context;
        this.orderFormPage = orderFormPage;
        this.orderServicesAndFeaturesPage = orderServicesAndFeaturesPage;
        this.orderDeliveryPage = orderDeliveryPage;
        this.orderPhoneAndSpendCapPage = orderPhoneAndSpendCapPage;
        this.orderEligibilityCheckPage = orderEligibilityCheckPage;
        this.orderEligibilityCheckFormPage = orderEligibilityCheckFormPage;
        this.orderBillingAndPaymentPage = orderBillingAndPaymentPage;
        this.orderReviewPage = orderReviewPage;
        this.creditCheckPage = creditCheckPage;
        this.signInContractPage = signInContractPage;
        this.orderConfirmationPage = orderConfirmationPage;
        this.processElements = processElements;
        this.orderNavigationPage = orderNavigationPage;
        this.orderOverviewPage = orderOverviewPage;
        this.softAssertion = new SoftAssertions();
    }

    @Then("^my order form opens$")
    public void my_order_form_opens() {
        this.logger.info("*** Order form attempts to open ...");

//        ((WebDriver) this.browser.instance()).switchTo().frame("iframe_roe"); // TODO: add switch to Driver (Cinnamon+)
        this.browser.switchTo("iframe_roe");

        assertThat(this.orderFormPage.orderNo.waitUntil(displayed).isDisplayed())
                .withFailMessage("Order Form page not displayed!")
                .isTrue();

        this.logger.info("*** Order form opened!\n");
    }

    @When("^I add my tariff as '(.*)' with delivery '(.*)'$")
    public void order_tariff_and_delivery(String tariff, String delivery) {
        this.logger.info(MessageFormat.format(
                "*** Add tariff as ''{0}'' with delivery ''{1}}'' ...",
                tariff, delivery
        ));

        assertThat(this.orderServicesAndFeaturesPage.isPageDisplayed())
                .withFailMessage("Services and Features page has not been loaded!")
                .isTrue();

        this.orderServicesAndFeaturesPage.getO2SimOnlyOptionByName(tariff).name.click();
        this.common.waitForNavigationLoadingToComplete(90, 1, true);

        this.advanceToNextPage(orderServicesAndFeaturesPage);

        this.logger.info("*** Tariff and delivery added!\n");
    }

    @When("^item (is|is not) reserved for this delivery$")
    public void item_is_reserved_for_this_delivery(String isOrNot) {
        this.logger.info("*** Reserve/Don't reserve item for delivery ...");

        if (isOrNot.equals("is")) {
            this.orderDeliveryPage.reserveLink.waitUntil(displayed).click();

            this.common.waitForLoadingToComplete(60, 1);
        }
        this.common.waitForLoadingToComplete(60, 1);

        this.advanceToNextPage(this.orderDeliveryPage);

        this.logger.info("*** Item status for delivery completed!");
    }

    @When("I select  tariff as '(.*)' with delivery '(.*)' and resoruceBandle '(.*)' and price as '(.*)'$")
    public void checkAllowance(String tariff, String delivery, String bundle, String price) {
        this.logger.info("Add tariff " + tariff + " with delivery " + delivery + " and resourceBundle " + bundle);
        assertTrue("Services and Features page has not been loaded", orderServicesAndFeaturesPage.isPageDisplayed());
        this.orderServicesAndFeaturesPage.getO2SimOnlyOptionByName(tariff).name.click();
        this.common.waitForNavigationLoadingToComplete(90, 1, true);
        this.advanceToNextPage(orderServicesAndFeaturesPage);
        this.advanceToNextPage(this.orderDeliveryPage);
        this.advanceToNextPage(this.orderDeliveryPage);
        this.context.set("resource", bundle);
        this.context.set("resource", price);
        this.logger.info("*** Tariff and delivery added\n");
    }

    // For Data Volume Test
    @When("I select a tariff with '(.*)', delivery '(.*)', resourceBundle '(.*)', and price as '(.*)'$")
    public void selectTariff(String tariff, String delivery, String bundle, String price) {
        logger.info("Add tariff " + tariff + " with delivery " + delivery + " and resourceBundle " + bundle);
        assertTrue(orderServicesAndFeaturesPage.isPageDisplayed());
        orderServicesAndFeaturesPage.getSimOnlyAndSimOnlyDataListOptions(tariff);
        common.waitForNavigationLoadingToComplete(90, 1, true);
        advanceToNextPage(orderServicesAndFeaturesPage);
        advanceToNextPage(orderDeliveryPage);
        context.set("bundle", bundle);
        context.set("price", price);
        logger.info("*** Tariff and delivery added\n");
    }

    @When("^I choose a number with '(.*)' spend cap$")
    public void choose_number_with_spend_cap(String spendCap) {
        UserDataModel userData = (UserDataModel) this.context.get("residentialUserAccountData");
        setTelNoAndSpendCap(spendCap);
    }

    @When("^I check the allowance bundle with respect to the price, and set '(.*)' spend cap$")
    public void choose_spend_allowance(String spendCap) {
        logger.info("*** Choose phone number with" + spendCap + " spend cap ...");
        UserDataModel userData = (UserDataModel) context.get("residentialUserAccountData");

        assertThat(orderPhoneAndSpendCapPage.isPageDisplayed())
                .isTrue()
                .withFailMessage("Phone No & Cap page not displayed!");
        orderPhoneAndSpendCapPage.getPhoneNumberPageElement().scrollIntoView().click();
        orderPhoneAndSpendCapPage.getPhoneNumber().click();
        userData.phoneNumber = orderPhoneAndSpendCapPage.getPhoneNumberPageElement().getValue();

        Supplier<PageElement> processIcon = () -> orderPhoneAndSpendCapPage.processIcon;
        Boolean result = retry.untilNotDisplayed(processIcon, 12, 1);
        assertThat(result)
                .withFailMessage("Process icon still displayed after selecting a phone number!")
                .isTrue();
        assertThat(orderPhoneAndSpendCapPage.getPhoneNumberPageElement().getValue())
                .isNotEmpty();

        orderPhoneAndSpendCapPage.spendCap.asSelect().selectByText(spendCap);
        result = retry.untilNotDisplayed(processIcon, 12, 1);
        assertThat(result)
                .withFailMessage("Process icon still displayed after selecting a phone number!")
                .isTrue();
        assertThat(orderPhoneAndSpendCapPage.spendCap.asSelect().getSelectedValue())
                .isNotEmpty();
        orderPhoneAndSpendCapPage.spendCap.asSelect().selectByText(spendCap);
        common.waitForLoadingToComplete(2, 1);
        for (PageElement option : orderServicesAndFeaturesPage.ele_allowanceBundleList.asList()) {
            if (option.getText().replaceAll(",", "").equals(context.get("bundle"))) {
                option.click();
                common.waitForLoadingToComplete(2, 1);
                logger.info("Price on Screen " + orderServicesAndFeaturesPage.lbl_price.asList().get(0).getText());
                common.wait(3);
                assertThat(orderServicesAndFeaturesPage.lbl_price.asList().get(0).waitUntil(displayed).getText())
                        .contains(context.get("price").toString())
                        .withFailMessage("Price is not displayed");
                break;
            }
        }
        advanceToNextPage(orderPhoneAndSpendCapPage);
        context.set("residentialUserAccountData", userData);
    }

    @When("^user passes Eligibility Check for phones$")
    public void user_passes_eligibility_check_phones() {
        this.logger.info("*** Passing Eligibility Check ...");
        assertThat(this.orderEligibilityCheckPage.getEligibilityButton().isDisplayed())
                .withFailMessage("Eligibility Check page not displayed!")
                .isTrue();

        int cnt = 3;
        this.logger.info("Open Eligibility Check form ...");
        while (cnt > 0) {
            this.orderEligibilityCheckPage.getEligibilityButton().click();
            this.logger.info(" Eligibility Check form button clicked ...");
            this.common.waitForNavigationLoadingToComplete(60, 1, false);
            if (this.orderEligibilityCheckFormPage.preferredTitlephones.isDisplayed(4)) {
                this.logger.info("Eligibility Check form opened!");
                break;
            }
            this.logger.info(MessageFormat.format("Eligibility Check form not opened! Retry #{0} ...", cnt));
            // no need to wait as isDisplayed() waits for 4 seconds

            cnt--;
        }
        assertThat(this.orderEligibilityCheckFormPage.preferredTitlephones.waitUntil(displayed).isDisplayed())
                .withFailMessage("Eligibility Check Form page not displayed!")
                .isTrue();

        this.orderEligibilityCheckFormPage.employmentStatusphones.asSelect().selectByValue("Employed");
        this.orderEligibilityCheckFormPage.personalAnnualIncomephones.asSelect().selectByValue("More than £50,000");
        this.orderEligibilityCheckFormPage.liveAtAddressPeriodphones.asSelect().selectByValue("7 to 8 years");
        this.common.wait(2);
        this.orderEligibilityCheckFormPage.confirmAndContinueButton.click();

        this.logger.info(">>> Check Eligibility Check popup has been closed ...");
        cnt = 180;
        while (cnt > 0) {
            cnt--;
            this.browser.setImplicitWait(1);
            if (this.orderEligibilityCheckFormPage.preferredTitlephones.isDisplayed()) {
                this.logger.info(
                        MessageFormat.format(
                                ">>> Check Eligibility Check popup still opened! Retry #{0} ...", cnt));
                this.common.wait(2);
                this.logger.info(">>> Check if there is a popup error ...");
//                <div id="ui-id-2" class="ui-dialog-content ui-widget-content" style="display: block; width: auto; min-height: 89px; max-height: none; height: auto;">Sorry. We could not process your request.</div>
                PageElement popupError = this.browser.findBy(By.XPath, "//div[@id='ui-id-2']");
                if (popupError != null && popupError.getText().contains("Sorry. We could not process your request.")) {
                    assertThat(true)
                            .withFailMessage("Error processing Eligibility!")
                            .isFalse();
                }
                this.logger.info(">>> No popup error message!");
                continue;// Still processing
            }
            this.logger.info(">>> Check Eligibility Check popup not found! Continue ...");
            break;
        }

        assertThat(this.orderEligibilityCheckFormPage.preferredTitlephones.isDisplayed())
                .withFailMessage("Eligibility Check Form page still displayed! Has the process hanged up?")
                .isFalse();

        this.browser.restoreImplicitWait();
//        this.orderServicesAndFeaturesPage.nextButton.waitUntil(displayed).click();
        this.advanceToNextPage(orderEligibilityCheckPage);

        this.logger.info("*** Eligibility Check passed!\n");
    }

    @When("^user passes Credit Check for phones$")
    public void user_passes_credit_check_for_phones() {
        this.logger.info("*** Attempt to pass Credit Check ...");
        this.orderReviewPage.getButton("Credit Check").click();
        if (this.creditCheckPage.continueAnywaysBtn.isDisplayed()) {
            this.common.wait(2);
            this.creditCheckPage.continueAnywaysBtn.waitUntil(displayed).click();
        }
        UserDataModel userData = (UserDataModel) this.context.get("residentialUserAccountData");
        assertThat(this.creditCheckPage.isPageDisplayed())
                .withFailMessage("Credit Check page not displayed!")
                .isTrue();
        this.common.wait(2);
        this.creditCheckPage.paymentDetails.waitUntil(displayed).click();
        this.common.wait(2);
        this.creditCheckPage.paymentDetails.waitUntil(displayed).click();
        //new
        this.orderServicesAndFeaturesPage.lbl_paymentInstrument.getText();
        this.orderServicesAndFeaturesPage.ddl_newCardSelect.asSelect().selectByIndex(1);
        this.orderServicesAndFeaturesPage.btn_newCard.click();
        this.browser.displayIframesInfo();
        this.browser.switchTo("cardIFrame");
        // this.browser.switchTo("newcard selected");
        this.creditCheckPage.cardName.waitUntil(displayed).setValue(
                MessageFormat.format("Auto {0} {1}", userData.firstName, userData.lastName));
        this.creditCheckPage.cardNumber.waitUntil(displayed).setValue(userData.userPaymentModel.cardPan);
        this.creditCheckPage.expiryDateMonth.asSelect().selectByValue(userData.userPaymentModel.cardExpiryMonth);
        // Select is done by last 2 digits of the year
        this.creditCheckPage.expiryDateYear.asSelect().selectByValue(
                userData.userPaymentModel.cardExpiryYear.substring(
                        userData.userPaymentModel.cardExpiryYear.length() - 2));
        this.creditCheckPage.cvv.setValue(userData.userPaymentModel.cardCvv);
        // this.creditCheckPage.onlineValidationButton.click();
        this.common.wait(2);
        this.creditCheckPage.onlineValidationButtonphones.click();
        this.common.wait(10);
        this.logger.info("button");
        this.browser.switchToDefault();
        this.browser.switchTo("iframe_roe");

        int cnt = 20;
        boolean isValidationSuccessful = false;

        while (cnt > 0) {
            this.browser.setImplicitWait(1);
            if (this.creditCheckPage.validationMessageErrors.isDisplayed()) {
                this.logger.error(MessageFormat.format(
                        "Online Validation FAILED! Message: {0}",
                        this.creditCheckPage.validationMessageErrors.getText()));
                break;
            }

            this.browser.setImplicitWait(1);
            if (this.creditCheckPage.validationMessageSuccess.isDisplayed() &&
                    this.creditCheckPage.validationMessageSuccess.getText().
                            contains("That card has been successful! You can now continue with your order.")) {
                this.logger.info(MessageFormat.format(
                        "Online Validation passed! Message: {0}",
                        this.creditCheckPage.validationMessageSuccess.getText()));
                isValidationSuccessful = true;
                break;
            }

            cnt--;
            this.logger.info(
                    MessageFormat.format("Online Validation processing! Waiting #{0}...", cnt));
            this.common.wait(3);
        }

//        assertThat(isValidationSuccessful)
//                .withFailMessage(MessageFormat.format(
//                        "Online Validation FAILED! Message: {0}",
//                        this.creditCheckPage.validationMessageErrors.isDisplayed(1)
//                                ? this.creditCheckPage.validationMessageErrors.getText()
        //                     : "N/A"))
        //     .isTrue();
        this.browser.restoreImplicitWait();

        // TODO: refactor this
        try {
            this.common.wait(1);
//            ((WebDriver) this.browser.instance()).findElement(By.linkText("APPLICATION")).sendKeys(Keys.PAGE_UP);
            this.browser.findBy(com.nttdata.cinnamon.driver.By.LinkName, "APPLICATION").setValue(Keys.PAGE_UP);
            this.common.wait(2);
            this.creditCheckPage.application.click();
        } catch (Exception e) {
            this.logger.warn("Could not click on APPLICATION link! Retry ...");
            this.common.wait(1);
            this.browser.findBy(com.nttdata.cinnamon.driver.By.LinkName, "APPLICATION").setValue(Keys.PAGE_UP);
//            ((WebDriver) this.browser.instance()).findElement(By.linkText("APPLICATION")).sendKeys(Keys.PAGE_UP);
            this.common.wait(2);
            this.creditCheckPage.application.click();
        }
        this.common.wait(5);

        this.creditCheckPage.getConfirmMonthlyCostCheckbox().click();
        this.creditCheckPage.getConfirmNoChangesInCircumstancesCheckbox().click();
        this.common.wait(2);
        this.creditCheckPage.confirmAndContinueButton.click();
        System.out.println("button clicked");

        this.common.wait(5);

        this.logger.info("Saving Credit Checks data ...");
        cnt = 120;
        while (cnt > 0) {
            cnt--;
            this.browser.setImplicitWait(1);
            if (this.creditCheckPage.isPageDisplayed()) {
                this.logger.info(MessageFormat.format(
                        "Credit Check popup still displayed! Saving in progress! Retry #{0}", cnt));
                this.common.wait(2); // Still processing
                continue;
            }

            this.logger.info("Credit Checks saving complete! Continue ...");
            break;
        }

        assertThat(this.creditCheckPage.isPageDisplayed())
                .withFailMessage("Credit Check Form popup still displayed! Has the process hanged up?")
                .isFalse();

        Supplier<PageElement> processIcon = () -> this.orderPhoneAndSpendCapPage.processIcon;
        Boolean result = this.retry.untilNotDisplayed(processIcon, 12, 1);
        assertThat(result)
                .withFailMessage("Process icon still displayed after selecting a phone number!")
                .isTrue();

        this.logger.info("*** Credit Check passed!\n");
    }

    @Then("^I select android phone type as (.*) and saletype as '(.*)'$")
    public void I_select_android(String phoneType, String sale) {
        this.orderServicesAndFeaturesPage.btn_phones.asList().get(2).click();
        this.common.wait(5);
        this.advanceToNextPage(orderServicesAndFeaturesPage);
        this.common.waitForLoadingToComplete(2, 1);

        //android click
        this.orderServicesAndFeaturesPage.tab_android.scrollIntoView().click();
        this.common.wait(2);
        this.orderServicesAndFeaturesPage.txt_deviceSearch.click();
        this.orderServicesAndFeaturesPage.txt_deviceSearch.setValue(phoneType);
        this.common.waitForNavigationLoadingToComplete(90, 1, true);

        //adding phone
        this.orderServicesAndFeaturesPage.btn_androidAdd.click();
        this.browser.setImplicitWait(5);
        this.context.set("sale1", sale);
        this.orderServicesAndFeaturesPage.ddl_saleType.asList().get(0).click();
        this.browser.setImplicitWait(2);
        this.orderServicesAndFeaturesPage.ddl_saleType.asList().get(0).asSelect().selectByText((String) this.context.get("sale1"));
        this.common.waitForNavigationLoadingToComplete(90, 1, true);
        this.orderServicesAndFeaturesPage.btn_ok.scrollIntoView().click();
        this.common.waitForNavigationLoadingToComplete(90, 1, true);
        this.advanceToNextPage(orderServicesAndFeaturesPage);


    }

    @Then("^I select Mobile Broadband Devices as (.*) and saletype as '(.*)'$")
    public void I_select_mobile_broadBand_Device(String phoneType, String sale) {
        this.common.waitForLoadingToComplete(2, 1);
        this.orderServicesAndFeaturesPage.mobileBroadBandDevices.click();
        this.common.wait(5);
        this.advanceToNextPage(orderServicesAndFeaturesPage);
        this.common.waitForLoadingToComplete(2, 1);

        //android click
        this.orderServicesAndFeaturesPage.tab_iphone.scrollIntoView().click();
        this.common.wait(2);
        this.orderServicesAndFeaturesPage.txt_phoneSearch.click();
        this.orderServicesAndFeaturesPage.txt_phoneSearch.setValue(phoneType);
        this.common.waitForNavigationLoadingToComplete(90, 1, true);
        //adding phone
        this.orderServicesAndFeaturesPage.btn_androidAdd.click();
        this.browser.setImplicitWait(5);
        this.context.set("sale1", sale);
        this.orderServicesAndFeaturesPage.ddl_saleType.asList().get(0).click();
        this.browser.setImplicitWait(2);
        this.orderServicesAndFeaturesPage.ddl_saleType.asList().get(0).asSelect().selectByText((String) this.context.get("sale1"));
        this.common.waitForNavigationLoadingToComplete(90, 1, true);
        this.orderServicesAndFeaturesPage.btn_ok.scrollIntoView().click();
        this.common.waitForNavigationLoadingToComplete(90, 1, true);
        this.advanceToNextPage(orderServicesAndFeaturesPage);


    }

    @When("^get sku id of device as '(.*)'$")

    public void get_sku_id_of_device(String offeringname) {

        this.orderServicesAndFeaturesPage.expandplm.waitUntil(displayed);
        this.orderServicesAndFeaturesPage.expandplm.scrollIntoView().click();
        this.orderServicesAndFeaturesPage.productmanagement.hover();
        this.orderServicesAndFeaturesPage.PLMManagement.hover();
        this.orderServicesAndFeaturesPage.PLMManagement.click();
        this.browser.switchToTab(1);
        this.orderServicesAndFeaturesPage.devicestemplate.click();
        this.common.waitForLoadingToComplete(60, 2, true);

        //offering code
        this.common.wait(20);

        this.orderServicesAndFeaturesPage.offeringname.asList().get(0).click();
        System.out.println("offering code box");
//        this.common.wait(5);


        this.orderServicesAndFeaturesPage.offeringname.asList().get(0).setValue(offeringname);

        this.orderServicesAndFeaturesPage.search_plm.scrollIntoView().click();

        this.common.wait(10);
        if (this.orderServicesAndFeaturesPage.model.isDisplayed()) {
            this.orderServicesAndFeaturesPage.model.scrollIntoView().getText();
            System.out.println("device name" + offeringname);
            System.out.println("SKU ID IS " + this.orderServicesAndFeaturesPage.model.getText());


        } else {
            this.logger.info(offeringname + "model not found");

        }

    }


    @When("^get sku id of simo plans as '(.*)'$")
    public void get_sku_id_of_simo_plans(String offeringname) {
        this.orderServicesAndFeaturesPage.expandplm.waitUntil(displayed);
        this.orderServicesAndFeaturesPage.expandplm.scrollIntoView().click();
        this.orderServicesAndFeaturesPage.productmanagement.hover();
        this.orderServicesAndFeaturesPage.PLMManagement.hover();
        this.orderServicesAndFeaturesPage.PLMManagement.click();
        this.browser.switchToTab(1);
        this.orderServicesAndFeaturesPage.simoplanstemplate.click();
        this.common.waitForLoadingToComplete(60, 2, true);
        this.common.wait(50);
        System.out.println("offering code box");
        this.orderServicesAndFeaturesPage.offeringname.asList().get(3).setValue(offeringname);
        this.orderServicesAndFeaturesPage.search_plm_accessories.asList().get(1).click();
        this.common.wait(10);
        if (this.orderServicesAndFeaturesPage.model.isDisplayed()) {
            this.orderServicesAndFeaturesPage.model.scrollIntoView().getText();
            System.out.println("device name" + offeringname);
            System.out.println("SKU ID IS " + this.orderServicesAndFeaturesPage.model.getText());


        } else {
            this.logger.info(offeringname + "model not found");

        }

    }

    @When("^get sku id of custom plans as '(.*)'$")
    public void get_sku_id_of_custom_plans(String offeringname) {
        this.orderServicesAndFeaturesPage.expandplm.waitUntil(displayed);
        this.orderServicesAndFeaturesPage.expandplm.scrollIntoView().click();
        this.orderServicesAndFeaturesPage.productmanagement.hover();
        this.orderServicesAndFeaturesPage.PLMManagement.hover();
        this.orderServicesAndFeaturesPage.PLMManagement.click();
        this.browser.switchToTab(1);
        this.orderServicesAndFeaturesPage.customplanstemplate.click();
        this.common.waitForLoadingToComplete(60, 2, true);
        this.common.wait(30);
        this.orderServicesAndFeaturesPage.offeringname_custom.click();
        System.out.println("offering code box");
        this.orderServicesAndFeaturesPage.offeringname_contains.setValue(offeringname);
        this.common.wait(2);
        this.orderServicesAndFeaturesPage.offeringname_apply.click();
        ;
        this.common.wait(10);
        if (this.orderServicesAndFeaturesPage.model.isDisplayed()) {
            this.orderServicesAndFeaturesPage.model.scrollIntoView().getText();
            System.out.println("device name" + offeringname);
            System.out.println("SKU ID IS " + this.orderServicesAndFeaturesPage.model.getText());
        } else {
            this.logger.info(offeringname + "model not found");
        }
    }

    @When("^get sku id of accessories as '(.*)'$")
    public void get_sku_id_of_accessories(String offeringname) {
        this.orderServicesAndFeaturesPage.expandplm.waitUntil(displayed);
        this.orderServicesAndFeaturesPage.expandplm.scrollIntoView().click();
        this.orderServicesAndFeaturesPage.productmanagement.hover();
        this.orderServicesAndFeaturesPage.PLMManagement.hover();
        this.orderServicesAndFeaturesPage.PLMManagement.click();
        this.browser.switchToTab(1);
        this.orderServicesAndFeaturesPage.accessories_plm.click();
        this.common.waitForLoadingToComplete(60, 2, true);
        //offering code
        this.common.wait(20);
        this.orderServicesAndFeaturesPage.offeringname.asList().get(2).click();
        System.out.println("offering code box");
        this.common.wait(5);
        this.orderServicesAndFeaturesPage.offeringname.asList().get(2).setValue(offeringname);
        this.orderServicesAndFeaturesPage.search_plm_accessories.asList().get(1).click();
        this.common.wait(5);
        if (this.orderServicesAndFeaturesPage.model.isDisplayed()) {
            this.orderServicesAndFeaturesPage.model.scrollIntoView().getText();
            System.out.println("device name" + offeringname);
            System.out.println("SKU ID IS " + this.orderServicesAndFeaturesPage.model.getText());
        } else {
            this.logger.info(offeringname + "model not found");
        }
    }

    @Then("^I select android watch type as (.*) and saletype as '(.*)'$")
    public void I_select_watch_android(String watchType, String sale) {

        this.orderServicesAndFeaturesPage.btn_wearables.asList().get(0).click();
        this.advanceToNextPage(orderServicesAndFeaturesPage);
        this.common.waitForLoadingToComplete(2, 1);

        //android watch click
        this.orderServicesAndFeaturesPage.btn_wearablesAndroid.scrollIntoView().click();
        this.common.wait(2);
        this.orderServicesAndFeaturesPage.txt_phoneSearch.click();
        this.orderServicesAndFeaturesPage.txt_phoneSearch.scrollIntoView().setValue(watchType);
        this.common.waitForNavigationLoadingToComplete(90, 1, true);

        //adding watches
        this.orderServicesAndFeaturesPage.btn_addAndroidWatch.click();
        this.browser.setImplicitWait(5);
        this.context.set("sale1", sale);
        this.orderServicesAndFeaturesPage.ddl_saleType.asList().get(0).click();
        this.browser.setImplicitWait(2);
        this.orderServicesAndFeaturesPage.ddl_saleType.asList().get(0).asSelect().selectByText((String) this.context.get("sale1"));
        this.common.waitForNavigationLoadingToComplete(90, 1, true);
        this.orderServicesAndFeaturesPage.btn_ok.scrollIntoView().click();
        this.common.waitForNavigationLoadingToComplete(90, 1, true);
        this.advanceToNextPage(orderServicesAndFeaturesPage);
    }

    @Then("^I select iphone watch type as (.*) and saletype as '(.*)'$")
    public void I_select_watch_iphone(String watchType, String sale) {

        this.orderServicesAndFeaturesPage.btn_wearables.asList().get(0).click();
        this.advanceToNextPage(orderServicesAndFeaturesPage);
        this.common.waitForLoadingToComplete(2, 1);

        //iphone watch click
//        this.orderServicesAndFeaturesPage.Wearables_android.scrollIntoView().click();
//        this.common.wait(2);
        this.orderServicesAndFeaturesPage.txt_phoneSearch.scrollIntoView().click();
        this.orderServicesAndFeaturesPage.txt_phoneSearch.scrollIntoView().setValue(watchType);
        this.common.waitForNavigationLoadingToComplete(90, 1, true);

        //adding watches
        this.orderServicesAndFeaturesPage.btn_addAppleWatch.click();
        this.browser.setImplicitWait(5);
        this.context.set("sale1", sale);
        this.orderServicesAndFeaturesPage.ddl_saleType.asList().get(0).click();
        this.browser.setImplicitWait(2);
        this.orderServicesAndFeaturesPage.ddl_saleType.asList().get(0).asSelect().selectByText((String) this.context.get("sale1"));
        this.common.waitForNavigationLoadingToComplete(90, 1, true);
        this.orderServicesAndFeaturesPage.btn_ok.scrollIntoView().click();
        this.common.waitForNavigationLoadingToComplete(90, 1, true);
        this.advanceToNextPage(orderServicesAndFeaturesPage);


    }

    //TODO YOU ARE HERE
    @And("I select the device type as (.*) and saletype as (.*) and check the custom plan name (.*)")
    public void i_Select_DeviceType_And_SaleType_And_Validate_CustomPlanName() {
        //TODO Merge 7 methods into one
    }

    @And("I specify the platform under test as {string}")
    public void the_platform_under_test_is(String platform) {
        context.set("platform", platform);
    }

    @Then("^I select a discontinued device$")
    public void I_select_discontinued_device(DataTable discontDevicesDataInput) {
        List<List<String>> dataInput = discontDevicesDataInput.asLists(String.class);
        navigateToOrderServicesAndFeaturesAndClickTab();
        int initialWait = 0;
        for (int a = 0; a < dataInput.size(); a++) {
            if (initialWait == 0) {
                common.wait(FIVE_SECS);
                initialWait++;
            }
            orderServicesAndFeaturesPage.txt_deviceSearch.setValue(dataInput.get(a).get(0));
            if (a == dataInput.size() - 1) {
                common.wait(FIVE_SECS); // Fails for the last value if the wait is NOT present
            }
            common.waitForNavigationLoadingToComplete(10, 1, true);

            PageElementCollection lbl_discontinuedDevicesList = (context.get("platform").toString().contains("watch")) ? ((Chrome) browser).findAllBy(By.XPath,
                    "//div[@id='" + getLblDevicesList() + "']//table[@role='presentation']//div[1]") : ((Chrome) browser).findAllBy(By.XPath,
                    "//div[@id='" + getLblDevicesList() + "']//table[@role='presentation']/tbody/tr/td");

            if (lbl_discontinuedDevicesList.asList().get(0).getText().contains("Like New")) {
                // To be ignored
            } else if (lbl_discontinuedDevicesList.asList().get(0).getText().equalsIgnoreCase(dataInput.get(a).get(0))) {
                softAssertion.fail("The " + dataInput.get(a).get(0) + " device is discontinued");
            } else if (lbl_discontinuedDevicesList.asList().get(0).getText()
                    .contains(dataInput.get(a).get(0)) && (lbl_discontinuedDevicesList.asList().get(0).getText().length() > dataInput.get(a).get(0).length())) {
                // Data table entry matches system value. However, the system value has additional text which excludes Like New
            } else {
                assertTrue(orderServicesAndFeaturesPage.searchWarning.getText()
                        .contains("There are no such offerings found."));
            }
            orderServicesAndFeaturesPage.txt_deviceSearch.clear();
        }
    }

    private void navigateToOrderServicesAndFeaturesAndClickTab() {
        switch (context.get("platform").toString().toLowerCase()) {
            case "android phones":
                orderServicesAndFeaturesPage.btn_phones.asList().get(2).click();
                advanceToNextPage(orderServicesAndFeaturesPage);
                common.waitForLoadingToComplete(2, 1);
                orderServicesAndFeaturesPage.tab_android.scrollIntoView().clickJs();
                break;
            case "apple phones":
                orderServicesAndFeaturesPage.btn_phones.asList().get(2).click();
                advanceToNextPage(orderServicesAndFeaturesPage);
                common.waitForLoadingToComplete(2, 1);
                orderServicesAndFeaturesPage.txt_deviceSearch.click();
                break;
            case "windows tablets":
                orderServicesAndFeaturesPage.btn_tablets.asList().get(0).click();
                advanceToNextPage(orderServicesAndFeaturesPage);
                common.waitForLoadingToComplete(2, 1);
                orderServicesAndFeaturesPage.tab_tabletsWindows.scrollIntoView().clickJs();
                orderServicesAndFeaturesPage.txt_deviceSearch.clickJs();
                break;
            case "android tablets":
                orderServicesAndFeaturesPage.btn_tablets.asList().get(0).click();
                advanceToNextPage(orderServicesAndFeaturesPage);
                common.waitForLoadingToComplete(2, 1);
                orderServicesAndFeaturesPage.tab_tabletsAndroid.scrollIntoView().clickJs();
                orderServicesAndFeaturesPage.txt_deviceSearch.click();
                break;
            case "apple tablets":
                orderServicesAndFeaturesPage.btn_tablets.asList().get(0).click();
                advanceToNextPage(orderServicesAndFeaturesPage);
                common.waitForLoadingToComplete(2, 1);
                orderServicesAndFeaturesPage.txt_deviceSearch.scrollIntoView().clickJs();
                orderServicesAndFeaturesPage.txt_deviceSearch.click();
                break;
            case "apple watches":
                orderServicesAndFeaturesPage.btn_wearables.asList().get(0).click();
                advanceToNextPage(orderServicesAndFeaturesPage);
                common.waitForLoadingToComplete(2, 1);
                orderServicesAndFeaturesPage.txt_deviceSearch.click();
                break;
            case "android watches":
                orderServicesAndFeaturesPage.btn_wearables.asList().get(0).click();
                advanceToNextPage(orderServicesAndFeaturesPage);
                common.waitForLoadingToComplete(2, 1);
                orderServicesAndFeaturesPage.tab_androidWatches.click();
                orderServicesAndFeaturesPage.txt_deviceSearch.scrollIntoView().clickJs();
                break;
        }
        common.wait(ONE_SEC);
    }

    private String getLblDevicesList() {
        String tagValue = "";
        switch (context.get("platform").toString().toLowerCase()) {
            case "android phones":
                tagValue = "Android";
                break;
            case "apple phones":
                tagValue = "iPhone";
                break;
            case "windows tablets":
                tagValue = "Windows";
                break;
            case "android tablets":
                tagValue = "Android Tablets";
                break;
            case "apple tablets":
                tagValue = "iPad";
                break;
            case "apple watches":
                tagValue = "Apple Watch";
                break;
            case "android watches":
                tagValue = "Android Watch";
                break;
        }
        return tagValue;
    }


    @When("^Providing Discount as (.*) and amount as (.*)$")
    public void Providing_Discount(String discount, String UpfrontDiscountAmount) {
        logger.info("*** provide upfront section");
        System.out.println("xpath" + this.orderServicesAndFeaturesPage.btn_show);
        logger.info("*** scroll down");
        orderServicesAndFeaturesPage.btn_show.scrollIntoView().click();
        logger.info("*** scroll down to upfront discount");
        orderServicesAndFeaturesPage.lbl_upfrontDiscount.scrollIntoView().click();
        context.set("sale1", discount);
        orderServicesAndFeaturesPage.UpfrontDiscountreasonselect.asList().get(0).click();
        browser.setImplicitWait(2);
        orderServicesAndFeaturesPage.UpfrontDiscountreasonselect.asList().get(0).asSelect().selectByText((String) this.context.get("sale1"));
        common.wait(7);
        orderServicesAndFeaturesPage.txt_specialCode.isDisplayed();
        orderServicesAndFeaturesPage.txt_specialCode.setValue("1111111111111");
        common.wait(5);
        orderServicesAndFeaturesPage.lbl_upfrontDiscountAmount.scrollIntoView().click();
        common.waitForNavigationLoadingToComplete(60, 1, false);
        common.wait(5);
        orderServicesAndFeaturesPage.txt_justification.scrollIntoView().click();
        orderServicesAndFeaturesPage.txt_justification.setValue("test");
        common.wait(5);
        orderServicesAndFeaturesPage.txt_upfrontDiscount.click();
        common.wait(10);
        orderServicesAndFeaturesPage.txt_upfrontDiscount.setValue(UpfrontDiscountAmount);
        common.wait(10);
        orderServicesAndFeaturesPage.lbl_upfrontDiscountAmount.click();
        common.wait(10);
    }

    @When("^I choose a number with '(.*)' spend cap for CCA$")
    public void choose_number_with_spend_cap_for_CCA(String spendCap) {
        this.logger.info(MessageFormat.format(
                "*** Choose phone number with ''{0}'' spend cap ...", spendCap));

        UserDataModel userData = (UserDataModel) this.context.get("residentialUserAccountData");

        assertThat(this.orderPhoneAndSpendCapPage.isPageDisplayed())
                .withFailMessage("Phone No & Cap page not displayed!")
                .isTrue();
        this.orderPhoneAndSpendCapPage.getPhoneNumberPageElement().scrollIntoView().click();
        this.orderPhoneAndSpendCapPage.getPhoneNumber().click();
        userData.phoneNumber = this.orderPhoneAndSpendCapPage.getPhoneNumberPageElement().getValue();


        Supplier<PageElement> processIcon = () -> this.orderPhoneAndSpendCapPage.processIcon;
        Boolean result = this.retry.untilNotDisplayed(processIcon, 12, 1);
        assertThat(result)
                .withFailMessage("Process icon still displayed after selecting a phone number!")
                .isTrue();
        assertThat(this.orderPhoneAndSpendCapPage.getPhoneNumberPageElement().getValue())
                .isNotEmpty();

        this.orderPhoneAndSpendCapPage.spendCap.asSelect().selectByText(spendCap);
        result = this.retry.untilNotDisplayed(processIcon, 12, 1);
        assertThat(result)
                .withFailMessage("Process icon still displayed after selecting a phone number!")
                .isTrue();
        assertThat(this.orderPhoneAndSpendCapPage.spendCap.asSelect().getSelectedValue())
                .isNotEmpty();
        this.orderPhoneAndSpendCapPage.showIcon.click();
        this.orderPhoneAndSpendCapPage.monthInputBox.setValue("5");
        this.common.waitForNavigationLoadingToComplete(90, 1, true);
        this.advanceToNextPage(this.orderPhoneAndSpendCapPage);
        this.context.set("residentialUserAccountData", userData);
        this.logger.warn(userData.toString());
        this.logger.info("*** Phone number with and spend cap selected!\n");
    }

    @When("^I choose a number with '(.*)' spend cap for upfrontDiscount$")
    public void choose_number_with_spend_cap_for_upfront_Discount(String spendCap) {
        this.logger.info(MessageFormat.format(
                "*** Choose phone number with ''{0}'' spend cap ...", spendCap));

        UserDataModel userData = (UserDataModel) this.context.get("residentialUserAccountData");

        assertThat(this.orderPhoneAndSpendCapPage.isPageDisplayed())
                .withFailMessage("Phone No & Cap page not displayed!")
                .isTrue();
        this.orderPhoneAndSpendCapPage.getPhoneNumberPageElement().scrollIntoView().click();
        this.orderPhoneAndSpendCapPage.getPhoneNumber().click();
        userData.phoneNumber = this.orderPhoneAndSpendCapPage.getPhoneNumberPageElement().getValue();


        Supplier<PageElement> processIcon = () -> this.orderPhoneAndSpendCapPage.processIcon;
        Boolean result = this.retry.untilNotDisplayed(processIcon, 12, 1);
        assertThat(result)
                .withFailMessage("Process icon still displayed after selecting a phone number!")
                .isTrue();
        assertThat(this.orderPhoneAndSpendCapPage.getPhoneNumberPageElement().getValue())
                .isNotEmpty();

        this.orderPhoneAndSpendCapPage.spendCap.asSelect().selectByText(spendCap);
        result = this.retry.untilNotDisplayed(processIcon, 12, 1);
        assertThat(result)
                .withFailMessage("Process icon still displayed after selecting a phone number!")
                .isTrue();
        assertThat(this.orderPhoneAndSpendCapPage.spendCap.asSelect().getSelectedValue())
                .isNotEmpty();
    }

    @Then("^I select phone type as (.*) and saletype as '(.*)'$")
    public void I_select_iphone(String phoneType, String sale) {
        this.orderServicesAndFeaturesPage.btn_phones.asList().get(2).click();
        this.advanceToNextPage(orderServicesAndFeaturesPage);
        this.common.wait(5);
        this.common.waitForLoadingToComplete(2, 1);
        this.orderServicesAndFeaturesPage.txt_deviceSearch.click();
        this.orderServicesAndFeaturesPage.txt_deviceSearch.setValue(phoneType);

        this.common.waitForNavigationLoadingToComplete(90, 1, true);
        //adding phone

        this.orderServicesAndFeaturesPage.btn_add.click();
        this.browser.setImplicitWait(5);
        this.context.set("sale1", sale);
        this.orderServicesAndFeaturesPage.ddl_saleType.asList().get(0).click();
        this.browser.setImplicitWait(2);
        this.orderServicesAndFeaturesPage.ddl_saleType.asList().get(0).asSelect().selectByText((String) this.context.get("sale1"));
        this.common.waitForNavigationLoadingToComplete(90, 1, true);
        this.orderServicesAndFeaturesPage.btn_ok.scrollIntoView().click();
        this.common.waitForNavigationLoadingToComplete(90, 1, true);
        this.advanceToNextPage(orderServicesAndFeaturesPage);
        this.common.waitForNavigationLoadingToComplete(90, 1, true);
    }


    private void checkIfEligibleForInsuranceProduct(String insuranceType) {
        common.waitForNavigationLoadingToComplete(60, 1, false);
        switch (insuranceType.toLowerCase()) {
            case "o2 insure full cover":
                try {
                    assertTrue("Insurance product is not applicable for this type of device #",
                            ((Chrome) browser).findBy(By.XPath, "//div[@class='offer_tree_table']//span[contains(text(),'O2 Insure Full Cover #')][1]").isDisplayed());
                } catch (Exception e) {
                    fail("Insurance product is not applicable for this type of device");
                }
                break;
            case "o2 insure damage cover":
                try {
                    assertTrue("Insurance product is not applicable for this type of device",
                            ((Chrome) browser).findBy(By.XPath, "//div[@class='offer_tree_table']//span[contains(text(),'O2 Insure Damage Cover #')][1]").isDisplayed());
                } catch (Exception e) {
                    fail("Insurance product is not applicable for this type of device");
                }
                break;
            case "o2 insure full cover for tablets":
                try {
                    assertTrue("Insurance product is not applicable for this type of device",
                            ((Chrome) browser).findBy(By.XPath, "//div[@class='offer_tree_table']//span[contains(text(),'O2 Insure Full Cover for Tablets #')][1]").isDisplayed());
                } catch (Exception e) {
                    fail("Insurance product is not applicable for this type of device");
                }
                break;
            case "o2 insure damage cover for tablets":
                try {
                    assertTrue("Insurance product is not applicable for this type of device",
                            ((Chrome) browser).findBy(By.XPath, "//div[@class='offer_tree_table']//span[contains(text(),'O2 Insure Damage Cover for Tablets #')][1]").isDisplayed());
                } catch (Exception e) {
                    fail("Insurance product is not applicable for this type of device");
                }
                break;
            case "o2 insure full cover for smart watches":
                try {
                    assertTrue("Insurance product is not applicable for this type of device",
                            ((Chrome) browser).findBy(By.XPath, "//div[@class='offer_tree_table']//span[contains(text(),'O2 Insure Full Cover for Smart Watches #')][1]").isDisplayed());

                } catch (Exception e) {
                    fail("Insurance product is not applicable for this type of device");
                }
                break;
            case "o2 insure damage cover for smart watches":
                try {
                    assertTrue("Insurance product is not applicable for this type of device",
                            ((Chrome) browser).findBy(By.XPath, "//div[@class='offer_tree_table']//span[contains(text(),'O2 Insure Damage Cover for Smart Watches #')][1]").isDisplayed());

                } catch (Exception e) {
                    fail("Insurance product is not applicable for this type of device");
                }
                break;
        }
    }

    @Then("^I select androidprice type as (.*) and saletype as '(.*)' and DevicePrice as'(.*)'$")
    public void I_select_Android_price(String phoneType, String sale, String price) {

        this.orderServicesAndFeaturesPage.btn_phones.asList().get(2).click();
        this.common.wait(3);
        System.out.println("phones clicked");
        this.advanceToNextPage(orderServicesAndFeaturesPage);
        this.common.wait(5);
        this.common.waitForLoadingToComplete(2, 1);
        //andrroid click
        this.orderServicesAndFeaturesPage.tab_android.scrollIntoView().click();
        this.common.waitForLoadingToComplete(2, 1);
        this.orderServicesAndFeaturesPage.txt_phoneSearch.click();
        this.orderServicesAndFeaturesPage.txt_phoneSearch.setValue(phoneType);

        this.common.waitForNavigationLoadingToComplete(90, 1, true);

        //phone price
        assertThat(this.orderServicesAndFeaturesPage.Androidprice.getText())
                .withFailMessage("Androidprice is not correct").contains(price);
        this.logger.info("Androidprice is correct");


        //adding phone

        this.orderServicesAndFeaturesPage.Androidaddbutton.click();

        System.out.println("button clicked");

        this.browser.setImplicitWait(5);

        this.context.set("sale1", sale);

        this.orderServicesAndFeaturesPage.saletype.asList().get(0).click();
        this.browser.setImplicitWait(2);
        this.orderServicesAndFeaturesPage.saletype.asList().get(0).asSelect().selectByText((String) this.context.get("sale1"));

        this.common.waitForNavigationLoadingToComplete(90, 1, true);

        this.orderServicesAndFeaturesPage.btn_ok.scrollIntoView().click();
        System.out.print("okbutton1");

        this.common.waitForNavigationLoadingToComplete(90, 1, true);
        this.advanceToNextPage(orderServicesAndFeaturesPage);


    }

    @When("^I choose a phone number custom plan with '(.*)' spend cap and check allowance '(.*)' and check price '(.*)'$")
    public void choose_phone_number_custom_plan_with_spend_cap(String spendCap, String allowance, String price) {
        this.logger.info(MessageFormat.format(
                "*** Choose phone number with ''{0}'' spend cap ...", spendCap));

        UserDataModel userData = (UserDataModel) this.context.get("residentialUserAccountData");

        assertThat(this.orderPhoneAndSpendCapPage.isPageDisplayed())
                .withFailMessage("Phone No & Cap page not displayed!")

                .isTrue();
// locator changed
        this.orderPhoneAndSpendCapPage.getPhoneNumberPageElement().scrollIntoView().click();
        this.orderPhoneAndSpendCapPage.getPhoneNumber().click();
        userData.phoneNumber = this.orderPhoneAndSpendCapPage.getPhoneNumberPageElement().getValue();

        Supplier<PageElement> processIcon = () -> this.orderPhoneAndSpendCapPage.processIcon;
        Boolean result = this.retry.untilNotDisplayed(processIcon, 12, 1);
        assertThat(result)
                .withFailMessage("Process icon still displayed after selecting a phone number!")
                .isTrue();
        assertThat(this.orderPhoneAndSpendCapPage.getPhoneNumberPageElement().getValue())
                .isNotEmpty();


        this.orderPhoneAndSpendCapPage.spendCap.asSelect().selectByText(spendCap);
        result = this.retry.untilNotDisplayed(processIcon, 12, 1);
        assertThat(result)
                .withFailMessage("Process icon still displayed after selecting a phone number!")
                .isTrue();
        assertThat(this.orderPhoneAndSpendCapPage.spendCap.asSelect().getSelectedValue())
                .isNotEmpty();
        System.out.println("allowance");
        //this.orderServicesAndFeaturesPage.allowanceBundle.asList().get(0).click();
        //this.orderServicesAndFeaturesPage.allowanceBundle.asList().get(0).asSelect().selectByText((String) this.context.get("resource"));
        this.common.waitForNavigationLoadingToComplete(90, 1, true);
        this.common.waitForLoadingToComplete(3, 1);
        this.orderServicesAndFeaturesPage.allowanceBundlephones1.asList().get(0).asSelect().selectByText((allowance));

        this.common.wait(10);
        assertThat(this.orderServicesAndFeaturesPage.lbl_price.asList().get(0).waitUntil(displayed).getText())
                .withFailMessage("Price is not displayed").contains(price);
        this.logger.info("pass- price is correct");
        this.advanceToNextPage(this.orderPhoneAndSpendCapPage);

    }

    @When("^I choose a number with '(.*)' spend cap for insurance$")
    public void choose_number_with_spend_cap_for_insurance(String spendCap) {
        this.logger.info(MessageFormat.format(
                "*** Choose phone number with ''{0}'' spend cap ...", spendCap));

        UserDataModel userData = (UserDataModel) this.context.get("residentialUserAccountData");

        assertThat(this.orderPhoneAndSpendCapPage.isPageDisplayed())
                .withFailMessage("Phone No & Cap page not displayed!")
                .isTrue();
        this.orderPhoneAndSpendCapPage.getPhoneNumberPageElement().scrollIntoView().click();
        this.orderPhoneAndSpendCapPage.getPhoneNumber().click();
        userData.phoneNumber = this.orderPhoneAndSpendCapPage.getPhoneNumberPageElement().getValue();

        Supplier<PageElement> processIcon = () -> this.orderPhoneAndSpendCapPage.processIcon;
        Boolean result = this.retry.untilNotDisplayed(processIcon, 12, 1);
        assertThat(result)
                .withFailMessage("Process icon still displayed after selecting a phone number!")
                .isTrue();
        assertThat(this.orderPhoneAndSpendCapPage.getPhoneNumberPageElement().getValue())
                .isNotEmpty();


        this.orderPhoneAndSpendCapPage.spendCap.asSelect().selectByText(spendCap);
        result = this.retry.untilNotDisplayed(processIcon, 12, 1);
        assertThat(result)
                .withFailMessage("Process icon still displayed after selecting a phone number!")
                .isTrue();
        assertThat(this.orderPhoneAndSpendCapPage.spendCap.asSelect().getSelectedValue())
                .isNotEmpty();
        this.context.set("residentialUserAccountData", userData);
        this.logger.warn(userData.toString());
        this.logger.info("*** Phone number with and spend cap selected!\n");
    }


    @When("^Providing Insurance as (.*)$")
    public void Providing_insurance(String insuranceType) {
        orderServicesAndFeaturesPage.btn_show.scrollIntoView().click();
        switch (insuranceType.toLowerCase()) {
            case "o2 insure full cover":
                orderServicesAndFeaturesPage.btn_insureFullCover.scrollIntoView();
                orderServicesAndFeaturesPage.btn_insureFullCover.click();
                checkIfEligibleForInsuranceProduct(insuranceType);
                common.waitForNavigationLoadingToComplete(60, 1, false);
                orderServicesAndFeaturesPage.ddl_insureFullCoverTermAndConditions.scrollIntoView();
                orderServicesAndFeaturesPage.ddl_insureFullCoverTermAndConditions.asSelect().selectByIndex(1);
                common.waitForNavigationLoadingToComplete(60, 1, false);
                logger.info("O2 Insure Full Cover selected");
                break;
            case "o2 insure damage cover":
                orderServicesAndFeaturesPage.btn_insureDamageCover.scrollIntoView();
                orderServicesAndFeaturesPage.btn_insureDamageCover.click();
                checkIfEligibleForInsuranceProduct(insuranceType);
                common.waitForNavigationLoadingToComplete(60, 1, false);
                orderServicesAndFeaturesPage.ddl_insureFullCoverTermAndConditions.scrollIntoView();
                orderServicesAndFeaturesPage.ddl_insureFullCoverTermAndConditions.asSelect().selectByIndex(1);
                common.waitForNavigationLoadingToComplete(60, 1, false);
                logger.info("O2 Insure Damage Cover selected");
                break;
            case "o2 insure full cover for tablets":
                orderServicesAndFeaturesPage.btn_ensureFullCoverTablet.scrollIntoView();
                orderServicesAndFeaturesPage.btn_ensureFullCoverTablet.click();
                checkIfEligibleForInsuranceProduct(insuranceType);
                common.waitForNavigationLoadingToComplete(60, 1, false);
                orderServicesAndFeaturesPage.ddl_insureFullCoverTermAndConditions.scrollIntoView();
                orderServicesAndFeaturesPage.ddl_insureFullCoverTermAndConditions.asSelect().selectByIndex(1);
                common.waitForNavigationLoadingToComplete(60, 1, false);
                logger.info("Insure Full Cover for Tablets selected");
                break;
            case "o2 insure damage cover for tablets":
                orderServicesAndFeaturesPage.btn_insureDamageCoverTablet.scrollIntoView();
                orderServicesAndFeaturesPage.btn_insureDamageCoverTablet.click();
                checkIfEligibleForInsuranceProduct(insuranceType);
                orderServicesAndFeaturesPage.ddl_insureFullCoverTermAndConditions.scrollIntoView();
                orderServicesAndFeaturesPage.ddl_insureFullCoverTermAndConditions.asSelect().selectByIndex(1);
                common.waitForNavigationLoadingToComplete(60, 1, false);
                logger.info("O2 Insure Damage Cover selected");
                break;
            case "o2 insure full cover for smart watches":
                orderServicesAndFeaturesPage.btn_insureFullCoverForSmartWatches.scrollIntoView();
                orderServicesAndFeaturesPage.btn_insureFullCoverForSmartWatches.click();
                checkIfEligibleForInsuranceProduct(insuranceType);
                orderServicesAndFeaturesPage.ddl_insureFullCoverTermAndConditions.scrollIntoView();
                orderServicesAndFeaturesPage.ddl_insureFullCoverTermAndConditions.asSelect().selectByIndex(1);
                common.waitForNavigationLoadingToComplete(60, 1, false);
                logger.info("Insure Full Cover for smart watches selected");
                break;
            case "o2 insure damage cover for smart watches":
                orderServicesAndFeaturesPage.btn_insureDamageCoverForSmartWatches.scrollIntoView();
                orderServicesAndFeaturesPage.btn_insureDamageCoverForSmartWatches.click();
                checkIfEligibleForInsuranceProduct(insuranceType);
                orderServicesAndFeaturesPage.ddl_insureFullCoverTermAndConditions.scrollIntoView();
                orderServicesAndFeaturesPage.ddl_insureFullCoverTermAndConditions.asSelect().selectByIndex(1);
                common.waitForNavigationLoadingToComplete(60, 1, false);
                logger.info("O2 Insure Damage Cover selected");
                break;
        }
    }


    @And("^I select a device (.*) and specify the sale type as (.*)$")
    public void iSelectADeviceAndSpecifyTheSaleType(String device, String saleType) {
        navigateToOrderServicesAndFeaturesAndClickTab();
        common.wait(FIVE_SECS);
        orderServicesAndFeaturesPage.txt_deviceSearch.setValue(device);
        common.waitForNavigationLoadingToComplete(90, 1, true);
        PageElement btn_addDevice = ((Chrome) browser).findBy(By.XPath,
                "//div[@id='" + getLblDevicesList() + "']//table[@role='presentation']/tbody/tr/td[5]/a");
        btn_addDevice.clickJs();
        common.wait(ONE_SEC);
        context.set("sale1", saleType);
        if (saleType.equalsIgnoreCase("Custom Plan with CCA")) {
            fail("For insurance the CCA journey is not covered as it is not data requirement");
        }
        getSaleTypeDropdownListByValue((String) context.get("sale1"));
        orderServicesAndFeaturesPage.btn_ok.scrollIntoView().click();
        common.waitForNavigationLoadingToComplete(90, 1, true);
        advanceToNextPage(orderServicesAndFeaturesPage);
    }

    @And("^I select offering_name (.*) sale_type (.*) price (.*) installment_term_min (.*) installment_term_max (.*) min_downpayment-upfront_payment_for_new (.*) min_downpayment-upfront_payment_for_existing (.*) max_downpayment-upfront_payment (.*)$")
    public void i_Select_Payment_Upfront_Downpayment(String offering_name,
                                                     String sale_type,
                                                     String expectedPrice,
                                                     String installment_term_min,
                                                     String installment_term_max,
                                                     String min_downpayment_upfront_payment_for_new,
                                                     String min_downpayment_upfront_payment_for_existing,
                                                     String max_downpayment_upfront_payment) {
        navigateToOrderServicesAndFeaturesAndClickTab();
        common.wait(FIVE_SECS);
        orderServicesAndFeaturesPage.txt_deviceSearch.waitUntil(enabled).isEnabled();
        orderServicesAndFeaturesPage.txt_deviceSearch.clickJs();
        orderServicesAndFeaturesPage.txt_deviceSearch.setValue(offering_name);
        common.waitForNavigationLoadingToComplete(90, 1, true);
        String actualPrice = ((Chrome) browser).findAllBy(By.XPath, "//div[@id='" + getLblDevicesList() + "']//table[@role='presentation']//tbody/tr/td").get(3).getText();
        if (!expectedPrice.contains(".")) {
            assertEquals("£" + expectedPrice + ".00", actualPrice);
        } else {
            assertEquals("£" + expectedPrice, actualPrice);
        }
        PageElement btn_addDevice = ((Chrome) browser).findBy(By.XPath,
                "//div[@id='" + getLblDevicesList() + "']//table[@role='presentation']/tbody/tr/td[5]");
        btn_addDevice.click();
        common.wait(ONE_SEC);
        context.set("sale1", sale_type);
        getSaleTypeDropdownListByValue((String) context.get("sale1"));
        orderServicesAndFeaturesPage.btn_ok.scrollIntoView().click();
        common.wait(FIVE_SECS);
        orderNavigationPage.getNextButton().click();
        common.wait(FIVE_SECS);
        handleCannotFindPlanForDeviceAndSaleType();
        setTelNoAndSpendCap("£5.00");
        if (sale_type.contains("CCA")) {
            orderNavigationPage.getPrevButton().click();
            orderServicesAndFeaturesPage.btn_show.scrollIntoView().click();
            specifyDownpaymentAndInstallmentTerm(min_downpayment_upfront_payment_for_existing, installment_term_min);
            orderNavigationPage.getPrevButton().click();
            common.waitForNavigationLoadingToComplete(10, 1, true);
            advanceToNextPage(orderServicesAndFeaturesPage);
            common.waitForNavigationLoadingToComplete(10, 1, true);
            orderServicesAndFeaturesPage.btn_show.scrollIntoView().click();
            specifyDownpaymentAndInstallmentTerm(max_downpayment_upfront_payment, installment_term_max);
            orderNavigationPage.getNextButton().click();
            common.waitForNavigationLoadingToComplete(10, 1, true);
            orderNavigationPage.getNextButton().click();
        } else if (!sale_type.contains("full upfront payment")) {
            fail("Sale Type is not currently supported. Either use Custom Plan with CCA or Full upfront Payment");
        }
    }

    private String getSaleTypeDropdownListByIndex(int index) {
        String ddl_value = "";
        int i = 0;
        if (index > 1) {
            fail("The index must be less than two for the Sales Type Drop-down");
        }
        orderServicesAndFeaturesPage.ddl_saleType.get(0).click();
        orderServicesAndFeaturesPage.ddl_saleType.get(0).setValue(Keys.ARROW_UP);   // Reset to index to 0
        common.wait(ONE_SEC);
        for (i = 0; i <= index; i++) {
            if (index == 0) {
                break;
            }
            orderServicesAndFeaturesPage.ddl_saleType.get(0).setValue(Keys.ARROW_DOWN);
            common.wait(ONE_SEC);
        }
        ddl_value = (i == 0) ? "Custom Plan with CCA" : "Custom Plan with full upfront payment";
        orderServicesAndFeaturesPage.ddl_saleType.get(0).setValue(Keys.ENTER);
        return ddl_value;
    }

    private void getSaleTypeDropdownListByValue(String value) {
        String ddl_value = value;
        int i = 0;
        orderServicesAndFeaturesPage.ddl_saleType.get(0).click();
        orderServicesAndFeaturesPage.ddl_saleType.get(0).setValue(Keys.ARROW_UP);   // Reset to index to 0
        common.wait(ONE_SEC);
        if (value.equals("Custom Plan with CCA")) {
        }
        if (value.equals("Custom Plan with full upfront payment")) {
            orderServicesAndFeaturesPage.ddl_saleType.get(0).setValue(Keys.ARROW_DOWN);
        }
        common.wait(ONE_SEC);
        orderServicesAndFeaturesPage.ddl_saleType.get(0).setValue(Keys.ENTER);
        common.wait(ONE_SEC);
    }

    private void handleCannotFindPlanForDeviceAndSaleType() {
        try {
            if (orderEligibilityCheckPage.getEligibilityButton().isDisplayed()) {
                fail("Cannot find plan for the device and sale type");
            }
        } catch (Exception ex) {
            logger.info("Plan successfully identified for the device and sale type");
        }
    }

    private void specifyDownpaymentAndInstallmentTerm(String amount, String term) {
        orderServicesAndFeaturesPage.txt_months.scrollIntoView();
        orderServicesAndFeaturesPage.txt_months.waitUntil(clickable).isEnabled();
        orderServicesAndFeaturesPage.txt_months.click();
        String actualMonthsStrValue = orderServicesAndFeaturesPage.txt_months.getAttribute("value");
        int actualMonthsValue = Integer.parseInt(orderServicesAndFeaturesPage.txt_months.getAttribute("value"));
        for (int i = 0; i < actualMonthsStrValue.length(); i++) {
            if (actualMonthsValue == 0)
                break;
            else {
                orderServicesAndFeaturesPage.txt_months.setValue("5");  // Bizarrely erases the field contents
                common.wait(TEN_SECS);
            }
        }
        orderServicesAndFeaturesPage.txt_months.click();
        orderServicesAndFeaturesPage.txt_months.setValue(term);
        common.waitForLoadingToComplete(30, 1, true);
        orderServicesAndFeaturesPage.txt_upfrontGbp.waitUntil(clickable).isEnabled();
        orderServicesAndFeaturesPage.txt_upfrontGbp.scrollIntoView().clickJs();
        String actualUpfrontGbpStrValue = orderServicesAndFeaturesPage.txt_upfrontGbp.getAttribute("value");
        for (int i = 0; i < actualUpfrontGbpStrValue.length(); i++) {
            if (actualUpfrontGbpStrValue.equals("0.00"))
                break;
            else {
                orderServicesAndFeaturesPage.txt_upfrontGbp.setValue(Keys.chord(Keys.CONTROL, "a"));
                orderServicesAndFeaturesPage.txt_upfrontGbp.setValue(Keys.DELETE);
                common.wait(FIVE_SECS);
            }
        }
        double expectedUpfrontGbpValue = Double.parseDouble(amount);
        double actualUpfrontGbpValue = Double.parseDouble(orderServicesAndFeaturesPage.txt_upfrontGbp.getAttribute("value"));
        int iterationController = 0;
        int i = 0;
        while (i != expectedUpfrontGbpValue) {
            common.wait(ONE_SEC);
            if (iterationController == 0) {
                if (expectedUpfrontGbpValue == actualUpfrontGbpValue) {
                    iterationController++;
                    break;
                }
                if (actualUpfrontGbpValue < expectedUpfrontGbpValue) {
                    // Proceed with code execution flow
                }
                if (actualUpfrontGbpValue > expectedUpfrontGbpValue) {
                    fail("Upfront amount is already predefined and cannot be changed to the value in the input data as it is lower.");
                }
            }
            if (actualUpfrontGbpValue != 0 && (actualUpfrontGbpValue == actualUpfrontGbpValue + i)) {
                // Infinite loop
                break;
            }
            orderServicesAndFeaturesPage.txt_upfrontGbp.setValue(Keys.ARROW_UP);
            i++;
        }
    }

    private void setTelNoAndSpendCap(String spendCap) {
        UserDataModel userData = (UserDataModel) context.get("residentialUserAccountData");
        logger.info(MessageFormat.format(
                "*** Choose phone number with ''{0}'' spend cap ...", spendCap));
        assertThat(orderPhoneAndSpendCapPage.isPageDisplayed())
                .withFailMessage("Phone No & Cap page not displayed!")
                .isTrue();
        Supplier<PageElement> processIcon = () -> orderPhoneAndSpendCapPage.processIcon;
        Boolean result = false;
        try {
            orderPhoneAndSpendCapPage.getPhoneNumberPageElement().scrollIntoView().click();
            orderPhoneAndSpendCapPage.getPhoneNumber().click();
            userData.phoneNumber = orderPhoneAndSpendCapPage.getPhoneNumberPageElement().getValue();
            result = retry.untilNotDisplayed(processIcon, 20, 1);
            assertThat(result)
                    .withFailMessage("Process icon still displayed after selecting a phone number!")
                    .isTrue();
            assertThat(orderPhoneAndSpendCapPage.getPhoneNumberPageElement().getValue())
                    .isNotEmpty();
            orderPhoneAndSpendCapPage.spendCap.asSelect().selectByText(spendCap);
            result = retry.untilNotDisplayed(processIcon, 12, 1);
            assertThat(result)
                    .withFailMessage("Process icon still displayed after selecting a phone number!")
                    .isTrue();
            assertThat(orderPhoneAndSpendCapPage.spendCap.asSelect().getSelectedValue())
                    .isNotEmpty();
        } catch (StaleElementReferenceException ex) {
            orderPhoneAndSpendCapPage.getPhoneNumberPageElement().scrollIntoView().click();
            orderPhoneAndSpendCapPage.getPhoneNumber().click();
            userData.phoneNumber = orderPhoneAndSpendCapPage.getPhoneNumberPageElement().getValue();
            result = retry.untilNotDisplayed(processIcon, 20, 1);
            assertThat(result)
                    .withFailMessage("Process icon still displayed after selecting a phone number!")
                    .isTrue();
            assertThat(orderPhoneAndSpendCapPage.getPhoneNumberPageElement().getValue())
                    .isNotEmpty();
            orderPhoneAndSpendCapPage.spendCap.asSelect().selectByText(spendCap);
            result = retry.untilNotDisplayed(processIcon, 12, 1);
            assertThat(result)
                    .withFailMessage("Process icon still displayed after selecting a phone number!")
                    .isTrue();
            assertThat(orderPhoneAndSpendCapPage.spendCap.asSelect().getSelectedValue())
                    .isNotEmpty();
        }
        advanceToNextPage(orderPhoneAndSpendCapPage);
        context.set("residentialUserAccountData", userData);
        logger.warn(userData.toString());
        logger.info("*** Phone number with and spend cap selected!\n");
    }

    @Then("^I select android tablet to check price type as (.*) and saletype as '(.*)' and DevicePrice as'(.*)'$")
    public void I_select_tablet_checkprice_android(String tabletType, String sale, String price) {
        this.orderServicesAndFeaturesPage.btn_tablets.asList().get(0).click();
        this.advanceToNextPage(orderServicesAndFeaturesPage);
        this.common.waitForLoadingToComplete(2, 1);
        this.orderServicesAndFeaturesPage.txt_deviceSearch.scrollIntoView().click();
        //android click
        this.orderServicesAndFeaturesPage.tab_tabletsAndroid.scrollIntoView().click();
        this.orderServicesAndFeaturesPage.txt_deviceSearch.scrollIntoView().click();
        this.orderServicesAndFeaturesPage.txt_deviceSearch.click();
        this.orderServicesAndFeaturesPage.txt_deviceSearch.setValue(tabletType);
        this.common.waitForNavigationLoadingToComplete(90, 1, true);
        //phone price
        assertThat(this.orderServicesAndFeaturesPage.txt_androidTabletPrice.getText())
                .withFailMessage("tabletprice is not correct").contains(price);
        this.logger.info("tabletprice is correct");
        //adding phone
        this.orderServicesAndFeaturesPage.btn_addAndroidTablet.click();
        this.browser.setImplicitWait(5);
        this.context.set("sale1", sale);
        this.orderServicesAndFeaturesPage.ddl_saleType.asList().get(0).click();
        this.browser.setImplicitWait(2);
        this.orderServicesAndFeaturesPage.ddl_saleType.asList().get(0).asSelect().selectByText((String) this.context.get("sale1"));
        this.common.waitForNavigationLoadingToComplete(90, 1, true);
        this.orderServicesAndFeaturesPage.btn_ok.scrollIntoView().click();
        System.out.print("okbutton1");
        this.common.waitForNavigationLoadingToComplete(90, 1, true);
        this.advanceToNextPage(orderServicesAndFeaturesPage);
    }

    @Then("^I select windows tablet to check price type as (.*) and saletype as '(.*)' and DevicePrice as'(.*)'$")
    public void I_select_tablet_checkprice_windows(String tabletType, String sale, String price) {
        this.orderServicesAndFeaturesPage.btn_tablets.asList().get(0).click();
        this.common.wait(5);
        this.advanceToNextPage(orderServicesAndFeaturesPage);
        this.common.wait(5);
        this.common.waitForLoadingToComplete(2, 1);
        this.orderServicesAndFeaturesPage.txt_deviceSearch.scrollIntoView().click();
        //android click
        this.orderServicesAndFeaturesPage.tab_tabletsWindows.scrollIntoView().click();
        this.orderServicesAndFeaturesPage.txt_deviceSearch.scrollIntoView();
        this.orderServicesAndFeaturesPage.txt_deviceSearch.click();
        this.orderServicesAndFeaturesPage.txt_deviceSearch.setValue(tabletType);
        this.common.waitForNavigationLoadingToComplete(90, 1, true);
        //tablet price
        assertThat(this.orderServicesAndFeaturesPage.txt_windowsTabletPrice.getText())
                .withFailMessage("tabletprice is not correct").contains(price);
        this.logger.info("tabletprice is correct");
        //adding phone
        this.orderServicesAndFeaturesPage.btn_addWindowsTablet.click();
        this.browser.setImplicitWait(5);
        this.context.set("sale1", sale);
        this.orderServicesAndFeaturesPage.ddl_saleType.asList().get(0).click();
        this.browser.setImplicitWait(2);
        this.orderServicesAndFeaturesPage.ddl_saleType.asList().get(0).asSelect().selectByText((String) this.context.get("sale1"));
        this.common.waitForNavigationLoadingToComplete(90, 1, true);
        this.orderServicesAndFeaturesPage.btn_ok.scrollIntoView().click();
        this.common.waitForNavigationLoadingToComplete(90, 1, true);
        this.advanceToNextPage(orderServicesAndFeaturesPage);
    }

    @Then("^I select watches apple to check price type as (.*) and saletype as '(.*)' and DevicePrice as'(.*)'$")
    public void I_select_watches_apple_checkprice(String watchType, String sale, String price) {
        this.orderServicesAndFeaturesPage.btn_wearables.asList().get(0).click();
        this.advanceToNextPage(orderServicesAndFeaturesPage);
        this.common.waitForLoadingToComplete(2, 1);
        //android watch click
//        this.orderServicesAndFeaturesPage.Wearables_android.scrollIntoView().click();
//        this.common.wait(2);
        this.orderServicesAndFeaturesPage.txt_phoneSearch.click();
        this.orderServicesAndFeaturesPage.txt_phoneSearch.scrollIntoView().setValue(watchType);
        this.common.waitForNavigationLoadingToComplete(90, 1, true);
        //tablet price
        assertThat(this.orderServicesAndFeaturesPage.lbl_watchesApplePrice.getText())
                .withFailMessage("watches price is not correct").contains(price);
        this.logger.info("watches price is correct");
        //adding phone
        this.orderServicesAndFeaturesPage.btn_addAppleWatches.click();
        this.browser.setImplicitWait(5);
        this.context.set("sale1", sale);
        this.orderServicesAndFeaturesPage.ddl_saleType.asList().get(0).click();
        this.browser.setImplicitWait(2);
        this.orderServicesAndFeaturesPage.ddl_saleType.asList().get(0).asSelect().selectByText((String) this.context.get("sale1"));
        this.common.waitForNavigationLoadingToComplete(90, 1, true);
        this.orderServicesAndFeaturesPage.btn_ok.scrollIntoView().click();
        this.common.waitForNavigationLoadingToComplete(90, 1, true);
        this.advanceToNextPage(orderServicesAndFeaturesPage);
    }

    @Then("^I select watches android to check price type as (.*) and saletype as '(.*)' and DevicePrice as'(.*)'$")
    public void I_select_watches_checkprice_android(String watchType, String sale, String price) {
        this.orderServicesAndFeaturesPage.btn_wearables.asList().get(0).click();
        this.advanceToNextPage(orderServicesAndFeaturesPage);
        this.common.waitForLoadingToComplete(2, 1);
        //android watch click
        this.orderServicesAndFeaturesPage.btn_wearablesAndroid.scrollIntoView().click();
        this.common.wait(2);
        this.orderServicesAndFeaturesPage.txt_phoneSearch.click();
        this.orderServicesAndFeaturesPage.txt_phoneSearch.scrollIntoView().setValue(watchType);
        this.common.waitForNavigationLoadingToComplete(90, 1, true);
        //tablet price
        assertThat(this.orderServicesAndFeaturesPage.lbl_watchesAndroidPrice.getText())
                .withFailMessage("watches price is not correct").contains(price);
        this.logger.info("watches price is correct");
        //adding phone
        this.orderServicesAndFeaturesPage.btn_addAndroidWatches.click();
        this.browser.setImplicitWait(5);
        this.context.set("sale1", sale);
        this.orderServicesAndFeaturesPage.ddl_saleType.asList().get(0).click();
        this.browser.setImplicitWait(2);
        this.orderServicesAndFeaturesPage.ddl_saleType.asList().get(0).asSelect().selectByText((String) this.context.get("sale1"));
        this.common.waitForNavigationLoadingToComplete(90, 1, true);
        this.orderServicesAndFeaturesPage.btn_ok.scrollIntoView().click();
        this.common.waitForNavigationLoadingToComplete(90, 1, true);
        this.advanceToNextPage(orderServicesAndFeaturesPage);
    }

    @Then("^I select tablet to check price type as (.*) and saletype as '(.*)' and DevicePrice as'(.*)'$")
    public void I_select_tablet_checkprice(String tabletType, String sale, String price) {
        this.orderServicesAndFeaturesPage.btn_tablets.asList().get(0).click();
        this.common.wait(5);
        this.advanceToNextPage(orderServicesAndFeaturesPage);
        this.common.wait(2);
        this.common.waitForLoadingToComplete(2, 1);
        this.common.wait(2);
        this.orderServicesAndFeaturesPage.txt_deviceSearch.scrollIntoView().click();
        this.orderServicesAndFeaturesPage.txt_deviceSearch.click();
        this.orderServicesAndFeaturesPage.txt_deviceSearch.setValue(tabletType);
        this.common.waitForNavigationLoadingToComplete(90, 1, true);
        //tablet price
        this.orderServicesAndFeaturesPage.txt_tabletPrice.getText();
        this.logger.info("actual price " + this.orderServicesAndFeaturesPage.txt_tabletPrice.getText());
        assertThat(this.orderServicesAndFeaturesPage.txt_tabletPrice.getText())
                .withFailMessage("tabletprice is not correct").contains(price);
        this.logger.info("tabletprice is correct");
        //adding phone
        this.orderServicesAndFeaturesPage.btn_addIpad.click();
        this.browser.setImplicitWait(5);
        this.context.set("sale1", sale);
        this.orderServicesAndFeaturesPage.ddl_saleType.asList().get(0).click();
        this.browser.setImplicitWait(2);
        this.orderServicesAndFeaturesPage.ddl_saleType.asList().get(0).asSelect().selectByText((String) this.context.get("sale1"));
        this.common.waitForNavigationLoadingToComplete(90, 1, true);
        this.orderServicesAndFeaturesPage.btn_ok.scrollIntoView().click();
        this.common.waitForNavigationLoadingToComplete(90, 1, true);
        this.advanceToNextPage(orderServicesAndFeaturesPage);
    }

    @When("^I open PLM form expand and provide offering name as '(.*)' and flat offering as '(.*)' and condition set as '(.*)' and price as '(.*)' and tariff date as '(.*)'$")
    public void _PLM_pdated_with_date(String offering, String flatoffering, String conditionset, String
            price, String tariffstartdate) {
        this.orderServicesAndFeaturesPage.expandplm.waitUntil(displayed);
        this.orderServicesAndFeaturesPage.expandplm.scrollIntoView().click();
        this.orderServicesAndFeaturesPage.productmanagement.hover();
        this.orderServicesAndFeaturesPage.PLMManagement.hover();
        this.orderServicesAndFeaturesPage.PLMManagement.click();
        this.browser.switchToTab(1);
        this.orderServicesAndFeaturesPage.rpipricetemplate.click();
        this.common.waitForLoadingToComplete(60, 2, true);
        //offering code
        this.orderServicesAndFeaturesPage.offeringcode.click();
        System.out.println("offering code box");
        this.common.wait(5);
        this.orderServicesAndFeaturesPage.offeringcodebar.setValue(offering);
        this.orderServicesAndFeaturesPage.offeringsearch.click();
        this.common.wait(4);
// check flat offering name
        this.orderServicesAndFeaturesPage.flatofferingresult.waitUntil(displayed);
        this.orderServicesAndFeaturesPage.flatofferingresult.scrollIntoView();
        this.orderServicesAndFeaturesPage.flatofferingresult.getText();
        this.common.waitForNavigationLoadingToComplete(60, 1, false);
//        // plan name check
        this.common.wait(2);
        System.out.println("checking plan name");
        System.out.println("plan name" + this.orderServicesAndFeaturesPage.flatofferingresult.getText());
        assertThat(this.orderServicesAndFeaturesPage.flatofferingresult.getText())
                .withFailMessage("plan name is not correct").contains(flatoffering)
        ;
        this.logger.info("plan name is correct");
        // conditioncheck
        this.common.wait(4);
        System.out.println("plan name" + this.orderServicesAndFeaturesPage.conditionset.getText());
        assertThat(this.orderServicesAndFeaturesPage.conditionset.getText())
                .withFailMessage("allowance not correct").contains(conditionset)
        ;

        this.logger.info("allowance is correct");


        // tariff start date
//        System.out.println("tariff date" + this.orderServicesAndFeaturesPage.tarrifstartdate.getText());
//        assertThat(this.orderServicesAndFeaturesPage.tarrifstartdate.getText())
//                .withFailMessage("date is not correct").contains(tariffstartdate)
//        ;

//row2
        if (!tariffstartdate.equals(this.orderServicesAndFeaturesPage.tarrifstartdate.getText())) {
            this.common.wait(2);
            assertThat(this.orderServicesAndFeaturesPage.tarrifstartdaterow2.getText())
                    .withFailMessage("date is not correct for row2").contains(tariffstartdate)
            ;

            assertThat(this.orderServicesAndFeaturesPage.lbl_priceSecondRow.getText())
                    .withFailMessage("price not correct for row2").contains(price)
            ;


        }
//date check for row1
        else if (tariffstartdate.equals(this.orderServicesAndFeaturesPage.tarrifstartdate.getText())) {

//date check for row1
            this.common.wait(2);

            assertThat(this.orderServicesAndFeaturesPage.tarrifstartdate.getText())
                    .withFailMessage("date is not correct").contains(tariffstartdate);
            System.out.println("date is correct" + this.orderServicesAndFeaturesPage.tarrifstartdate.getText());

            //price check
            System.out.println("plan name" + this.orderServicesAndFeaturesPage.lbl_price2.scrollIntoView().getText());

            assertThat(this.orderServicesAndFeaturesPage.lbl_price2.getText())
                    .withFailMessage("price not correct").contains(price);
            System.out.println("price is correct" + this.orderServicesAndFeaturesPage.lbl_price2.getText());
        }


    }


    @When("^I open PLM form for prechecks and provide offering name as '(.*)' and flat offering as '(.*)' and condition set as '(.*)' and price as '(.*)'$")
    public void PLM_rpi_prechecks(String offering, String flatoffering, String conditionset, String price) {
        this.orderServicesAndFeaturesPage.expandplm.waitUntil(displayed);
        this.orderServicesAndFeaturesPage.expandplm.scrollIntoView().click();
        this.orderServicesAndFeaturesPage.productmanagement.hover();
        this.orderServicesAndFeaturesPage.PLMManagement.hover();
        this.orderServicesAndFeaturesPage.PLMManagement.click();
        this.browser.switchToTab(1);
        this.orderServicesAndFeaturesPage.rpipricetemplate.click();
        this.common.waitForLoadingToComplete(60, 2, true);
        //offering code
        this.common.wait(2);
        this.orderServicesAndFeaturesPage.offeringcode.click();
        System.out.println("offering code box");
        this.common.wait(5);
        this.orderServicesAndFeaturesPage.offeringcodebar.setValue(offering);
        this.orderServicesAndFeaturesPage.offeringsearch.click();
        this.common.wait(4);
        // check flat offering name
        this.orderServicesAndFeaturesPage.flatofferingresult.waitUntil(displayed);
        this.orderServicesAndFeaturesPage.flatofferingresult.scrollIntoView();
        this.orderServicesAndFeaturesPage.flatofferingresult.getText();
        this.common.waitForNavigationLoadingToComplete(60, 1, false);
        // plan name check
        this.common.wait(2);
        System.out.println("checking plan name");
        System.out.println("plan name" + this.orderServicesAndFeaturesPage.flatofferingresult.getText());
        assertThat(this.orderServicesAndFeaturesPage.flatofferingresult.getText())
                .withFailMessage("plan name is not correct").contains(flatoffering);
        this.logger.info("plan name is correct");
        // conditioncheck
        this.common.wait(4);
        System.out.println("plan name" + this.orderServicesAndFeaturesPage.conditionset.getText());
        assertThat(this.orderServicesAndFeaturesPage.conditionset.getText())
                .withFailMessage("allowance not correct").contains(conditionset);
        this.logger.info("allowance is correct");
        //date check for row1
        this.common.wait(2);
        //price check
        System.out.println("plan name" + this.orderServicesAndFeaturesPage.lbl_price2.scrollIntoView().getText());
        assertThat(this.orderServicesAndFeaturesPage.lbl_price2.getText())
                .withFailMessage("price not correct").contains(price);
        System.out.println("price is correct" + this.orderServicesAndFeaturesPage.lbl_price2.getText());
    }

    @Then("^I select tablet windows to check price type as (.*) and saletype as '(.*)'$")
    public void I_select_insurance_tablet_windows(String tabletType, String sale) {
        this.orderServicesAndFeaturesPage.tab_tablets.asList().get(0).click();
        this.advanceToNextPage(orderServicesAndFeaturesPage);
        this.common.wait(5);
        this.common.waitForLoadingToComplete(2, 1);
        this.common.wait(5);
        this.common.waitForLoadingToComplete(2, 1);
        this.orderServicesAndFeaturesPage.tab_tabletsWindows.scrollIntoView().click();
        this.common.waitForLoadingToComplete(2, 1);
        this.orderServicesAndFeaturesPage.txt_phoneSearch.click();
        this.orderServicesAndFeaturesPage.txt_phoneSearch.setValue(tabletType);
        //adding phone
        this.orderServicesAndFeaturesPage.addwindowstablet.click();
        this.browser.setImplicitWait(5);
        this.context.set("sale1", sale);
        this.orderServicesAndFeaturesPage.saletype.asList().get(0).click();
        this.browser.setImplicitWait(2);
        this.orderServicesAndFeaturesPage.saletype.asList().get(0).asSelect().selectByText((String) this.context.get("sale1"));
        this.common.waitForNavigationLoadingToComplete(90, 1, true);
        this.orderServicesAndFeaturesPage.btn_ok.scrollIntoView().click();
        System.out.print("okbutton1");
        this.common.waitForNavigationLoadingToComplete(90, 1, true);
        this.advanceToNextPage(orderServicesAndFeaturesPage);


    }

    @Then("^I select tablet android to check price type as (.*) and saletype as '(.*)'$")
    public void I_select_insurance_tablet_android(String tabletType, String sale) {
        this.common.waitForLoadingToComplete(2, 1);
        this.orderServicesAndFeaturesPage.tab_tablets.asList().get(0).click();
        this.advanceToNextPage(orderServicesAndFeaturesPage);
        this.common.wait(5);
        this.common.waitForLoadingToComplete(2, 1);
        this.orderServicesAndFeaturesPage.tab_tabletsAndroid.scrollIntoView().click();
        this.common.waitForNavigationLoadingToComplete(90, 1, true);
        this.orderServicesAndFeaturesPage.txt_phoneSearch.click();
        this.orderServicesAndFeaturesPage.txt_phoneSearch.setValue(tabletType);
        //adding tablet
        this.common.waitForNavigationLoadingToComplete(90, 1, true);
        // this.orderServicesAndFeaturesPage.addbutton.scrollIntoView().click();
        this.orderServicesAndFeaturesPage.txt_deviceSearch.click();
        //adding phone
        this.orderServicesAndFeaturesPage.btn_addWindowsTablet.click();
        this.browser.setImplicitWait(5);
        this.context.set("sale1", sale);
        this.orderServicesAndFeaturesPage.ddl_saleType.asList().get(0).click();
        this.browser.setImplicitWait(2);
        this.orderServicesAndFeaturesPage.ddl_saleType.asList().get(0).asSelect().selectByText((String) this.context.get("sale1"));
        this.common.waitForNavigationLoadingToComplete(90, 1, true);
        this.orderServicesAndFeaturesPage.btn_ok.scrollIntoView().click();
        System.out.print("okbutton1");
        this.common.waitForNavigationLoadingToComplete(90, 1, true);
        this.advanceToNextPage(orderServicesAndFeaturesPage);
    }

    @Then("^I select phone type as (.*) and saletype as '(.*)' and DevicePrice as'(.*)'$")
    public void I_select_iphone(String phoneType, String sale, String price) {
        this.orderServicesAndFeaturesPage.btn_phones.asList().get(2).click();
        this.advanceToNextPage(orderServicesAndFeaturesPage);
        this.common.waitForLoadingToComplete(2, 1);
        this.orderServicesAndFeaturesPage.txt_deviceSearch.click();
        this.orderServicesAndFeaturesPage.txt_deviceSearch.setValue(phoneType);

        this.common.waitForNavigationLoadingToComplete(90, 1, true);

        //phone price


        assertThat(this.orderServicesAndFeaturesPage.lbl_phonePrice.getText())
                .withFailMessage("phoneprice is not correct").contains(price);
        this.logger.info("phoneprice is correct");


        //adding phone

        this.orderServicesAndFeaturesPage.btn_add.click();

        this.browser.setImplicitWait(5);

        this.context.set("sale1", sale);

        this.orderServicesAndFeaturesPage.ddl_saleType.asList().get(0).click();
        this.browser.setImplicitWait(2);
        this.orderServicesAndFeaturesPage.ddl_saleType.asList().get(0).asSelect().selectByText((String) this.context.get("sale1"));

        this.common.waitForNavigationLoadingToComplete(90, 1, true);

        this.orderServicesAndFeaturesPage.btn_ok.scrollIntoView().click();
        System.out.print("okbuttonclicked");

        this.common.waitForNavigationLoadingToComplete(90, 1, true);
        this.advanceToNextPage(orderServicesAndFeaturesPage);


    }

    @Then("^I select accessories type as (.*) and saletype as '(.*)' and equipment section as '(.*)'$")
    public void I_select_accesories(String phoneType, String sale, String equipmentType) {
        this.common.waitForLoadingToComplete(2, 1);
        this.orderServicesAndFeaturesPage.Accessories.asList().get(0).click();
        this.advanceToNextPage(orderServicesAndFeaturesPage);
        this.common.waitForLoadingToComplete(3, 1);
        for (PageElement addEquipment : this.orderServicesAndFeaturesPage.equipmentList.asList()) {
            if (addEquipment.getText().contains(equipmentType)) {
                addEquipment.click();
                break;
            }
        }
        this.browser.setImplicitWait(2);
        this.orderServicesAndFeaturesPage.txt_phoneSearch.click();
        this.orderServicesAndFeaturesPage.txt_phoneSearch.setValue(phoneType);
        this.browser.restoreImplicitWait();
        this.common.waitForNavigationLoadingToComplete(90, 1, true);
        this.browser.waitUntil(readyState(ReadyState.COMPLETE));
        this.orderServicesAndFeaturesPage.btn_add.click();
        this.browser.setImplicitWait(5);
        this.context.set("sale1", sale);
        this.orderServicesAndFeaturesPage.saletype.asList().get(0).click();
        this.orderServicesAndFeaturesPage.saletype.asList().get(0).asSelect().selectByText((String) this.context.get("sale1"));
        this.common.waitForNavigationLoadingToComplete(90, 1, true);
        this.orderServicesAndFeaturesPage.btn_ok.scrollIntoView().click();
        this.common.waitForNavigationLoadingToComplete(90, 1, true);
        this.advanceToNextPage(orderServicesAndFeaturesPage);

    }


    @And("^I select next button for accessories$")
    public void select_next_btn_for_accessories() {
        this.common.waitForLoadingToComplete(90, 1);
        orderServicesAndFeaturesPage.nxtBtn.click();


    }

    @When("^I choose a phone number with '(.*)' spend cap$")
    public void choose_phone_number_with_spend_cap(String spendCap) {
        this.logger.info(MessageFormat.format(
                "*** Choose phone number with ''{0}'' spend cap ...", spendCap));

        UserDataModel userData = (UserDataModel) this.context.get("residentialUserAccountData");

        assertThat(this.orderPhoneAndSpendCapPage.isPageDisplayed())
                .withFailMessage("Phone No & Cap page not displayed!")
                .isTrue();

        this.orderPhoneAndSpendCapPage.getPhoneNumberPageElement().scrollIntoView().click();
        String env= (String) this.context.get("env");
        if(env.contains("paym4uat")||env.contains("paym4")) {
            this.orderPhoneAndSpendCapPage.getPhoneNumberonPaym4Uat().click();
        }
        else {
            this.orderPhoneAndSpendCapPage.getPhoneNumber().click();
        }
        userData.phoneNumber = this.orderPhoneAndSpendCapPage.getPhoneNumberPageElement().getValue();

        Supplier<PageElement> processIcon = () -> this.orderPhoneAndSpendCapPage.processIcon;
        Boolean result = this.retry.untilNotDisplayed(processIcon, 25, 1);
        assertThat(result)
                .withFailMessage("Process icon still displayed after selecting a phone number!")
                .isTrue();
        if(env.contains("paym4uat")||env.contains("paym4")) {
            assertThat(this.orderPhoneAndSpendCapPage.getPhoneNumberPageElementonpaym4uat().getValue())
                    .isNotEmpty();
        }
        else {
            assertThat(this.orderPhoneAndSpendCapPage.getPhoneNumberPageElement().getValue())
                    .isNotEmpty();
        }

//        this.orderPhoneAndSpendCapPage.sim.click();
//        this.orderPhoneAndSpendCapPage.spendCap.asSelect().selectByValue(
//                MessageFormat.format("{0}.00", spendCap.replace("£", "")));
        this.orderPhoneAndSpendCapPage.spendCap.asSelect().selectByText(spendCap);
        result = this.retry.untilNotDisplayed(processIcon, 12, 1);
        assertThat(result)
                .withFailMessage("Process icon still displayed after selecting a phone number!")
                .isTrue();
        assertThat(this.orderPhoneAndSpendCapPage.spendCap.asSelect().getSelectedValue())
                .isNotEmpty();

        this.advanceToNextPage(this.orderPhoneAndSpendCapPage);

        this.context.set("residentialUserAccountData", userData);
        this.logger.warn(userData.toString());
        this.logger.info("*** Phone number with and spend cap selected!\n");
    }


    @When("^I choose a phone number with '(.*)' spend cap for free perk$")
    public void choose_phone_number_with_spend_cap_for_free_perk(String spendCap) {
        this.logger.info(MessageFormat.format(
                "*** Choose phone number with ''{0}'' spend cap ...", spendCap));

        UserDataModel userData = (UserDataModel) this.context.get("residentialUserAccountData");

        assertThat(this.orderPhoneAndSpendCapPage.isPageDisplayed())
                .withFailMessage("Phone No & Cap page not displayed!")
                .isTrue();
        this.orderPhoneAndSpendCapPage.getPhoneNumber().click();
        userData.phoneNumber = this.orderPhoneAndSpendCapPage.getPhoneNumberPageElement().getValue();

        Supplier<PageElement> processIcon = () -> this.orderPhoneAndSpendCapPage.processIcon;
        Boolean result = this.retry.untilNotDisplayed(processIcon, 20, 1);
        assertThat(result)
                .withFailMessage("Process icon still displayed after selecting a phone number!")
                .isTrue();
        assertThat(this.orderPhoneAndSpendCapPage.getPhoneNumberPageElement().getValue())
                .isNotEmpty();

        this.orderPhoneAndSpendCapPage.spendCap.asSelect().selectByText(spendCap);
        result = this.retry.untilNotDisplayed(processIcon, 12, 1);
        assertThat(result)
                .withFailMessage("Process icon still displayed after selecting a phone number!")
                .isTrue();
        assertThat(this.orderPhoneAndSpendCapPage.spendCap.asSelect().getSelectedValue())
                .isNotEmpty();

        this.common.waitForLoadingToComplete(90, 1);

        assertThat(this.orderPhoneAndSpendCapPage.avilablePerksCount.asList().get(2).scrollIntoView().getText()).contains("");
        assertThat(this.orderPhoneAndSpendCapPage.avilablePerksCount.asList().get(2).scrollIntoView().isEnabled()).isTrue();
        this.orderPhoneAndSpendCapPage.allCheckBox.asList().get(7).scrollIntoView().click();
//        assertThat(this.orderPhoneAndSpendCapPage.dialogError.isDisplayed())
//                .withFailMessage("Dialog error is not displayed!")
//                .isTrue();
        this.common.waitForLoadingToComplete(90, 1);
        this.orderPhoneAndSpendCapPage.allCheckBox.asList().get(14).scrollIntoView().click();
        this.common.waitForLoadingToComplete(90, 1);
        this.advanceToNextPage(this.orderPhoneAndSpendCapPage);
        this.context.set("residentialUserAccountData", userData);
        this.logger.warn(userData.toString());
        this.logger.info("*** Phone number with and spend cap selected!\n");
    }

    @When("^user passes Eligibility Check$")
    public void user_passes_eligibility_check() {
        this.logger.info("*** Passing Eligibility Check ...");

        assertThat(this.orderEligibilityCheckPage.getEligibilityButton().isDisplayed())
                .withFailMessage("Eligibility Check page not displayed!")
                .isTrue();

        int cnt = 3;
        this.logger.info("Open Eligibility Check form ...");
        while (cnt > 0) {
            this.orderEligibilityCheckPage.getEligibilityButton().click();
            if (this.orderEligibilityCheckFormPage.preferredTitle.isDisplayed(4)) {
                this.logger.info("Eligibility Check form opened!");
                break;
            }
            this.logger.info(MessageFormat.format("Eligibility Check form not opened! Retry #{0} ...", cnt));
            // no need to wait as isDisplayed() waits for 4 seconds

            cnt--;
        }
        assertThat(this.orderEligibilityCheckFormPage.preferredTitle.waitUntil(displayed).isDisplayed())
                .withFailMessage("Eligibility Check Form page not displayed!")
                .isTrue();

        this.orderEligibilityCheckFormPage.employmentStatus.asSelect().selectByValue("Employed");
        this.orderEligibilityCheckFormPage.personalAnnualIncome.asSelect().selectByValue("More than £50,000");
        if (this.orderEligibilityCheckFormPage.liveAtAddressPeriod.isDisplayed()) {
            this.orderEligibilityCheckFormPage.liveAtAddressPeriod.asSelect().selectByValue("7 to 8 years");
        }
        this.common.wait(2);
        this.orderEligibilityCheckFormPage.confirmAndContinueButton.click();

        this.logger.info(">>> Check Eligibility Check popup has been closed ...");
        cnt = 180;
        while (cnt > 0) {
            cnt--;
            this.browser.setImplicitWait(1);
            if (this.orderEligibilityCheckFormPage.preferredTitle.isDisplayed()) {
                this.logger.info(
                        MessageFormat.format(
                                ">>> Check Eligibility Check popup still opened! Retry #{0} ...", cnt));
                this.common.wait(2);
                this.logger.info(">>> Check if there is a popup error ...");
//                <div id="ui-id-2" class="ui-dialog-content ui-widget-content" style="display: block; width: auto; min-height: 89px; max-height: none; height: auto;">Sorry. We could not process your request.</div>
                PageElement popupError = this.browser.findBy(By.XPath, "//div[@id='ui-id-2']");
                if (popupError != null && popupError.getText().contains("Sorry. We could not process your request.")) {
                    assertThat(true)
                            .withFailMessage("Error processing Eligibility!")
                            .isFalse();
                }
                this.logger.info(">>> No popup error message!");
                continue;// Still processing
            }
            this.logger.info(">>> Check Eligibility Check popup not found! Continue ...");
            break;
        }

        assertThat(this.orderEligibilityCheckFormPage.preferredTitle.isDisplayed())
                .withFailMessage("Eligibility Check Form page still displayed! Has the process hanged up?")
                .isFalse();

        this.browser.restoreImplicitWait();
//        this.orderServicesAndFeaturesPage.nextButton.waitUntil(displayed).click();
        this.advanceToNextPage(orderEligibilityCheckPage);

        this.logger.info("*** Eligibility Check passed!\n");
    }

    @And("I review for discount in review Section")
    public void i_Review_For_Discounts_In_Review_Section() {
        this.orderReviewPage.discountSection.isDisplayed();
        assertThat(this.orderReviewPage.discountRecurringCharge.getText().isEmpty()).withFailMessage("Discount-RecurringCharge is not applicable for this :- " + this.orderReviewPage.discountRecurringCharge.getText());
        assertThat(this.orderReviewPage.discountNonRecurringCharge.getText().isEmpty()).withFailMessage("Discount-NonRecurringCharge is not applicable for this :- " + this.orderReviewPage.discountNonRecurringCharge.getText());
    }


    @When("^all Payment Information is correct$")
    public void all_payment_information_is_correct() {
        this.logger.info("*** Payment  Information page to be displayed ...");

        assertThat(this.orderBillingAndPaymentPage.isPageDisplayed())
                .withFailMessage("Payment & Billing page not displayed!")
                .isTrue();

//        this.orderServicesAndFeaturesPage.nextButton.waitUntil(displayed).click();
        this.advanceToNextPage(orderBillingAndPaymentPage);
        this.logger.info("*** Payment  Information page displayed!\n");
    }

    @When("^I have entered Interaction description and read the script to user$")
    public void interaction_information_and_read_script() {
        this.logger.info("*** Enter Interaction description and read the script ...");

        assertThat(this.orderReviewPage.isPageDisplayed())
                .withFailMessage("Order Review page not displayed!")
                .isTrue();

        this.orderReviewPage.interactionDescription.setValue("Interaction description information!");
        Supplier<PageElement> processIcon = () -> this.orderPhoneAndSpendCapPage.processIcon;
        Boolean result = this.retry.untilNotDisplayed(processIcon, 12, 1);
        assertThat(result)
                .withFailMessage("Process icon still displayed after selecting a phone number!")
                .isTrue();


        this.logger.info("Reading the script action ...");


        this.browser.setImplicitWait(1);
        int cnt = 3;
        while (cnt > 0) {
            cnt--;
            this.orderReviewPage.orderParametersBlock.waitUntil(displayed).click();
            this.common.wait(5);
            if (!this.orderReviewPage.scriptLink.isDisplayed(3)) {
                this.logger.warn("Retry expanding Reading Script block ...");
                continue;
            }

            this.orderReviewPage.scriptLink.click();
            this.common.wait(2);
            this.orderReviewPage.readTheScriptConfirmation.asSelect().selectByValue("7777001");
            this.common.wait(2);
            this.orderReviewPage.selectJourneyType.asList().get(0).waitUntil(displayed).asSelect().selectByIndex(1);
            this.orderReviewPage.selectProductType.waitUntil(displayed).asSelect().selectByIndex(1);
            this.common.wait(2);
            this.orderReviewPage.selectJourneyType.asList().get(1).waitUntil(displayed).asSelect().selectByValue("7777001");

            result = this.retry.untilNotDisplayed(processIcon, 12, 1);
            assertThat(result)
                    .withFailMessage("Process icon still displayed after selecting a phone number!")
                    .isTrue();
            break;
        }
        this.browser.restoreImplicitWait();

        this.logger.info("*** Interaction description and script actions completed!\n");
    }

    @When("^user passes Credit Check$")
    public void user_passes_credit_check() {
        this.logger.info("*** Attempt to pass Credit Check ...");
        this.orderReviewPage.getButton("Send CI/CS Documents").click();
        this.common.wait(5);
        this.orderReviewPage.getButton("Credit Check").click();
        if (this.creditCheckPage.continueAnywaysBtn.isDisplayed()) {
            this.common.wait(2);
            this.creditCheckPage.continueAnywaysBtn.waitUntil(displayed).click();
        }

        UserDataModel userData = (UserDataModel) this.context.get("residentialUserAccountData");

        assertThat(this.creditCheckPage.isPageDisplayed())
                .withFailMessage("Credit Check page not displayed!")
                .isTrue();

        this.common.wait(2);
        this.creditCheckPage.paymentDetails.waitUntil(displayed).click();
        this.common.wait(2);
        this.creditCheckPage.paymentDetails.waitUntil(displayed).click();

        this.browser.displayIframesInfo();
        this.browser.switchTo("cardIFrame");
        this.creditCheckPage.cardName.waitUntil(displayed).setValue(
                MessageFormat.format("Auto {0} {1}", userData.firstName, userData.lastName));
        this.creditCheckPage.cardNumber.waitUntil(displayed).setValue(userData.userPaymentModel.cardPan);
        this.creditCheckPage.expiryDateMonth.asSelect().selectByValue(userData.userPaymentModel.cardExpiryMonth);
        // Select is done by last 2 digits of the year
        this.creditCheckPage.expiryDateYear.asSelect().selectByValue(
                userData.userPaymentModel.cardExpiryYear.substring(
                        userData.userPaymentModel.cardExpiryYear.length() - 2));
        this.creditCheckPage.cvv.setValue(userData.userPaymentModel.cardCvv);
        this.common.wait(5);
        this.creditCheckPage.paymentConfirmButton.click();
        //  this.creditCheckPage.onlineValidationButton.click();
        this.common.wait(10);

        this.browser.switchToDefault();
        this.browser.switchTo("iframe_roe");

        int cnt = 20;
        boolean isValidationSuccessful = false;

        while (cnt > 0) {
            this.browser.setImplicitWait(1);
            if (this.creditCheckPage.validationMessageErrors.isDisplayed()) {
                this.logger.error(MessageFormat.format(
                        "Online Validation FAILED! Message: {0}",
                        this.creditCheckPage.validationMessageErrors.getText()));
                break;
            }

            this.browser.setImplicitWait(1);
            if (this.creditCheckPage.validationMessageSuccess.isDisplayed() &&
                    this.creditCheckPage.validationMessageSuccess.getText().
                            contains("That card has been successful! You can now continue with your order.")) {
                this.logger.info(MessageFormat.format(
                        "Online Validation passed! Message: {0}",
                        this.creditCheckPage.validationMessageSuccess.getText()));
                isValidationSuccessful = true;
                break;
            }

            cnt--;
            this.logger.info(
                    MessageFormat.format("Online Validation processing! Waiting #{0}...", cnt));
            this.common.wait(3);
        }

        assertThat(isValidationSuccessful)
                .withFailMessage(MessageFormat.format(
                        "Online Validation FAILED! Message: {0}",
                        this.creditCheckPage.validationMessageErrors.isDisplayed(1)
                                ? this.creditCheckPage.validationMessageErrors.getText()
                                : "N/A"))
                .isTrue();
        this.browser.restoreImplicitWait();

        // TODO: refactor this
        try {
            this.common.wait(1);
//            ((WebDriver) this.browser.instance()).findElement(By.linkText("APPLICATION")).sendKeys(Keys.PAGE_UP);
            this.browser.findBy(com.nttdata.cinnamon.driver.By.LinkName, "APPLICATION").setValue(Keys.PAGE_UP);
            this.common.wait(2);
            this.creditCheckPage.application.click();
        } catch (Exception e) {
            this.logger.warn("Could not click on APPLICATION link! Retry ...");
            this.common.wait(1);
            this.browser.findBy(com.nttdata.cinnamon.driver.By.LinkName, "APPLICATION").setValue(Keys.PAGE_UP);
//            ((WebDriver) this.browser.instance()).findElement(By.linkText("APPLICATION")).sendKeys(Keys.PAGE_UP);
            this.common.wait(2);
            this.creditCheckPage.application.click();
        }
        this.common.wait(2);

        this.creditCheckPage.getConfirmMonthlyCostCheckbox().click();
        this.creditCheckPage.getConfirmNoChangesInCircumstancesCheckbox().click();
        this.common.wait(2);
        this.creditCheckPage.confirmAndContinueButton.click();

        this.logger.info("Saving Credit Checks data ...");
        cnt = 120;
        while (cnt > 0) {
            cnt--;
            this.browser.setImplicitWait(1);
            if (this.creditCheckPage.isPageDisplayed()) {
                this.logger.info(MessageFormat.format(
                        "Credit Check popup still displayed! Saving in progress! Retry #{0}", cnt));
                this.common.wait(2); // Still processing
                continue;
            }

            this.logger.info("Credit Checks saving complete! Continue ...");
            break;
        }

        assertThat(this.creditCheckPage.isPageDisplayed())
                .withFailMessage("Credit Check Form popup still displayed! Has the process hanged up?")
                .isFalse();

        Supplier<PageElement> processIcon = () -> this.orderPhoneAndSpendCapPage.processIcon;
        Boolean result = this.retry.untilNotDisplayed(processIcon, 12, 1);
        assertThat(result)
                .withFailMessage("Process icon still displayed after selecting a phone number!")
                .isTrue();

        this.logger.info("*** Credit Check passed!\n");
    }

    @When("^contract is Signed$")
    public void sign_order_contract() {
        this.logger.info("*** Attempt to Sign contract ...\n");

        UserDataModel userData = (UserDataModel) this.context.get("residentialUserAccountData");


        this.orderReviewPage.getButton("Configure Contract").click();

        Supplier<PageElement> processIcon = () -> this.orderPhoneAndSpendCapPage.processIcon;
        Boolean result = this.retry.untilNotDisplayed(processIcon, 30, 1);
        assertThat(result)
                .withFailMessage("Process icon still displayed after clicking 'Configure Contract'!")
                .isTrue();

        assertThat(this.orderReviewPage.contractName.isDisplayed(4))
                .withFailMessage("Contract name/number not displayed after clicking on 'Configure Contract'!")
                .isTrue();
        userData.contractNo = this.orderReviewPage.contractName.getText();
        this.logger.info(userData.toString());

        this.common.wait(3);
        //this.browser.switchToDefault();
        this.orderReviewPage.getSignInContract().scrollIntoView();
        this.orderReviewPage.getSignInContract().click();
        result = this.retry.untilNotDisplayed(processIcon, 30, 1);
        assertThat(result)
                .withFailMessage("Process icon still displayed after clicking 'Sign' contract!")
                .isTrue();
        assertThat(this.signInContractPage.isPageDisplayed())
                .withFailMessage("Sign popup page not displayed!")
                .isTrue();

        this.signInContractPage.acceptTheSimo.click();
        this.signInContractPage.saveButton.click();
        result = this.retry.untilNotDisplayed(processIcon, 30, 1);
        assertThat(result)
                .withFailMessage("Process icon still displayed after saving the Sign in popup form!")
                .isTrue();

        this.context.set("residentialUserAccountData", userData);

        this.logger.info("*** Contract signed!\n");
    }

    @When("^I checkout the order$")
    public void i_checkout_the_order() {
        this.logger.info("*** Checking out order ...");

        this.orderReviewPage.getButton("Check Out").click();
        Supplier<PageElement> processIcon = () -> this.orderPhoneAndSpendCapPage.processIcon;
        boolean result = this.retry.untilNotDisplayed(processIcon, 120, 1);
        assertThat(result)
                .withFailMessage("Process icon still displayed after clicking 'Check Out'!")
                .isTrue();

        this.logger.info("*** Order checked out!\n");
    }

    @Then("^order is placed successfully$")
    public void order_is_processed_successfully() {
        this.logger.info("*** Validating order has been processed ...");

        UserDataModel userData = (UserDataModel) this.context.get("residentialUserAccountData");

        assertThat(this.orderConfirmationPage.isPageDisplayed())
                .withFailMessage("Order Confirmation page not displayed!")
                .isTrue();
        userData.orderNo = this.orderConfirmationPage.orderNumber.getText();
        this.logger.info(userData.toString());

        this.context.set("residentialUserAccountData", userData);
        String env = (String) this.context.get("env");
        this.db.connect(Env.get().settingsProperty("db_connection"));
        this.db.insert("ResidentialAccount", true,
                userData.firstName.replace("'", "''"),
                userData.lastName.replace("'", "''"),
                userData.userEmail,
                userData.contactMobile,
                userData.password.replace("'", "''"),
                userData.userPaymentModel.bankAccount,
                userData.userPaymentModel.bankSortCode,
                userData.userPaymentModel.cardPan,
                userData.userPaymentModel.cardExpiryMonth,
                userData.userPaymentModel.cardExpiryYear,
                userData.userPaymentModel.cardCvv,
                userData.postcode,
                userData.address,
                userData.phoneNumber,
                userData.contractNo,
                userData.orderNo,
                env, // TODO: get this from env config
                "0",
                "0",
                "0",
                new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(new Date()));

        this.logger.info("*** Order processed successfully!\n");
    }

    private void advanceToNextPage(BasePage currentPage) {
        int retries = 4;
        boolean result = false;

        this.logger.info(MessageFormat.format(">>> Navigating from {0} page ...", currentPage.getClass().getName()));

        while (--retries > 0) {
            this.browser.setImplicitWait(1);
            if (currentPage.isPageDisplayed()) {

                this.orderNavigationPage.getNextButton().click();
                this.common.waitForNavigationLoadingToComplete(60, 1, false);

                if (retries == 3) continue; // First loop when I press Next - no need to wait for anything
                // Next button hasn't been pressed or next page is loading
                this.logger.info(
                        MessageFormat.format(
                                ">>> Navigation failed. Has Next button been pressed? Retrying #{0}...", retries));
                this.common.wait(2);
                continue;
            }

            result = true;
            this.logger.info(">>> Navigation to next page successful ...");
            break;
        }

        assertThat(result)
                .withFailMessage(
                        MessageFormat.format("Could not navigate to next page after {0} retries!", retries))
                .isTrue();
    }

    private void advanceToNextPage() {
        int retries = 3;
        boolean result = false;

        assertThat(this.orderNavigationPage.isPageDisplayed())
                .withFailMessage("Could not find Order Navigation elements!")
                .isTrue();
        this.logger.info("Navigating to next page ...");

        while (retries-- > 0) {
            this.browser.setImplicitWait(1);
            this.orderNavigationPage.getNextButton().click();
            if (this.processElements.loadingProgressControl.isDisplayed()) {
                this.logger.info("Next page is loading ...");
                this.common.waitForLoadingToComplete(60, 1);
                this.browser.restoreImplicitWait();
                result = true;

                break;
            }

            this.logger.info(
                    MessageFormat.format(
                            "Navigation failed. Has Next button been pressed? Retrying #{0}...", retries));
            this.common.wait(2);
        }

        assertThat(result)
                .withFailMessage(
                        MessageFormat.format("Could not navigate to next page after {0} retries!", retries))
                .isTrue();
    }

    @When("^I select Existing Mobile order$")
    public void select_Existing_Mobile_order() {
        this.logger.info("*** Select existing mobile order ...");
        orderOverviewPage.getFirstExistingOrder().click();

    }

    @When("I select regular phone number")
    public void select_regular_phone_number() {
        this.logger.info("**Radio button select" + this.orderServicesAndFeaturesPage.btn_regularPhoneNoRadioOpt.isSelected());
        this.orderServicesAndFeaturesPage.btn_regularPhoneNoRadioOpt.waitUntil(displayed).click();
        Supplier<PageElement> processIcon = () -> this.orderPhoneAndSpendCapPage.processIcon;
        Boolean result = this.retry.untilNotDisplayed(processIcon, 20, 1);
        assertThat(result)
                .withFailMessage("Process icon still displayed after selecting a regular phone number radio button!")
                .isTrue();
        assertThat(this.orderServicesAndFeaturesPage.btn_regularPhoneNoRadioOpt.getValue())
                .withFailMessage("Regular phone number is not present!")
                .isNotEmpty();
        this.advanceToNextPage();
    }
}


