package com.o2.pages.csrd;

import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.o2.pages.BasePage;

public class OrderEligibilityCheckPage extends BasePage {
    @Find(by = By.CssSelector, locator = ".nc-composite-layout-item-horizontal.acc-container")
    public PageElement accountInformationBlock;

    @Override
    public PageElement getPageCheckElement() {
        return this.accountInformationBlock;
    }

    public PageElement getEligibilityButton() {
        return this.accountInformationBlock.findChild(By.CssSelector, ".contracts__button");
    }
}
