package com.o2.pages.csrd;

import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.nttdata.cinnamon.driver.controls.PageElementCollection;
import com.o2.pages.BasePage;

import static org.assertj.core.api.Assertions.assertThat;

public class OrderOverviewPage extends BasePage {
	
	@Find(by = By.XPath, locator = "//*[text()='Existing:']")
    public PageElement existingText;
	
	public PageElement getFirstExistingOrder() {
		PageElementCollection existingList = this.browser.findAllBy(By.XPath, "//*[text()='Existing:']//following::span[@class='bulkTreeItem bulkTreeItemRoeTreeItem']");
        
        
        assertThat(existingList.size())
        .withFailMessage("Could not find any existing order!")
        .isGreaterThanOrEqualTo(1);
        
        PageElement firstExistingOrder = existingList.asList().get(0);
        
        return firstExistingOrder;
        
    }

}
