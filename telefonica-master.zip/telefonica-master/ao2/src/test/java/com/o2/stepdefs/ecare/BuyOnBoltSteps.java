package com.o2.stepdefs.ecare;

import com.google.inject.Inject;
import com.nttdata.cinnamon.cache.Context;
import com.nttdata.cinnamon.driver.Browser;
import com.o2.models.ecare.BoltOn;
import com.o2.pages.ecare.BuyBoltOnPage;
import com.o2.stepdefs.BaseStep;
import com.o2.util.Common;
import io.cucumber.java.en.And;
import io.cucumber.java.en.When;

import java.text.MessageFormat;

import static com.nttdata.cinnamon.wait.ElementConditions.displayed;
import static org.assertj.core.api.Assertions.assertThat;

public class BuyOnBoltSteps extends BaseStep {
    private final BuyBoltOnPage buyBoltOnPage;
    private final Common common;
    private final Context context;
    private final Browser browser;

    @Inject
    public BuyOnBoltSteps(final BuyBoltOnPage buyBoltOnPage, final Common common, Context context, final Browser browser) {
        this.buyBoltOnPage = buyBoltOnPage;
        this.common = common;
        this.context = context;
        this.browser = browser;
    }

    @And("^I check bolt on Type options$")
    public void i_checked_bolt_on_type_options() {
        this.logger.info("** Buy a bolt on page is displayed ...");
        this.common.waitForLoadingToComplete(2, 1);
        assertThat(this.buyBoltOnPage.isPageDisplayed(90)).withFailMessage("Buy a bolt on  page has not opened!")
                .isTrue();
        this.buyBoltOnPage.boltOnTypeOption.waitUntil(displayed).click();
        this.common.wait(5);
        this.buyBoltOnPage.boltOnTypeOptions1.asList().get(0).click();
        assertThat(this.buyBoltOnPage.boltOnTypeOptions1.asList().get(0).isDisplayed()).isTrue();
        this.buyBoltOnPage.boltOnTypeOption.waitUntil(displayed).click();
        this.common.wait(5);
        this.buyBoltOnPage.boltOnTypeOptions1.asList().get(1).click();
        assertThat(this.buyBoltOnPage.boltOnTypeOptions1.asList().get(1).isDisplayed()).isTrue();
        this.buyBoltOnPage.boltOnTypeOption.waitUntil(displayed).click();
        this.common.wait(5);
        this.buyBoltOnPage.boltOnTypeOptions1.asList().get(2).click();
        assertThat(this.buyBoltOnPage.boltOnTypeOptions1.asList().get(2).isDisplayed()).isTrue();
        this.buyBoltOnPage.boltOnTypeOption.waitUntil(displayed).click();
        this.common.wait(5);
        this.buyBoltOnPage.boltOnTypeOptions1.asList().get(3).click();
        assertThat(this.buyBoltOnPage.boltOnTypeOptions1.asList().get(3).isDisplayed()).isTrue();
        this.buyBoltOnPage.boltOnTypeOption.waitUntil(displayed).click();
        this.common.wait(5);
        this.buyBoltOnPage.boltOnTypeOptions1.asList().get(3).click();

    }

    @And("^I select o2 travel option as '(.*)'$")
    public void i_select_o2_travel_option(String addOnTitle) {
        boolean found = false;

        for (BoltOn boltOn : this.buyBoltOnPage.getAllBoltOn()) {
            if (boltOn.title.getText().equalsIgnoreCase(addOnTitle)) {
                boltOn.addToPlanButton.click();
                found = true;
                break;
            }
        }

        assertThat(found)
                .withFailMessage(
                        MessageFormat.format("Could not find a Bolt On whose name is: ''{0}''!",
                                addOnTitle))
                .isTrue();

    }

    @When("^I click on add bolt on button$")
    public void i_click_on_add_bolt_on_button() {
        this.buyBoltOnPage.termConditionCheckBox.click();
        this.buyBoltOnPage.addBoltOnBtn.click();
        assertThat(this.buyBoltOnPage.isPageDisplayed(90)).withFailMessage("Bolt On added Title is not displayed!")
                .isTrue();
    }

    @And("^I select bolt on type as as '(.*)'$")
    public void i_checked_bolt_on_type_options(String boltOnType) {
        this.logger.info("**Try to select Bolt On Type...");
        if(this.buyBoltOnPage.boltOnTypeDropdown.isDisplayed(5)) {
            this.buyBoltOnPage.boltOnTypeDropdown.clickJs();
            browser.setImplicitWait(5);
            int options = this.buyBoltOnPage.boltOnTypeDropdownOptions.asList().size();//.asSelect().selectByValue(boltOnType);
            this.logger.info("options size:" + options);
            assertThat(options).withFailMessage("Bolt on Type option drop down options are not displayed!")
                    .isPositive();
            for (int i = 0; i < options; i++) {
                this.logger.info("options :" + this.buyBoltOnPage.boltOnTypeDropdownOptions.asList().get(i).getText().trim());
                if (this.buyBoltOnPage.boltOnTypeDropdownOptions.asList().get(i).getText().trim().equals(boltOnType)) {
                    this.buyBoltOnPage.boltOnTypeDropdownOptions.asList().get(i).clickJs();
                    this.logger.info("Select bolt on:" + boltOnType);
                    break;
                }
            }

            browser.setImplicitWait(2);
            assertThat(this.buyBoltOnPage.boltOnTypeDropdown.getText().trim().equals(boltOnType)).withFailMessage("Bolt On Option is not selected ").isTrue();
        }else{
            this.buyBoltOnPage.boltOnOptions.asSelect().selectByValue(boltOnType);
            browser.setImplicitWait(2);
            assertThat( this.buyBoltOnPage.boltOnOptions.asSelect().getSelectedValue().trim().equals(boltOnType)).withFailMessage("Bolt On Option is not selected ").isTrue();
        }


        this.context.set("BoltOnType", boltOnType);
        this.logger.info(boltOnType + "** is selected as Bolt On Type...");
    }

    @When("^I add bolt on$")
    public void i_add_bolt_on() {
        logger.info("Attempt to select Bolt On ...");
        String boltType = (String) this.context.get("BoltOnType");
        if (boltType.equals("Data") || boltType.equals("Messaging")) {
            this.buyBoltOnPage.termConditionCheckBox.click();
            this.buyBoltOnPage.addBoltOnBtn.click();
        } else {
            for (BoltOn boltOn : this.buyBoltOnPage.getAllBoltOn()) {
                if (boltOn.addToPlanButton.getText().trim().contains("Add to plan")) {
                    boltOn.addToPlanButton.click();
                    browser.setImplicitWait(5);
                    if (!(buyBoltOnPage.alreadyCovered.isDisplayed())) {
                        this.logger.info("Bolt on ''" + boltOn.title + "''selected!");
                        break;
                    }
                    browser.restoreImplicitWait();
                }
            }
            browser.restoreImplicitWait();
            this.buyBoltOnPage.termConditionCheckBox.click();
            this.buyBoltOnPage.addBoltOnBtn.waitUntil(displayed).clickJs();
        }

        buyBoltOnPage.waitForProcessLoadingToComplete(20, 2, 2);
        browser.setImplicitWait(5);
        assertThat(this.buyBoltOnPage.serverErrorPopup.isDisplayed())
                .withFailMessage("Could not add Bolt On because of Backend Error!")
                .isFalse();
        boolean isErrorDisplayed = buyBoltOnPage.orderErrorPopUp.isDisplayed();
        assertThat(isErrorDisplayed)
                .withFailMessage(
                        "Could not add Bolt On!" + (isErrorDisplayed ? ("Error: " + buyBoltOnPage.orderErrorPopUpText.getText()) : ""))
                .isFalse();
        browser.restoreImplicitWait();
    }

}
