package com.o2.pages.ecomm;

import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;

public class ReviewPage extends BasePage {


    @Find(by = By.XPath, locator = "//span[@id='terms-custom']")
    public PageElement termsCheckBox;

    @Find(by = By.XPath, locator = "//input[@id='insurance-terms']")
    public PageElement termsInsurance;

    @Find(by = By.XPath, locator = "//label[@id='insurance-terms-label']/span")
    public PageElement termsInsuranceTxt;

    @Find(by = By.XPath, locator = "//button[@id='order-review-continue']")
    public PageElement payNow;

    @Find(by = By.XPath, locator = "//*[@id='contract-message']")
    public PageElement OrderContractMessageRP;

    @Find(by = By.XPath, locator = "//*[@id='stock-extended-message-single']")
    public PageElement stockExtMessageDDPORP;

    @Find(by = By.XPath, locator = "//div[@id='delivery-details-section']//p[@id='review-generic-delivery-message']")
    public PageElement deliveryTextRP;

    @Find(by = By.XPath, locator = "//tr[@id='basket-delivery']/td/div/p[@id='contract-message']")
    public PageElement orderContractMessageRPOrderSummary;
}
