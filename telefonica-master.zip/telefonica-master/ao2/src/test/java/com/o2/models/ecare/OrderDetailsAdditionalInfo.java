package com.o2.models.ecare;

import com.nttdata.cinnamon.driver.controls.PageElement;

public class OrderDetailsAdditionalInfo {
   public PageElement orderNumberMain;
    public PageElement orderType;
    public PageElement orderNumber;
    public PageElement orderDate;
    public PageElement status;
    public PageElement orderPlaced;
    public PageElement items;
    public PageElement totalUpFrontCost;
    public PageElement totalMonthlyCost;
    public PageElement TotalCost;

    public OrderDetailsAdditionalInfo(PageElement orderNumberMain, PageElement orderType, PageElement orderNumber, PageElement orderDate, PageElement status, PageElement orderPlaced, PageElement items, PageElement totalUpFrontCost, PageElement totalMonthlyCost, PageElement TotalCost){
        this.orderNumberMain=orderNumberMain;
        this.orderNumber=orderNumber;
        this.orderType=orderType;
        this.orderDate=orderDate;
        this.status=status;
        this.orderPlaced=orderPlaced;
        this.items=items;
        this.totalUpFrontCost=totalUpFrontCost;
        this.totalMonthlyCost=totalMonthlyCost;
        this.TotalCost=TotalCost;
    }
}

