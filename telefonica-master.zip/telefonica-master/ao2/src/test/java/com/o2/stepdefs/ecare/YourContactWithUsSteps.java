package com.o2.stepdefs.ecare;

import static org.assertj.core.api.Assertions.assertThat;

import com.google.inject.Inject;
import com.nttdata.cinnamon.cache.Context;
import com.o2.models.ecare.EcareUser;
import com.o2.pages.ecare.YourContactWithUsPage;
import com.o2.stepdefs.BaseStep;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class YourContactWithUsSteps extends BaseStep {
    private final YourContactWithUsPage yourContactWithUsPage;
    private final Context context;

    @Inject
    public YourContactWithUsSteps(final YourContactWithUsPage yourContactWithUsPage, final Context context) {
        this.yourContactWithUsPage = yourContactWithUsPage;
        this.context = context;
    }

    @Then("^I can see all my contact details$")
    public void i_can_see_all_my_contact_details() {
        this.logger.info("*** Check if Your Contact With Us page has been loaded ...");

        this.logger.info("** Attempt to check Your Contact With Us page has been reached ...");

        assertThat(this.yourContactWithUsPage.isPageDisplayed())
                .withFailMessage("Your Contact With Us page has not opened!").isTrue();

        this.logger.info("** Your Contact With Us page displayed!\n");
    }

    @When("^I want to update my marketing preferences$")
    public void i_want_to_update_my_marketing_preferences() {
        this.logger.info("*** Attempt to click on Change Details to update marketing preferences ...");

        this.yourContactWithUsPage.changeDetails.first().click();

        this.logger.info("*** Actioning on Change Details complete!\n");
    }

    @Then("Email address is displayed under Notifications tab")
    public void email_address_is_displayed_under_notifications_tab() {
        this.logger.info("*** Check if Notification section has been loaded ...");

        assertThat(this.yourContactWithUsPage.notificationsTabTitle.isDisplayed())
                .withFailMessage("Notification section has not opened!").isTrue();

        this.logger.info("** Attempt to check Email address under Notification tab ...");
        EcareUser ecareUser = (EcareUser) this.context.get("ecareLoginData");

        //assertThat(this.yourContactWithUsPage.isEmailNotificationDisplayed(ecareUser.username.toString()))
          //      .withFailMessage("Email address is not present under Notification tab!").isTrue();

        assertThat(this.yourContactWithUsPage.emailNotification.isDisplayed(5))
                .withFailMessage("Email address is not present under Notification tab!").isTrue();

        this.logger.info("** Email address displayed under Notification tab!\n");
    }

    @Then("^I Verify the '(.*)' under contact details$")
    public void i_verify_the_under_contact_details(String contactDetailsfieldName) {
        this.logger.info("*** Check if Contact Details  section has been loaded ...");

       // assertThat(this.yourContactWithUsPage.contactDetails.isDisplayed())
         //       .withFailMessage("Contact Details section has not loaded!").isTrue();

        this.logger.info("** Attempt to check Email address under Contact Details section ...");
        EcareUser ecareUser = (EcareUser) this.context.get("ecareLoginData");

        assertThat(this.yourContactWithUsPage.contactDetailsEmail(ecareUser.username).isDisplayed(5))
                .withFailMessage("Email address is not present under Contact Details section!").isTrue();

        this.logger.info("** Email address displayed under Contact Details section!\n");
    }

    @Then("Contact email is displayed under your details section")
    public void Contact_email_is_displayed_under_your_details_section() {

        this.logger.info("*** Check email address under your details section ...");
        EcareUser ecareUser = (EcareUser) this.context.get("ecareLoginData");
        assertThat(this.yourContactWithUsPage.yourSimcontactDetailsEmail(ecareUser.username.toLowerCase()).isDisplayed(5))
                .withFailMessage("Email address is not present under your Details section!").isTrue();

        this.logger.info("** Email address displayed under your Details section!\n");

    }

}
