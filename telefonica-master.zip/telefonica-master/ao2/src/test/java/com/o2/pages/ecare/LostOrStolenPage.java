package com.o2.pages.ecare;

import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;

public class LostOrStolenPage extends EcareBasePage {
    @Find(by = By.Id, locator = "mat-radio-2")
    public PageElement deliverToMeRadioBtn;
    @Find(by = By.Id, locator = "mat-radio-3")
    public PageElement visitMyLocalO2Sotre;

    @Find(by = By.XPath, locator = "//div[@class='o2uk-checkbox-inner-container']")
    public PageElement checkBoxForBlockMylostStoleSim;

    @Find(by = By.XPath, locator = "//button[@class='mat-focus-indicator mat-button-base o2uk-primary-button']")
    public PageElement continueBtn;


    @Find(by = By.XPath, locator = "//input[@formcontrolname='_phoneNumberField']")
    public PageElement contactNbr;

    @Find(by = By.XPath, locator = "//div[@class='o2uk-billing-history-card__button-text']")
    public PageElement updateAddressLink;

    @Find(by = By.XPath, locator = "//input[@formcontrolname='houseNumber']")
    public PageElement houseNumber;

    @Find(by = By.XPath, locator = "//input[@formcontrolname='postcode']")
    public PageElement postCode;
    @Find(by = By.XPath, locator = "//span[contains(text(),'Find')]")
    public PageElement findBtn;

    @Find(by = By.XPath, locator = "//a[@class='text-link text-link_size_bold']//div[@class='edit-address-dialog__link-text']")
    public PageElement saveCloseBtn;

    @Find(by = By.CssSelector, locator = ".o2uk-notification-message")
    public PageElement simDisconnectionNotification;

    @Find(by = By.XPath, locator = "//button[@class='mat-focus-indicator mat-button-base o2uk-primary-button']")
    public PageElement orderNewSimBtn;

    @Find(by = By.XPath, locator = "//div[@class='new-sim-card__description']")
    public PageElement replacementSimDesciptionPanel;

    @Find(by = By.XPath, locator = "//h2[@class='review-order-delivery__title']")
    public PageElement deliveryPanel;

    @Find(by = By.XPath, locator = "//span[contains(text(),' Confirm order ')]")
    public PageElement confirmOrderBtn;

    @Find(by = By.XPath, locator = "//div[@class='order-confirmation__new-sim']")
    public PageElement orderConfimrationNewSim;


    @Find(by = By.ClassName, locator = "o2uk-card card-order-details o2uk-card_white o2uk-card_with-title")
    public PageElement detailPanelOfNewSimOnConfirmationPage;

    @Find(by = By.XPath, locator = "//div[@class='order-confirmation__button']")
    public PageElement orderConfirmationNewSimHisotry;

    @Find(by = By.CssSelector, locator = ".o2uk-notification-message__body-template>div")
    public PageElement barringNewSimMessage;


}
