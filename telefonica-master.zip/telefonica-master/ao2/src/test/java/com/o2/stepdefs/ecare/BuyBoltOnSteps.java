package com.o2.stepdefs.ecare;

import static org.assertj.core.api.Assertions.assertThat;

import com.google.inject.Inject;
import com.nttdata.cinnamon.driver.Browser;
import com.o2.pages.ecare.BuyBoltOnPage;
import com.o2.stepdefs.BaseStep;
import com.o2.core.util.Common;

import io.cucumber.java.en.Then;

public class BuyBoltOnSteps extends BaseStep {
	private final BuyBoltOnPage buyBoltOnPage;
	private final Browser browser;
	private final Common common;

	@Inject
	public BuyBoltOnSteps(final BuyBoltOnPage buyBoltOnPage, final Browser browser, final Common common) {
		this.buyBoltOnPage = buyBoltOnPage;
		this.browser = browser;
		this.common = common;
	}

	@Then("Buy Bolt Ons  page opens successfully")
	public void buy_bolt_ons_page_opens_successfully() {
		this.logger.info("** Waiting for Buy Bolt Ons  page to open ...");
        this.common.wait(15);
		assertThat(this.buyBoltOnPage.isPageDisplayed(90)).withFailMessage("Buy Bolt Ons  page not displayed!")
				.isTrue();

		this.logger.info("** Buy Bolt Ons page opens!");
	}
}
