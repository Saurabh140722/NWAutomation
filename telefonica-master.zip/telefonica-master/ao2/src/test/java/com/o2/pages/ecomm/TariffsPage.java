package com.o2.pages.ecomm;

import com.google.inject.Inject;
import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.FindByKey;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.nttdata.cinnamon.driver.controls.PageElementCollection;
import com.o2.core.util.Retry;
import com.o2.models.ecomm.Tariffs;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

public class TariffsPage extends BasePage {

    @Inject
    public TariffsPage(final Retry retry) {
        this.retry = retry;
    }

    @FindByKey(key ="sortByLink")
    public PageElement sortByLink1;

    @Find(by = By.XPath, locator = "//h1[contains(@class,'o2uk-header-curve__text-title')]")
    public PageElement pageTitle;

    @Find(by = By.XPath, locator = " //span[contains(text(),' View all results ')]")
    public PageElement viewAllResultsBtn;

    @Find(by = By.XPath, locator = "//*[@class='tariff-card ng-star-inserted']")
    public PageElementCollection trafficPlanElements;


    @Find(by = By.XPath, locator = "//div[@class='o2uk-container']//div[@class='tariff-card__wrapper']")
    public PageElementCollection traffiCards;

    @Find(by = By.XPath, locator = "//o2uk-radio-group")
    public PageElement sortByRadioBtnGroup;

    @Find(by = By.XPath, locator = "//div[@class='o2uk-sort-and-filter__container']/div/div/button[@class='o2uk-sort-and-filter__sorting']/span[text()=' SORT BY ']")
    public PageElement sortByLink;

    @Find(by = By.XPath, locator = "//o2uk-sort//button[@aria-label='Sort by']")
    public PageElement sortByLinkUAT2;

    @Find(by = By.XPath, locator = "//risk-assessment-dialog//div[@id='o2uk-dialog-title-0']/div/h3")
    public PageElement haveOrderInProgress;

    @Find(by = By.XPath, locator = "//risk-assessment-dialog//div[@id='o2uk-dialog-title-0']//button")
    public PageElement haveOrderInProgressCloseButton;

    @Find(by = By.XPath, locator = "//o2uk-dialog-actions/button[2]")
    public PageElement finishCheckingout;

    public PageElement getSimPlan(String simPlan) {
        return this.browser.findBy(By.XPath, "//h3[contains(text(),'" + simPlan + "')]//following-sibling::p[@class='product-cta']");
    }


    public List<Tariffs> getAllTariffs() {
        if (trafficPlanElements == null) {
            this.logger.warn("No Traffic  plans found on the page! Is this a negative scenario?");
            return null;
        }

        List<Tariffs> alltrafficPlans = new ArrayList<>();
        this.logger.info(MessageFormat.format("Found {0} Traffic plans on the page. Continue ...",
                (long) trafficPlanElements.asList().size()));

        this.browser.setImplicitWait(3);

        for (PageElement plan : trafficPlanElements.asList()) {
           // this.logger.info("plan**** button" + plan.findChild(By.XPath, "//*[@role='button']//*[text()=' Add to basket ']").getText());
            Tariffs traffic = new Tariffs(plan.findChild(By.CssSelector, ".o2uk-data>p"),
                    plan.findChildren(By.CssSelector, "div[class*='tariff-card__info']>p"),
                    plan.findChild(By.CssSelector, ".o2uk-price"),
                    plan.findChild(By.CssSelector, ".o2uk-primary-button"));

            alltrafficPlans.add(traffic);
        }
        this.browser.restoreImplicitWait();
        this.logger.info("****Total traffic count***:" + alltrafficPlans.size());
        return alltrafficPlans;
    }

    public List<Tariffs> getAll5GTariffs() {
        if (trafficPlanElements == null) {
            this.logger.warn("No Traffic  plans found on the page! Is this a negative scenario?");
            return null;
        }

        List<Tariffs> alltrafficPlans = new ArrayList<>();
        this.logger.info(MessageFormat.format("Found {0} Traffic plans on the page. Continue ...",
                (long) trafficPlanElements.asList().size()));

        this.browser.setImplicitWait(3);

        for (PageElement plan : trafficPlanElements.asList()) {
            // this.logger.info("plan**** button" + plan.findChild(By.XPath, "//*[@role='button']//*[text()=' Add to basket ']").getText());
            Tariffs traffic = new Tariffs(plan.findChild(By.CssSelector, ".o2uk-data>p"),
                    plan.findChildren(By.CssSelector, "div[class*='tariff-card__info margin']>p"),

                    plan.findChild(By.CssSelector, ".o2uk-price"),
                    plan.findChild(By.CssSelector, ".o2uk-primary-button"));

            alltrafficPlans.add(traffic);
        }
        this.browser.restoreImplicitWait();
        this.logger.info("****Total traffic count***:" + alltrafficPlans.size());
        return alltrafficPlans;
    }
}
