package com.o2.pages.ecare;

import com.google.inject.Inject;
import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.FindByKey;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.nttdata.cinnamon.driver.controls.PageElementCollection;
import com.o2.core.util.Common;
import com.o2.core.util.Retry;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

import static com.nttdata.cinnamon.wait.ElementConditions.displayed;
import static com.nttdata.cinnamon.wait.ElementConditions.enabled;

public class AccountLandingPage extends EcareBasePage {
    private final Retry retry;
    private final Common common;
    @Find(by = By.CssSelector, locator = ".o2uk-account-welcome__service-title")
    public PageElement welcomeMessage;

    //@Find(by = By.CssSelector, locator = ".main-dropdown__wrapper")
   //@Find(by = By.XPath, locator = "//div[@role='button' and @aria-label='My O2 links']") -
    @FindByKey(key ="myO2MenuLink")
    public PageElement myO2MenuLink;

    @Find(by = By.CssSelector, locator = ".main-dropdown-list__wrapper.content-limited")
    public PageElement myO2MenuListParent;

    @Find(by = By.XPath, locator = "//div[@class='o2uk-account-welcome__usage-graph-title-container']")
    public PageElementCollection usageGraphList;

    @Inject
    public AccountLandingPage(final Retry retry, final Common common) {
        this.retry = retry;
        this.common = common;
    }

    @Override
    protected PageElement getPageCheckElement() {
        return this.welcomeMessage.waitUntil(displayed.and(enabled));
    }

    public PageElement getSubmenubyText(String submenuName) {
        return this.myO2MenuListParent.findChild(By.XPath, "//a[contains(@class,'main-dropdown-list') and contains(@title,'"+submenuName+"')]");

    }

    public boolean isWelcomeMessageDisplayed() {
        browser.setImplicitWait(2);
        boolean condition = retry.retryAction(
                () -> welcomeMessage.isDisplayed() && welcomeMessage.getText() != null,
                8,
                1);
        browser.restoreImplicitWait();

        return condition;
    }

    public String getWelcomeMessage() {
        String welcomeMessageText = "";
        browser.setImplicitWait(2);

        int retries = 3;

        while (retries > 0) {
            logger.info("Check if Welcome message is displayed ...");
            if (isWelcomeMessageDisplayed()) {
                logger.info("Welcome message found! Attempt to get its content ...");
                try {
                    welcomeMessageText = welcomeMessage.getText();
                    break;
                } catch (Exception e) {
                    logger.warn(MessageFormat.format("Error retrieving Welcome message! Retry #{0} ...", retries));
                }
            } else {
                logger.warn(MessageFormat.format("Welcome message not displayed! Retry #{0} ...", retries));
            }
            common.wait(2);
            retries--;
        }

        return welcomeMessageText;
    }

    public boolean isUsageGrapthDisplay(String grapthName) {
        List<PageElement> graphList = new ArrayList<PageElement>();
        graphList.clear();
        graphList = this.usageGraphList.asList();
        this.logger.warn(graphList.size() + "******" + graphList.get(0).isDisplayed(150));

        if (graphList.size() < 1) {
            this.logger.warn("* Usage graph not present..");
            return false;
        }

        PageElement graphPresent = graphList.stream().filter(u -> u.getText().toString().trim().equals(grapthName))
                .findFirst().orElse(null);

        return graphPresent.isDisplayed();
    }
}
