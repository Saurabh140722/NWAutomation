package com.o2.models.csrd;

import com.nttdata.cinnamon.driver.controls.PageElement;
import com.nttdata.cinnamon.driver.controls.PageElementCollection;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import java.text.MessageFormat;

public class CustomerInteractionRow {
    public PageElement interactionName;
    public PageElement subject;
    public PageElement description;
    public PageElement relatesTo;
    public PageElement interactionDate;
    public PageElement initiatedBy;

    public CustomerInteractionRow(PageElementCollection tableRow) {
        this.interactionName = tableRow.asList().get(2);
        this.subject = tableRow.asList().get(4);
        this.description = tableRow.asList().get(5);
        this.relatesTo = tableRow.asList().get(6);
        this.interactionDate = tableRow.asList().get(7);
        this.initiatedBy = tableRow.asList().get(8);
    }

    public boolean isEqualTo(CustomerInteractionRowModel model) {
        return isEqualTo(model, 0);
    }

    public boolean isEqualTo(CustomerInteractionRowModel model, int interactionDateOffset) {
        DateTimeFormatter format = DateTimeFormat.forPattern("dd/MM/yyyy HH:mm:ss");
        DateTime thisInteractionDate = format.parseDateTime(this.interactionDate.getText());
        DateTime modelInteractionDate = format.parseDateTime(model.interactionDate);

        int timeDiff = thisInteractionDate.getSecondOfDay() - modelInteractionDate.getSecondOfDay();

        return this.interactionName.getText().equals(model.interactionName)
                && this.subject.getText().equals(model.subject)
                && this.description.getText().equals(model.description)
                && this.relatesTo.getText().contains(model.relatesTo)
                && this.initiatedBy.getText().contains(model.initiatedBy)
                && timeDiff <= interactionDateOffset;
    }

    @Override
    public String toString() {
        return MessageFormat.format("Customer Interaction: {0}, {1}, {2}, {3}, {4}, {5}",
                this.interactionName.getText(),
                this.subject.getText(),
                this.description.getText(),
                this.relatesTo.getText(),
                this.interactionDate.getText(),
                this.initiatedBy.getText());
    }
}
