package com.o2.pages.csrd;

import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.o2.pages.BasePage;

public class DeactivatePaymentPopupPage extends BasePage {
    @Find(by = By.CssSelector, locator = ".ui-dialog.ui-corner-all.ui-widget.ui-widget-content.ui-front.nc-user-confirm.ui-dialog-buttons.ui-draggable.title-exist")
    public PageElement root;

    @Find(by = By.Id, locator = "ui-id-4")
    public PageElement title;

    @Find(by = By.CssSelector, locator = ".confirm-button.default-focus.ui-button.ui-corner-all.ui-widget")
    public PageElement  confirmButton;

    public PageElement getTitle() {
        return this.root.findChild(By.CssSelector, ".ui-dialog-title");
    }

    @Override
    public boolean isPageDisplayed() {
        return getTitle().isDisplayed() && getTitle().getText().contains("Deactivate Payment Instrument");
    }
}
