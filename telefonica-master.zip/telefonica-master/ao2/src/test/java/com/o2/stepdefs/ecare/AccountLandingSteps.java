package com.o2.stepdefs.ecare;

import static org.assertj.core.api.Assertions.assertThat;

import java.text.MessageFormat;

import com.google.inject.Inject;
import com.nttdata.cinnamon.cache.Context;
import com.nttdata.cinnamon.driver.Browser;
import com.o2.models.ecare.EcareUser;
import com.o2.pages.ecare.AccountLandingPage;
import com.o2.pages.ecare.BuyBoltOnPage;
import com.o2.stepdefs.BaseStep;

import com.o2.util.Common;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class AccountLandingSteps extends BaseStep {
	private final Context context;
	private final AccountLandingPage accountLandingPage;
	private final Common common;
	private final BuyBoltOnPage buyBoltOnPage;
	private final Browser browser;
	@Inject
	public AccountLandingSteps(final Context context, final AccountLandingPage accountLandingPage, Common common, BuyBoltOnPage buyBoltOnPage, Browser browser) {
		this.context = context;
		this.accountLandingPage = accountLandingPage;
		this.common = common;
		this.buyBoltOnPage = buyBoltOnPage;
		this.browser = browser;
	}

	@When("^home page opens successfully$")
	public void home_page_opens_successfully() {
		this.logger.info("** Waiting for Home landing page to open ...");

		//assertThat(this.accountLandingPage.isPageDisplayed(90)).withFailMessage("Home landing page not displayed!")
		//		.isTrue();
       this.common.waitForLoadingToComplete(3,1);
	   this.common.wait(5);
		EcareUser ecareUser = (EcareUser) this.context.get("ecareLoginData");
		this.browser.setImplicitWait(5);
		assertThat(this.accountLandingPage.welcomeMessage.getText())
			.isEqualTo(MessageFormat.format("Welcome, {0}", ecareUser.firstName));

		this.logger.info("** Home landing page opens!");
	}


	@When("I can see usage graph title under uk tab")
	public void i_can_see_usage_graph_title_under_uk_tab() {
		String[] graphNames = { "UK Data", "Europe Zone fair usage data" };
		for (String name : graphNames) {
			assertThat(this.accountLandingPage.isUsageGrapthDisplay(name))
					.withFailMessage(MessageFormat.format("Could not find : ''{0}'' usage graph under UK tab", name))
					.isNotNull();
		}

	}

	@Then("I can see usage graph title under Abroad tab")
	public void i_can_see_usage_graph_title_under_abroad_tab() {
		// this.common.waitForLoadingToComplete(2, 1);
		this.common.wait(90);
		String[] graphNames = { "Roaming Bolt On" };
		for (String name : graphNames) {
			assertThat(this.accountLandingPage.isUsageGrapthDisplay(name))
					.withFailMessage(
							MessageFormat.format("Could not find : ''{0}'' usage graph under Abroad tab", name))
					.isNotNull();
		}
	}
	
}
