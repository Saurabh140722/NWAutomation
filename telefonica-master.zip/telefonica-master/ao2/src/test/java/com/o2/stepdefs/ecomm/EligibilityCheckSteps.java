package com.o2.stepdefs.ecomm;

import com.google.inject.Inject;
import com.nttdata.cinnamon.cache.Context;
import com.nttdata.cinnamon.driver.Browser;
import com.nttdata.cinnamon.webdriver.util.ReadyState;
import com.o2.core.data.UserData;
import com.o2.core.util.Common;
import com.o2.models.ecomm.EcommUser;
import com.o2.pages.ecomm.AgreementPage;
import com.o2.pages.ecomm.EligibilityCheckPage;
import io.cucumber.java.en.And;
import org.assertj.core.api.Assertions;

import static com.nttdata.cinnamon.wait.ElementConditions.*;
import static com.nttdata.cinnamon.wait.conditions.Conditions.ajaxFinished;
import static com.nttdata.cinnamon.wait.conditions.Conditions.readyState;
import static org.assertj.core.api.Assertions.assertThat;

public class EligibilityCheckSteps extends BaseStep {
    private final AgreementPage agreementPage;
    private final Context context;
    private final Browser browser;
    private final Common common;
    private final EligibilityCheckPage eligibilityCheckPage;
    private final UserData userdata;


    @Inject
    public EligibilityCheckSteps(final EligibilityCheckPage eligibilityCheckPage, AgreementPage agreementPage, final Context context, final Browser browser, final Common common, UserData userdata) {
        this.eligibilityCheckPage = eligibilityCheckPage;
        this.agreementPage = agreementPage;
        this.context = context;
        this.browser = browser;
        this.common = common;
        this.userdata = userdata;
    }


    @And("^I verify middle name is displayed for your detail section$")
    public void i_verify_middle_name_for_your_detail() {
        Assertions.assertThat(this.eligibilityCheckPage.firstName.isDisplayed())
                .withFailMessage("First name is not displayed under your detail section!").isTrue();
        Assertions.assertThat(this.eligibilityCheckPage.middleName.isDisplayed())
                .withFailMessage("Middle name is not displayed under your detail section!").isTrue();
        Assertions.assertThat(this.eligibilityCheckPage.lastName.isDisplayed())
                .withFailMessage("Last name is not displayed under your detail section!").isTrue();
        Assertions.assertThat(this.eligibilityCheckPage.dob.isDisplayed())
                .withFailMessage("Dob is not displayed under your detail section!").isTrue();
        Assertions.assertThat(this.eligibilityCheckPage.mobileNbr.isDisplayed())
                .withFailMessage("Mobile Number is not displayed under your detail section!").isTrue();
    }


    @And("I complete the address verification and eligibility check")
    public void i_verify_address_eligibility_check() throws InterruptedException {
        this.browser.waitUntil(readyState(ReadyState.COMPLETE));
        EcommUser ecommUser = (EcommUser) this.context.get("eCommUserData");
        this.common.wait(8);
        if (this.eligibilityCheckPage.makeSureYourOrderPageTitle.isDisplayed()) {
            this.logger.info("Make sure your order is right for you page is displayed..");
            eligibilityCheckPage.contiueOrderWayBtn.waitUntil(displayed.and(enabled).and(present).and(clickable)).clickJs();
            eligibilityCheckPage.waitForjustaMomentLoadingToComplete(15, 2, 2);
        }
        Assertions.assertThat(eligibilityCheckPage.pageTitle.getText().trim().equals("Secure checkout")).withFailMessage(
                        " Secure checkout page not loaded.")
                .isTrue();

        Assertions.assertThat(eligibilityCheckPage.enableSectionHeader.getText().trim().equals("Your details")).withFailMessage(
                        " Your details section not displayed.")
                .isTrue();
        this.logger.info("*** Attempt to complete  Step 1 of 5:Your details ....");

        String userType = (String) this.context.get("userType");
        if (userType.equals("existing")) {
            if (this.eligibilityCheckPage.userDetailsNOChangeContinue.isPresent()) {
                this.eligibilityCheckPage.userDetailsNOChangeContinue.click();
                eligibilityCheckPage.waitForjustaMomentLoadingToComplete(30, 2, 2);
            }
        }

        if (this.eligibilityCheckPage.firstName.isDisplayed()) {
            this.logger.info("*** Enter data in your details section ....");
            UserData user = userdata.generate();
            this.eligibilityCheckPage.title.click();
            this.eligibilityCheckPage.titleOptions.asList().get(0).click();
            this.eligibilityCheckPage.firstName.setValue(user.userDataModel.firstName);//.lastNameecommUser.firstName.replaceAll("[^A-Za-z]+",""));
            this.eligibilityCheckPage.lastName.setValue(user.userDataModel.lastName);
            this.eligibilityCheckPage.dob.setValue("12/09/1987");
            this.eligibilityCheckPage.mobileNbr.setValue(ecommUser.mobile);
            this.eligibilityCheckPage.houseNbr.setValue("B33 8TH");
            common.wait(2);
            eligibilityCheckPage.postCode.setValue("CM20 3RS");
            common.wait(2);
            eligibilityCheckPage.findBtn.waitUntil(displayed.and(enabled).and(present).and(clickable)).clickJs();
            common.wait(2);
            if (this.eligibilityCheckPage.selectAddress.isDisplayed()) {
                this.eligibilityCheckPage.selectAddress.asSelect().selectByIndex(1);
            } else {
                this.eligibilityCheckPage.selectAddressFromDropdown();
            }
            this.eligibilityCheckPage.confirmContinueBtn.click();
            eligibilityCheckPage.waitForProcessLoadingToComplete(30, 2, 2);
            this.browser.waitUntil(ajaxFinished);
            eligibilityCheckPage.yourDetailTileforEditing.waitUntil(displayed);
//            assertThat(eligibilityCheckPage.yourDetailNeedToChangeAny.isDisplayed()).withFailMessage(
//                            " Could NOT save Your details data.")
//                    .isTrue();
            //eligibilityCheckPage.userDetailsContinue.waitUntil(displayed).clickJs();
            eligibilityCheckPage.deliveryContinue.waitUntil(displayed).clickJs();
        }
//            assertThat(eligibilityCheckPage.getYourDetailEmail(ecommUser.email).isDisplayed()).withFailMessage(
//                            " Could NOT find login user email address in Your details .")
//                    .isTrue();
        if (this.eligibilityCheckPage.eligibiltyCheckCompleteHeader.isDisplayed()) {
            Assertions.assertThat(this.eligibilityCheckPage.eligibiltyCheckCompleteHeader.isDisplayed())
                    .withFailMessage("Eligibility complete header is not displayed!").isTrue();
        }


        if (eligibilityCheckPage.timeAtAddressDropDown.isDisplayed()) {
            this.logger.info("Eligibility check section is displayed...");
            this.common.wait(8);
            Assertions.assertThat(this.eligibilityCheckPage.timeAtAddressDropDown.isDisplayed()).withFailMessage("Eligibility Check details to be filled is not displayed").isTrue();
            Assertions.assertThat(this.eligibilityCheckPage.personalAnnualIncomeDropDown.isDisplayed()).withFailMessage("Eligibility Check details to be filled is not displayed").isTrue();
            Assertions.assertThat(this.eligibilityCheckPage.employmentStatusDropDown.isDisplayed()).withFailMessage("Eligibility Check details to be filled is not displayed").isTrue();

            // TODO these locators have been chagne to o2UK-Select, hence select cannot be used, revert if require
            if (eligibilityCheckPage.timeAtAddressDropDown.getTagName().equals("o2uk-select")) {
                eligibilityCheckPage.selectEligilibilityCheckDropdowns();
           } else {
                this.eligibilityCheckPage.timeAtAddressDropDown.asSelect().selectByIndex(6);
                this.common.wait(2);

                this.eligibilityCheckPage.employmentStatusDropDown.asSelect().selectByIndex(1);
                this.common.wait(2);

                this.eligibilityCheckPage.personalAnnualIncomeDropDown.asSelect().selectByIndex(5);
                this.common.wait(2);
            }

            eligibilityCheckPage.termsAndConditionCheckBox.waitUntil(displayed.and(enabled).and(clickable)).click();
            eligibilityCheckPage.eligibilityConfirmContinueBtn.waitUntil(displayed.and(enabled).and(present).and(clickable)).clickJs();
            eligibilityCheckPage.waitForProcessLoadingToComplete(30, 2, 2);
            this.browser.waitUntil(ajaxFinished);
//            assertThat(eligibilityCheckPage.getEditButton("Eligibility check").isDisplayed()).withFailMessage(
//                            " Could NOT save Eligibility check data.")
//                    .isTrue();
        }

        if (agreementPage.sendContractInfoAndSummary.isDisplayed()) {
            agreementPage.sendContractInfoAndSummary.clickJs();
            common.wait(3);
            Assertions.assertThat(agreementPage.contractInfoAndSummarySENT.isDisplayed());
        }
        if (agreementPage.contractInfoAndSummaryReceivedConfirm.isEnabled()) {
            agreementPage.contractInfoAndSummaryReceivedConfirm.clickJs();
            if (agreementPage.confirmNContinue.isEnabled()) {
                agreementPage.confirmNContinue.clickJs();
                if (agreementPage.continuetoPayment.isDisplayed()) {
                    agreementPage.continuetoPayment.clickJs();
                }
            }

        }

        try {
            if (eligibilityCheckPage.homeDeliveryContinue.isDisplayed()) {
                eligibilityCheckPage.getHomeDeliveryOption();
                eligibilityCheckPage.homeDeliveryContinue.clickJs();
            }

            if (this.eligibilityCheckPage.navigatePaymentContinueBtn.isDisplayed()) {
                this.eligibilityCheckPage.navigatePaymentContinueBtn.waitUntil(displayed.and(enabled).and(present).and(clickable)).clickJs();
                this.logger.info("*** Completed Step 1 of 5:Your details ....");
                eligibilityCheckPage.waitForjustaMomentLoadingToComplete(15, 2, 2);
            }

            if (this.eligibilityCheckPage.makeSureYourOrderPageTitle.isDisplayed()) {
                this.logger.info("Make sure your order is right for you page is displayed..");
                this.eligibilityCheckPage.contiueOrderWayBtn.waitUntil(displayed.and(enabled).and(present).and(clickable)).clickJs();
                eligibilityCheckPage.waitForjustaMomentLoadingToComplete(15, 2, 2);
            }
        } catch (Exception e) {
            e.printStackTrace();

        }
    }

    //for demo
    @And("^I complete the address verification and eligibility check with HomeDelivery option$")
    public void i_verify_address_eligibility_check_with_option() {
        this.browser.waitUntil(readyState(ReadyState.COMPLETE));
        EcommUser ecommUser = (EcommUser) this.context.get("eCommUserData");

        if (this.eligibilityCheckPage.makeSureYourOrderPageTitle.isDisplayed()) {
            this.logger.info("Make sure your order is right for you page is displayed..");
            this.eligibilityCheckPage.contiueOrderWayBtn.waitUntil(displayed.and(enabled).and(present).and(clickable)).clickJs();
            eligibilityCheckPage.waitForjustaMomentLoadingToComplete(15, 2, 2);
        }
        Assertions.assertThat(eligibilityCheckPage.pageTitle.getText().trim().equals("Secure checkout")).withFailMessage(
                        " Secure checkout page not loaded.")
                .isTrue();
        this.logger.info("*** Attempt to complete  Step 1 of 5:Your details ....");

        Assertions.assertThat(eligibilityCheckPage.enableSectionHeader.getText().trim().equals("Your details")).withFailMessage(
                        " Your details section not displayed.")
                .isTrue();

        if (this.eligibilityCheckPage.firstName.isDisplayed()) {
            this.logger.info("*** Enter data in your details section ....");
            this.eligibilityCheckPage.title.waitUntil(displayed.and(clickable)).clickJs();
            this.eligibilityCheckPage.titleOptions.asList().get(0).click();
            this.eligibilityCheckPage.firstName.setValue(ecommUser.firstName);
            this.eligibilityCheckPage.lastName.setValue(ecommUser.lastName);
            this.eligibilityCheckPage.dob.setValue(ecommUser.dob);
            this.eligibilityCheckPage.mobileNbr.setValue(ecommUser.mobile);
            this.eligibilityCheckPage.houseNbr.setValue("B33 8TH");
            this.eligibilityCheckPage.postCode.setValue("SL1 4ED");
            this.eligibilityCheckPage.findBtn.waitUntil(displayed.and(enabled).and(present).and(clickable)).clickJs();
            eligibilityCheckPage.waitForProcessLoadingToComplete(6, 2, 2);
            this.eligibilityCheckPage.selectAddress.asSelect().selectByIndex(0);
            this.eligibilityCheckPage.confirmContinueBtn.click();
            eligibilityCheckPage.waitForProcessLoadingToComplete(30, 2, 2);
            this.browser.waitUntil(ajaxFinished);
            Assertions.assertThat(eligibilityCheckPage.getEditButton("Your details").isDisplayed()).withFailMessage(
                            " Could NOT save Your details data.")
                    .isTrue();

        } else {
            Assertions.assertThat(eligibilityCheckPage.getYourDetailEmail(ecommUser.email).isDisplayed()).withFailMessage(
                            " Could NOT find login user email address in Your details .")
                    .isTrue();

            if (this.eligibilityCheckPage.userDetailsNOChangeContinue.isDisplayed()) {
                this.eligibilityCheckPage.userDetailsNOChangeContinue.click();
                eligibilityCheckPage.waitForjustaMomentLoadingToComplete(30, 2, 2);
            }
        }

        if (this.eligibilityCheckPage.deliverNCollectionHeader.isDisplayed()) {
            this.eligibilityCheckPage.deliverNCollectionHeader.isDisplayed();
            this.eligibilityCheckPage.homeDelivery.waitUntil(displayed).clickJs();
            this.eligibilityCheckPage.homeDeliveryContinue.waitUntil(displayed).clickJs();
            eligibilityCheckPage.waitForjustaMomentLoadingToComplete(30, 2, 10);
            browser.waitUntil(ajaxFinished);
            browser.setImplicitWait(4);
            Assertions.assertThat(this.eligibilityCheckPage.getEditButton("Delivery or collection").waitUntil(displayed.and(enabled).and(present).and(clickable)).isDisplayed(5))
                    .withFailMessage("Could NOT save Delivery and Collection data...").isTrue();

            Assertions.assertThat(eligibilityCheckPage.errorReservingOrderMessage.isDisplayed())
                    .withFailMessage("Could not reserve order!")
                    .isFalse();
            browser.restoreImplicitWait();
        }

        if (eligibilityCheckPage.enableSectionHeader.getText().trim().equals("Eligibility check")) {
            this.logger.info("Eligibility check section is displayed...");
            Assertions.assertThat(this.eligibilityCheckPage.timeAtAddressDropDown.isDisplayed()).withFailMessage("Eligibility Check details to be filled is not displayed").isTrue();
            Assertions.assertThat(this.eligibilityCheckPage.personalAnnualIncomeDropDown.isDisplayed()).withFailMessage("Eligibility Check details to be filled is not displayed").isTrue();
            Assertions.assertThat(this.eligibilityCheckPage.employmentStatusDropDown.isDisplayed()).withFailMessage("Eligibility Check details to be filled is not displayed").isTrue();
            this.eligibilityCheckPage.timeAtAddressDropDown.asSelect().selectByIndex(6);
            this.eligibilityCheckPage.employmentStatusDropDown.asSelect().selectByIndex(1);
            this.eligibilityCheckPage.personalAnnualIncomeDropDown.asSelect().selectByIndex(5);
            eligibilityCheckPage.termsAndConditionCheckBox.waitUntil(displayed.and(enabled).and(clickable)).click();
            eligibilityCheckPage.EligibilityCheckContinueBtn.waitUntil(displayed.and(enabled).and(present).and(clickable)).clickJs();
            eligibilityCheckPage.waitForProcessLoadingToComplete(30, 2, 2);
            this.browser.waitUntil(ajaxFinished);
            Assertions.assertThat(eligibilityCheckPage.getEditButton("Eligibility check").isDisplayed()).withFailMessage(
                            " Could NOT save Eligibility check data.")
                    .isTrue();
        }

        if (this.eligibilityCheckPage.eligibiltyCheckCompleteHeader.isDisplayed()) {
            Assertions.assertThat(this.eligibilityCheckPage.eligibiltyCheckCompleteHeader.isDisplayed())
                    .withFailMessage("Eligibility complete header is not displayed!").isTrue();
        }

        if (this.eligibilityCheckPage.navigatePaymentContinueBtn.isDisplayed()) {
            this.eligibilityCheckPage.navigatePaymentContinueBtn.waitUntil(displayed.and(enabled).and(present).and(clickable)).clickJs();
            this.logger.info("*** Completed Step 1 of 5:Your details ....");
            eligibilityCheckPage.waitForjustaMomentLoadingToComplete(15, 2, 2);
        }

        if (this.eligibilityCheckPage.makeSureYourOrderPageTitle.isDisplayed()) {
            this.logger.info("Make sure your order is right for you page is displayed..");
            this.eligibilityCheckPage.contiueOrderWayBtn.waitUntil(displayed.and(enabled).and(present).and(clickable)).clickJs();
            eligibilityCheckPage.waitForjustaMomentLoadingToComplete(15, 2, 2);
        }


    }
}