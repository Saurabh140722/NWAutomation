package com.o2.stepdefs.ecomm;

import com.google.inject.Inject;
import com.nttdata.cinnamon.cache.Context;
import com.nttdata.cinnamon.driver.Browser;
import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.nttdata.cinnamon.driver.controls.PageElementCollection;
import com.nttdata.cinnamon.webdriver.util.ReadyState;
import com.o2.models.ecomm.EcommUser;
import com.o2.pages.ecomm.BasketPage;
import com.o2.pages.ecomm.SignInPage;
import com.o2.util.Common;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.assertj.core.api.Assertions;

import java.text.MessageFormat;

import static com.nttdata.cinnamon.wait.ElementConditions.displayed;
import static com.nttdata.cinnamon.wait.ElementConditions.enabled;
import static com.nttdata.cinnamon.wait.conditions.Conditions.readyState;
import static org.assertj.core.api.Assertions.assertThat;


public class BasketSteps extends BaseStep{

    private final Context context;
    private final BasketPage basketPage;
    private final Browser browser;
    public static boolean eligibilityStatusCheckFlag=false;
    public final SignInPage signInPage;
    public Common common;


    @Inject
    public BasketSteps(final Context context, final BasketPage basketPage, Browser browser, SignInPage signInPage) {
        this.context = context;
        this.basketPage = basketPage;
        this.browser = browser;
        this.signInPage = signInPage;
    }

    @When("I click on basket")
    public void i_Click_On_Basket() {
        this.logger.info("OnClick of baskt. user details page opening.....");
        this.basketPage.basketCartButton.waitUntil(displayed);
        this.basketPage.basketCartButton.click();
    }


    @And("^basket page opens$")
    public void basket_Page_Opens() {
        this.basketPage.checkoutBasket.waitUntil(displayed);
        this.logger.info("basket page opened successfully.....");
    }

    @When("I click on checkout option")
    public void i_Click_On_Checkout_Option() throws InterruptedException {
        this.logger.info("checkout option has been clicked.....");
        Thread.sleep(10000);
        this.basketPage.checkoutBasket.waitUntil(displayed);
        this.basketPage.checkoutBasket.click();
        this.basketPage.userAddress.waitUntil(displayed);
    }

    @And("User details displayed should be same as address in JSON records")
    public void user_Details_Should_Be_Same_As_Address_In_JSON_Records() {
        String concattedAddress=null,formatAddress=null;
        this.logger.info("** User details with address displayed...");
        EcommUser ecommUser = (EcommUser) this.context.get("eCommUserData");
        this.basketPage.userAddressLine.waitUntil(displayed);
        this.logger.info("User addressLine sixe--> "+this.basketPage.userAddressLine.getSize());

        this.logger.info("User addressLine text--> "+this.basketPage.userAddressLine.getText());
        formatAddress =formatAddress(this.basketPage.userAddressLine.getText().toString());
       /*  close for sanity test concattedAddress=convertAddressToString(ecommUser);
        if(formatAddress.length() == concattedAddress.length()){
            assertThat(formatAddress.equals(concattedAddress))
                    .withFailMessage("User address does not match with the address in Json records").isTrue();
        }*/
    }

  /*  public String convertAddressToString(EcommUser ecommUser){
        String concattedAddressTemp=null;
        concattedAddressTemp=ecommUser.addresses.get(0).houseNo.toString()+" "+
                ecommUser.addresses.get(0).street.toString()+" "+
                ecommUser.addresses.get(0).county.toString()+" "+
                ecommUser.addresses.get(0).city.toString()+" "+
                ecommUser.addresses.get(0).postcode.toString();
        return concattedAddressTemp;
    }  close for sanity test*/

    public String formatAddress(String userAddressLineTemp){
        String formatAddressTemp=null;
        formatAddressTemp=userAddressLineTemp.replace("\n"," ");
        return formatAddressTemp;
    }


    @When("I choose to continue checkout with existing user details")
    public void     i_Choose_To_Continue_Checkout_With_Existing_User_Details() {
        this.basketPage.userDetailsNOChangeContinue.click();
        Assertions.assertThat(this.basketPage.deliverNCollectionHeader.isDisplayed())
                .withFailMessage("Delivery and Collection is not displayed!").isTrue();
        this.basketPage.deliverNCollectionHeader.isDisplayed();
    }


    @When("I select HomeDelivery option")
    public void I_Select_HomeDelivery_Option() throws InterruptedException {
        this.basketPage.homeDelivery.clickJs();
        if(this.basketPage.deliveryOutOfStockDialog.isDisplayed()){
            if(this.basketPage.deliveryOutOfStockmessage.isDisplayed()){
                this.logger.info("Something in your order is now out of stock, Please remove the out of stock item(s) from your basket ");
            }
        }
        Thread.sleep(10000);
        this.basketPage.homeDeliveryContinue.waitUntil(displayed);
        this.basketPage.homeDeliveryContinue.click();
        Thread.sleep(10000);
        if(this.basketPage.EligibilityCheckHeader.isDisplayed()){
            this.logger.info("Eligibility check to be completed before proceeding to home delivery...");
        }else if(this.basketPage.eligibiltyCheckCompleteHeader.isDisplayed()){
            this.logger.info("Eligibility check is completed and proceed to payment option.");
        }
    }

    @When("Depending on Eligibility Check status, I was asked to complete Eligibility Check")
    public void depending_On_EligibilityCheck_Status_I_Was_Asked_To_Complete_Eligibility_Check() throws InterruptedException {
        Thread.sleep(10000);
//        assertThat(this.basketPage.yearsAtYourAddressConfirmation.isDisplayed()).withFailMessage("Eligibility Check details to be filled is not displayed").isTrue();
        if(this.basketPage.yearsAtYourAddressConfirmationHeader.isDisplayed()) {
            if(this.basketPage.employmentStatusConfirmationHeader.isDisplayed()) {
                if(this.basketPage.anuualIncomeConfirmationHeader.isDisplayed()) {
                    eligibilityStatusCheckFlag=true;
                }
            }
        }
    }

    @And("Depending on eligibilityCheckStatus, I proceed to select EligibilityCheck-Details like {string}, {string}, {string}")
    public void depending_On_EligibilityCheckStatus_I_Proceed_To_Select_EligibilityCheckDetails_Like_TimeAtAddress_EmploymentStatus_PersonalAnnualIncome(String timeAtAddress, String empStatus, String annualIncome) throws InterruptedException {
        this.logger.info("eligibilityStatusCheckFlag--->" + this.eligibilityStatusCheckFlag);
        Thread.sleep(10000);
        if(eligibilityStatusCheckFlag) {
            this.basketPage.eligibiltyCheckCompleteContinue.click();
        }else {
//            this.basketPage.editEligibilityCheck.click();
            Thread.sleep(5000);
            this.basketPage.timeAtAddress.asSelect().selectByText(timeAtAddress);
            this.basketPage.employmentStatus.asSelect().selectByText(empStatus);
            this.basketPage.personalAnnualIncome.asSelect().selectByText(annualIncome);
            this.basketPage.EligibilityCheckAgree.click();
            this.basketPage.EligibilityCheckContinue.waitUntil(enabled);
            this.basketPage.EligibilityCheckContinue.click();
        }
    }

    @Then("Application navigates to payment page")
    public void Application_Navigates_To_Payment_Page() {
        this.basketPage.eligibiltyCheckCompleteContinue.isDisplayed();
    }

    @When("I select ClickNCollect option and click on SelectStore")
    public void I_Select_ClickNCollect_Option_And_Click_On_SelectStore() {
        this.logger.info("Proceeding to delivery using Click N Collect option.... ");
        this.basketPage.clickNCollect.clickJs();
        this.basketPage.selectStore.waitUntil(displayed);
        this.basketPage.selectStore.click();
        this.logger.info("Delivery Option is - Click N Collect  ");
    }


    @Then("ClickNSelect dialog will open")
    public void clicknselect_Dialog_Will_Open() {
        this.logger.info("Click and Select dialog box will open to search for the Stores using Postal Code ");
        Assertions.assertThat(this.basketPage.clickNCollectDialog.isDisplayed()).withFailMessage("SelectStore did not open ClickNSelect Dialog to select store");
    }

    public int getBasketCount(String linkName){
        int basketItemsCount=0;
        browser.setImplicitWait(20);
        this.logger.info("getting count of Basket Items...");
        this.logger.info(MessageFormat.format("** Attempt to navigate to ''{0}'' ...", linkName));
        this.signInPage.getLink("Shop").hover();
        this.signInPage.getLink(linkName).scrollIntoView().clickJs();
        this.browser.waitUntil(readyState(ReadyState.COMPLETE));
        basketPage.basketCartButton.waitUntil(displayed);
//        if(basketPage.youHaveOrderInProgressCloseDialog.isDisplayed()){
//            basketPage.cancelOrderBasket.clickJs();
//        }
        if(basketPage.basketCountButton.isDisplayed()) {
            basketItemsCount=Integer.valueOf(basketPage.basketCountButton.getText());
        }
        this.logger.info("basketItemsCount:- "+basketItemsCount);
        return basketItemsCount;
    }

    public void emptyBasket(){
        int basketItemsCount=0;
        browser.setImplicitWait(20);
        this.logger.info("Emptying Basket...");
        String linkName = "Tech and accessories";
        this.logger.info(MessageFormat.format("** Attempt to navigate to ''{0}'' ...", linkName));
        this.signInPage.getLink("Shop").hover();
        this.signInPage.getLink(linkName).scrollIntoView().clickJs();
        this.browser.waitUntil(readyState(ReadyState.COMPLETE));
        basketPage.basketCartButton.waitUntil(displayed).clickJs();
        if(basketPage.emptyBasket.isDisplayed()){
            basketPage.emptyBasket.clickJs();
        }
        if(basketPage.emptyBasketCloseDialog.isDisplayed()) {
            basketPage.cancelOrderBasket.clickJs();
        }
        if(basketPage.emptyBasketCancelOrder.isDisplayed()){
            basketPage.emptyBasketCancelOrder.clickJs();
        }
        if(basketPage.basketCountButton.isDisplayed()) {
            this.logger.info("Basket emptying is not Success");
        }else if(!basketPage.basketCountButton.isDisplayed()) {
            this.logger.info("Basket emptying is Success");
        }
    }

    @When("I enter PostcodeORTown to find stores to ClickAndSelect")
    public void I_Enter_PostcodeORTown_To_Find_Stores_To_ClickAndSelect() {
        EcommUser ecommUser = (EcommUser) this.context.get("eCommUserData");
        this.logger.info("Searching the stores near to user address...");
        //  this.basketPage.clickNCollectPostCode.setValue(ecommUser.addresses.get(0).postcode);
        this.basketPage.findByPostcodeButton.click();
        this.basketPage.listViewOfClickNCollectStores.click();
        this.basketPage.chooseFirstStore.click();
    }

    public void getMultiChildren(){
        PageElement lq = null;
        PageElementCollection pageElementChilds = lq.findChildren(By.XPath,"//*[@id='o2uk-dialog-0']//o2uk-retail-shop-card/div[1]//button");
        for(int i=0; i<=pageElementChilds.size();i++){
        }
    }

    @When("I selected Store to ClickNCollect")
    public void I_Selected_Store_To_ClickNCollect() {
        this.logger.info("user selects the store to collect");
        this.basketPage.chooseFirstStore.click();
        this.basketPage.collectOrderNotificationMessage.waitUntil(displayed);
    }

    @Then("I confirmation message should be displayed with date of collect")
    public void I_Confirmation_Message_Should_Be_Displayed_With_Date_Of_Collect() {
        this.basketPage.collectOrderNotificationMessage.isDisplayed();
        Assertions.assertThat(this.basketPage.collectOrderNotificationMessage.isDisplayed()).withFailMessage("unable to accept ClickNCollect, check for error...");
    }

    @When("I confirm and  continue for clickNcollect")
    public void I_Confirm_And_Continue_For_ClickNcollect() throws InterruptedException {
        Thread.sleep(10000);
        if(basketPage.someThingWentWrongMessageClose.isDisplayed()){
            this.logger.info("SomethingWentWrong error Message was closed after selecting clickNSelect store. ");
            basketPage.someThingWentWrongMessageClose.click();
        }
        this.basketPage.deliveryConfirm.click();
        if(this.basketPage.eligibiltyCheckCompleteHeader.isDisplayed()){
            this.logger.info("Eligibility check to be completed before proceeding to home delivery...");
        }else this.basketPage.eligibiltyCheckCompleteHeader.waitUntil(displayed);
    }

    @When("I choose and confirm to change user address")
    public void I_Choose_And_Confirm_To_Change_User_Address() {
        EcommUser ecommUser = (EcommUser) this.context.get("eCommUserData");
        this.logger.info("Changing User Address....");
        this.basketPage.userDetailsChangeOption.click();
        this.basketPage.addressChangeDialog.waitUntil(displayed);
        this.basketPage.addressChangeDialogConfirm.click();
        this.basketPage.msisdnValuePhoneNo.setValue(ecommUser.mobile);
        this.basketPage.msisdnValueSubmit.click();
        this.basketPage.verifyPhoneNumberHeader.waitUntil(displayed);
        this.basketPage.otacDigitCode1.setValue("1");
        this.basketPage.otacDigitCode2.setValue("1");
        this.basketPage.otacDigitCode3.setValue("1");
        this.basketPage.otacDigitCode4.setValue("1");
        this.basketPage.otacDigitCode5.setValue("1");
        this.basketPage.otacDigitCode6.setValue("1");
        this.basketPage.continueButton.click();
    }



}
