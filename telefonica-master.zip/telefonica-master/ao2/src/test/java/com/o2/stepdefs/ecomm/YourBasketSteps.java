package com.o2.stepdefs.ecomm;

import com.google.inject.Inject;
import com.nttdata.cinnamon.cache.Context;
import com.nttdata.cinnamon.driver.Browser;
import com.nttdata.cinnamon.webdriver.util.ReadyState;
import com.o2.models.ecomm.Basket;
import com.o2.models.ecomm.Tariffs;
import com.o2.pages.ecomm.PhonePage;
import com.o2.pages.ecomm.YourBasketPage;
import com.o2.util.Common;
import io.cucumber.java.en.And;
import org.apache.commons.lang.NotImplementedException;
import org.assertj.core.api.Assertions;

import java.text.MessageFormat;
import java.util.List;

import static com.nttdata.cinnamon.wait.ElementConditions.*;
import static com.nttdata.cinnamon.wait.conditions.Conditions.readyState;
import static org.assertj.core.api.Assertions.assertThat;

public class YourBasketSteps extends BaseStep {
    private final Browser browser;
    private final YourBasketPage yourBasketPage;
    private final Context context;
    private final Common common;
    private final PhonePage phonePage;


    @Inject
    public YourBasketSteps(final Browser browser,final YourBasketPage yourBasketPage,final Context context,final Common common,final PhonePage phonePage) {
        this.browser = browser;
        this.yourBasketPage = yourBasketPage;
        this.context = context;
        this.common = common;
        this.phonePage = phonePage;
    }

    @And("^I verify item added to basket$")
    public void iVerifyBasket() throws InterruptedException {
        this.logger.info("Verifying items added in Basket...");
        browser.waitUntil(readyState(ReadyState.COMPLETE));
        this.common.wait(8);
        String basketMsg = yourBasketPage.basketBtn.getAttribute("aria-label");
        if (basketMsg.contains("no items in basket")) {
            browser.refresh();
            browser.waitUntil(readyState(ReadyState.COMPLETE));
        }
        Thread.sleep(20000);
        yourBasketPage.checkoutBtn.waitUntil(displayed);
        List<Basket> basket = yourBasketPage.getItemAddedInBasket();
        context.set("packageCount", basket.size());
        yourBasketPage.checkoutBtn.waitUntil(displayed).clickJs();
    }

    @And("I empty the basket")
    public void i_Empty_The_Basket() {
        this.logger.info("Verifying items added in Basket...");
        browser.waitUntil(readyState(ReadyState.COMPLETE));
        this.common.wait(8);
        String basketMsg = yourBasketPage.basketBtn.getAttribute("aria-label");
        if (basketMsg.contains("no items in basket")) {
            browser.refresh();
            browser.waitUntil(readyState(ReadyState.COMPLETE));
        }
        List<Basket> basket = yourBasketPage.getItemAddedInBasket();
        context.set("packageCount", basket.size());
        this.logger.info("Emptying " + basket.size() + " Items in the Basket :-");
        yourBasketPage.emptyBasket.clickJs();
        this.common.wait(10);
        yourBasketPage.emptyBasketDialog.waitUntil(displayed);
        yourBasketPage.cancelOrderEmptyBasket.clickJs();
        this.common.wait(10);
        yourBasketPage.yourBasketIsEmpty.waitUntil(displayed);
        Assertions.assertThat(yourBasketPage.yourBasketIsEmpty.isDisplayed()).withFailMessage("Emptying Basket not successful, try again");
    }

    @And("^I validate message for '(.*)' promocode as '(.*)'$")
    public void i_verified_promo_code_message(String status, String promoCode) throws InterruptedException {
        switch (status) {
            case "invalid":
                Assertions.assertThat(yourBasketPage.promoCodeTxtBox.isDisplayed())
                        .withFailMessage("Promo Code text box is not displayed!")
                        .isTrue();
                yourBasketPage.promoCodeTxtBox.setValue(promoCode);
                yourBasketPage.updateButton.click();
                Assertions.assertThat(yourBasketPage.promoCodeErrorMessage.isDisplayed())
                        .withFailMessage("Promo Code error message is not displayed!")
                        .isTrue();
                Assertions.assertThat(yourBasketPage.promoCodeErrorMessage.getText().contains("This promo code does not exist"))
                        .withFailMessage("Promo Code error message is not displayed!");
                break;
            case "valid":
                Assertions.assertThat(yourBasketPage.promoCodeTxtBox.isDisplayed())
                        .withFailMessage("Promo Code text box is not displayed!")
                        .isTrue();
                Thread.sleep(5000);
                yourBasketPage.promoCodeTxtBox.scrollIntoView().waitUntil(enabled);
                yourBasketPage.promoCodeTxtBox.setValue(promoCode);
                if (yourBasketPage.updateButton.isEnabled()) {
                    yourBasketPage.updateButton.clickJs();
                }
                Assertions.assertThat(yourBasketPage.updateButton.isEnabled())
                        .withFailMessage("Promo Code is not valid or does not exist");
                break;
            default:
                throw new NotImplementedException(MessageFormat
                        .format("Option ''{0}''  promo Code message is displayed!", status));

        }

    }

    @And("^I verify added '(.*)' to basket$")
    public void iBuildMyPackageWithSimtype(String plan) {
        this.browser.waitUntil(readyState(ReadyState.COMPLETE));
        assertThat(!(this.yourBasketPage.pageTitle.getText().trim().equals("Your basket is empty"))).withFailMessage(
                        "Cannot add the item into basket.Your basket is empty.")
                .isTrue();

        this.logger.info("*** Attempt to checkout the added item in basket....");
        switch (plan.toUpperCase()) {
            case "PHONE":
                String selectedPhone = (String) this.context.get("phone");
                String monthly = (String) this.context.get("monthly");
                String upfornt = (String) this.context.get("upfornt");

                Assertions.assertThat(yourBasketPage.selectedPhone.isDisplayed())
                        .withFailMessage("Cannot retrieve device name from Basket!")
                        .isTrue();
                String basketPhone = yourBasketPage.selectedPhone.getText();
                assertThat(basketPhone)
                        .withFailMessage(
                                MessageFormat.format("Expected device ''{0}'' not found in basket! Found: ''{1}''",
                                        selectedPhone, basketPhone))
                        .isEqualToIgnoringCase(selectedPhone);


                //TOOD: update xpath for Monthly and upfornt payment in Basket page
        /*
              assertThat(this.phonePage.monthlyPayment.getText().equals(monthly)).withFailMessage(
                        "Monthly payment amount not match..")
                .isTrue();

              assertThat(this.phonePage.upfrontPayment.getText().equals(upfornt)).withFailMessage(
                        "Upfornt paymnet amount not match..")
                .isTrue();

         */

                this.yourBasketPage.checkoutBtn.waitUntil(displayed.and(enabled).and(present).and(clickable)).clickJs();
                yourBasketPage.waitForjustaMomentLoadingToComplete(3, 2, 6);

                this.logger.info("*** Successfully checkout the item....");
                break;

            case "SIM":
                List<Basket> basket = this.yourBasketPage.getItemAddedInBasket();
                Tariffs traffic = (Tariffs) this.context.get("Plan");
                //TODO: to complete the flow
                browser.refresh();

                assertThat(basket.size())
                        .withFailMessage("Could not find any  Package in basket page...")
                        .isPositive();

                this.context.set("packageCount", basket.size());
                this.logger.info("traffic" + (traffic != null));
                String planName= (String) this.context.get("PlanName");

                Assertions.assertThat(basket.get(0).tariffName)
                        .withFailMessage(
                                MessageFormat.format("Expected sim ''{0}'' not found in basket! Found: ''{1}''",
                                        planName, basket.get(0).tariffName))
                        .containsIgnoringCase(planName);

                this.yourBasketPage.checkoutBtn.waitUntil(displayed.and(enabled).and(present).and(clickable)).clickJs();
                yourBasketPage.waitForjustaMomentLoadingToComplete(3, 2, 6);
                this.logger.info("*** Successfully checkout the  added item....");
                break;
            default:
                throw new NotImplementedException(MessageFormat
                        .format("Invalid plan type ''{0}''!", plan));

        }
    }


}
