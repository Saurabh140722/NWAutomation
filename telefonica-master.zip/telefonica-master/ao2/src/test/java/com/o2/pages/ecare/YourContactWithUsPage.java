package com.o2.pages.ecare;

import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.nttdata.cinnamon.driver.controls.PageElementCollection;

public class YourContactWithUsPage extends EcareBasePage {
    @Find(by = By.CssSelector, locator = ".o2uk-header-curve__text-title.ng-star-inserted")
    public PageElement pageTitle;

    @Find(by = By.CssSelector, locator = ".mat-focus-indicator.mat-button-base.o2uk-primary-button")
    public PageElementCollection changeDetails;

    @Find(by = By.XPath, locator = "//button[@role='tab']//label[text()='Notifications']")
    public PageElement notificationsTab;

    @Find(by = By.XPath, locator = "//h3[text()='Notification email']")//".o2uk-your-contact-with-us-notification__title")
    public PageElement notificationsTabTitle;

    @Find(by = By.CssSelector, locator = ".contact-details")
    public PageElement contactDetails;

    @Find(by = By.XPath, locator = "//h3[text()='Notification email']/following::div[@class='sessioncamhidetext']")
    public PageElement emailNotification;


    public String getContactDetailValue(String contactName) {
        PageElement contactValue = contactDetails.findBy(By.XPath, "//div[@class='contact-details__name' and text()=' "
                + contactName + " ']/following-sibling::div[@class='contact-details__value']");
        return contactValue.getText().trim();
    }
    public PageElement contactDetailsEmail(String emailAddress) {
        PageElement emailNotification = this.browser.findBy(By.XPath,
                "//*[@class='o2uk-manage-my-details-card__row']//*[text()=' Email ']//following::*[@class='sessioncamhidetext']");
        return emailNotification;
    }

    public PageElement yourSimcontactDetailsEmail(String emailAddress) {
        PageElement emailNotification = this.browser.findBy(By.XPath,
                "//*[@class='contact-details']//div[contains(@class,'sessioncamhidetext') and contains(text(),'"+emailAddress+ "')]");
        return emailNotification;
    }



    public boolean isEmailNotificationDisplayed(String emailAddress) {
        PageElementCollection emailNotification = this.browser.findAllBy(By.XPath,
                "//o2uk-notification-message[contains(@id,'notification')]//div[contains(text(),'Notification: "
                        + emailAddress + "')]");

		return emailNotification.asList().size() > 0;
	}

    @Override
    public boolean isPageDisplayed() {
        return pageTitle.isDisplayed()
				&& pageTitle.getText().equalsIgnoreCase("Your contact with us");
    }
}
