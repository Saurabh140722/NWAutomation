package com.o2.pages.csrd;

import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.o2.pages.BasePage;

public class OrderFormPage extends BasePage {
    @Find(by = By.CssSelector, locator = ".salesOrderName")
    public PageElement orderNo;

    @Find(by = By.CssSelector, locator = ".nc-loader-text")
    public PageElement loading;

}
