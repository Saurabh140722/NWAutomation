package com.o2.pages.csrd;

import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.FindByKey;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.nttdata.cinnamon.driver.controls.PageElementCollection;
import com.o2.models.csrd.ServicesAndFeaturesRow;
import com.o2.pages.BasePage;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import static com.o2.Constants.FIVE_SECS;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

public class OrderServicesAndFeaturesPage extends BasePage {
    @Find(by = By.CssSelector, locator = ".bulkTreeItem.bulkTreeItemRoeTreeItem")
    public PageElement orderItem;

    @Find(by = By.CssSelector, locator = "#\\39 156572417865211588")
    public PageElement connectivityColumnHeader;

    @Find(by = By.CssSelector, locator = ".roe-widget-content.wrapper_selection")
    public PageElementCollection widgetsRoot;

    @Find(by = By.XPath, locator = "//table[@class='roe-table']/tr[2]/td[@class='roe-table-cell item'][1]/input")
    public PageElementCollection btn_phones;

    @Find(by = By.XPath, locator = " //table[@class='roe-table']/tr[4]/td[@class='roe-table-cell item']/input")
    public PageElementCollection btn_wearables;

    @Find(by = By.XPath, locator = "//*[@id='true']/ul/li[2]/a")
    public PageElement btn_wearablesAndroid;

    @Find(by = By.XPath, locator = "//tbody/tr/td[@class='sale equipment_price']/span")
    public PageElement lbl_phonePrice;

    @Find(by = By.XPath, locator = "//td//td//td//a[@role='button']")
    public PageElement btn_add;

    @Find(by = By.CssSelector, locator = ".hw-search-filter__search-input input")
    public PageElement txt_deviceSearch;

    @Find(by = By.CssSelector, locator = "[class='hw-search-warning']")
    public PageElement searchWarning;

    @Find(by = By.XPath, locator = "//*[@id='gen_menu_0']")
    public PageElement expandplm;

    @Find(by = By.XPath, locator = "//a[contains(text(),'Next')]")
    public PageElement nxtBtn;

    @Find(by = By.XPath, locator = "//span[contains(text(),'Product Management')]")
    public PageElement productmanagement;

    @Find(by = By.XPath, locator = "//span[contains(text(),'PLM Management')]")
    public PageElement PLMManagement;

    @Find(by = By.XPath, locator = "//a[contains(text(),'RPI Price Template')]")
    public PageElement rpipricetemplate;

    @Find(by = By.XPath, locator = "//a[contains(text(),'Devices Template')]")
    public PageElement devicestemplate;
    @Find(by = By.XPath, locator = "//a[contains(text(),'SIMO Plans Template')]")
    public PageElement simoplanstemplate;
    @Find(by = By.XPath, locator = "//a[contains(text(),'Custom Plans Template')]")
    public PageElement customplanstemplate;
    @Find(by = By.XPath, locator = "//a[contains(text(),'Accessories')]")
    public PageElement accessories_plm;

    @Find(by = By.XPath, locator = "//td/input[@class='gwt-TextBox nc-field-text-input']")
    public PageElement offeringcode;

//    @Find(by = By.XPath, locator = "//*[@id='9158913236313820302']")
//    public PageElement offeringname;
//    @Find(by = By.XPath, locator = "//tr[1]/td[1]/input[@class='gwt-TextBox nc-field-text-input']")
//    public PageElement offeringname;

//    @Find(by = By.XPath, locator = "//*[@id='9158913236313820302']")
//    public PageElement offeringname;

    @Find(by = By.XPath, locator = "//div[@class='border-wrapper-form-input']/table/tbody/tr/td/table/tbody/tr[1]/td/table/tbody/tr/td[1]/table/tbody/tr[1]/td/table/tbody/tr/td/input[1]")
    public PageElementCollection offeringname;


    @Find(by = By.XPath, locator = "//td/input[@class='gwt-TextBox nc-field-text-input focused-content']")
    public PageElement offeringcodebar;

    @Find(by = By.XPath, locator = " //div[@class='nc-toolbar-cell disable-border gwt-Button-wrapper button_action_id_9157107553913147671_9137007409413676336-wrapper TableCtrl-button-wrapper nc-search-button-wrapper']\n")
    public PageElement offeringsearch;

    @Find(by = By.XPath, locator = " //*[@id=\"9157107424613147577\"]/div/div[4]/div[2]/table/tbody[1]/tr/td[3]/div/div/a/div")
    public PageElement flatofferingresult;

    @Find(by = By.XPath, locator = "//*[@id='9157107424613147577']/div/div[4]/div[2]/table/tbody[1]/tr/td[4]/div/div/a")
    public PageElement conditionset;

    @Find(by = By.XPath, locator = " //*[@id=\"9157107424613147577\"]/div/div[4]/div[2]/table/tbody[1]/tr[1]/td[7]/div/div")
    public PageElement tarrifstartdate;

    @Find(by = By.XPath, locator = "//*[@id=\"9157107424613147577\"]/div/div[4]/div[2]/table/tbody[1]/tr[2]/td[7]/div")
    public PageElement tarrifstartdaterow2;

    @Find(by = By.XPath, locator = "//*[@id=\"9157107424613147577\"]/div/div[4]/div[2]/table/tbody[1]/tr[2]/td[9]/div/div")
    public PageElement lbl_priceSecondRow;

    @Find(by = By.XPath, locator = "//*[@id='9157107424613147577']/div/div[4]/div[2]/table/tbody[1]/tr/td[9]/div/div")
    public PageElement lbl_price2;

    @Find(by = By.XPath, locator = "//*[@id='true']/ul/li[2]/a ")
    public PageElement tab_tabletsWindows;

    @Find(by = By.XPath, locator = "//*[@id='Windows']/div/div[1]/div/table/tbody/tr[1]/td[4]/span")
    public PageElement txt_windowsTabletPrice;

    @Find(by = By.XPath, locator = "//*[@id='Android Watch']/div/div[1]/div/table/tbody/tr[1]/td[4]/span")
    public PageElement lbl_watchesAndroidPrice;

    @Find(by = By.XPath, locator = "//*[@id='Apple Watch']/div/div[1]/div/table/tbody/tr[1]/td[4]/span")
    public PageElement lbl_watchesApplePrice;

    @Find(by = By.XPath, locator = "//*[@id='Android Watch']/div/div[1]/div/table/tbody/tr[1]/td[5]/a")
    public PageElement btn_addAndroidWatches;

    @Find(by = By.XPath, locator = "//*[@id='Apple Watch']/div/div[1]/div/table/tbody/tr[1]/td[5]/a")
    public PageElement btn_addAppleWatches;
    @FindByKey(key = "windowTabletAddBtn")
    public PageElement addwindowstablet;

    @Find(by = By.XPath, locator = "//*[@id='Windows']/div/div[1]/div/table/tbody/tr[1]/td[5]/a")
    public PageElement btn_addWindowsTablet;

    @Find(by = By.XPath, locator = "//*[@id='true']/ul/li[2]/a")
    public PageElement tab_androidWatches;

    @Find(by = By.XPath, locator = "//*[@id='Android Tablets']/div/div[1]/div/table/tbody/tr/td[4]/span")
    public PageElement txt_androidTabletPrice;

    @FindByKey(key = "andriodTabletAddBtn")
    public PageElement addandroidtablet;

    @Find(by = By.XPath, locator = "//*[@id='Android Tablets']/div/div[1]/div/table/tbody/tr/td[5]/a")
    public PageElement btn_addAndroidTablet;

    @Find(by = By.XPath, locator = " //table[@class='roe-table']/tr[5]/td[@class='roe-table-cell item']/input")
    public PageElementCollection tab_tablets;

    @Find(by = By.XPath, locator = "//*[@id='iPad']/div/div[1]/div/table/tbody/tr/td[4]/span")
    public PageElement txt_tabletPrice;

    @Find(by = By.XPath, locator = "//*[@id='true']/ul/li[3]/a")
    public PageElement tab_tabletsAndroid;

    @FindByKey(key = "addipad")
    public PageElement addipad;
    @Find(by = By.XPath, locator = "//div[@class='wrapper_box_selection roe-widget']//div[@id='iPad']//table//tbody//tr//td[5]//a[@role='button']")
    public PageElement btn_addIpad;

    @Find(by = By.XPath, locator = "//span[contains(text(),'O2 Insure Damage Cover for Tablets')]")
    public PageElement btn_insureDamageCoverTablet;

    @Find(by = By.XPath, locator = "//span[contains(text(),'O2 Insure Damage Cover for Smart Watches')]")
    public PageElement o2ensuredamagecoverwatches;

    @Find(by = By.XPath, locator = "//span[contains(text(),'O2 Insure Full Cover for Tablets')]")
    public PageElement btn_ensureFullCoverTablet;

    @Find(by = By.XPath, locator = "//span[contains(text(),'O2 Insure Full Cover for Smart Watches')]")
    public PageElement o2ensurefullcoverwatches;

    @Find(by = By.CssSelector, locator = ".hw-search-filter__search-input input")
    public PageElement txt_phoneSearch;

    @Find(by = By.XPath, locator = "//div[@class='characteristicValues equipment_value_element']/span/select")
    public PageElementCollection saletype;

    @FindByKey(key = "andriodPrice")
    public PageElement Androidprice;
    public PageElementCollection ddl_saleType;
    @Find(by = By.XPath, locator = "//*[@id='Android']/div/div[1]/div/table/tbody/tr/td[4]")
    public PageElement txt_androidPrice;
    @Find(by = By.XPath, locator = "//*[@id='true']/ul/li[2]/a")
    public PageElement tab_android;
    @Find(by = By.XPath, locator = "//*[@id='true']/ul/li[1]/a")
    public PageElement tab_iphone;

    @FindByKey(key = "andriodButton")
    public PageElement Androidaddbutton;

    @Find(by = By.XPath, locator = "//*[@id='paymentInstument']/table/tbody/tr/td[1]")
    public PageElement paymentinstrument;

    @Find(by = By.XPath, locator = "//*[@id=\"paymentInstument\"]/table/tbody/tr/td[2]/select")
    public PageElement newcardselect;

    @Find(by = By.XPath, locator = "//*[@id=\"paymentInstument\"]/table/tbody/tr/td[4]/button")
    public PageElement newcardbutton;
    @Find(by = By.XPath, locator = "//div[@class='wrapper_box_selection roe-widget']//div[@id='Android']//table//tbody//tr//td[5]//a[@role='button']")
    public PageElement btn_androidAdd;

    @Find(by = By.XPath, locator = "//div[@class='wrapper_box_selection roe-widget']//div[@id='Android Watch']//table//tbody//tr//td[5]//a[@role='button']")
    public PageElement btn_addAndroidWatch;

    @Find(by = By.XPath, locator = "//div[@class='wrapper_box_selection roe-widget']//div[@id='Apple Watch']//table//tbody//tr//td[5]//a[@role='button']")
    public PageElement btn_addAppleWatch;

    @Find(by = By.XPath, locator = "//*[@id='paymentInstument']/table/tbody/tr/td[1]")
    public PageElement lbl_paymentInstrument;

    @Find(by = By.XPath, locator = "//*[@id=\"paymentInstument\"]/table/tbody/tr/td[2]/select")
    public PageElement ddl_newCardSelect;

    @Find(by = By.XPath, locator = "//*[@id=\"paymentInstument\"]/table/tbody/tr/td[4]/button")
    public PageElement btn_newCard;

    @Find(by = By.XPath, locator = "//*[@role='toolbar']//*[text()='OK']")
    public PageElement btn_ok;

    @Find(by = By.XPath, locator = "//span[@class='collapsed']/span")
    public PageElement btn_show;

    @Find(by = By.XPath, locator = " //td[@class='GEGUAMFDAJ GEGUAMFDCJ nc-table-cell-ta '][7]")
    public PageElement model;

    @Find(by = By.XPath, locator = " //div[@class='characteristicValues']/div/span/select")
    public PageElementCollection allowanceBundlephones1;


    @Find(by = By.XPath, locator = "//button[@class='gwt-Button button_action_id_9158913560813821940_9137007409413676336 TableCtrl-button nc-search-button']")
    public PageElement search_plm;

    @Find(by = By.XPath, locator = "//button[contains(text(),'Search')]")
    public PageElementCollection search_plm_accessories;

    @Find(by = By.XPath, locator = "//span[@class='roe-table-cell roe-table-body-title']/span[contains(text(),'Upfront Discount')]")
    public PageElement lbl_upfrontDiscount;

    @Find(by = By.XPath, locator = " //*[@id=\"TopTree\"]/div/div/div/div[1]/div/div/div/div/div/div[1]/div[1]/div[1]/div/div[2]/table/tbody/tr/td[1]/table/tbody/tr/td/span[@class='bulkTreeItem bulkTreeItemRoeTreeItem']")
    public PageElement Customplan;

    @Find(by = By.XPath, locator = "//*[@id='listCharacteristicsSelect_9158369203265231897']")
    public PageElementCollection UpfrontDiscountreasonselect;

    @Find(by = By.XPath, locator = "//div[@class='characteristicValues characteristic-invalid-change']/input")
    public PageElement txt_specialCode;

    @Find(by = By.XPath, locator = "//div[@class='characteristicValues characteristic-invalid-change']/input")
    public PageElement txt_justification;

    @Find(by = By.XPath, locator = "//label[contains(text(),'Upfront Discount Amount')]")
    public PageElement lbl_upfrontDiscountAmount;

    @Find(by = By.XPath, locator = "//span[@class='ui-spinner ui-corner-all ui-widget ui-widget-content input-errorHighlight']/input")
    public PageElement txt_upfrontDiscount;

    @Find(by = By.XPath, locator = "//div[@class='characteristicValues characteristic-correct-change']//span[@class='ui-spinner ui-corner-all ui-widget ui-widget-content']/input")
    public PageElement txt_upfrontDiscount2;

    @Find(by = By.XPath, locator = "//span[contains(text(),'O2 Insure Full Cover')][1]")
    public PageElement btn_insureFullCover;

    @Find(by = By.XPath, locator = "//span[contains(text(),'O2 Insure Damage Cover')][1]")
    public PageElement btn_insureDamageCover;

    @Find(by = By.XPath, locator = "//span[contains(text(),'O2 Insure Damage Cover for Smart Watches')][1]")
    public PageElement btn_insureDamageCoverForSmartWatches;

    @Find(by = By.XPath, locator = "//span[contains(text(),'O2 Insure Full Cover for Smart Watches')][1]")
    public PageElement btn_insureFullCoverForSmartWatches;

    @Find(by = By.XPath, locator = "//div[@class='characteristicValues characteristic-invalid-change']/span/select")
    public PageElement ddl_insureFullCoverTermAndConditions;

    @Find(by = By.XPath, locator = "//table[@class='roe-table']/tr[3]/td[@class='roe-table-cell item']/input")
    public PageElementCollection Accessories;
    @Find(by = By.XPath, locator = "//table[@class='roe-table']/tr[6]/td[@class='roe-table-cell item']/input")
    public PageElement mobileBroadBandDevices;
    public PageElementCollection accessories;
    @Find(by = By.XPath, locator = "//*[@id='true']/ul/li[12]/a")
    public PageElement appleWatch;

    @Find(by = By.XPath, locator = " //table[@class='roe-table']/tr[5]/td[@class='roe-table-cell item']/input")
    public PageElementCollection btn_tablets;

    @Find(by = By.XPath, locator = " //table[@class='roe-table']/tr[5]/td[@class='roe-table-cell item']/input")
    public PageElement button_tablets;

    @Find(by = By.XPath, locator = "//input[@aria-label='Regular Phone Number']")
    public PageElement btn_regularPhoneNoRadioOpt;

    @Find(by = By.XPath, locator = "//img[@aria-label='Sorting and Filtering for Offering Name column']")
    public PageElement offeringname_custom;

    @Find(by = By.XPath, locator = "//input[@aria-label='contains']")
    public PageElement offeringname_contains;

    @Find(by = By.XPath, locator = "//button[@class='gwt-Button button_action_id_applygwt-uid-109 TableCtrl-button gwt-ParCtrl-btn gwt-ParCtrl-btn-apply']")
    public PageElement offeringname_apply;


    @Find(by = By.XPath, locator = "//div[@class='roe-widget-content contracts__button_disabled']/table/tbody/tr/td[3]")
    public PageElementCollection lbl_price;

    @Find(by = By.XPath, locator = "//div[@class='characteristicValues']//div//select/option")
    public PageElementCollection ele_allowanceBundleList;

    private final List<String> txt_allowanceBundleList = new ArrayList<>();

    @Find(by = By.CssSelector, locator = "div.refsel_name")
    public PageElementCollection regularPhoneNumbers;

    @Find(by = By.XPath, locator = "//table[@class='roe-table']")
    public PageElement servicesFeaturesMainTable;

    @Find(by = By.XPath, locator = "//table[@class='roe-table']/tbody[@class='roe-table-body']/tr/td[2]")
    public PageElementCollection simOnlyAndSimOnlyDataList;
    @Find(by = By.XPath, locator = "//div[@class='tab_filter tab_filter-hardware tab_filter-equipment']/ul/li/a")
    public PageElementCollection equipmentList;

    @Find(by = By.XPath, locator = "//span[@class='roe-table-cell roe-table-body-title']/span[contains(text(),'Upfront Discount')]")
    public PageElement UpfrontDiscount;

    @Find(by = By.XPath, locator = "//div[@class='characteristicValues characteristic-invalid-change']/input")
    public PageElement specialcode;

    @Find(by = By.XPath, locator = "//div[@class='characteristicValues characteristic-invalid-change']/input")
    public PageElement justification;

    @Find(by = By.XPath, locator = "//div[@class='roe-table offer_characteristic_wrapper offering-editor-generic-cwidget']//div//div//tr[@class='characteristic-item force_enabled characteristic-invalid']//td//label[contains(text(),'Justification')]")
    public PageElement justificationlevel;

    @Find(by = By.XPath, locator = "//*[@id='gwt-uid-6063']")
    public PageElement upfrontdiscount;

    @Find(by = By.XPath, locator = "/html/body/div[2]/div[2]/div[2]/div[2]/div[2]/table/tbody/tr[1]/td[2]/div/div/div[3]/div[3]/div/div[3]/table/tbody/tr/td/div/div[2]/table/tbody/tr/td/div/div/div/div/div[2]/div[1]/div/div[2]/div/div[7]/div[3]/table/tbody/tr/td/div/div/table/tbody/tr/td/div/div/div/div/div/div[1]/div/div/div/div[2]/div/div[3]/div/div/tr[4]/td[2]/div/span/span/a[1]/span[1]")
    public PageElement upfrontdiscountarrow;
    @Find(by = By.Id, locator = "90081009")
    public PageElement homeDelivery;

    @Find(by = By.XPath, locator = "//table[@class='parameters']/tbody/tr[2]/td[2]/div/span/span/input")
    public PageElement txt_upfrontGbp;

    @Find(by = By.XPath, locator = "//table[@class='parameters']/tbody/tr[3]/td[2]/div/span/span/input")
    public PageElement txt_months;

    @Find(by = By.CssSelector, locator = "div[class='clearfix status expandable equipment_order_items_container']")
    public PageElement lbl_equipmentPanel;

    @Override
    public boolean isPageDisplayed() {
        return this.connectivityColumnHeader.isDisplayed(FIVE_SECS)
                && this.connectivityColumnHeader.getText().contains("PAYM Connectivity")
                && this.servicesFeaturesMainTable.isDisplayed(FIVE_SECS)
                && this.simOnlyAndSimOnlyDataList.get(0).isDisplayed(FIVE_SECS);
    }

    public void getSimOnlyAndSimOnlyDataListOptions(String tariff) {
        boolean flag = false;
        for (int i = 0; i < simOnlyAndSimOnlyDataList.size(); i++) {
            if (simOnlyAndSimOnlyDataList.get(i).getText().equals(tariff)) {
                assertEquals(tariff, simOnlyAndSimOnlyDataList.get(i).getText());
                flag = true;
                simOnlyAndSimOnlyDataList.get(i).click();
            }
        }
        if (!flag) {
            fail("The expected Offering Name (Sim plan) that was taken from the input data does NOT exist in the system.");
        }
    }

    public List<ServicesAndFeaturesRow> getO2SimOnlyOptions() {
        List<ServicesAndFeaturesRow> servicesAndFeaturesRows = new ArrayList<>();
        PageElementCollection options = this.widgetsRoot.asList().get(2)
                .findChildren(By.CssSelector, ".roe-table-row.offering_description_available");

        assertThat(options.size())
                .withFailMessage("There are no options displayed for O2 Sim Only!")
                .isGreaterThanOrEqualTo(1);

        for (PageElement option : options.asList()) {
            servicesAndFeaturesRows.add(new ServicesAndFeaturesRow(option));
        }
        return servicesAndFeaturesRows;
    }

    public ServicesAndFeaturesRow getO2SimOnlyOptionByName(String optionName) {
        List<ServicesAndFeaturesRow> options = getO2SimOnlyOptions();

        ServicesAndFeaturesRow option = options.stream()
                .filter(o -> o.name.getText().toLowerCase(Locale.ROOT).contains(optionName.toLowerCase(Locale.ROOT)))
                .findFirst()
                .orElse(null);

        assertThat(option)
                .withFailMessage(
                        MessageFormat.format(
                                "Could not find an O2 Sim Only option with name: ''{0}''!", optionName))
                .isNotNull();

        return option;
    }

    public List<ServicesAndFeaturesRow> getO2SimOnlyDataOptions() {
        List<ServicesAndFeaturesRow> servicesAndFeaturesRows = new ArrayList<>();
        PageElementCollection options = this.widgetsRoot.asList().get(2)
                .findChildren(By.CssSelector, ".roe-table-row.offering_description_available");

        assertThat(options.size())
                .withFailMessage("There are no options displayed for O2 Sim Only!")
                .isGreaterThanOrEqualTo(1);

        for (PageElement option : options.asList()) {
            servicesAndFeaturesRows.add(new ServicesAndFeaturesRow(option));
        }

        return servicesAndFeaturesRows;
    }

    public ServicesAndFeaturesRow getO2SimOnlyDataOptionByName(String optionName) {
        ServicesAndFeaturesRow option = getO2SimOnlyDataOptions().stream()
                .filter(o -> o.name.getText().toLowerCase(Locale.ROOT).contains(optionName.toLowerCase(Locale.ROOT)))
                .findFirst()
                .orElse(null);

        assertThat(option)
                .withFailMessage(
                        MessageFormat.format(
                                "Could not find an O2 Sim Only Data option with name: ''{0}''!", optionName))
                .isNotNull();

        return option;
    }
}
