package com.o2.stepdefs;

import com.google.inject.Inject;
import com.nttdata.cinnamon.logging.Logger;

public abstract class BaseStep {
    @Inject
    public Logger logger;
}
