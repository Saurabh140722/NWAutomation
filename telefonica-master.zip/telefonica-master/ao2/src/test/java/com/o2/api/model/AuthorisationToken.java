package com.o2.api.model;

public class AuthorisationToken {
    public String access_token;

    public String token_type;

    public int expires_in;
}
