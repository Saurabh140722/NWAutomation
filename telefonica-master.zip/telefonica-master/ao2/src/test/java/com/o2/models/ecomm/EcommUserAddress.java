package com.o2.models.ecomm;

import java.text.MessageFormat;

public class EcommUserAddress {

    public String type;
    public String houseNo;
    public String street;
    public String county;
    public String city;
    public String postcode;
    public String country;

    @Override
    public String toString() {
        return MessageFormat.format("Login eComm User Address Details:" +
                        "\n\tType:\t\t\t{0}" +
                        "\n\tHouseNo:\t\t\t{1}" +
                        "\n\tStreet:\t\t{2}" +
                        "\n\tCounty:\t\t{3}" +
                        "\n\tCity:\t\t\t{4}" +
                        "\n\tPostcode:\t\t\t{5}" +
                        "\n\tCountry:\t\t{6}" ,
                this.type,
                this.houseNo,
                this.street,
                this.county,
                this.city,
                this.postcode,
                this.country

        );
    }
}
