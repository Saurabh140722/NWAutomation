package com.o2.acceptancetests.ecare;

import com.google.inject.Inject;
import com.google.inject.Injector;
import com.nttdata.cinnamon.driver.Browser;

public class BrowserUtil {
    @Inject
    Injector injector;

    private static BrowserUtil INSTANCE;

    private BrowserUtil() {}

    public static Browser getBrowser() {
        return instance().injector.getInstance(Browser.class);
    }

    public static BrowserUtil instance() {
        if(INSTANCE == null) {
            INSTANCE = new BrowserUtil();
        }

        return INSTANCE;
    }
}