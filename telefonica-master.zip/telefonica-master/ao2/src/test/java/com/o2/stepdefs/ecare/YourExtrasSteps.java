package com.o2.stepdefs.ecare;

import static org.assertj.core.api.Assertions.assertThat;

import java.text.MessageFormat;
import java.util.List;

import com.google.inject.Inject;
import com.nttdata.cinnamon.cache.Context;
import com.nttdata.cinnamon.driver.Browser;
import com.o2.models.ecare.Extra;
import com.o2.pages.ecare.YourExtrasPage;
import com.o2.stepdefs.BaseStep;
import com.o2.core.util.Common;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class YourExtrasSteps extends BaseStep {
	private final YourExtrasPage yourExtrasPage;
	private final Browser browser;
	private final Common common;
	// private String title;
	private final VerifyPage verifyPage;
	private final Context context;

	@Inject
	public YourExtrasSteps(final YourExtrasPage yourExtrasPage, final Browser browser, final Common common,
						   final VerifyPage verifyPage, final Context context) {
		this.yourExtrasPage = yourExtrasPage;
		this.browser = browser;
		this.common = common;
		this.verifyPage = verifyPage;
		this.context = context;
	}

	@Then("Your Extras page opens successfully")
	public void your_extras_page_opens_successfully() {
		this.logger.info("** Waiting for Your Extra page to open ...");
		this.browser.setImplicitWait(5);

		assertThat(this.yourExtrasPage.isPageDisplayed()).withFailMessage("Your Extra page not displayed!").isTrue();

		this.logger.info("** Your Extra page opens!");
	}

	@When("I select extra")
	public void i_select_extra() {
		this.logger.info("*Select extra on page is displayed ...");
		assertThat(this.yourExtrasPage.getAllExtra().size() > 0).withFailMessage("Extras are not displayed!").isTrue();

		List<Extra> extraList = this.yourExtrasPage.getAllExtra();
		extraList.get(0).thisExtraButton.click();
		this.context.set("SelectedExtra", extraList);
		this.browser.setImplicitWait(10);

		if (this.verifyPage.digitOne.isDisplayed()) {
			this.verifyPage.digitOne.click();
			this.verifyPage.digitOne.setValue("999999");
			this.verifyPage.continueButton.click();
		}

	}

	@Then("I verify redeem this extra and Cancel button is enable for added extra option")
	public void i_verify_redeem_this_extra_and_cancel_button_is_enable_for_added_extra_option() {
		this.logger.info("* Ready to redeem tab open ...");
		this.browser.refresh();
		this.browser.setImplicitWait(5);
		List<Extra> addedExtra = (List<Extra>) this.context.get("SelectedExtra");

		Extra extra = this.yourExtrasPage.getAllReadyToRedeemExtra().stream()
				.filter(u -> u.titleText.equals(addedExtra.get(0).titleText)).findFirst().orElse(null);

		// TODO: probably worth to move assertions out of here and keep it in test
		assertThat(extra).withFailMessage(
						MessageFormat.format("Could not find a added extra with title : ''{0}'' in redeem to ready tab",
								addedExtra.get(0).titleText))
				.isNotNull();

		assertThat(extra.thisExtraButton.isEnabled()).withFailMessage("Redeem this extra button not enable!").isTrue();
		assertThat(extra.cancelLink.isEnabled()).withFailMessage("Cancel link not enable!").isTrue();

	}

	@And("^I select extra '(.*)' perk$")
	public void i_select_extra_free_perk(String freePerk) {
		this.logger.info("*Select extra on page is displayed ...");
		assertThat(this.yourExtrasPage.getAllFreeExtra().size() > 0).withFailMessage("Extras are not displayed!").isTrue();
		List<Extra> extraList = this.yourExtrasPage.getAllFreeExtra();
		this.context.set("SelectedFreeExtra", extraList);
		Extra extra=this.yourExtrasPage.getAllFreeExtra().stream().filter(u->u.freePrice.getText().trim().contains(freePerk)).findAny().orElse(null);
		extra.thisExtraButton.click();

		}
	}


