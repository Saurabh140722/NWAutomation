package com.o2.stepdefs.csrd;

import com.google.inject.Inject;
import com.o2.pages.csrd.CreateAccessForYourTicketPopupPage;
import com.o2.pages.csrd.TicketsPage;
import com.o2.stepdefs.BaseStep;
import com.o2.util.Common;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

import static org.assertj.core.api.Assertions.assertThat;

public class TicketsSteps extends BaseStep {
    private final Common common;
    private final TicketsPage ticketsPage;
    private final CreateAccessForYourTicketPopupPage createAccessForYourTicketPopupPage;

    @Inject
    public TicketsSteps(final Common common,
                        final TicketsPage ticketsPage,
                        final CreateAccessForYourTicketPopupPage createAccessForYourTicketPopupPage) {
        this.common = common;
        this.ticketsPage = ticketsPage;
        this.createAccessForYourTicketPopupPage = createAccessForYourTicketPopupPage;
    }

    @Then("^Tickets page opens successfully$")
    public void tickets_page_opens_successfully() {
        assertThat(this.ticketsPage.isPageDisplayed())
                .withFailMessage("Tickets page not displayed!")
                .isTrue();
    }

    @When("^I create an 'Access for you' ticket$")
    public void i_create_access_for_my_ticket() {
        this.ticketsPage.createAccessForYourTicketButton.click();

        assertThat(this.createAccessForYourTicketPopupPage.isPageDisplayed())
                .withFailMessage("'Create Access For Your Ticket' popup not displayed!")
                .isTrue();

        this.createAccessForYourTicketPopupPage.customerConsentProvided.asSelect().selectByText("Yes");
        this.createAccessForYourTicketPopupPage.setContactName();
         this.createAccessForYourTicketPopupPage.setNomineeContact();
        this.createAccessForYourTicketPopupPage.reasonForReview.setValue("Automation Testing");
        this.createAccessForYourTicketPopupPage.initiatedBy.asSelect().selectByText("Customer");
        this.createAccessForYourTicketPopupPage.setReportedBy();
        this.createAccessForYourTicketPopupPage.createButton.click();

        this.common.waitForLoadingToComplete(12, 1);
    }
}
