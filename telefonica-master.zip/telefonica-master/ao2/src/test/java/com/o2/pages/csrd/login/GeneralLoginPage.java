package com.o2.pages.csrd.login;

import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.o2.pages.BasePage;

public class GeneralLoginPage extends BasePage {
	@Find(by = By.CssSelector, locator = "#loginnt_button > div > a")
	public PageElement logAsNttButton;

	@Override
	public PageElement getPageCheckElement() {
		return this.logAsNttButton;
	}

}