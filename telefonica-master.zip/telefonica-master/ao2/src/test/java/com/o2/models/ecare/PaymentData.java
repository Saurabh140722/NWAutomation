package com.o2.models.ecare;

import com.google.inject.Inject;
import com.nttdata.cinnamon.cache.Context;
import com.nttdata.cinnamon.file.json.JsonParser;
import com.nttdata.cinnamon.file.reader.Reader;
import com.nttdata.cinnamon.logging.Logger;

import java.text.MessageFormat;
import java.util.List;
import java.util.Objects;

import static org.assertj.core.api.Assertions.assertThat;

public class PaymentData {
    private final Logger logger;
    private final List<PaymentDetails> userBankAccountDetail;
    private final Context context;

    @Inject
    public PaymentData(final Logger logger,
                             final Reader reader,
                             final JsonParser jsonParser, Context context) {
        this.logger = logger;
        this.context = context;
        // TODO Move this logic in to common function
        String env = System.getProperty("env");
        this.context.set("env", env);
        String dataLoginFilePath = System.getProperty("user.dir") + "\\src\\test\\resources\\data\\ecare\\" + env + "\\bank_details.json";
        String data = reader.readFileAsString(dataLoginFilePath, false);
        this.userBankAccountDetail = jsonParser.toObjList(data, PaymentDetails.class);
    }

    public PaymentDetails getPaymentDetails() {
        PaymentDetails paymentDetail = this.userBankAccountDetail.stream()
                .findFirst()
                .orElse(null);

        assertThat(paymentDetail).withFailMessage(
                "Could not find a paymnet detail !")
                .isNotNull();

        this.logger.info(MessageFormat.format("Bank detail for bank type: {0}:\n",
                Objects.requireNonNull(paymentDetail).toString()));

        return paymentDetail;
    }
}
