package com.o2.models.ecare;

import com.nttdata.cinnamon.driver.controls.PageElement;

public class Extra {
	public PageElement title;
	public PageElement price;
	public PageElement thisExtraButton;
	public PageElement cancelLink;
	public PageElement freePrice;
	public String free;
	public String titleText;

	public Extra() {

	}

	public Extra(PageElement title, PageElement price, PageElement thisExtraButton) {
		this.title = title;
		this.price = price;
		this.thisExtraButton = thisExtraButton;

		this.titleText = this.title.getText().toString().trim();
	}
	
	public Extra(PageElement freePrice, PageElement thisExtraButton) {
		this.freePrice=freePrice;
		this.thisExtraButton = thisExtraButton;
	}

	public Extra(PageElement title, PageElement price, PageElement thisExtraButton, PageElement cancelLink) {
		this.title = title;
		this.price = price;
		this.thisExtraButton = thisExtraButton;
		this.cancelLink = cancelLink;

		this.titleText = this.title.getText().toString().trim();
	}
	public Extra(PageElement title, PageElement price,String free,PageElement thisExtraButton, PageElement cancelLink) {
		this.title = title;
		this.price = price;
		this.free=free;
		this.thisExtraButton = thisExtraButton;
		this.cancelLink = cancelLink;

		this.titleText = this.title.getText().toString().trim();
	}


	@Override
	public boolean equals(Object classobject) {
		if (classobject == this)
			return true;
		if (!(classobject instanceof Extra))
			return false;

		Extra extra = (Extra) classobject;
		return extra.title.equals(this.title);

	}

}
