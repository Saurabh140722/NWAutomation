package com.o2.pages.csrd;

import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.FindByKey;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.nttdata.cinnamon.driver.controls.PageElementCollection;
import com.o2.pages.BasePage;

public class CreditCheckPage extends BasePage {
    @Find(by = By.Id, locator = "ui-id-3")
    public PageElement creditCheckPopup;

    @Find(by = By.CssSelector, locator = "input[type='checkbox']")
    public PageElementCollection checkboxes;

    @FindByKey(key ="validationBtn")
    public PageElement onlineValidationButtonphones;

    @Find(by = By.XPath, locator = "//button[contains(text(),'Continue anyway')]")
    public PageElement continueAnywaysBtn;

    @Find(by = By.XPath, locator = "//span[contains(text(),'Continue anyway')]")
    public PageElement continueAnywaysBtn1;




    //ad2
//    @Find(by = By.CssSelector, locator = ".ui-button.ui-widget.ui-state-default.ui-corner-all.ui-button-text-only")
//    public PageElement confirmAndContinueButton;

    //ad1

//    @Find(by = By.XPath, locator = "//*[@role='toolbar']/button[text()='Confirm and continue']")
//    public PageElement confirmAndContinueButton;


    @Find(by = By.XPath, locator = "/html/body/div[10]/div/div/div[3]/div/button[1]")
    public PageElement confirmAndContinueButton;


    @Find(by = By.LinkName, locator = "APPLICATION")
    public PageElement application;

    @Find(by = By.LinkName, locator = "PAYMENT DETAILS")
    public PageElement paymentDetails;

    @Find(by = By.Id, locator = "cardIFrame")
    public PageElement cardVerificationFrame;

    @Find(by = By.Id, locator = "cardName")
    public PageElement cardName;

    @Find(by = By.Id, locator = "cardNumber")
    public PageElement cardNumber;

    @Find(by = By.Id, locator = "expiryDateMonthInput")
    public PageElement expiryDateMonth;

    @Find(by = By.Id, locator = "expiryDateYearInput")
    public PageElement expiryDateYear;

    @Find(by = By.Id, locator = "csc")
    public PageElement cvv;

    @Find(by = By.Id, locator = "pre-copyBtnMc")
    public PageElement onlineValidationButton;

    @Find(by = By.Id, locator = "bConfirmPaymentButton")
    public PageElement paymentConfirmButton;


    @Find(by = By.Id, locator = "messageDiv")
    public PageElement validationMessageErrors;

    @Find(by = By.Id, locator = "cardDiv")
    public PageElement validationMessageSuccess;

    @Override
    public PageElement getPageCheckElement() {
        return this.application;
    }

    public PageElement getConfirmMonthlyCostCheckbox() {
        return this.checkboxes.asList().get(1);
    }

    public PageElement getConfirmNoChangesInCircumstancesCheckbox() {
        return this.checkboxes.asList().get(2);
    }
}
