package com.o2.stepdefs.ecare;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.text.MessageFormat;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import com.o2.stepdefs.BaseStep;
import com.o2.util.Common;
import org.apache.commons.lang.NotImplementedException;

import com.google.inject.Inject;
import com.google.inject.Injector;
import com.nttdata.cinnamon.cache.Context;
import com.nttdata.cinnamon.conf.Env;
import com.nttdata.cinnamon.db.Db;
import com.nttdata.cinnamon.db.DbResult;
import com.nttdata.cinnamon.logging.Logger;
import com.o2.api.OrderProcess;
import com.o2.core.data.UserData;
import com.o2.models.ecare.EcareUser;
import com.o2.models.ecare.EcareUserData;
import com.o2.models.ecare.LoginCsrUser;
import com.o2.models.ecare.LoginCsrUserData;
import com.o2.models.ecare.PlanType;
import com.o2.models.ecare.Role;
import com.o2.pages.BasePage;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class CommonSteps extends BaseStep {
    @Inject
    Injector injector;

    private final Logger logger;
    private final Db db;
    private final Common common;
    private final LoginCsrUserData loginCsrUserData;
    private final UserData userData;
    private final EcareUserData ecareUserData;
    private final Context context;
    private final OrderProcess orderProcess;


    @Inject
    public CommonSteps(final Logger logger, final Db db, final Common common,
                       final LoginCsrUserData loginCsrUserData, final UserData userData,
                       final EcareUserData ecareUserData,
                       final Context context, final OrderProcess orderProcess) {
        this.logger = logger;
        this.db = db;
        this.common = common;
        this.loginCsrUserData = loginCsrUserData;
        this.userData = userData;
        this.ecareUserData = ecareUserData;
        this.context = context;
        this.orderProcess = orderProcess;
    }

    @Then("^eCare '(.*)' page is displayed$")
    public void ecare_page_is_displayed(String pageName) throws IOException {
        this.logger.info(MessageFormat.format("*** Wait for page ''{0}'' to load ...", pageName));

        List<String> pages = this.common.getAllEcarePages();
        String thisPage = pages.stream()
                .filter(p -> p.toLowerCase(Locale.ROOT)
                        .contains(MessageFormat.format("{0}page", pageName.replace(" ", "").toLowerCase(Locale.ROOT))))
                .findFirst().orElse(null);

        Class<?> pageClass = null;
        try {
            pageClass = Class.forName(thisPage);
        } catch (ClassNotFoundException e) {
            this.logger.error(e.getMessage());
            e.printStackTrace();
        }

        assertThat(pageClass)
                .withFailMessage(MessageFormat
                        .format("Could not find a page object defined whose name contains: ''{0}''!", pageName))
                .isNotNull();

        BasePage page = (BasePage) this.injector.getInstance(pageClass);

        assertThat(page.isPageDisplayed())
                .withFailMessage(MessageFormat.format("''{0}'' page not displayed!", pageName)).isTrue();

        this.logger.info(MessageFormat.format("*** Page ''{0}'' has loaded and is displayed!\n", pageName));
    }

    @Then("^CSRD '(.*)' page is displayed$")
    public void csrd_page_is_displayed(String pageName) throws IOException {
        this.logger.info(MessageFormat.format("*** Wait for page ''{0}'' to load ...", pageName));

        List<String> pages = this.common.getAllCsrdPages();
        String thisPage = pages.stream()
                .filter(p -> p.toLowerCase(Locale.ROOT)
                        .contains(MessageFormat.format("{0}page", pageName.replace(" ", "").toLowerCase(Locale.ROOT))))
                .findFirst().orElse(null);

        Class<?> pageClass = null;
        try {
            pageClass = Class.forName(thisPage);
        } catch (ClassNotFoundException e) {
            this.logger.error(e.getMessage());
            e.printStackTrace();
        }

        assertThat(pageClass)
                .withFailMessage(MessageFormat
                        .format("Could not find a page object defined whose name contains: ''{0}''!", pageName))
                .isNotNull();

        BasePage page = (BasePage) this.injector.getInstance(pageClass);

        assertThat(page.isPageDisplayed())
                .withFailMessage(MessageFormat.format("''{0}'' page not displayed!", pageName)).isTrue();

        this.logger.info(MessageFormat.format("*** Page ''{0}'' has loaded and is displayed!\n", pageName));
    }

    // TODO: this exists in csrd
//    @Given("^I have login details for (?:a|an) '(.*)' account$")
//    public void i_have_login_details_for_account_type_ecare(String accountRole) {
//        this.logger.info("** Attempt to retrieve CSR login test data ...");
//
//        String thisAccountRole = accountRole.toUpperCase().replace(" ", "_");
//        Role role = com.nttdata.cinnamon.util.Common.convertToEnum(thisAccountRole, Role.class);
//        LoginCsrUser loginCsrUser = this.loginCsrUserData.getLoginDetailsByRole(role);
//
//        this.context.set("loginUser", loginCsrUser);
//
//        this.logger.info("** CSR Login test data retrieved!\n");
//    }

//    @Given("^I have details of an existing user which '(can|must|must not)' be active and '(is|is not)' cancelled$")
//    public void i_have_details_of_a_customer_with_basic(String activeOrNot, String cancelledOrNot) {
//        retrieveUser(activeOrNot, cancelledOrNot, null);
//    }

//    @Given("^I have details of an existing user which '(can|must|must not)' be active and '(is|is not)' cancelled and user:$")
//    public void i_have_details_of_a_customer_with_extended(String activeOrNot, String cancelledOrNot, DataTable table) {
//        retrieveUser(activeOrNot, cancelledOrNot, table);
//    }

    private void retrieveUser(String activeOrNot, String cancelledOrNot, DataTable table) {
        String isActive = "";
        String hasGoodwill = "";
        String errorMessage = "";
        int isCancelled = cancelledOrNot.equals("is") ? 1 : 0;

        this.db.connect(Env.get().settingsProperty("db_connection"));

        switch (activeOrNot) {
            case "can":
                // do nothing - we accept both active and not active users
                break;
            case "must":
                isActive = MessageFormat.format("and processed = {0} ", 1);
                break;
            case "must not":
                isActive = MessageFormat.format("and processed = {0} ", 0);
                break;
            default:
                throw new IllegalArgumentException();
        }

        if (table != null) {
            List<Map<String, String>> rows = table.asMaps(String.class, String.class);
            if (rows.get(0).get("has_goodwill") != null) {
                hasGoodwill = rows.get(0).get("has_goodwill").equals("yes")
                        ? MessageFormat.format("and hasGoodwill = {0} ", 1)
                        : MessageFormat.format("and hasGoodwill = {0} ", 0);
                errorMessage += MessageFormat.format("has Goodwill: ''{0}'' ", rows.get(0).get("has_goodwill"));
            }
        }

        String query = MessageFormat.format(
                "SELECT * FROM ResidentialAccount WHERE used = 0 and isCancelled = {0} {1}{2}order by id desc",
                isCancelled, isActive, hasGoodwill);

        DbResult result = this.db.query(query);

        assertThat(result.get().size()).withFailMessage(MessageFormat.format(
                "Could not find any test user data that match: active = ''{0}'', cancelled = ''{1}'', extra = ''{2}''",
                activeOrNot, cancelledOrNot, errorMessage)).isGreaterThanOrEqualTo(1);

        UserData userData = this.userData.generate(result);
        this.context.set("residentialUserAccountData", userData.userDataModel);
        this.logger.info(MessageFormat.format("Customer test data:\n{0}", userData.toString()));
    }
//    @Given("^I have details of an existing user which '(is|is not)' used and '(does|does not)' have A4U opened tickets$")
//    public void i_have_details_of_a_customer_with2(String usedOrNot, String ticketsOrNot) {
//        int isUsed = usedOrNot.equals("is") ? 1 : 0;
//        int hasTickets = ticketsOrNot.equals("does") ? 1 : 0;
//
//        this.db.connect(Env.get().settingsProperty("db_connection"));
//
//        DbResult result = this.db.query(MessageFormat.format(
//                "SELECT * FROM ResidentialAccount WHERE used = {0} and hasTickets = {1} order by id desc", isUsed,
//                hasTickets));
//
//        assertThat(result.get().size()).withFailMessage(
//                        MessageFormat.format("Could not find any test user data which ''{0}'' used and ''{1}'' have tickets!",
//                                usedOrNot, ticketsOrNot))
//                .isGreaterThanOrEqualTo(1);
//
//        UserData userData = this.userData.generate(result);
//        this.context.set("residentialUserAccountData", userData.userDataModel);
//        this.logger.info(MessageFormat.format("Customer test data:\n{0}", userData.toString()));
//    }

    @Given("^I have login details for an eCare '(new|existing)' account with '(.*)' plan$")
    public void i_have_ecare_login_details(String accountType, String planType) {
        this.logger.info("** Attempt to retrieve eCare login test data ...");

        // // TODO: when needed implement the new case. if this won't be needed remove
        // the parameter from this step
        switch (accountType) {
            case "existing":

                String thisplanType = planType.toUpperCase().replace(" ", "_");
                PlanType plantype = com.nttdata.cinnamon.util.Common.convertToEnum(thisplanType, PlanType.class);
                EcareUser ecareUser = this.ecareUserData.getEcareLoginDetails(plantype);
                this.context.set("ecareLoginData", ecareUser);
                this.logger.info("** eCare Login test data retrieved!\n");
                break;

            case "new":
            default:
                throw new NotImplementedException(MessageFormat
                        .format("Option ''{0}'' for eCare login details has not been implemented yet!", accountType));
        }

        this.logger.info("** eCare Login test data retrieved!\n");
    }
}
