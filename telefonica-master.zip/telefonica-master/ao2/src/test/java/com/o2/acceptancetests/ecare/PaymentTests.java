package com.o2.acceptancetests.ecare;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(
        plugin = { "com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:", "summary" },
        glue = { "com.o2.stepdefs", "com.o2.hooks" },
        features = "src/test/resources/features",
        tags = "@usePayment"
)
public class PaymentTests {
    @BeforeClass
    public static void setup() {
        // Any BeforeAll logic ...
    }

    @AfterClass
    public static void teardown() {
        // DriverUtil.getDriver().close();
        BrowserUtil.getBrowser().close();
    }
}