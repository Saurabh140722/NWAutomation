package com.o2.stepdefs.csrd;

import com.google.inject.Inject;
import com.nttdata.cinnamon.cache.Context;
import com.nttdata.cinnamon.driver.Browser;
import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.nttdata.cinnamon.driver.controls.PageElementCollection;
import com.nttdata.cinnamon.logging.Logger;
import com.o2.pages.csrd.navigation.CancelOrder;
import com.o2.stepdefs.BaseStep;
import com.o2.util.Common;
import io.cucumber.java.en.And;
import io.cucumber.java.en.When;
import org.openqa.selenium.WebDriver;

import java.text.MessageFormat;

import static org.assertj.core.api.Assertions.assertThat;

public class CancelOrderSteps extends BaseStep {
    private final CancelOrder cancelOrder;
    private final Logger logger;
    private final Browser browser;
    private final Common common;
    private final Context context;

    @Inject
    public CancelOrderSteps(final CancelOrder cancelOrder, final Logger logger,
                            final Browser browser,
                            final Common common,
                            final Context context) {
        this.cancelOrder = cancelOrder;
        this.logger = logger;
        this.browser = browser;
        this.common = common;
        this.context = context;
    }

    @When("^I click on Back CSR_Desktop button$")
    public void i_backTo_CSR_Desktop_button() {
        this.browser.getWebDriver(WebDriver.class).switchTo().defaultContent();
        this.cancelOrder.backtoCsrDesktopButton.click();
        this.browser.switchToDefault();
    }

    @And("^I select on existing order with status as '(.*)'$")
    public void i_select_on_existing_Order(String orderStatus) {
        this.logger.info(MessageFormat.format("*** Search the order status: {0}...", orderStatus));
        boolean isOrderStatusFound = false;

        for (PageElement tableRows : this.cancelOrder.tableRows.asList()) {
            PageElementCollection tableDetail = tableRows.findChildren(By.Tag, "td");
            PageElement status = tableDetail.asList().get(3);
            PageElement checkbox = tableDetail.asList().get(0);

            if ((status.isDisplayed()) && (status.getText().contains(orderStatus))) {
                isOrderStatusFound = true;
                checkbox.click();
                break;
            }
        }

        assertThat(isOrderStatusFound)
                .withFailMessage(
                        MessageFormat.format("Could not find an order whose status is: ''{0}''!",
                                orderStatus))
                .isTrue();

        this.logger.info(MessageFormat.format("*** Found order with status: ''{0}'' ...", isOrderStatusFound));
    }

    @And("^I cancel the order$")
    public void i_cancel_order() {
        this.logger.info("*** Attempting to cancel order ...");
        this.browser.setImplicitWait(2);
        this.cancelOrder.cancelOrderLink.click();
        this.cancelOrder.textBoxAreaForReasonDesc.click();
        this.cancelOrder.textBoxAreaForReasonDesc.setValue("Order is placed wrongly");
        this.cancelOrder.textBoxAreaForInteractionDesc.click();
        this.cancelOrder.textBoxAreaForInteractionDesc.setValue("Test");
        this.cancelOrder.continueBtn.click();
        this.browser.restoreImplicitWait();

        // TODO: @Rahul - please add here the assertion that checks order has been indeed canceled

        this.logger.info("*** Order has been canceled!");
    }

    @And("^I should see the order status as '(.*)'$")
    public void i_should_see_orderStatus_expired(String criteria) {
        this.common.waitForLoadingToComplete(60, 2, true);

        this.logger.info(MessageFormat.format("*** Search the order status: {0}...", criteria));

        for (PageElement tableRows : this.cancelOrder.tableRows.asList()) {

            PageElementCollection tableDetail = tableRows.findChildren(By.Tag, "td");

            PageElement status = tableDetail.asList().get(3);

            this.logger.info(MessageFormat.format("*** Search the order status on ui: {0}...", status.getText()));

            if ((status.isDisplayed()) && (status.getText().contains(criteria))) {
                assertThat(status.isDisplayed())
                        .withFailMessage("Expired order status is displayed")
                        .isTrue();
                break;
            } else {
                assertThat(status.isDisplayed())
                        .withFailMessage("Expired order status is not displayed")
                        .isFalse();
            }
        }
    }
}
