package com.o2.models.csrd;

import com.google.inject.Inject;
import com.nttdata.cinnamon.file.json.JsonParser;
import com.nttdata.cinnamon.file.reader.Reader;
import com.nttdata.cinnamon.logging.Logger;

import java.text.MessageFormat;
import java.util.List;
import java.util.Objects;

import static org.assertj.core.api.Assertions.assertThat;

public class EcareUserData {
    private final Logger logger;
    private final List<EcareUser> loginEcareUsers;

    @Inject
    public EcareUserData(final Logger logger,
                         final Reader reader,
                         final JsonParser jsonParser) {
        this.logger = logger;

        // TODO: @Anup: let's pull this from a Constant class/config file
        String dataLoginFilePath = System.getProperty("user.dir") + "\\src\\test\\resources\\data\\csrd\\login_accounts.json";
        String data = reader.readFileAsString(dataLoginFilePath, false);

        this.loginEcareUsers = jsonParser.toObjList(data, EcareUser.class);
    }

    public EcareUser getEcareLoginDetails(PlanType planType) {
        EcareUser eCareUser = this.loginEcareUsers.stream()
                .filter(u -> u.planType.equals(planType.toString()))
                .findFirst()
                .orElse(null);

        assertThat(eCareUser).withFailMessage(
                MessageFormat.format(
                        "Could not find a Login eCare User data with Plan Type: ''{0}''", planType))
                .isNotNull();

        this.logger.info(MessageFormat.format("eCare Login details for plan type: {0}:\n{1}",
                planType.toString(), Objects.requireNonNull(eCareUser).toString()));

        return eCareUser;
    }
}
