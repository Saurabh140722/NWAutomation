package com.o2.stepdefs.ecomm;

import com.google.inject.Inject;
import com.nttdata.cinnamon.conf.Env;
import com.nttdata.cinnamon.driver.Browser;
import com.nttdata.cinnamon.webdriver.util.ReadyState;
import com.o2.core.util.Retry;
import com.o2.pages.ecomm.SignInPage;
import io.cucumber.java.en.Given;

import java.text.MessageFormat;

import static com.nttdata.cinnamon.wait.conditions.Conditions.readyState;

public class NavigationSteps extends BaseStep {
    private final Browser browser;
    private final SignInPage signInPage;
    private final Retry retry;

    @Inject
    public NavigationSteps(final Browser browser, final SignInPage signInPage, final Retry retry) {
        this.browser = browser;
        this.signInPage = signInPage;
        this.retry = retry;
    }

    @Given("^eComm application opens$")
    public void eComm_application_opens() {
        this.logger.info("*** Opening eComm application ...");
        this.browser.open(Env.get().envProperty("eComm"));
        this.browser.waitUntil(readyState(ReadyState.COMPLETE));
        this.logger.info("*** eComm application opened!\n");
    }

//    @Given("^I navigate to '(.*)' page$")
//    public void i_navigate_to_page(String linkName) {
//        this.logger.info(MessageFormat.format("** Attempt to navigate to ''{0}'' ...", linkName));
//        this.browser.waitUntil(readyState(ReadyState.COMPLETE));
//        browser.setImplicitWait(5);
//        boolean result = retry.retryAction(
//                () -> {
//                    this.signInPage.getLink("Shop").hover();
//                    this.signInPage.getLink(linkName).isDisplayed(2);
//                    this.signInPage.getMenuLink(linkName).click();
//                    return (browser.currentUrl().contains(linkName));
//                },
//                2, 2);
//        this.browser.waitUntil(readyState(ReadyState.COMPLETE));
//        this.logger.info(MessageFormat.format("** Navigation to ''{0}'' complete!\n", linkName));
//    }
}
