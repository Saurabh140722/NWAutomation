package com.o2.models.ecare;

import java.text.MessageFormat;

public class PaymentDetails {
    public String bankAccountType;
    public String bankAccount;
    public String bankSortCode;
    public String cardPan;
    public String cardExpiryMonth;
    public String cardExpiryYear;
    public String cardCvv;

    @Override
    public String toString() {
        return MessageFormat.format("Payment Detail:" +
                        "\n\tbankAccountType:\t\t\t{0}" +
                        "\n\tbankAccount:\t\t{1}" +
                        "\n\tbankSortCode:\t\t{2}" +
                        "\n\tcardPan:\t\t\t{3}" +
                        "\n\tcardExpiryMonth:\t\t\t{4}" +
                        "\n\tcardExpiryYear:\t\t\t{5}" +
                        "\n\tcardCvv:\t\t\t{6}",
                this.bankAccountType,
                this.bankAccount,
                this.bankSortCode,
                this.cardPan,
                this.cardExpiryMonth,
                this.cardExpiryYear,
                this.cardCvv
        );
    }
}
