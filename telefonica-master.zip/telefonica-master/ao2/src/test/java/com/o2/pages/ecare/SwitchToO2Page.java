package com.o2.pages.ecare;

import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;

public class SwitchToO2Page extends EcareBasePage {

	@Find(by = By.XPath, locator = "//h1[text()=' Switch to O2 ']")
	public PageElement pageTitle;

//	@Find(by = By.CssSelector, locator = "#mat-input-0")
//	public PageElement movingFromAnotherProviderDropdown;

	@Find(by = By.CssSelector, locator = "#mat-select-0")
	public PageElement movingFromAnotherProviderDropdown;

	@Find(by = By.XPath, locator = "//span[contains(text(),' Move or cancel a number ')]")
	public PageElement selectingmovingFromAnotherProviderDropdown;



	@Find(by = By.CssSelector, locator = "#mat-input-0")
	public PageElement numberYouWantToCancelTextbox;

	@Find(by = By.CssSelector, locator = "#mat-option-1")
	public PageElement numberYouWantToCanceldropdownvalue;



	@Find(by = By.CssSelector, locator = "#mat-input-1")
	public PageElement stacCodeTextbox;

	// Error message: The mobile number should start with 07 and be 11 digits long
	@Find(by = By.CssSelector, locator = "#mat-hint-0")
	public PageElement mobileNumberErrorMessage;

	// Please enter a valid STAC.
	@Find(by = By.CssSelector, locator = "#mat-hint-1")
	public PageElement stacCodeErrorMessage;

	// 222333PRU
	@Find(by = By.XPath, locator = "//h2[text()=' Unable to validate your code ']")
	public PageElement validateYourCodeErrorMessageTitle;

	// We couldn't validate your code due to a problem on our side. You can try
	// again, or transfer your number later.
	@Find(by = By.XPath, locator = "//div[contains(@class,'notification-message__text')]")
	public PageElement validateYourCodeErrorMessageText;

	@Override
	public boolean isPageDisplayed() {
		if (!pageTitle.isDisplayed())
			return false;
		return pageTitle.getText().trim().equalsIgnoreCase("Switch to O2");
	}
}
