package com.o2.pages.csrd;

import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.o2.pages.BasePage;

public class PaymentMandatePage extends BasePage {
    @Find(by = By.CssSelector, locator = "button[class*='button_action_id_9153840173713143800_9153840173713143803_compositepopup_']")
    public PageElement createButton;
}
