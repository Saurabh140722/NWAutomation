package com.o2.models.ecare;

import com.nttdata.cinnamon.driver.controls.PageElement;


public class OrdersDetails {
    public PageElement orderNumber;
    public PageElement orderType;
    public PageElement orderDescription;
    public PageElement orderDate;
    public PageElement initiatingChannel;
    public PageElement status;
    public PageElement totalPrice;
    public PageElement viewOrderDetailsButton;


    public OrdersDetails(PageElement orderNumber, PageElement orderType, PageElement orderDescription, PageElement orderDate,PageElement initiatingChannel, PageElement status, PageElement totalPrice, PageElement viewOrderDetailsButton){
        this.orderNumber=orderNumber;
        this.orderType=orderType;
        this.orderDescription=orderDescription;
        this.orderDate=orderDate;
        this.initiatingChannel=initiatingChannel;
        this.status=status;
        this.totalPrice=totalPrice;
        this.viewOrderDetailsButton=viewOrderDetailsButton;
    }

}
