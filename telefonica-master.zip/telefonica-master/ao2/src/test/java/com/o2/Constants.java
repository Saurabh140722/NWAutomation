package com.o2;

public class Constants {

    public static final int ONE_SEC = 1;
    public static final int TWO_SECS = 2;
    public static final int FIVE_SECS = 5;
    public static final int SEVEN_SECS = 7;
    public static final int TEN_SECS = 10;

}
