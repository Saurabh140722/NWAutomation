package com.o2.pages.ecare;

import com.google.inject.Inject;
import com.nttdata.cinnamon.driver.Browser;
import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.nttdata.cinnamon.driver.controls.PageElementCollection;
import com.o2.models.ecare.BillingHistoryPaymentSuccessDetails;
import com.o2.pages.BasePage;

import java.util.ArrayList;
import java.util.List;

public class BillingHistoryPaymentSuccessDetailsPage extends BasePage {

    private Browser browser;

    @Inject
    public BillingHistoryPaymentSuccessDetailsPage(Browser browser) {
        this.browser = browser;
    }

    @Find(by = By.XPath, locator ="//o2uk-payment-card//div[contains(@class,'o2uk-expansion-panel-content')]//dl/div/div")
    public PageElementCollection paymentCardAdditionalInfo;

    @Find(by = By.XPath, locator ="//o2uk-card-title//div[text()='Additional Information']")
    public PageElement paymentCardAdditionalInfoHeader;

    @Find(by = By.XPath, locator ="o2uk-billing-history-card__value")
    public PageElementCollection paymentCardInfo;

    public  List<BillingHistoryPaymentSuccessDetails> getBillingHistoryPaymentDetails() {
        List<BillingHistoryPaymentSuccessDetails> bpdListTemp = new ArrayList<>();

        if (paymentCardAdditionalInfo.asList().isEmpty()) {
            this.logger.info("There are no Payment Details in Billing History");
        }

        if (!paymentCardAdditionalInfoHeader.isDisplayed()) {
            if (paymentCardAdditionalInfo.asList().isEmpty()) {
                BillingHistoryPaymentSuccessDetails billingHistoryPaymentDetail = new BillingHistoryPaymentSuccessDetails(
                        browser.findBy(By.XPath, "//o2uk-billing-history-card-header/dl//div[2]//dd/div"),
                        browser.findBy(By.XPath, "//o2uk-billing-history-card-header/dl//div[3]//dd/div"),
                        browser.findBy(By.XPath, "//o2uk-billing-history-card-header/dl//div[4]//dd/div"));
                bpdListTemp.add(billingHistoryPaymentDetail);
            }
        } else if (paymentCardAdditionalInfoHeader.isDisplayed()) {
            if (paymentCardAdditionalInfo.asList().size() > 1) {
                BillingHistoryPaymentSuccessDetails billingHistoryPaymentDetail = new BillingHistoryPaymentSuccessDetails(
                        browser.findBy(By.XPath, "//o2uk-billing-history-card-header/dl//div[2]//dd/div"),
                        browser.findBy(By.XPath, "//o2uk-billing-history-card-header/dl//div[3]//dd/div"),
                        browser.findBy(By.XPath, "//o2uk-billing-history-card-header/dl//div[4]//dd/div"),

                        browser.findBy(By.XPath, "//div[contains(@class,'o2uk-expansion-panel-content')]//dl/div[2]//dd//div"),
                        browser.findBy(By.XPath, "//div[contains(@class,'o2uk-expansion-panel-content')]//dl/div[2]//dd//div"),
                        browser.findBy(By.XPath, "//div[contains(@class,'o2uk-expansion-panel-content')]//dl/div[2]//dd//div"),
                        browser.findBy(By.XPath, "//div[contains(@class,'o2uk-expansion-panel-content')]//dl/div[2]//dd//div"),
                        browser.findBy(By.XPath, "//div[contains(@class,'o2uk-expansion-panel-content')]//dl/div[2]//dd//div"));
                bpdListTemp.add(billingHistoryPaymentDetail);
            }
        }
            bpdListTemp.stream().forEach(p -> this.logger.info("PmtDtl:- "+p.paymentDate.getText() + " :: " + p.paymentMethod.getText() + " :: " + p.amount.getText() + " :: " + p.frequency.getText() + " :: "+p.channel.getText()+" :: "+p.transactionID));

        return bpdListTemp;
    }
    }
