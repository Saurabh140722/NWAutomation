package com.o2.stepdefs.ecare;

import static org.assertj.core.api.Assertions.assertThat;

import com.google.inject.Inject;
import com.nttdata.cinnamon.driver.Browser;
import com.o2.pages.ecare.SpendCapPage;
import com.o2.stepdefs.BaseStep;
import com.o2.core.util.Common;

import io.cucumber.java.en.Then;

public class SpendCapSteps extends BaseStep {
	private final SpendCapPage spendCapPage;
	private final Browser browser;
	private final Common common;

	@Inject
	public SpendCapSteps(final SpendCapPage spendCapPage, final Browser browser, final Common common) {
		this.spendCapPage = spendCapPage;
		this.browser = browser;
		this.common = common;
	}

	@Then("Spend Cap page opens successfully")
	public void spend_cap_page_opens_successfully() {
		this.logger.info("** Waiting for Spend Cap page to open ...");
		this.browser.setImplicitWait(5);

		assertThat(this.spendCapPage.isPageDisplayed()).withFailMessage("Spend Cap page not displayed!").isTrue();

		this.logger.info("** Spend Cap page opens!");
	}

}
