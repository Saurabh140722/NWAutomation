package com.o2.stepdefs.ecomm;

import com.google.inject.Inject;
import com.nttdata.cinnamon.driver.Browser;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.nttdata.cinnamon.webdriver.util.ReadyState;
import com.o2.models.ecomm.Accessories;
import com.o2.pages.ecomm.AccessoriesPage;
import com.o2.pages.ecomm.PhonePage;
import com.o2.util.Common;
import io.cucumber.java.en.And;
import com.nttdata.cinnamon.cache.Context;
import org.assertj.core.api.Assertions;
import org.openqa.selenium.Keys;

import static com.nttdata.cinnamon.wait.ElementConditions.*;
import static com.nttdata.cinnamon.wait.ElementConditions.present;
import static com.nttdata.cinnamon.wait.conditions.Conditions.ajaxFinished;
import static com.nttdata.cinnamon.wait.conditions.Conditions.readyState;
import static org.assertj.core.api.Assertions.assertThat;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

public class AccessoriesSteps extends BaseStep {
    private final Logger logger;
    private final AccessoriesPage accessoriesPage;
    private final Context context;
    private final Browser browser;
    public final Common common;
    private final PhonePage phonePage;
    public List<String> acccessoriesDetail = new ArrayList<>();

    @Inject
    public AccessoriesSteps(final Logger logger, final AccessoriesPage accessoriesPage, final Context context, final Browser browser, final Common common,final PhonePage phonePage) {

        this.logger = logger;
        this.accessoriesPage = accessoriesPage;
        this.context = context;
        this.browser = browser;
        this.common = common;
        this.phonePage = phonePage;
    }

    @And("^I select  device card brand '(.*)' with device card name '(.*)'$")
    public void i_select_device_card(String deviceCardBrand, String deviceCardName) {
        this.logger.info("** Accessories Page is loaded...");
        this.common.waitForLoadingToComplete(4, 1);
        this.accessoriesPage.viewAllProductsBtn.click();
        this.common.waitForLoadingToComplete(2, 1);
        String searchText = deviceCardBrand + " " + deviceCardName;
        browser.setImplicitWait(2);
        if (phonePage.searchBox.waitUntil(displayed).isDisplayed()) {
            logger.info(" ++++++++++++ PHONE SEARCH BOX DISPLAYED!");
        } else {
            logger.info(" ++++++++++++ PHONE SEARCH BOX NOT DISPLAYED!");
        }
        if (phonePage.searchBox.isEnabled()) {
            logger.info(" ++++++++++++ PHONE SEARCH BOX ENABLED!");
        } else {
            logger.info(" ++++++++++++ PHONE SEARCH BOX NOT ENABLED!");
        }
        if (phonePage.searchBox.isPresent()) {
            logger.info(" ++++++++++++ PHONE SEARCH BOX PRESENT!");
        } else {
            logger.info(" ++++++++++++ PHONE SEARCH BOX NOT PRESENT!");
        }
        phonePage.searchBox.waitUntil(displayed.and(enabled).and(present).and(clickable)).clickJs();
        phonePage.searchBox.setValue(searchText);
        phonePage.searchBox.setValue(Keys.ENTER);
        browser.waitUntil(ajaxFinished);
        browser.setImplicitWait(5);
        browser.refresh();
        this.browser.waitUntil(readyState(ReadyState.COMPLETE));
        boolean found = false;
        List<PageElement> phone=phonePage.phoneDetails.asList();
        assertThat(phone.size())
                .withFailMessage("Could not find any matching phone!")
                .isPositive();

        int totalPhone = phone.size();
        this.logger.info("totalPhone:"+totalPhone);

        for (int i = 0; i < totalPhone; i++) {
            if (phone.get(i).getText().replace("\n", " ").equals(searchText)) {
                logger.info(MessageFormat.format("Phone found: {0}", searchText));
                phone.get(i).clickJs();
                found = true;
                break;
            }
        }

        assertThat(found).withFailMessage(
                        MessageFormat.format(
                                "Could not find a phone with : ''{0}''",searchText))
                .isTrue();
        this.context.set("phone", searchText);
        this.browser.waitUntil(readyState(ReadyState.COMPLETE));
        this.browser.setImplicitWait(3);
        this.logger.info(MessageFormat.format(
                "*** Select the ''{0}'' phone is completed.... ",searchText));
    }





        /*
        List<Accessories> accessoriesList = this.accessoriesPage.getAllAccessories();
        List<String> acccessoriesDetail = new ArrayList<>();
        for (int i = 0; i < accessoriesList.size(); i++) {
            if ((accessoriesList.get(i).title.getText().equals(deviceCardBrand)) && (accessoriesList.get(i).name.getText().equals(deviceCardName))) {
                acccessoriesDetail.add(accessoriesList.get(i).title.getText());
                acccessoriesDetail.add(accessoriesList.get(i).name.getText());
                acccessoriesDetail.add(accessoriesList.get(i).price.getText());
                this.context.set("SelectedAccessories", acccessoriesDetail);
                accessoriesList.get(i).title.waitUntil(clickable).clickJs();
                this.logger.info("Selected Device"+accessoriesList.get(i).title.getText());
                break;
            }
        }

    }*/
    @And("I verify whether selected device is {string}")
    public void i_Verify_Whether_Selected_Device_IsInStock(String stockAvailabilityCheck) {
        Assertions.assertThat(accessoriesPage.iStockOROutOfStock.getText().contains(stockAvailabilityCheck)).withFailMessage("Selected device is Not in Stock");
        Assertions.assertThat(accessoriesPage.iStockOROutOfStock.getText().contains(stockAvailabilityCheck)).isTrue();
    }

    @And("I select deviceCardBrand {string} with deviceCardName {string}")
    public void i_Select_DeviceCardBrand_With_DeviceCardName(String deviceCardBrand, String deviceCardName) {
            this.logger.info("** Accessories Page is loaded...");
            this.common.waitForLoadingToComplete(4, 1);
            this.accessoriesPage.viewAllProductsBtn.click();
            this.common.waitForLoadingToComplete(2, 1);
            List<Accessories> accessoriesList = this.accessoriesPage.getAllAccessories();
            accessoriesList.forEach(p->this.logger.info(p.title+"---"+p.name));
//            accessoriesList.stream().forEach(p->System.out.println(p.title.getText()+"::"+p.name.getText()+"::"+p.title.getText()+"::"+p.price.getText()));
            Accessories accessoriesRequired = accessoriesList.stream().filter(p->p.title.getText().trim().equalsIgnoreCase(deviceCardBrand) && p.name.getText().trim().equalsIgnoreCase(deviceCardName))
                    .findFirst().orElse(null);
            accessoriesRequired.title.clickJs();
            acccessoriesDetail.add(accessoriesRequired.title.getText());
            acccessoriesDetail.add(accessoriesRequired.name.getText());
            acccessoriesDetail.add(accessoriesRequired.price.getText());
            this.logger.info("SelectedAccessories-->"+acccessoriesDetail);
            this.context.set("SelectedAccessoriesTitle",accessoriesRequired.title.getText());
            this.context.set("SelectedAccessoriesName",accessoriesRequired.name.getText());
            this.context.set("SelectedAccessoriesPrice",accessoriesRequired.price.getText());
            this.logger.info("AccessoriesSteps->Selected Device Details: - "+acccessoriesDetail.toString());

        }

}
