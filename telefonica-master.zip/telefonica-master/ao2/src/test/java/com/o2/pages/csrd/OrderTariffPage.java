package com.o2.pages.csrd;

import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.o2.pages.BasePage;

public class OrderTariffPage extends BasePage {
    @Find(by = By.Id, locator = "gwt-uid-3196_input")
    public PageElement phoneNumberTextField;

    @Find(by = By.Id, locator = "listCharacteristicsSelect_9156572418065211705")
    public PageElement spendCapTextField;

}
