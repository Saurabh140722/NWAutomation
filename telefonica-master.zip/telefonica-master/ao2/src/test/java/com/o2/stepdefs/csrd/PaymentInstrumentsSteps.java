package com.o2.stepdefs.csrd;

import com.google.inject.Inject;
import com.nttdata.cinnamon.cache.Context;
import com.nttdata.cinnamon.driver.Browser;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.o2.core.data.UserData;
import com.o2.core.data.UserDataModel;
import com.o2.core.util.Retry;
import com.o2.models.csrd.PaymentInstrumentRow;
import com.o2.pages.csrd.AccountLandingPage;
import com.o2.pages.csrd.AccountSummaryPage;
import com.o2.pages.csrd.DeactivatePaymentPopupPage;
import com.o2.pages.csrd.PaymentInstrumentsPage;
import com.o2.stepdefs.BaseStep;
import com.o2.util.Common;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

import java.text.DateFormat;
import java.text.MessageFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;
import java.util.function.Supplier;
import java.util.stream.Collectors;

import static com.nttdata.cinnamon.wait.ElementConditions.displayed;
import static org.assertj.core.api.Assertions.assertThat;

public class PaymentInstrumentsSteps extends BaseStep {
    private final Common common;
    private final Browser browser;
    private final Retry retry;
    private final UserData userData;
    private final AccountLandingPage accountLandingPage;
    private final AccountSummaryPage accountSummaryPage;
    private final PaymentInstrumentsPage paymentInstrumentsPage;
    private final DeactivatePaymentPopupPage deactivatePaymentPopupPage;
    private final Context context;

    @Inject
    public PaymentInstrumentsSteps(final Common common,
                                   final Browser browser,
                                   final Retry retry,
                                   final UserData userData,
                                   final AccountLandingPage accountLandingPage,
                                   final AccountSummaryPage accountSummaryPage,
                                   final PaymentInstrumentsPage paymentInstrumentsPage,
                                   final DeactivatePaymentPopupPage deactivatePaymentPopupPage,
                                   final Context context) {
        this.common = common;
        this.browser = browser;
        this.retry = retry;
        this.userData = userData;
        this.accountLandingPage = accountLandingPage;
        this.accountSummaryPage = accountSummaryPage;
        this.paymentInstrumentsPage = paymentInstrumentsPage;
        this.deactivatePaymentPopupPage = deactivatePaymentPopupPage;
        this.context = context;
    }

    @When("^I add '(a|another)' Payment Instrument$")
    public void i_add_a_payment_instrument(String paymentInstrument) {
        this.logger.info("*** Attempt to add Payment Instrument ...");

        boolean isAnotherPaymentInstrument = paymentInstrument.equals("another");
        UserDataModel userDataModel = (UserDataModel) this.context.get("residentialUserAccountData");
        String bankSortCode;
        String bankAccount;

        if (isAnotherPaymentInstrument) {
            this.logger.info(">>> Clean all previous extra Payment Instruments that are still active ...");
            invalidateAnyNonPrimaryPaymentInstruments();
            this.logger.info(">>> Clean complete!");

            bankSortCode = this.userData.getPaymentDataByName("Change").bankSortCode;
            bankAccount = this.userData.getPaymentDataByName("Change").bankAccount;
        } else {
            bankSortCode = userDataModel.userPaymentModel.bankSortCode;
            bankAccount = userDataModel.userPaymentModel.bankAccount;
        }

        this.accountLandingPage.paymentInstrumentsButton.waitUntil(displayed).click();

        // TODO: all retries should be implemented through a method/helper
        int cnt = 3;
        while (cnt > 0) {
            cnt--;
            try {
                if (!this.paymentInstrumentsPage.sortCode.waitUntil(displayed).isDisplayed(6)) {
                    this.logger.warn(">>> Sort Code not displayed yet! Retry ...");
                    continue;
                }

                this.paymentInstrumentsPage.sortCode.waitUntil(displayed).click();
                this.logger.warn("\t\t bank sort code: " + bankSortCode);
                this.paymentInstrumentsPage.sortCode.setValue(bankSortCode);
                break;
            } catch (Exception e) {
                this.logger.warn(
                        MessageFormat.format(
                                "Error setting Sort Code. Exception:\n{0}\nRetry ...", e.getMessage()));
                this.common.wait(4);
            }
        }
        this.common.wait(4);
        System.out.println("payment");
        this.paymentInstrumentsPage.sortCode.setValue(bankSortCode);

//        assertThat(this.paymentInstrumentsPage.sortCode.getValue())
//            .isEqualTo(bankSortCode);
        this.common.waitForLoadingToComplete(5, 1);

        this.paymentInstrumentsPage.bankAccountNumber.setValue(bankAccount);
        this.paymentInstrumentsPage.bankAccountHolder.setValue(userDataModel.getName());
        if (this.paymentInstrumentsPage.createButton.isDisplayed()) {
            assertThat(this.paymentInstrumentsPage.createButton.waitUntil(displayed).isDisplayed())
                    .withFailMessage("Payment Instruments - Could not find Create button!")
                    .isTrue();

            String sdf = new SimpleDateFormat("dd/MM/yyy HH:mm:ss").format(new Date());
            this.context.set("paymentInstrumentCreationDateTime", sdf);
            this.paymentInstrumentsPage.createButton.click();
        }
        if (this.paymentInstrumentsPage.paymentInstrumentcreateButton.isDisplayed()) {
            assertThat(this.paymentInstrumentsPage.paymentInstrumentcreateButton.waitUntil(displayed).isDisplayed())
                    .withFailMessage("Payment Instruments - Could not find Create button!")
                    .isTrue();

            String sdf = new SimpleDateFormat("dd/MM/yyy HH:mm:ss").format(new Date());
            this.context.set("paymentInstrumentCreationDateTime", sdf);
            this.paymentInstrumentsPage.paymentInstrumentcreateButton.click();
        }
        if (paymentInstrumentsPage.confirmBtn.isDisplayed()) {
            paymentInstrumentsPage.confirmBtn.click();
        }
        this.common.waitForLoadingToComplete(5, 1);

        Supplier<PageElement> sortCodeSupplied = () -> this.paymentInstrumentsPage.sortCode;
        Boolean result = this.retry.untilNotDisplayed(sortCodeSupplied, 30, 1);

        assertThat(result)
                .withFailMessage("Payment Instruments page is still displayed!")
                .isTrue();

        this.logger.info("*** Payment Instrument added!\n");
    }

    @Then("^the new Payment Instrument is active and set as Default$")
    public void the_new_payment_instrument_is_active_and_set_as_default() {
        this.logger.info("*** Validate new Payment Instrument is added and set as Default ...");

        String bankAccount = this.userData.getPaymentDataByName("Change").bankAccount;
        Date paymentInstrumentCreationDateTime = stringToDate((String) this.context.get("paymentInstrumentCreationDateTime"));
        List<PaymentInstrumentRow> paymentInstruments = this.accountSummaryPage.getPaymentInstruments();

        PaymentInstrumentRow paymentInstrument = paymentInstruments.stream()
                .filter(pi ->
                        (pi.name != null && pi.name.getText().equals("Bank Account 7925"))
                                && (pi.creationDate != null &&
                                (dateDifferenceInSeconds(stringToDate(pi.creationDate.getText()), paymentInstrumentCreationDateTime) != null)
                                &&
                                dateDifferenceInSeconds(stringToDate(pi.creationDate.getText()), paymentInstrumentCreationDateTime) <= 2))
                .findFirst()
                .orElse(null);

        assertThat(paymentInstrument)
                .withFailMessage(MessageFormat.format(
                        "Could not find the new Payment Instrument that has been at ''{0}'' with name ''{1}''!",
                        dateToString(paymentInstrumentCreationDateTime), "Bank Account 7925"))
                .isNotNull();

        this.logger.info("*** Payment Instrument validated!\n");
    }

    // TODO: this refers to 1st page only as it seems new one are always added on 1st page. refactor if needed
    private void invalidateAnyNonPrimaryPaymentInstruments() {
        if (!this.accountSummaryPage.getPaymentInstrumentsTable().isDisplayed()) {
            this.logger.error("Could not find Payment Instruments table!");
            return;
        }

        List<PaymentInstrumentRow> paymentInstruments = this.accountSummaryPage.getPaymentInstruments().stream()
                .filter(pi ->
                        (pi.name != null && pi.name.getText().equals("Bank Account 7925"))
                                && pi.status.getText().toLowerCase(Locale.ROOT).contains("active")
                                && pi.defaultPayment.getText().toLowerCase(Locale.ROOT).contains("yes")
                )
                .collect(Collectors.toList());

        if (paymentInstruments.size() == 0) return;

        for (PaymentInstrumentRow paymentInstrument : paymentInstruments) {
            paymentInstrument.checkbox.scrollIntoView();
            paymentInstrument.checkbox.click();
            this.accountSummaryPage.deactivateButton.click();
            if (this.deactivatePaymentPopupPage.isPageDisplayed(4)) {
                this.deactivatePaymentPopupPage.confirmButton.click();
            }
            Supplier<PageElement> processIcon = () -> this.accountSummaryPage.loading;
            Boolean result = this.retry.untilNotDisplayed(processIcon, 12, 1);
            assertThat(result)
                    .withFailMessage("Process/Loading icon still displayed after deactivating a Payment Instrument!")
                    .isTrue();

        }
    }

    private String dateToString(Date date) {
        return dateToString(date, "dd/MM/yyyy HH:mm:ss");
    }

    private String dateToString(Date date, String format) {
        // TODO: resolve this in a proper way. add also logging
        if (date == null) return "ERROR - Date passed is null";

        DateFormat df = new SimpleDateFormat(format);

        return df.format(date);
    }

    private Date stringToDate(String dateTimeAsString, String format) {
        SimpleDateFormat dateTimeFormat = new SimpleDateFormat(format, Locale.ENGLISH);

        try {
            return dateTimeFormat.parse(dateTimeAsString);
        } catch (ParseException e) {
            this.logger.error(MessageFormat.format(
                    "Unable to parse string ''{0}'' as Date using format ''{1}''",
                    dateTimeAsString, format));
            return null;
        }
    }

    private Date stringToDate(String dateTimeAsString) {
        return stringToDate(dateTimeAsString, "dd/MM/yyyy HH:mm:ss");
    }

    private Long dateDifferenceInSeconds(Date date1, Date date2) {
        if (date1 == null || date2 == null) {
            this.logger.error(
                    MessageFormat.format(
                            "Could not find difference between dates as at least one is null!\nDate1: ''{0}'', Date2: ''{1}''",
                            date1, date2));

            return null;
        }

        long dateDiffAsMilliseconds = Math.abs(date2.getTime() - date1.getTime());

        return TimeUnit.SECONDS.convert(dateDiffAsMilliseconds, TimeUnit.MILLISECONDS);
    }
}
