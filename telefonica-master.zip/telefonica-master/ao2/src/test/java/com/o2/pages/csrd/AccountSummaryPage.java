package com.o2.pages.csrd;

import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.nttdata.cinnamon.driver.controls.PageElementCollection;
import com.o2.models.csrd.PaymentInstrumentRow;
import com.o2.pages.BasePage;

import java.util.ArrayList;
import java.util.List;

public class AccountSummaryPage extends BasePage {
    @Find(by = By.Id, locator = "label_9135584008513286551_lightparctrl_2")
    public PageElement billingAccountSummaryTitle;

    @Find(by = By.CssSelector, locator = ".GEGUAMFDIK.TableCtrl.nc-table-content-zebra")
    public PageElementCollection tables;

    @Find(by = By.CssSelector, locator = ".gwt-Button.button_action_id_9153486186713158414_9153606717813178431_baiptablectrl_3.TableCtrl-button.TableCtrl-button-icon.CancelIco")
    public PageElement deactivateButton;

    @Find(by = By.CssSelector, locator = ".nc-loading")
    public PageElement loading;

    @Override
    public boolean isPageDisplayed() {
        if (!billingAccountSummaryTitle.isDisplayed()) return false;

        return this.billingAccountSummaryTitle.getText().equals("Billing Account Summary");
    }

    public PageElement getPaymentInstrumentsTable() {
        return tables.asList().get(1);
    }

    public List<PaymentInstrumentRow> getPaymentInstruments() {
        PageElement tableBody = getPaymentInstrumentsTable().findChild(By.Tag, "tbody");
        PageElementCollection tableRows = tableBody.findChildren(By.Tag, "tr");
        List<PaymentInstrumentRow> paymentInstruments = new ArrayList<>();

        for(PageElement row : tableRows.asList()) {
            PageElementCollection columns = row.findChildren(By.Tag, "td");
            PaymentInstrumentRow paymentInstrumentRow = new PaymentInstrumentRow(columns);
            paymentInstruments.add(paymentInstrumentRow);
        }

        return paymentInstruments;
    }
}
