package com.o2.models.csrd;

import java.text.MessageFormat;

public class EcareUser {
    public String planType;
    public String username;
    public String password;
    public String securityCode;
    public String title;
    public String firstName;
    public String lastName;
    public String mobile;

    @Override
    public String toString() {
        return MessageFormat.format("Login eCare User:" +
                        "\n\tPlan:\t\t\t{0}" +
                        "\n\tUsername:\t\t{1}" +
                        "\n\tPassword:\t\t{2}" +
                        "\n\tCode:\t\t\t{3}" +
                        "\n\tTitle:\t\t\t{4}" +
                        "\n\tFirst Name:\t\t{5}" +
                        "\n\tLast Name:\t\t{6}" +
                        "\n\tMobile:\t\t\t{7}",
                this.planType,
                this.username,
                this.password,
                this.securityCode,
                this.title,
                this.firstName,
                this.lastName,
                this.mobile
                );
    }
}
