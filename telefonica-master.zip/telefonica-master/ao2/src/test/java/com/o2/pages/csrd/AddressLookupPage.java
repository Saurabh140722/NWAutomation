package com.o2.pages.csrd;

import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.o2.pages.BasePage;

import static com.nttdata.cinnamon.wait.ElementConditions.displayed;

public class AddressLookupPage extends BasePage {
    @Find(by = By.CssSelector, locator = ".nc-composite-top-layout.nc-widget-state.nc-control.nc-control-compositepopup.widgetContainerId_9153338375613156622.widgetId_compositepopup_2")
    public PageElement addressFormRoot;

    @Find(by = By.Id, locator = "9153345485613159424")
    public PageElement streetNo;

    @Find(by = By.CssSelector, locator = ".ParCtrl-editButton.addressLookupButton")
    public PageElement addressLookupButton;

    @Find(by = By.Id, locator = "9153345507813159589")
    public PageElement addresses;

    @Find(by = By.CssSelector, locator = ".gwt-Button.button_action_id_9153338375613156622_9153365228013196590_compositepopup_2.TableCtrl-button.ParCtrl-editButton")
    public PageElement confirmAddressButton;

    public PageElement getPostcode() {
        try {
            return this.addressFormRoot.findChild(By.Id, "9153345485613159362");
        } catch (Exception e) {
            return this.addressFormRoot.findChild(By.Id, "9153345485613159362_1");
        }
    }

    @Override
    public boolean isPageDisplayed() {
        this.logger.warn("Check if street no is displayed ...");
        if (this.streetNo.waitUntil(displayed).isDisplayed())
            this.logger.warn("\t\tStreet No Displayed!");
        else
            this.logger.warn("\t\tStreet No NOT Displayed!");

        this.logger.warn("Check if street no is enabled ...");
        if (this.streetNo.isEnabled())
            this.logger.warn("\t\tStreet No Enabled!");
        else
            this.logger.warn("\t\tStreet NOT Enabled!");

        return this.streetNo.isDisplayed() && this.streetNo.isEnabled();
    }
}
