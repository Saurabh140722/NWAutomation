package com.o2.stepdefs.ecare;

import com.google.inject.Inject;
import com.nttdata.cinnamon.cache.Context;
import com.nttdata.cinnamon.driver.Browser;
import com.o2.models.ecare.EcareUser;
import com.o2.pages.ecare.LostOrStolenPage;
import io.cucumber.java.en.And;
import org.openqa.selenium.WebDriver;


import static com.nttdata.cinnamon.wait.ElementConditions.displayed;
import static org.assertj.core.api.Assertions.assertThat;

public class LostOrStolenSteps {
    private final Browser browser;
    private final LostOrStolenPage lostOrStolenPage;
    private final Context context;

    @Inject
    public LostOrStolenSteps(final Browser browser, LostOrStolenPage lostOrStolenPage, final Context context) {
        this.browser = browser;
        this.lostOrStolenPage = lostOrStolenPage;
        this.context = context;
    }

    @And("^I click on deliver to me radio button of replacement sim card$")
    public void i_click_on_visit_my_local02Sotre_Radio_Button() {
        this.lostOrStolenPage.visitMyLocalO2Sotre.waitUntil(displayed).click();
        //TODO
        // Need to implement the logic once get the test data
    }

    @And("^I fill the customer number and address field$")
    public void i_fill_contactnumber_addressfield() {
        this.browser.refresh();
        this.browser.setImplicitWait(5);
        this.browser.getWebDriver(WebDriver.class).switchTo().defaultContent();
       // this.lostOrStolenPage.deliverToMeRadioBtn.waitUntil(displayed).click();
        EcareUser ecareUser = (EcareUser) this.context.get("ecareLoginData");
        this.browser.getWebDriver(WebDriver.class).switchTo().defaultContent();
        this.lostOrStolenPage.contactNbr.setValue(ecareUser.mobile);
        //this.lostOrStolenPage.updateAddressLink.click();
        //this.lostOrStolenPage.houseNumber.setValue("539");
        //this.lostOrStolenPage.postCode.setValue("B338TH");
        //this.lostOrStolenPage.findBtn.click();
        this.browser.setImplicitWait(2);
        this.lostOrStolenPage.saveCloseBtn.waitUntil(displayed).click();
        assertThat(this.lostOrStolenPage.simDisconnectionNotification.waitUntil(displayed).isDisplayed())
                .withFailMessage("Sim disconnection notification is not displayed!").isTrue();
        this.lostOrStolenPage.orderNewSimBtn.click();
        this.lostOrStolenPage.confirmOrderBtn.click();
        assertThat(this.lostOrStolenPage.replacementSimDesciptionPanel.isDisplayed())
                .withFailMessage("Replacement sim panel is not displayed!").isTrue();
        assertThat(this.lostOrStolenPage.deliveryPanel.isDisplayed())
                .withFailMessage("Delivery Panel is not displayed!").isTrue();


    }

    @And("^I can see the new sim detail on E care application$")
    public void i_can_see_new_detail_on_Ecare_application() {
        this.browser.setImplicitWait(4);
        assertThat(this.lostOrStolenPage.barringNewSimMessage.getText()
                .equals("Your sim is now blocked from the network. Please activate your new one when it arrives"))
                .withFailMessage("Barring new sim message is not displayed!").isTrue();
        assertThat(this.lostOrStolenPage.orderConfimrationNewSim.isDisplayed())
                .withFailMessage("Order confirmation new sim panel is not displayed!").isTrue();
        assertThat(this.lostOrStolenPage.orderConfirmationNewSimHisotry.isDisplayed())
                .withFailMessage("view order history button is not displayed!").isTrue();


    }

}
