package com.o2.models.csrd;

import java.text.MessageFormat;

public class CustomerInteractionRowModel {
    public String interactionName;
    public String subject;
    public String description;
    public String relatesTo;
    public String interactionDate;
    public String initiatedBy;

    @Override
    public String toString() {
        return MessageFormat.format("Customer Interaction: {0}, {1}, {2}, {3}, {4}, {5}",
                this.interactionName,
                this.subject,
                this.description,
                this.relatesTo,
                this.interactionDate,
                this.initiatedBy);
    }
}
