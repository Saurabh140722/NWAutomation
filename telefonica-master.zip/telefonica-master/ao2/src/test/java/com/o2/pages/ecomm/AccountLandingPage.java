package com.o2.pages.ecomm;

import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;

public class AccountLandingPage extends EcommBasePage {
    @Find(by = By.CssSelector, locator = ".o2uk-account-welcome__service-title")
    public PageElement welcomeMessage;

    @Find(by = By.CssSelector, locator = ".main-dropdown__wrapper")
    public PageElement myO2MenuLink;

    @Find(by = By.CssSelector, locator = ".main-dropdown-list.content-limited.visible")
    public PageElement myO2MenuListParent;

    @Override
    protected PageElement getPageCheckElement() {
        return this.welcomeMessage;
    }

    public PageElement getSubmenu(String submenuName) {
        return this.myO2MenuListParent.findBy(By.LinkName, submenuName);
    }
}
