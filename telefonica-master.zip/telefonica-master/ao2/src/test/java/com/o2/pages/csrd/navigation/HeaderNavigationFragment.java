package com.o2.pages.csrd.navigation;

import com.google.inject.Inject;
import com.google.inject.Injector;
import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.o2.core.util.Common;
import com.o2.pages.BasePage;

import java.text.MessageFormat;
import java.util.Objects;

import static com.nttdata.cinnamon.wait.ElementConditions.displayed;
import static org.assertj.core.api.Assertions.assertThat;

public class HeaderNavigationFragment extends BasePage {
    @Inject
    Injector injector;

    private final Common common;

    @Find(by = By.CssSelector, locator = ".gwt-Button.more-links")
    public PageElement moreLinks;

    @Find(by = By.CssSelector, locator = ".gwt-MenuBar.gwt-MenuBar-vertical.more-links-dropdown-content")
    public PageElement moreLinksSubmenuItems;

    @Inject
    public HeaderNavigationFragment(final Common common) {
        this.common = common;
    }

    public void navigateToMoreLinks(String navigationPath) {
        assertThat(navigationPath)
                .withFailMessage("Cannot navigate as navigation path is empty!")
                .isNotEmpty();

        moreLinks.waitUntil(displayed).click();

        PageElement submenu = moreLinksSubmenuItems.waitUntil(displayed).findChildren(By.CssSelector, ".gwt-MenuItem")
                .asList()
                .stream().filter(el -> el.getText().contains(navigationPath))
                .findFirst()
                .orElse(null);

        assertThat(submenu)
                .withFailMessage(
                        MessageFormat.format(
                                "Could not find submenu in More Link whose name is: ''{0}''!", navigationPath))
                .isNotNull();

        Objects.requireNonNull(submenu).click();
    }
}
