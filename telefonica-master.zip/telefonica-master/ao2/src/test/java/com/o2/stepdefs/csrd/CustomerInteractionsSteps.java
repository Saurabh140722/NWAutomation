package com.o2.stepdefs.csrd;

import com.google.inject.Inject;
import com.nttdata.cinnamon.cache.Context;
import com.nttdata.cinnamon.driver.Browser;
import com.nttdata.cinnamon.driver.By;
import com.o2.models.csrd.CustomerInteractionRow;
import com.o2.models.csrd.CustomerInteractionRowModel;
import com.o2.pages.csrd.CustomerInteractionsPage;
import com.o2.stepdefs.BaseStep;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.lang.NotImplementedException;

import java.text.MessageFormat;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Collectors;

import static com.nttdata.cinnamon.wait.ElementConditions.displayed;
import static org.assertj.core.api.Assertions.assertThat;

public class CustomerInteractionsSteps extends BaseStep {
    private final CustomerInteractionsPage customerInteractionsPage;
    private final Browser browser;
    private final Context context;

    @Inject
    public CustomerInteractionsSteps(final CustomerInteractionsPage customerInteractionsPage,
                                     final Browser browser,
                                     final Context context) {
        this.customerInteractionsPage = customerInteractionsPage;
        this.browser = browser;
        this.context = context;
    }

    @When("^I open an interaction whose date is '(.*)'$")
    public void i_open_an_interaction_which_date_is(String interactionDate) {
        this.logger.info("*** Find an interaction whose date is ''{0}'' ...");

        switch (interactionDate.toLowerCase(Locale.ROOT)) {
            case "latest":
                List<CustomerInteractionRow> interactions = this.customerInteractionsPage.getCustomerInteractions();
                assertThat(interactions.size())
                        .withFailMessage("There are no interactions displayed in the Interactions Table!")
                        .isGreaterThanOrEqualTo(1);

                CustomerInteractionRow interaction = interactions.get(0);
                this.context.set("interactionName", interaction.interactionName.getText());
                this.browser.findBy(By.LinkName, interaction.interactionName.getText()).click();

                break;
            default:
                throw new NotImplementedException("Only 'latest' case/option is implemented!");
        }
        this.logger.info("*** Interaction found and clicked to open ...");
    }

    @Then("^correct interaction page opens$")
    public void correct_interaction_opens() {
        this.logger.info("*** Assert correct interaction page has opened ...");

        String interactionName = (String) this.context.get("interactionName");
        String currentInteractionPageTitle = this.customerInteractionsPage.interactionPageTitle.waitUntil(displayed).getText();

        assertThat(currentInteractionPageTitle)
                .withFailMessage(MessageFormat.format(
                        "Wrong interaction page opened! Expected title to be: ''{0}'' but was: ''{1}''!",
                        interactionName, currentInteractionPageTitle
                ))
                .isEqualTo(interactionName);

        this.logger.info("*** Correct interaction page is opened!");
    }


    @When("^I log a new interaction with:$")
    public void i_log_a_new_interaction_with(DataTable table) {
        this.logger.info("*** Logging a new interaction ...");

        List<Map<String, String>> newInteractionData = table.asMaps(String.class, String.class);

        this.customerInteractionsPage.logInteractionButton.click();
        assertThat(this.customerInteractionsPage.newInteractionPopup.isDisplayed())
                .withFailMessage("New Log Interaction popup not displayed!")
                .isTrue();

        this.context.set("newInteraction", this.customerInteractionsPage.logNewInteraction(newInteractionData.get(0)));
        this.customerInteractionsPage.waitForNcLoadingToComplete();

        this.logger.info("*** New interaction logged!\n");
    }

    @Then("^the new interaction is displayed on the page$")
    public void the_new_interaction_is_displayed_on_the_page() {
        this.logger.info("*** Check if new logged interaction is displayed on the page ...");

        assertThat(this.customerInteractionsPage.isPageDisplayed())
                .withFailMessage("Customer Interactions page not loaded!")
                .isTrue();

        List<CustomerInteractionRow> actualCustomerInteractions = this.customerInteractionsPage.getCustomerInteractions();
        CustomerInteractionRowModel expectedInteraction = (CustomerInteractionRowModel) this.context.get("newInteraction");

        assertThat(
                actualCustomerInteractions.stream()
                        .filter(ci -> ci.isEqualTo(expectedInteraction, 20))
                        .findFirst()
                        .orElse(null))
                .withFailMessage(
                        MessageFormat.format("Could not find an interaction with: ''{0}''!",
                                Collections.singletonList(expectedInteraction)))
                .isNotNull();

        this.logger.info("*** New logged interaction displayed!");
    }

    @Then("^I can see an interaction with:$")
    public void i_can_see_an_interaction_with(DataTable table) {
        this.logger.info("*** Check if an interaction exists in Customer Interactions table ...");

        List<Map<String, String>> expectedInteractions = table.asMaps(String.class, String.class);

        assertThat(this.customerInteractionsPage.isPageDisplayed())
                .withFailMessage("Customer Interactions page not loaded!")
                .isTrue();

        List<CustomerInteractionRow> actualCustomerInteractions = this.customerInteractionsPage.getCustomerInteractions();
        Map<String, String> expectedInteraction = expectedInteractions.get(0); // TODO: can make this test assert more than 1 interaction

        this.logger.info(
                MessageFormat.format(
                        "Actual Interactions:\n{0}",
                        actualCustomerInteractions.stream().map(CustomerInteractionRow::toString).collect(Collectors.joining("\n"))));

        // TODO: refactor this when we know what happens with Override for Back Office India Team
        assertThat(
                    actualCustomerInteractions.stream()
                    .filter(ci -> ci.subject.getText().toLowerCase(Locale.ROOT).contains(expectedInteraction.get("subject")))
                    .findFirst()
                    .orElse(null))
                .withFailMessage(
                        MessageFormat.format("Could not find an interaction with: ''{0}''!",
                                Collections.singletonList(expectedInteraction)))
                .isNotNull();

        this.logger.info("*** Interaction found in Customer Interactions table!\n");
    }
}
