package com.o2.stepdefs.ecare;

import java.text.MessageFormat;

import com.google.inject.Inject;
import com.o2.pages.ecare.EditContactDetailsPage;
import com.o2.stepdefs.BaseStep;

import io.cucumber.java.en.When;

public class ContactDetailsSteps extends BaseStep {
    private final EditContactDetailsPage editContactDetailsPage;

    @Inject
    public ContactDetailsSteps(final EditContactDetailsPage editContactDetailsPage) {
        this.editContactDetailsPage = editContactDetailsPage;
    }

    @When("^I update my Contact Details '(.*)'$")
    public void i_edit_my_contact_details_entry(String field) {
        this.logger.info(MessageFormat.format("** Attempt to edit ''{0}'' ...", field));

        this.editContactDetailsPage.changeMobile.click();

        this.logger.info(MessageFormat.format("** Entry ''{0}'' updated!\n", field));
    }
}
