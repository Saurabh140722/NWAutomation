package com.o2.pages.csrd;

import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.FindByKey;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.o2.pages.BasePage;

public class ResidentialAccountIntroPage extends BasePage {
    @Find(by = By.Id, locator = "email")
    public PageElement email;

    @Find(by = By.Id, locator = "confirm-email")
    public PageElement reEnterEmail;


//    @Find(by = By.Id, locator = "continueButton")
//    public PageElement continueButton;

    @FindByKey(key ="continueButton")
    public PageElement continueButton;

    @Find(by = By.Id, locator = "assistedCareError")
    public PageElement errorMessage;

}
