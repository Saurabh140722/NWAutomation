package com.o2.pages.csrd;

import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.o2.pages.BasePage;

public class SignInContractPage extends BasePage {
    @Find(by = By.Id, locator = "ui-id-1")
    public PageElement signPopoup;

    @Find(by = By.Id, locator = "9134592689313199787")
    public PageElement customerSigneeDate;

    @Find(by = By.CssSelector, locator = ".nc-table-cell-checkbox")
    public PageElement acceptTheSimo;

    @Find(by = By.CssSelector, locator = "button[class*='gwt-Button button_action_id_']")
    public PageElement saveButton;

    @Override
    public PageElement getPageCheckElement() {
        return this.customerSigneeDate;
    }
}
