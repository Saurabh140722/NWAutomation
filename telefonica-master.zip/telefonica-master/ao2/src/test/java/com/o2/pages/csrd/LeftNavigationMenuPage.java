package com.o2.pages.csrd;

import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.nttdata.cinnamon.driver.controls.PageElementCollection;
import com.o2.pages.BasePage;

import java.text.MessageFormat;

import static org.assertj.core.api.Assertions.assertThat;

public class LeftNavigationMenuPage extends BasePage {
    @Find(by = By.CssSelector, locator = ".left-up-panel")
    public PageElement leftMenuRoot;

    @Override
    protected PageElement getPageCheckElement() {
        return this.leftMenuRoot;
    }

    public PageElementCollection getLeftMenuItems() {
        return leftMenuRoot.findAllBy(By.CssSelector, "a[id*='id_tab_']");
    }

    public PageElement getLeftMenuItem(String menuItem) {
        PageElement result = getLeftMenuItems().asList().stream()
                .filter(el -> el.getText().equalsIgnoreCase(menuItem))
                .findFirst()
                .orElse(null);

        assertThat(result != null && result.isDisplayed() && result.isEnabled())
                .withFailMessage(MessageFormat.format("Could not find menu item: ''{0}''!", menuItem))
                .isTrue();

        return result;
    }
}
