package com.o2.stepdefs.ecomm;

import com.google.inject.Inject;
import com.nttdata.cinnamon.cache.Context;
import com.nttdata.cinnamon.driver.Browser;
import com.nttdata.cinnamon.webdriver.util.ReadyState;
import com.o2.pages.ecomm.AccessoriesSelectedDetailPage;
import com.o2.pages.ecomm.PhonePage;
import io.cucumber.java.en.And;
import org.assertj.core.api.Assertions;

import java.text.MessageFormat;
import java.util.logging.Logger;

import static com.nttdata.cinnamon.wait.conditions.Conditions.readyState;
import static org.assertj.core.api.Assertions.assertThat;
import static com.nttdata.cinnamon.wait.ElementConditions.*;

public class AccessoriesSelectedDetailSteps extends BaseStep {
    private final Logger logger;
    private final AccessoriesSelectedDetailPage accessoriesSelectedDetailPage;
    private final Context context;
    private final Browser browser;
    private final PhonePage phonePage;

    @Inject
    public AccessoriesSelectedDetailSteps(final Logger logger, final AccessoriesSelectedDetailPage accessoriesSelectedDetailPage, final Context context, final Browser browser,final PhonePage phonePage) {

        this.logger = logger;
        this.accessoriesSelectedDetailPage = accessoriesSelectedDetailPage;
        this.context = context;
        this.browser = browser;
        this.phonePage = phonePage;
    }

    @And("^I add accessories detail in basket$")
    public void i_add_selected_detail_in_basket() {
        this.logger.info("** Accessories Detail Page is loaded...");
        this.browser.waitUntil(readyState(ReadyState.COMPLETE));
        boolean inStock = false;
        this.browser.setImplicitWait(30);
        String selectedAccessoryTitle = context.get("SelectedAccessoriesTitle").toString().replace("\n"," ");
        String selectedAccessoryName = context.get("SelectedAccessoriesName").toString().replace("\n"," ");
        String selectedAccessory = (selectedAccessoryTitle +" "+ selectedAccessoryName).replaceAll("[\\[\\]]","");
        Assertions.assertThat(phonePage.selectedPhoneDetails.isDisplayed(5)).withFailMessage(
                        "Accessory Details not loaded")
                .isTrue();
        this.logger.info(selectedAccessory+"----123:--- "+phonePage.selectedPhoneDetails.getText().replace("\n", " "));
        Assertions.assertThat(phonePage.selectedPhoneDetails.getText().replace("\n", " "))
                .withFailMessage(
                        MessageFormat.format("Selected Accessory ''{0}'' not displayed!", selectedAccessory))
                .isEqualTo(selectedAccessory);

        Assertions.assertThat(phonePage.stockAvailability.getText().trim())
                .withFailMessage(MessageFormat.format("Selected Accessory ''{0}'' is out of stock!", selectedAccessory))
                .isEqualTo("In stock");

        this.accessoriesSelectedDetailPage.AddToBasketBtn.waitUntil(displayed.and(enabled).and(present).and(clickable)).clickJs();
        /*
        List<AccessoriesSelectedDetail> accessoriesSelectedDetailList = this.accessoriesSelectedDetailPage.getAllAccessoriesSelectedDetail();
        this.context.set("SelectedAccessoriesDetail", accessoriesSelectedDetailList);
        List<String> accessories = (List<String>) this.context.get("SelectedAccessories");
<<<<<<< HEAD
        assertThat(accessories.size())
                .withFailMessage("Could not retrieve accessories from Context!")
                .isPositive();
=======

//        assertThat(accessories.size())
//                .withFailMessage("Could not retrieve accessories from Context!")
//                .isPositive();
>>>>>>> 8b4c812461b2dd8e00216de0405e3d43894b1ee8
        assertThat(accessories.get(1))
                .withFailMessage("Accessories selected name is not displayed!")
                .isEqualTo(accessoriesSelectedDetailList.get(0).deviceName);

        for (int i = 0; i < accessoriesSelectedDetailList.size(); i++) {
            if (accessoriesSelectedDetailList.get(i).availability.equals("In stock")) {
                this.accessoriesSelectedDetailPage.AddToBasketBtn.click();
                inStock = true;
                break;
            } else {
                assertThat(inStock)
                        .withFailMessage(
                                MessageFormat.format("Could not find device availability is: ''{0}''!",
                                        accessoriesSelectedDetailList.get(i).deviceTitle)
                        )
                        .isTrue();
            }
<<<<<<< HEAD
        }*/

        }

    }
