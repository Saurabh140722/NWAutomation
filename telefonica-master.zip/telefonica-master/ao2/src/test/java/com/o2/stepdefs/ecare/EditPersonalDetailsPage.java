package com.o2.stepdefs.ecare;

import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.nttdata.cinnamon.driver.controls.PageElementCollection;
import com.o2.pages.BasePage;
import org.apache.commons.lang.NotImplementedException;

import static org.assertj.core.api.Assertions.assertThat;

public class EditPersonalDetailsPage extends BasePage {
    @Find(by = By.CssSelector, locator = ".o2uk-dialog-content-parent.ng-tns-c43-0")
    public PageElement popupParentWindow;

    @Find(by = By.CssSelector, locator = "input[class*='o2uk-input-element mat-input-element']")
    public PageElementCollection personalDetailsElements;

    @Find(by = By.CssSelector, locator = ".o2uk-dialog-title__content")
    public PageElement popupTitle;

    @Find(by = By.CssSelector, locator = ".mat-focus-indicator.mat-button-base.o2uk-primary-button")
    public PageElementCollection buttons;

    @Find(by = By.CssSelector, locator = ".o2uk-dialog-title")
    public PageElement successTitle;

    @Find(by = By.CssSelector, locator = ".o2uk-dialog-title__button")
    public PageElement closeButton;

    @Override
    protected PageElement getPageCheckElement() {
        return this.popupTitle;
    }

    public PageElement titleName() {
        assertContactDetailsFormIsDisplayed();
        return this.personalDetailsElements.asList().get(0);
    }

    public PageElement firstName() {
        assertContactDetailsFormIsDisplayed();
        return this.personalDetailsElements.asList().get(1);
    }

    public PageElement middleName() {
        assertContactDetailsFormIsDisplayed();
        return this.personalDetailsElements.asList().get(2);
    }

    public PageElement lastName() {
        assertContactDetailsFormIsDisplayed();
        return this.personalDetailsElements.asList().get(3);
    }

    public PageElement dob() {
        assertContactDetailsFormIsDisplayed();
        return this.personalDetailsElements.asList().get(4);
    }

    public PageElement submitChangesButton() {
        assertThat(this.buttons.asList().size())
                .withFailMessage("Could not find Submit Changes Button form element in popup! Have locators changed?")
                .isEqualTo(2);

        return this.buttons.asList().get(1);
    }

    public PageElement saveButton() {
        assertThat(this.buttons.asList().size())
                .withFailMessage("Could not find Save Button form element in popup! Have locators changed?")
                .isEqualTo(2);

        return this.buttons.asList().get(1);
    }

    private void assertContactDetailsFormIsDisplayed() {
        assertThat(this.personalDetailsElements.asList().size())
                .withFailMessage("Could not find Contact Details form elements in popup! Have locators changed?")
                .isEqualTo(5);
    }
}
