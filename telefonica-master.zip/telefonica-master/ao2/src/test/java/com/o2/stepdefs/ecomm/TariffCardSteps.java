package com.o2.stepdefs.ecomm;

import com.google.inject.Inject;
import com.nttdata.cinnamon.driver.Browser;

import static org.assertj.core.api.Assertions.assertThat;

import com.nttdata.cinnamon.cache.Context;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.o2.models.ecomm.TariffCard;
import com.o2.pages.ecomm.TariffCardPage;
import com.o2.util.Common;
import io.cucumber.java.en.And;

import java.text.MessageFormat;
import java.util.List;

public class TariffCardSteps extends BaseStep {
    private final TariffCardPage tariffCardPage;
    private final Browser browser;
    private final Common common;
    private final Context context;

    @Inject
    public TariffCardSteps(final TariffCardPage tariffCardPage, final Browser browser, final Common common, final Context context) {

        this.tariffCardPage = tariffCardPage;
        this.browser = browser;
        this.common = common;
        this.context = context;
    }

    @And("^I add '(.*)' tariff for '(.*)' to basket$")
    public void i_select_tariff_for_tab_label(String tariffCard, String tabLabel) {
        this.logger.info("*Tariff card page for Pay monthly sim only plan is opened...");
        boolean found = false;
        for (PageElement tab : this.tariffCardPage.tariffCardTabLabel.asList()) {
            System.out.println("Test" + tab.getText());
            this.browser.setImplicitWait(5);
            if (tab.getText().contains(tabLabel)) {
                assertThat(this.tariffCardPage.getAllTariffCard().size() > 0).withFailMessage("Tariff Card are not displayed!").isTrue();
                List<TariffCard> tariffList = this.tariffCardPage.getAllTariffCard();
                this.context.set("allTariffCardDetail", tariffList);
                for (TariffCard tariff : this.tariffCardPage.getAllTariffCard()) {
                    if (tariff.title.getText().equalsIgnoreCase(tariffCard)) {
                        tariff.addToBasketBtn.click();
                        found = true;
                        break;
                    }
                }
                assertThat(found)
                        .withFailMessage(
                                MessageFormat.format("Could not find a Tariff Card whose name is: ''{0}''!",
                                        tariffCard)
                        )
                        .isTrue();
            }
        }

    }

}
