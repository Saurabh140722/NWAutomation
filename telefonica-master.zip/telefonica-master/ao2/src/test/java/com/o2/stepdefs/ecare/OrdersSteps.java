package com.o2.stepdefs.ecare;

import com.google.inject.Inject;
import com.nttdata.cinnamon.cache.Context;
import com.nttdata.cinnamon.driver.Browser;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.o2.models.ecare.OrderDetailsAdditionalInfo;
import com.o2.models.ecare.OrdersDetails;
import com.o2.pages.ecare.BillingHistoryPage;
import com.o2.pages.ecare.OrdersPage;
import com.o2.stepdefs.BaseStep;
import com.o2.util.Common;
import io.cucumber.java.en.And;
import org.apache.commons.lang.StringUtils;

import java.util.List;

import static com.nttdata.cinnamon.wait.ElementConditions.displayed;
import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

public class OrdersSteps extends BaseStep {

    private final BillingHistoryPage billingHistoryPage;
    private final OrdersPage ordersPage;
    private final Browser browser;
    private final Common common;
    private final Context context;
    @Inject
    public OrdersSteps(BillingHistoryPage billingHistoryPage, OrdersPage ordersPage, Browser browser, Common common, Context context){
        this.billingHistoryPage = billingHistoryPage;
        this.ordersPage = ordersPage;
        this.browser = browser;
        this.common = common;
        this.context = context;
    }

    public void sortPaymentsBy(String sortByValue, String sortByAscDescValue){
        billingHistoryPage.sortBy.clickJs();
        ordersPage.ordersSortByDate.waitUntil(displayed);
        ordersPage.ordersSortByPrice.waitUntil(displayed);
        if(sortByValue.equalsIgnoreCase("Date")){
            billingHistoryPage.sortByOptions.asList().stream()
                    .filter(p->p.getText().trim().equalsIgnoreCase(sortByAscDescValue))
                    .findFirst()
                    .orElse(null);
        }else if(sortByValue.equalsIgnoreCase("Amount")){
            PageElement pe = billingHistoryPage.sortByOptions.asList()
                    .stream()
                    .filter(p->p.getText().trim().equalsIgnoreCase(sortByAscDescValue))
                    .findFirst()
                    .orElse(null);
            pe.clickJs();
            billingHistoryPage.sortBy.clickJs();
        }
    }

    public void filterPaymentsBy(String filterByValue){
        billingHistoryPage.filterBy.clickJs();
        billingHistoryPage.filterByStatusCaption.waitUntil(displayed);
        if (!(billingHistoryPage.filterByClearAll.isDisplayed() && billingHistoryPage.filterBySelectAll.isDisplayed())) {
            billingHistoryPage.filterByStatusCaption.clickJs();
        }
        PageElement pe = billingHistoryPage.filterByOptions.asList().stream()
                .filter(p->p.getText().trim().equalsIgnoreCase("filterByValue"))
                .findFirst()
                .orElse(null);
        pe.clickJs();
        billingHistoryPage.filterBy.clickJs();
    }

    @And("Order page opens successfully")
    public void order_Page_Opens_Successfully() {
        this.logger.info("Navigating to Your Orders page...");
        ordersPage.yourOrders.waitUntil(displayed);
        ordersPage.manageOrders.waitUntil(displayed);
    }


    @And("I verify OrderDetails section displayed")
    public void i_Verify_OrderDetails_Section_Displayed() {
        this.logger.info("Verifying for Order Details Section...");
        if(ordersPage.orderCards.asList().isEmpty()){
            this.logger.info("There are no Orders..");
        }else  if(ordersPage.orderCards.asList().size()>0){
            this.logger.info("Order Details Present are :- "+ordersPage.orderCards.asList().size());
        }
    }

    @And("I verify OrderDetails of the date {string}")
    public void iVerifyOrderDetails(String orderDate) throws InterruptedException {
        this.browser.setImplicitWait(30);
        if(OrdersPage.orderDetailCards.isDisplayed()) {
            if ((!ordersPage.orderCards.asList().isEmpty()) && ordersPage.orderCards.asList().size() > 0) {
                Thread.sleep(10000);
                List<OrdersDetails> odList = ordersPage.getOrderDetails();
                OrdersDetails od = odList.stream().filter(p -> p.orderDate.getText().trim().equals("27 Apr 2022"))
                        .findFirst()
                        .orElse(null);
                ordersPage.selectedOrderNumber = od.orderNumber.getText().trim();
                this.context.set("selectedOrderNumber",ordersPage.selectedOrderNumber);
                od.viewOrderDetailsButton.waitUntil(displayed).scrollIntoView().clickJs();
            }
        }else this.logger.info("Orders Details are not present");
    }

    @And("I select the Orders to view in detail")
    public void iSelectTheOrdersToViewInDetail() {
        browser.setImplicitWait(20);
        ordersPage.yourOrderHeader.waitUntil(displayed);
        ordersPage.selectedOrderInOrderDetailPage.waitUntil(displayed);
        if(ordersPage.OrderDetailAdditionalInfo.isDisplayed()){
            List<OrderDetailsAdditionalInfo> odetA = ordersPage.getOrderDetailsAdditionalInfo();
            String selectedOrderNumber1 = StringUtils.substringAfterLast((String) this.context.get("selectedOrderNumber"),"");
            OrderDetailsAdditionalInfo odp = odetA.stream().filter(p->p.orderNumberMain.getText().contains(selectedOrderNumber1)).findFirst().orElse(null);
//            this.logger.info(odp.orderNumberMain.getText());
            assertThat(selectedOrderNumber1.equalsIgnoreCase(odp.orderNumberMain.getText().trim())).withFailMessage("Order Number was not selected correctly,"+selectedOrderNumber1+"<--Selected Order Number :: Order Number Clicked for Detail Info -->"+odp.orderNumberMain.getText());
        }
    }
}
