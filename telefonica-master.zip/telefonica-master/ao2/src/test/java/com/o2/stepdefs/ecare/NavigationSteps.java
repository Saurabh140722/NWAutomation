package com.o2.stepdefs.ecare;

import static com.nttdata.cinnamon.wait.ElementConditions.*;
import static com.nttdata.cinnamon.wait.conditions.Conditions.readyState;
import static org.assertj.core.api.Assertions.assertThat;

import java.text.MessageFormat;

import com.google.inject.Inject;
import com.nttdata.cinnamon.conf.Env;
import com.nttdata.cinnamon.driver.Browser;
import com.nttdata.cinnamon.driver.controls.PageElement;

import com.nttdata.cinnamon.webdriver.util.ReadyState;
import com.o2.pages.ecare.AccountLandingPage;
import com.o2.pages.ecare.SignInPage;
import com.o2.stepdefs.BaseStep;

import com.o2.util.Common;
import io.cucumber.java.en.Given;

public class NavigationSteps extends BaseStep {
    private final Browser browser;
    private final AccountLandingPage accountLandingPage;
    private final SignInPage signInPage;
    private final Common common;

    @Inject
    public NavigationSteps(final Browser browser, final AccountLandingPage accountLandingPage,
                           final SignInPage signInPage, Common common) {
        this.browser = browser;
        this.accountLandingPage = accountLandingPage;
        this.signInPage = signInPage;
        this.common = common;
    }

    @Given("^eCare application opens$")
    public void eCare_application_opens() throws InterruptedException {
        this.logger.info("*** Opening eCare application ...");

        this.browser.open(Env.get().envProperty("eCareHost"));
        this.browser.setImplicitWait(30);
        this.browser.waitUntil(readyState(ReadyState.COMPLETE));
        this.signInPage.email.waitUntil(displayed);
       assertThat(this.signInPage.isPageDisplayed())
                .withFailMessage("Sign In page not displayed - could not find Email field on the page!").isTrue();

        this.logger.info("*** eCare application opened!\n");
    }

    // TODO: will go as common
    @Given("^I navigate to '(.*)' page$")
    public void i_navigate_to_page(String linkName) {
        this.logger.info(MessageFormat.format("** Attempt to navigate to ''{0}'' ...", linkName));
        this.browser.waitUntil(readyState(ReadyState.COMPLETE));
         this.accountLandingPage.myO2MenuLink.waitUntil(displayed.and(enabled).and(clickable)).clickJs();
         assertThat(this.accountLandingPage.myO2MenuListParent.isDisplayed(5))
                .withFailMessage("My O2 menu has not opened!").isTrue();
         browser.setImplicitWait(5);
        PageElement submenuElement=this.accountLandingPage.getSubmenubyText(linkName);
        submenuElement.waitUntil(displayed.and(present).and(clickable));
        assertThat(submenuElement)
                .withFailMessage(MessageFormat.format("Could not find a submenu named: ''{0}''", linkName))
                .isNotNull();

        submenuElement.clickJs();
        this.logger.info(MessageFormat.format("** Navigation to ''{0}'' complete!\n", linkName));
    }

}
