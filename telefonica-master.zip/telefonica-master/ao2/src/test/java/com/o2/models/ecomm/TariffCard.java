package com.o2.models.ecomm;

import com.nttdata.cinnamon.driver.controls.PageElement;

public class TariffCard {
public PageElement title;
public PageElement label;
public PageElement infoText;
public PageElement price;
public PageElement addToBasketBtn;

    public TariffCard(PageElement title,PageElement label,PageElement infoText,PageElement price,PageElement addToBasketBtn)
    {
        this.title=title;
        this.label=label;
        this.infoText=infoText;
        this.price=price;
        this.addToBasketBtn=addToBasketBtn;
    }
    @Override
    public boolean equals(Object classobject) {
        if (classobject == this)
            return true;
        if (!(classobject instanceof TariffCard))
            return false;

        TariffCard extra = (TariffCard) classobject;
        return extra.title.equals(this.title);

    }



}
