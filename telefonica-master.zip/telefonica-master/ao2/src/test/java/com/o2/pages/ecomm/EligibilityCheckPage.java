package com.o2.pages.ecomm;

import com.google.inject.Inject;
import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.nttdata.cinnamon.driver.controls.PageElementCollection;
import com.o2.util.Common;

import static com.nttdata.cinnamon.wait.ElementConditions.*;
import static com.nttdata.cinnamon.wait.ElementConditions.clickable;
import static org.assertj.core.api.Assertions.assertThat;

public class EligibilityCheckPage extends BasePage {
    @Inject
    Common common;

    @Find(by = By.XPath, locator = "//h1[contains(@class,'checkout-header__title_text')]")
    public PageElement pageTitle;

    @Find(by = By.XPath, locator = "//o2uk-step-header[@aria-selected='true']//h2")
    public PageElement enableSectionHeader;

    @Find(by = By.XPath, locator ="//*[contains(@class,'o2uk-checkout-header')]//p")
    public PageElement currentCheckoutPage;

    @Find(by = By.XPath, locator ="//*[@formcontrolname='termsAndConditionsField']//input ")
    public PageElement termsAndConditionCheckBox;

    @Find(by = By.XPath, locator ="//*[contains(@class,'checkout-registration__intro-title')]")
    public PageElement yourDetailTileForExitingUser;

    @Find(by = By.XPath, locator ="//h2[text()='Your details ']")
    public PageElement yourDetailTileforEditing;

    @Find(by = By.XPath, locator ="//o2uk-your-details//o2uk-link/button")
    public PageElement yourDetailNeedToChangeAny;

    @Find(by = By.XPath, locator ="//*[@class='your-details__field-label']/following::b[contains(@class,'your-details__field-value')]")
    public PageElementCollection yourDetailDataForExitingUser;

    public PageElement getEditButton(String sectionName)
    {
        return this.browser.findBy(By.XPath,"//button[contains(@aria-label,'"+sectionName+"')]");
    }

    public PageElement getYourDetailEmail(String emailId)
    {
        PageElement email = this.browser.findBy(By.XPath,"//o2uk-your-details/div/div[2]//b[contains(@class,'your-details__field-value')]");
        if(email.waitUntil(displayed).getText().trim().contains(emailId))
            return email;
        else
            return null;    }

    @Find(by = By.XPath, locator = "//button[@type='button']/span[text()=' Continue ']")
    public PageElement userDetailsNOChangeContinue;

    @Find(by = By.XPath, locator = "//button[@type='button']/span[text()=' Confirm and continue ']")
    public PageElement deliveryContinue;

    @Find(by = By.XPath, locator = "//o2uk-your-details//button/span")
    public PageElement userDetailsContinue;

    @Find(by = By.XPath, locator = "//h2[text()=' Delivery or collection ']")
    public PageElement deliverNCollectionHeader;

    @Find(by = By.XPath, locator = "//button//span[text()='Home delivery']")
    public PageElement homeDelivery;

    @Find(by = By.XPath, locator = "//h2[contains(text(),'Your details ')]")
    public PageElement yourDetail;

    @Find(by = By.XPath, locator = "//button[@type='button']/span[text()=' Confirm and continue ']")
    public PageElement homeDeliveryContinue;

    @Find(by = By.XPath, locator = "//h2[text()='Eligibility check ']//following::*[text()=' YEARS AT YOUR ADDRESS ']//following::b[1]")//*[@id='mat-input-6']")
    public PageElement timeAtAddress;

    @Find(by = By.XPath, locator = "//h2[text()='Eligibility check ']//following::*[text()=' EMPLOYMENT STATUS ']//following::b[1]")//select[@formcontrolname='employmentStatusField']")//*[@id='mat-input-4']")
    public PageElement employmentStatus;

    @Find(by = By.XPath, locator = "//o2uk-radio-group/o2uk-radio-button")
    public PageElementCollection homeDeliveryOptionsRadiobutton;

    @Find(by = By.XPath, locator = "//h2[text()=' Delivery ']")
    public PageElementCollection DeliveryHeader;

    @Find(by = By.XPath, locator = "//o2uk-vertical-stepper//div[2]/o2uk-step-header//o2uk-svg-resolver")
    public PageElementCollection DeliveryHeaderEdit;

    public PageElement getHomeDeliveryOption(){

        return homeDeliveryOptionsRadiobutton.asList().get(2).clickJs();
    }

    @Find(by = By.XPath, locator = "//h2[text()='Eligibility check ']//following::*[text()=' PERSONAL ANNUAL INCOME ']//following::b[1]")
    public PageElement personalAnnualIncome;


    @Find(by = By.XPath, locator = "//*[@id='mat-checkbox-1-input']")
    public PageElement EligibilityCheckAgree;

    @Find(by = By.XPath, locator = "//*[@formcontrolname='termsAndConditionsField']//following::span[text()=' Confirm and continue ']")
    public PageElement eligibilityConfirmContinueBtn;

    @Find(by = By.XPath, locator = "//*[@id='mat-checkbox-1-input']/following::button[contains(@class,'mat-focus-indicator')]")
    public PageElement EligibilityCheckContinueBtn;

    @Find(by = By.XPath, locator = "//h2[text()='Eligibility check ']")
    public PageElement eligibiltyCheckHeader;

    @Find(by = By.XPath, locator = "//p[text()=' The eligibility check is complete ']")
    public PageElement eligibiltyCheckCompleteHeader;

    @Find(by = By.XPath, locator = "//button[@type='button']/span[text()=' Continue ']")
    public PageElementCollection continueBtn;

    @Find(by = By.XPath, locator = "//button[contains(text(),' Continue order anyway ')]")
    public PageElement contiueOrderWayBtn;

    @Find(by = By.XPath, locator = "//*[@placeholder='Select title']")
    public PageElement title;

    @Find(by = By.CssSelector, locator = ".o2uk-option-content")
    public PageElementCollection titleOptions;

    @Find(by = By.XPath, locator = "//*[@name='fname']")
    public PageElement firstName;

    @Find(by = By.XPath, locator = "//*[@name='mname']")
    public PageElement middleName;

    @Find(by = By.XPath, locator = "//*[@name='lname']")
    public PageElement lastName;

    @Find(by = By.XPath, locator = "//*[@name='bday']")
    public PageElement dob;

    @Find(by = By.XPath, locator = "//*[@name='tel']")
    public PageElement mobileNbr;

    @Find(by = By.XPath, locator = "//*[@name='address']")
    public PageElement houseNbr;

    @Find(by = By.XPath, locator = "//*[@name='postal']")
    public PageElement postCode;

    @Find(by = By.XPath, locator = "//span[contains(text(),'Find')]")
    public PageElement findBtn;

    @Find(by = By.XPath, locator = "//select[@formcontrolname='addressField']")
    public PageElement selectAddress;

    @Find(by = By.XPath, locator = "//o2uk-select[@formcontrolname='addressField']")
    public PageElement selectAddressUAT2;

    @Find(by = By.XPath, locator = "//o2uk-option")
    public PageElementCollection selectAddressOption;

    public void selectAddressFromDropdown() throws InterruptedException {
        findBtn.waitUntil(displayed.and(enabled).and(present).and(clickable)).clickJs();
        this.common.wait(2);
        selectAddressUAT2.clickJs();
        this.common.wait(2);
            assertThat(selectAddressOption.asList().size()).withFailMessage(
                            "Address does not exist for the entered postcode, Please check")
                    .isPositive();

            selectAddressOption.asList().get(0).clickJs();
            confirmContinueBtn.waitUntil(enabled);
            this.common.wait(2);

    }

    @Find(by = By.XPath, locator = "//span[contains(text(),' Confirm and continue ')]")
    public PageElement confirmContinueBtn;

    @Find(by = By.CssSelector, locator = "#cdk-step-content-0-1 > div > div > delivery > div.row.ng-star-inserted > div > o2uk-notification-message > div.o2uk-notification-message__flex-wrapper.ng-tns-c141-55.ng-star-inserted > h3")
    public PageElement errorReservingOrderMessage;

    @Find(by = By.XPath, locator = "//div[contains(@class,'checkout-registration__navigate-payment')]//button//span[text()=' Continue ']")
    public PageElement navigatePaymentContinueBtn;

    @Find(by = By.XPath, locator = "//h1[text()='Make sure your order is right for you']")
    public PageElement makeSureYourOrderPageTitle;


    @Find(by = By.XPath, locator = "//*[@formcontrolname='currentAddressDurationField']")
    public PageElement timeAtAddressDropDown;

    @Find(by = By.XPath, locator = "//*[@formcontrolname='employmentStatusField']")
    public PageElement employmentStatusDropDown;

    @Find(by = By.XPath, locator = "//*[@formcontrolname='annualIncomeField']") //o2uk-select
    public PageElement personalAnnualIncomeDropDown;

    @Find(by = By.XPath, locator = "//o2uk-option")
    public PageElementCollection selectOptions;

    public void selectEligilibilityCheckDropdowns() throws InterruptedException {
        logger.info("***Attempt to select the value from Eligilibility drop down*** ");
        this.browser.setImplicitWait(30);
        timeAtAddressDropDown.scrollIntoView().clickJs();
        Thread.sleep(10000);
        selectOptions.asList().stream().forEach(p-> this.logger.info(selectOptions.asList().size()+"-->"+p.getText()));
        PageElement ecTimeAtAddress = selectOptions.asList().stream().filter(p->p.getText().trim().equalsIgnoreCase("9 to 10 years"))
                .findFirst()
                .orElse(null);
        Thread.sleep(20000);
        ecTimeAtAddress.scrollIntoView().clickJs();
        Thread.sleep(10000);

        employmentStatusDropDown.scrollIntoView().clickJs();
        Thread.sleep(10000);
        selectOptions.asList().stream().forEach(p1-> this.logger.info(selectOptions.asList().size()+"-->"+p1.getText()));
        PageElement ecEmpStatus = selectOptions.asList().stream().filter(p1->p1.getText().trim().equalsIgnoreCase("Employed"))
                .findFirst()
                .orElse(null);
        Thread.sleep(20000);
        ecEmpStatus.scrollIntoView().clickJs();
        Thread.sleep(10000);

        personalAnnualIncomeDropDown.scrollIntoView().clickJs();
        Thread.sleep(10);
        selectOptions.asList().stream().forEach(p2-> this.logger.info(selectOptions.asList().size()+"-->"+p2.getText()));
        PageElement ecAnnualIncome = selectOptions.asList().stream().filter(p2->p2.getText().trim().equalsIgnoreCase("£40,001-£50,000"))
                .findFirst()
                .orElse(null);
        Thread.sleep(10000);
        ecAnnualIncome.scrollIntoView().clickJs();
        Thread.sleep(20000);
    }

}
