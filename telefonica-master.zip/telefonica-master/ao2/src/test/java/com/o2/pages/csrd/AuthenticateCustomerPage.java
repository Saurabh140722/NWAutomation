package com.o2.pages.csrd;

import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.nttdata.cinnamon.driver.controls.PageElementCollection;
import com.o2.pages.BasePage;

import java.text.MessageFormat;

import static org.assertj.core.api.Assertions.assertThat;

public class AuthenticateCustomerPage extends BasePage {
    @Find(by = By.Id, locator = "challengeAuthentication")
    public PageElement authenticateOptionsBlock;

    @Find(by = By.Id, locator = "owner-yes")
    public PageElement isAccountOwner;

    @Find(by = By.Id, locator = "owner-no")
    public PageElement isNotAccountOwner;

    @Find(by = By.Id, locator = "agentdefaultButton")
    public PageElement continueButton;

    @Find(by = By.Id, locator = "override")
    public PageElement override;

    @Find(by = By.Id, locator = "btnSubmit")
    public PageElement acceptBtn;

    @Override
    public PageElement getPageCheckElement() {
        return this.authenticateOptionsBlock;
    }

    public PageElementCollection getAuthenticateOptions() {
        PageElementCollection options = this.authenticateOptionsBlock.findAllBy(By.CssSelector, "label");

        assertThat(options.size())
                .withFailMessage("Could not find any Authentication Options!")
                .isGreaterThanOrEqualTo(1);

        return options;
    }

    public PageElement getAuthenticateOptions(String optionName) {
        PageElement element = this.getAuthenticateOptions().asList().stream()
                .filter(el -> el.getText().contains(optionName))
                .findFirst()
                .orElse(null);

        // If we'll use this for negative scenario then remove this assertion and place it within tests/actions
        assertThat(element)
                .withFailMessage(
                        MessageFormat.format(
                                "Could not find an Authenticate Option that matches: ''{0}''!", optionName))
                .isNotNull();

        return element;
    }
}
