package com.o2.models.ecare;

import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.nttdata.cinnamon.driver.controls.PageElementCollection;

public class PaymentInstrumentRow {
    public PageElement checkbox;
    public PageElement  name;
    public PageElement creationDate;
    public PageElement status;
    public PageElement defaultPayment;

    public PaymentInstrumentRow(PageElementCollection tableRow) {
        this.checkbox = tableRow.asList().get(0).findChild(By.Tag, "label");
        this.name = tableRow.asList().get(1).findChild(By.Tag, "a");
        this.creationDate = tableRow.asList().get(3);
        this.status = tableRow.asList().get(4);
        this.defaultPayment = tableRow.asList().get(5);
    }
}
