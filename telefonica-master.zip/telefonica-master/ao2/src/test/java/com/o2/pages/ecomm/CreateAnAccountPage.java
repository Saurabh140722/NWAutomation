package com.o2.pages.ecomm;

import com.google.inject.Inject;
import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.FindByKey;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.o2.core.util.Retry;

import static com.nttdata.cinnamon.wait.ElementConditions.*;
import static com.nttdata.cinnamon.wait.ElementConditions.clickable;
import static org.assertj.core.api.Assertions.assertThat;

public class CreateAnAccountPage extends BasePage {
    private final Retry retry;

    @Inject
    public CreateAnAccountPage(final Retry retry) {
        this.retry = retry;
    }


    @FindByKey(key ="registerLink")
    public PageElement registerLink;

    @Find(by = By.XPath, locator = "//a[@id='registerNow']")
    public PageElement newToO2Btton;

    @Find(by = By.Id, locator = "emailOnly")
    public PageElement email;

    @Find(by = By.Id, locator = "password")
    public PageElement password;

    @Find(by = By.Id, locator = "continueButton")
    public PageElement RegisterButton;

    @Find(by = By.XPath, locator = "//input[@placeholder='Select title']")
    public PageElement title;

    @Find(by = By.Name, locator = "fname")
    public PageElement firstName;

    @Find(by = By.Name, locator = "lname")
    public PageElement lastName;

    @Find(by = By.Name, locator = "bday")
    public PageElement dateOfBirth;

    @Find(by = By.Name, locator = "tel")
    public PageElement mobileNumber;

    @Find(by = By.Name, locator = "postal")
    public PageElement postalCode;

    @Find(by = By.XPath, locator = "//div[@class='select-address__find']//*[text()=' Find ']")
    public PageElement findButton;

    @Find(by = By.XPath, locator = "//select[@formcontrolname='addressField']")
    public PageElement SelectAddress;

    @Find(by = By.XPath, locator = "//div[contains(@class,'your-details')]//*[text()=' Confirm and continue ']")
    public PageElement confirmAndContinueButton;

    public void clickRegisterLink() {
        boolean result = retry.retryAction(() -> {
            try {
                registerLink.waitUntil(displayed.and(enabled).and(present).and(clickable)).clickJs();
                return true;
            } catch (Exception e) {
                logger.warn(">> Could not click on Register link! Error: " + e.getMessage() + "\nRetry ...");
                return false;
            }
        }, 6, 2);

        assertThat(result)
                .withFailMessage("Could not access Register link/menu!")
                .isTrue();
    }
}
