package com.o2.pages.ecare;
import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.nttdata.cinnamon.driver.controls.PageElementCollection;

public class MakeAReturnPage extends EcareBasePage{
    @Find(by = By.XPath, locator = "//h1[text()=' Make a return ']")
    public PageElement pageTitle;

    @Find(by = By.CssSelector, locator = ".o2uk-option")
    public PageElementCollection reasonForReturnDropDownValues;

    @Find(by = By.CssSelector, locator = ".o2uk-select-value")
    public PageElement reasonForReturnDropDown;

    @Find(by = By.XPath, locator = "//p[contains(@class,'o2uk-notification-message__title')]")
    public PageElement messageTitle;

    @Find(by = By.XPath, locator = "//p[@class='margin-top_size_s ng-star-inserted']")
    public PageElement messageText;

    @Find(by = By.XPath, locator = "//p[@class='ng-star-inserted']")
    public PageElement IMEINumber;

    @Find(by = By.XPath, locator = "//h2[text()=' Repayments ']/following::div[@class='content__description ng-star-inserted']")
    public PageElement itemYouReturningSection;

    public PageElement getReturnAmount() {
        return this.itemYouReturningSection.findBy(By.XPath, "//div[@class='o2uk-price ng-star-inserted']");
    }

    @Override
    public boolean isPageDisplayed() {
        if (!pageTitle.isDisplayed())
            return false;

        return pageTitle.getText().trim().equalsIgnoreCase("Make a return");
    }

}
