package com.o2.pages.csrd;

import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.o2.pages.BasePage;

public class BillingAccountFormPage extends BasePage {
    @Find(by = By.Id, locator = "9135386130713487803")
    public PageElement accountName;

    @Find(by = By.Id, locator = "9153459242813170005")
    public PageElement isVatInvoice;

    @Find(by = By.Id, locator = "id_refsel421742675_input")
    public PageElement billHandlingCode; // This is a complex control -> need to get children to gain access to options

    @Find(by = By.Id, locator = "id_refsel378255731_input")
    public PageElement paymentMethods; // This is a complex control -> need to get children to gain access to options

    @Find(by = By.CssSelector, locator = ".gwt-Button.button_action_id_9149312617013712023_9149312617013712061_compositepopup_1.TableCtrl-button.ParCtrl-editButton")
    public PageElement confirmButton; // This is a complex control -> need to get children to gain access to options

    @Find(by = By.CssSelector, locator = ".confirm-button.default-focus.ui-button.ui-corner-all.ui-widget")
    public PageElement confirmPopupButton; // This is a complex control -> need to get children to gain access to options

}
