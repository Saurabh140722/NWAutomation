package com.o2.pages.csrd;

import com.google.inject.Inject;
import com.nttdata.cinnamon.cache.Context;
import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.nttdata.cinnamon.driver.controls.PageElementCollection;
import com.o2.models.csrd.CustomerInteractionRow;
import com.o2.models.csrd.CustomerInteractionRowModel;
import com.o2.pages.BasePage;
import com.o2.util.Common;

import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import static com.nttdata.cinnamon.wait.ElementConditions.displayed;
import static org.assertj.core.api.Assertions.assertThat;

public class CustomerInteractionsPage extends BasePage {
    private final Common common;
    private final Context context;
    @Find(by = By.Id, locator = "label_9141531210113366722_csrdtablectrl_3")
    public PageElement pageTitle;

    @Find(by = By.CssSelector, locator = ".TableCtrl.nc-table-content-zebra.scroll")
    public PageElement interactionsTable;

    @Find(by = By.CssSelector, locator = "button[class^='gwt-Button button_action_id_'][class$='TableCtrl-button TableCtrl-button-icon InteractionNew']")
    public PageElement logInteractionButton;

    @Find(by = By.CssSelector, locator = ".ui-dialog.ui-corner-all.ui-widget.ui-widget-content.ui-front.JQPopup.ui-draggable.title-exist")
    public PageElement newInteractionPopup;

    @Find(by = By.CssSelector, locator = ".refsel_arrow")
    public PageElementCollection popupArrows;

    @Find(by = By.Id, locator = "nc_refsel_list_table")
    public PageElement optionsRoot;

//    @Find(by = By.CssSelector, locator = "div[id^='nc_refsel_list_title_row_']")
    @Find(by = By.CssSelector, locator = ".refsel_name")
    public PageElementCollection options;

    @Find(by = By.CssSelector, locator = ".nc-memo-field")
    public PageElement newInteractionDescription;

    @Find(by = By.CssSelector, locator = "div[class^='nc-toolbar-cell disable-border gwt-Button-wrapper button_action_id_'][class$='_compositepopup_4-wrapper TableCtrl-button-wrapper ParCtrl-editButton-wrapper']")
    public PageElement newInteractionCreateButton;

    @Find(by = By.CssSelector, locator = ".gwt-Label.nc-uip-page-caption")
    public PageElement interactionPageTitle;

    @Inject
    public CustomerInteractionsPage(final Common common,
                                    final Context context) {
        this.common = common;
        this.context = context;
    }

    @Override
    public boolean isPageDisplayed() {
        return this.pageTitle.isDisplayed() && this.pageTitle.getText().contains("Customer Interactions");
    }

    public List<CustomerInteractionRow> getCustomerInteractions() {
        List<CustomerInteractionRow> customerInteractions = new ArrayList<>();

        assertThat(this.interactionsTable.isDisplayed())
                .withFailMessage("Could not find Customer Interactions table!")
                .isTrue();

        PageElementCollection rows = this.interactionsTable.findAllBy(By.CssSelector, "tr[role='row']");

        assertThat(rows.size())
                .withFailMessage("Could not find any Customer Interactions!")
                .isGreaterThanOrEqualTo(1);

        for (PageElement row : rows.asList()) {
            PageElementCollection columns = row.findChildren(By.Tag, "td");
            customerInteractions.add(new CustomerInteractionRow(columns));
        }

        return customerInteractions;
    }

    public CustomerInteractionRowModel logNewInteraction(Map<String, String> interaction) {
        assertThat(this.popupArrows.size())
                .withFailMessage("Could not select/open drop down lists for Log New Interaction popup!")
                .isGreaterThanOrEqualTo(1);

        // Channel
        this.popupArrows.asList().get(0).click();
        assertThat(this.optionsRoot.waitUntil(displayed).isDisplayed())
                .withFailMessage("Drop down options not loaded!")
                .isTrue();
        this.getVisibleOptionByName(interaction.get("channel")).click();

        // Subject
        this.browser.setImplicitWait(5);
        this.popupArrows.asList().get(1).click();
        assertThat(this.optionsRoot.waitUntil(displayed).isDisplayed())
                .withFailMessage("Drop down options not loaded!")
                .isTrue();
        this.getVisibleOptionByName(interaction.get("subject")).click();

        // Description
        String description = MessageFormat.format(
                "{0} - {1}",
                new SimpleDateFormat("dd-MM-yyyy HH:mm:ss").format(new Date()),
                interaction.get("description"));
        this.newInteractionDescription.setValue(description);

        // Relates to
        this.popupArrows.asList().get(3).click();
        assertThat(this.optionsRoot.waitUntil(displayed).isDisplayed())
                .withFailMessage("Drop down options not loaded!")
                .isTrue();
        this.getVisibleOptionByName(interaction.get("relates_to")).click();

        CustomerInteractionRowModel customerInteractionRowModel = new CustomerInteractionRowModel();
        customerInteractionRowModel.subject = interaction.get("subject");
        customerInteractionRowModel.interactionName = MessageFormat.format(
                "{0} - {1}",
                interaction.get("channel"), interaction.get("subject"));
        customerInteractionRowModel.subject = interaction.get("subject");
        customerInteractionRowModel.description = description;
        customerInteractionRowModel.relatesTo = interaction.get("relates_to");
        customerInteractionRowModel.interactionDate = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new Date());
        customerInteractionRowModel.initiatedBy = "Agent";

        // Create
        this.newInteractionCreateButton.click();
        this.browser.restoreImplicitWait();

        return customerInteractionRowModel;
    }

    public PageElement getVisibleOptionByName(String optionName) {
        PageElement option = options.asList().stream()
                .filter(o -> o.isDisplayed() && o.getText().contains(optionName))
                .findFirst()
                .orElse(null);

        assertThat(option)
                .withFailMessage(MessageFormat.format(
                        "Could not find an option with name: ''{0}''!", optionName
                ))
                .isNotNull();

        return option;
    }
}
