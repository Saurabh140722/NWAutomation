package com.o2.acceptancetests.csrd.DATA_VOLUME_BDD_TEST_RUNNERS.Custom_Plans;

import com.o2.feature_file_appender.config.AppendDataToFeatureFile_Utility;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;

import java.util.function.Predicate;

import static org.junit.Assert.assertTrue;

@RunWith(Cucumber.class)
@CucumberOptions(
        plugin = {"com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:", "summary"},
        glue = {"com.o2.stepdefs", "com.o2.hooks"},
        features = "src/test/resources/features/BDD_TESTS_DATA_VOLUME/Custom_Plans_Tab/Data_Vol_Watches_Apple.feature",
        tags = "@cp_watches_apple"
)
public class CP_Watches_Apple_TestRunner {
    private AppendDataToFeatureFile_Utility utility;

    public CP_Watches_Apple_TestRunner() {
        utility = new AppendDataToFeatureFile_Utility();;
        utility.setExcelTab("Custom_Plans_Tab");
        utility.readCleanseDataSourceFileInto2DArray_CustomPlans("Custom_Plans.csv", true);
        Predicate<String> predStringEquals = s -> (s.equalsIgnoreCase("TBU"));
        Object[] args = {predStringEquals, 2, 0, 4};
        assertTrue(utility.copyFeatureFile("Watches_Apple.feature"));
        assertTrue(utility.appendDataToNewFeatureFile("outline", "filtered_map_by_colrange", args));
    }

    @BeforeClass
    public static void setup() {
        // Any BeforeAll logic ...
    }

    @AfterClass
    public static void teardown() {
        // BrowserUtil.getBrowser().close();
    }
}