package com.o2.pages.csrd;

import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.nttdata.cinnamon.driver.controls.PageElementCollection;
import com.o2.pages.BasePage;

import java.text.MessageFormat;

import static org.assertj.core.api.Assertions.assertThat;

public class OrderReviewPage extends BasePage {
    @Find(by = By.CssSelector, locator = ".nc-interaction.nc-interaction-submit.notes-textarea")
    public PageElement interactionDescription;

  //  @Find(by = By.XPath, locator = "//span[contains(text(),'Order Parameters')]")
  //  public PageElement orderParametersBlock;


    @Find(by = By.CssSelector, locator = ".order-configuration-block__sh-button._hidden")
    public PageElement orderParametersBlock;

    @Find(by = By.Id, locator = "listCharacteristicsSelect_9158507778513980661")
    public PageElement readTheScriptConfirmation;

    @Find(by = By.Id, locator = "listCharacteristicsSelect_9158507778513980661_script")
    public PageElement scriptLink;

    @Find(by = By.CssSelector, locator = ".info_box.warnings.roe-widget")
    public PageElement warningsRoot;

    @Find(by = By.CssSelector, locator = ".text_box.roe-warning.roe-warning-major.server-item")
    public PageElementCollection warningBlocks;

    @Find(by = By.CssSelector, locator = ".contracts__button")
    public PageElementCollection buttons;

    @Find(by = By.XPath, locator = "//button[text()='Continue anyway']")
    public PageElement continueAnywayBtn;


//    @Find(by = By.XPath, locator = "/html/body/div[3]/div[2]/div[2]/div[1]/div[3]/div/div[2]/ul/li[1]/div/button")
//    public PageElement creditCheckButton;
//
//    @Find(by = By.XPath, locator = "/html/body/div[3]/div[2]/div[2]/div[1]/div[3]/div/div[2]/ul/li[4]/div/button[1]")
//    public PageElement configureContract;

    @Find(by = By.CssSelector, locator = ".contract-element-name")
    public PageElement contractName;

    @Find(by = By.CssSelector, locator = ".contract-element-link")
    public PageElementCollection contractLinks;
    @Find(by = By.XPath, locator = "//th[text()='Discounts']")
    public PageElement discountSection;
    @Find(by = By.XPath, locator = "//div[@class='offer-elements']//tfoot//tr[1]/th[2]")
    public PageElement discountNonRecurringCharge;
    @Find(by = By.XPath, locator = "//div[@class='offer-elements']//tfoot//tr[1]/th[2]")
    public PageElement discountRecurringCharge;

    @Find(by = By.XPath, locator = "//div[@class='characteristic-item']//div[2]//div//span//select[1]")
    public PageElementCollection selectJourneyType;

    @Find(by = By.XPath, locator = "//div[@class='characteristic-item']//div[2]//div//span//select[2]")
    public PageElement selectProductType;



    @Override
    public PageElement getPageCheckElement() {
        return this.interactionDescription;
    }

    public int getWarnings() {
        return this.warningBlocks.size();
    }

    public PageElement getButton(String buttonName) {
        PageElement result = this.buttons.asList().stream()
                .filter(b -> b.getText().equalsIgnoreCase(buttonName))
                .findFirst()
                .orElse(null);

        assertThat(result)
                .withFailMessage(
                        MessageFormat.format("Could not find a button named ''{0}''!", buttonName))
                .isNotNull();

        return result;
    }

    public PageElement getSignInContract() {
        return this.contractLinks.asList().get(2);
    }
}
