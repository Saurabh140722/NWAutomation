package com.o2.feature_file_appender.unit_tests.mockito;

import com.o2.feature_file_appender.unit_tests.config.pojo.all_sim_plans_tab.TariffOffering;
import com.o2.feature_file_appender.unit_tests.config.TestBase_Mocked;
import org.junit.Test;

import java.util.List;

public class MockedTests extends TestBase_Mocked {
    private TariffOffering tariffOffering1;
    private TariffOffering tariffOffering2;
    private List<TariffOffering> tariffOfferingList;

    @Test
    public void mockitoKeyFeaturesExample() {
        //TODO
        // mock the value returned when calling a specific method
        //when(utility.getPartialOutputFilePath()).thenReturn("SampleTestName");

        // verify that the method is called once
        //verify(DemoImpl, times(1)).setTestMethodName(testInfo);
    }
}
