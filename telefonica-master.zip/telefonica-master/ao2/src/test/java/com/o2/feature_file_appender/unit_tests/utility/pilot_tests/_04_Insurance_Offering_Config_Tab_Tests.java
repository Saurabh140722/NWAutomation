package com.o2.feature_file_appender.unit_tests.utility.pilot_tests;

import com.o2.feature_file_appender.config.AppendDataToFeatureFile_Utility;
import org.junit.Before;
import org.junit.Test;

import java.util.function.Predicate;

import static org.junit.Assert.assertTrue;

public class _04_Insurance_Offering_Config_Tab_Tests {
    private AppendDataToFeatureFile_Utility ioc_utility;

    @Before
    public void beforeTest() {
        ioc_utility = new AppendDataToFeatureFile_Utility();
        ioc_utility.setExcelTab("Insurance_Offering_Config_Tab");
        ioc_utility.readCleanseDataSourceFileInto2DArray_InsuranceOfferingConfig("Insurance_Offering_Config.csv", false);
    }

    @Test
    public void filterResultsUsingPredicateByMap_GetMapValColRange_StringContains_PhonesAndroid() {
        Predicate<String> predStringEquals = s -> (s.contains("Nord2"));
        Object[] args = {predStringEquals, 1, 0, 2};
        assertTrue(ioc_utility.copyFeatureFile("Phones_Android.feature"));
        assertTrue(ioc_utility.appendDataToNewFeatureFile("outline", "filtered_map_by_colrange", args));
    }

    @Test
    public void filterResultsUsingPredicateByMap_GetMapValColRange_StringContains_PhonesApple() {
        Predicate<String> predStringEquals = s -> (s.contains("iPhone"));
        Object[] args = {predStringEquals, 1, 0, 2 };
        assertTrue(ioc_utility.copyFeatureFile("Phones_Apple.feature"));
        assertTrue(ioc_utility.appendDataToNewFeatureFile("outline", "filtered_map_by_colrange", args));
    }

    @Test
    public void filterResultsUsingPredicateByMap_GetMapValColRange_StringContains_TabletsAndroid() {
        Predicate<String> predStringEquals = s -> (s.contains("Galaxy Tab"));
        Object[] args = {predStringEquals, 1, 0, 2};
        assertTrue(ioc_utility.copyFeatureFile("Tablets_Android.feature"));
        assertTrue(ioc_utility.appendDataToNewFeatureFile("outline", "filtered_map_by_colrange", args));
    }

    @Test
    public void filterResultsUsingPredicateByMap_GetMapValColRange_StringContains_TabletsApple() {
        Predicate<String> predStringEquals = s -> (s.contains("iPad"));
        Object[] args = {predStringEquals, 1, 0, 2};
        assertTrue(ioc_utility.copyFeatureFile("Tablets_Apple.feature"));
        assertTrue(ioc_utility.appendDataToNewFeatureFile("outline", "filtered_map_by_colrange", args));
    }

    @Test
    public void filterResultsUsingPredicateByMap_GetMapValColRange_StringContains_TabletsWindows() {
        Predicate<String> predStringEquals = s -> (s.contains("Ideapad") || s.contains("Surface Pro"));
        Object[] args = {predStringEquals, 1, 0, 2};
        assertTrue(ioc_utility.copyFeatureFile("Tablets_Windows.feature"));
        assertTrue(ioc_utility.appendDataToNewFeatureFile("outline", "filtered_map_by_colrange", args));
    }

    @Test
    public void filterResultsUsingPredicateByMap_GetMapValColRange_StringContains_WatchesAndroid() {
        Predicate<String> predStringEquals = s -> (s.contains("Galaxy Watch"));
        Object[] args = {predStringEquals, 1, 0, 2};
        assertTrue(ioc_utility.copyFeatureFile("Watches_Android.feature"));
        assertTrue(ioc_utility.appendDataToNewFeatureFile("outline", "filtered_map_by_colrange", args));
    }

    @Test
    public void filterResultsUsingPredicateByMap_GetMapValColRange_StringContains_WatchesApple() {
        Predicate<String> predStringEquals = s -> (s.contains("Watch SE Sport") || s.contains("Watch Series 5"));
        Object[] args = {predStringEquals, 1, 0, 2};
        assertTrue(ioc_utility.copyFeatureFile("Watches_Apple.feature"));
        assertTrue(ioc_utility.appendDataToNewFeatureFile("outline", "filtered_map_by_colrange", args));
    }
}