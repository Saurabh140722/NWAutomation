package com.o2.pages.csrd;

import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.o2.pages.BasePage;

public class BillingAccountPage extends BasePage {
    @Find(by = By.CssSelector, locator = ".gwt-Button.button_action_id_9135559518513278430_9135459545013238088_baiptablectrl_1.TableCtrl-button.TableCtrl-button-icon.NewNote")
//    @Find(by = By.CssSelector, locator = "button[class*='.gwt-Button.button_action_id_9135559518513278430_9135459545013238088_baiptablectrl_']")
    public PageElement newBillingAccountButton;

    @Find(by = By.PartialLinkName, locator = "Pay Monthly")
    public PageElement payMonthlyBillingAccount;

    @Override
    protected PageElement getPageCheckElement() {
        return this.newBillingAccountButton;
    }
}
