package com.o2.feature_file_appender.unit_tests.utility.pilot_tests;

import com.o2.feature_file_appender.config.AppendDataToFeatureFile_Utility;
import org.junit.Before;
import org.junit.Test;

import java.util.function.Predicate;

import static org.junit.Assert.assertTrue;

public class _05_Custom_Plans_Tab_Tests {
    private AppendDataToFeatureFile_Utility cp_utility;

    @Before
    public void beforeTest() {
        cp_utility = new AppendDataToFeatureFile_Utility();
        cp_utility.setExcelTab("Custom_Plans_Tab");
        cp_utility.readCleanseDataSourceFileInto2DArray_CustomPlans("Custom_Plans.csv", true);
    }

    @Test
    public void filterResultsUsingPredicateByMap_GetMapValColRange_StringEquals_PhonesAndroid() {
        Predicate<String> predStringEquals = s -> (s.contains("Nord2"));
        Object[] args = {  predStringEquals, 2, 0, 4 };
        assertTrue(cp_utility.copyFeatureFile("Phones_Android.feature"));
        assertTrue(cp_utility.appendDataToNewFeatureFile("scenario","filtered_map_by_colrange", args));
    }

    @Test
    public void filterResultsUsingPredicateByMap_GetMapValColRange_StringEquals_PhonesApple() {
        Predicate<String> predStringEquals = s -> (s.contains("iPhone"));
        Object[] args = {  predStringEquals, 2, 0, 4 };
        assertTrue(cp_utility.copyFeatureFile("Phones_Apple.feature"));
        assertTrue(cp_utility.appendDataToNewFeatureFile("scenario", "filtered_map_by_colrange", args));
    }

    @Test
    public void filterResultsUsingPredicateByMap_GetMapValColRange_StringEquals_TabletsAndroid() {
        Predicate<String> predStringEquals = s -> (s.contains("Galaxy Tab"));
        Object[] args = {  predStringEquals, 2, 0, 4 };
        assertTrue(cp_utility.copyFeatureFile("Tablets_Android.feature"));
        assertTrue(cp_utility.appendDataToNewFeatureFile("scenario","filtered_map_by_colrange", args));
    }

    @Test
    public void filterResultsUsingPredicateByMap_GetMapValColRange_StringEquals_TabletsApple() {
        Predicate<String> predStringEquals = s -> (s.contains("iPad"));
        Object[] args = {  predStringEquals, 2, 0, 4 };
        assertTrue(cp_utility.copyFeatureFile("Tablets_Apple.feature"));
        assertTrue(cp_utility.appendDataToNewFeatureFile("scenario","filtered_map_by_colrange", args));
    }

    @Test
    public void filterResultsUsingPredicateByMap_GetMapValColRange_StringEquals_TabletsWindows() {
        Predicate<String> predStringEquals = s -> (s.contains("Ideapad") || s.contains("Surface Pro"));
        Object[] args = {  predStringEquals, 2, 0, 4 };
        assertTrue(cp_utility.copyFeatureFile("Tablets_Windows.feature"));
        assertTrue(cp_utility.appendDataToNewFeatureFile("scenario","filtered_map_by_colrange", args));
    }

    @Test
    public void filterResultsUsingPredicateByMap_GetMapValColRange_StringEquals_WatchesAndroid() {
        Predicate<String> predStringEquals = s -> (s.contains("Galaxy Watch"));
        Object[] args = {  predStringEquals, 2, 0, 4 };
        assertTrue(cp_utility.copyFeatureFile("Watches_Android.feature"));
        assertTrue(cp_utility.appendDataToNewFeatureFile("scenario","filtered_map_by_colrange", args));
    }

    @Test
    public void filterResultsUsingPredicateByMap_GetMapValColRange_StringEquals_WatchesApple() {
        Predicate<String> predStringEquals = s -> (s.contains("Watch SE Sport") || s.contains("Watch Series 5"));
        Object[] args = {  predStringEquals, 2, 0, 4 };
        assertTrue(cp_utility.copyFeatureFile("Watches_Apple.feature"));
        assertTrue(cp_utility.appendDataToNewFeatureFile("scenario","filtered_map_by_colrange", args));
    }

}
