package com.o2.stepdefs.csrd;

import com.google.inject.Inject;
import com.nttdata.cinnamon.cache.Context;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.nttdata.cinnamon.logging.Logger;
import com.o2.core.util.Retry;
import com.o2.models.csrd.Sort;
import com.o2.pages.csrd.ActivitiesPage;
import com.o2.pages.csrd.TodoItemPopupPage;
import com.o2.stepdefs.BaseStep;
import com.o2.util.Common;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.lang3.StringUtils;

import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.function.Supplier;
import java.util.stream.Collectors;

import static com.nttdata.cinnamon.wait.ElementConditions.displayed;
import static org.assertj.core.api.Assertions.assertThat;

public class ActivitiesSteps extends BaseStep {
    private final Logger logger;
    private final Retry retry;
    private final Context context;
    private final ActivitiesPage activitiesPage;
    private final TodoItemPopupPage todoItemPopupPage;
    private final Common common;

    @Inject
    public ActivitiesSteps(final Logger logger,
                           final Retry retry,
                           final Context context,
                           final ActivitiesPage activitiesPage,
                           final TodoItemPopupPage todoItemPopupPage, Common common) {
        this.logger = logger;
        this.retry = retry;
        this.context = context;
        this.activitiesPage = activitiesPage;
        this.todoItemPopupPage = todoItemPopupPage;
        this.common = common;
    }

    @When("^I add a new TODO item with:$")
    public void i_add_a_new_todo_item_with(DataTable table) {
        this.logger.info("*** Add new TODO Item Activity ...");

        this.context.set("totalTodoItemsBefore", this.activitiesPage.getTotalNoOfItems());

        this.activitiesPage.newTodoItemButton.waitUntil(displayed).click();
        assertThat(this.todoItemPopupPage.isPageDisplayed(10))
                .withFailMessage("New Todo Item Popup page not displayed!")
                .isTrue();

        String newTodoItemTitle = MessageFormat.format(
                "New todo item on {0}",
                new SimpleDateFormat("dd-MM-yyyy HH.mm.ss").format(new Date()));
        this.context.set("newTodoItemTitle", newTodoItemTitle);

        this.todoItemPopupPage.subject.waitUntil(displayed).setValue(newTodoItemTitle);
        this.todoItemPopupPage.type.asSelect().selectByText("Contact customer");
        this.todoItemPopupPage.arrowLink.asList().get(1).click();
        this.common.waitForLoadingToComplete(3,1);
      this.todoItemPopupPage.assignedToGroupOption.asList().get(2).click();
        this.todoItemPopupPage.createButton.click();

        Supplier<PageElement> processIcon = () -> this.todoItemPopupPage.subject;
        Boolean result = this.retry.untilNotDisplayed(processIcon, 12, 1);
        assertThat(result)
                .withFailMessage("Process icon still displayed after adding a new TODO item!")
                .isTrue();

        this.logger.info("*** TODO Item Activity submitted!\n");
    }

    @Then("^my Activities information is updated$")
    public void my_activities_information_is_updated() {
        int totalTodoItemsBefore = (int) this.context.get("totalTodoItemsBefore");
        int totalTodoItemsAfter = this.activitiesPage.getTotalNoOfItems();
        this.common.waitForLoadingToComplete(3,1);
//        assertThat(totalTodoItemsBefore + 1)
//                .withFailMessage(
//                        MessageFormat.format(
//                                "No new activities have been added to Activities table!\nBefore:{0}\nAfter:{1}",
//                                totalTodoItemsBefore, totalTodoItemsAfter))
//                .isEqualTo(totalTodoItemsAfter);

        this.activitiesPage.sortByDate(Sort.DESCENDING);

        List<String> currentActivities= this.activitiesPage.getRows().asList().stream()
                    .map(PageElement::getText)
                    .collect(Collectors.toList());
        String expectedActivityName = (String) this.context.get("newTodoItemTitle");

        assertThat(currentActivities.contains(expectedActivityName))
                .withFailMessage(
                        MessageFormat.format(
                                "Could not find the newly added Activity which name is: ''{0}''! Current activities: ''{1}''!",
                                expectedActivityName,
                                StringUtils.join(currentActivities, "\n")))
                .isTrue();
    }
}
