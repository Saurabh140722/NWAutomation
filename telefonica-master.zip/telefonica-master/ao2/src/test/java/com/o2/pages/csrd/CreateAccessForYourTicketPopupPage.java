package com.o2.pages.csrd;

import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.nttdata.cinnamon.driver.controls.PageElementCollection;
import com.o2.pages.BasePage;

import static com.nttdata.cinnamon.wait.ElementConditions.displayed;

public class CreateAccessForYourTicketPopupPage extends BasePage {
    @Find(by = By.Id, locator = "9154522161013179182")
    public PageElement customerConsentProvided; // Yes/No

    @Find(by = By.CssSelector, locator = ".refsel_arrow")
    public PageElementCollection textFieldsControls;


    @Find(by = By.Id, locator = "id_refsel1363328121_input")
    public PageElement contactNameField; // User test data

    @Find(by = By.Id, locator = "nc_refsel_list_row_0")
    public PageElement contactNameOption; // User test data

    @Find(by = By.CssSelector, locator = "#id_refsel1453510712_div > div > i")
    public PageElement nomineeContactArrowLink;

    @Find(by = By.Id, locator = "nc_refsel_list_row_0")
    public PageElement nomineeContactOption;

    @Find(by = By.Id, locator = "9154746523113189161")
    public PageElement reasonForReview; // any text

    @Find(by = By.Id, locator = "9154522161013179155")
    public PageElement initiatedBy; // Customer/Third Party Contact

    @Find(by = By.Id, locator = "id_refsel1122888489_input")
    public PageElement reportedByField; // User test data

    @Find(by = By.Id, locator = "nc_refsel_list_row_0")
    public PageElement reportedByOption; // User test data

    @Find(by = By.CssSelector, locator = "button[class*='button_action_id_9154796484413152647_9154796484413152650_compositepopup_']")
    public PageElement createButton;

    @Override
    protected PageElement getPageCheckElement() {
        return this.customerConsentProvided;
    }

    public void setContactName() {
        this.textFieldsControls.asList().get(0).waitUntil(displayed).click();
        this.contactNameOption.waitUntil(displayed).click();
    }

    public void setNomineeContact() {
        this.textFieldsControls.asList().get(1).waitUntil(displayed).click();
        this.nomineeContactOption.waitUntil(displayed).click();
    }

    public void setReportedBy() {
        this.textFieldsControls.asList().get(2).waitUntil(displayed).click();
        this.reportedByOption.waitUntil(displayed).click();
    }
}
