package com.o2.pages.ecomm;

import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.nttdata.cinnamon.driver.controls.PageElementCollection;

public class AgreementPage extends EcommBasePage {
    @Find(by = By.XPath, locator = "//button[contains(text(),' Download Pay Monthly Mobile Agreement ')]")
    public PageElement downloadPayMonthlyAgreementBtn;

    @Find(by = By.XPath, locator = "//*[@id='mat-checkbox-3-input']")
    public PageElement termConditionCheckBox;

    @Find(by = By.XPath, locator = "//*[@id='mat-checkbox-4-input']")
    public PageElement changeMindPolicyCheckBox;

    @Find(by = By.XPath, locator = "//*[@id='mat-checkbox-5-input']")
    public PageElement confirmationCheckBox;

    @Find(by = By.XPath, locator = "//button[@type='submit']/span[contains(text(),' Continue ')]")
    public PageElement monthalyMobileAgreementContinueBtn;

    @Find(by = By.XPath, locator = "//button[@type='button']/span[contains(text(),' Continue ')]")
    public PageElement continueBtn;

    @Find(by = By.CssSelector, locator = ".o2uk-dialog-title")
    public PageElement popupError;

    @Find(by = By.CssSelector, locator = "#cdk-step-content-3-0 > div > div > div > div > div.contract-agreement-info__continue-button.margin-top.margin-top_size_l.margin-bottom_size_m.ng-star-inserted > button")
    public PageElement continueButton;

    @Find(by = By.XPath, locator = "//span[contains(text(),' Pay now ')]")
    public PageElement payNowButton;

    @Find(by = By.CssSelector, locator = ".o2uk-checkbox-inner-container")
    public PageElementCollection agreementCheckboxes;

    @Find(by = By.XPath, locator = "//span[contains(text(),' Continue ')]")
    public PageElementCollection continueButtons;

    @Find(by = By.XPath, locator ="//h2[contains(text(),'Key information')]")
    public PageElement keyInformation;

    @Find(by = By.XPath, locator ="//h2[contains(text(),'Pre-contract Credit Information (PCCI)')]")
    public PageElement creditInformationPCCI;

    @Find(by = By.XPath, locator ="//o2uk-step-header[@aria-selected='true']//h2[contains(text(),'Consumer Credit Agreement')]")
    public PageElement creditAgreement;

    @Find(by = By.XPath, locator ="//o2uk-step-header[@aria-selected='true']//h2[contains(text(),'Pay Monthly Mobile Agreement')]")
    public PageElement payMobileAgreement;

    @Find(by = By.XPath, locator ="//o2uk-cics-section/div/button")
    public PageElement sendContractInfoAndSummary;

    @Find(by = By.XPath, locator ="//o2uk-cics-section/div/o2uk-notification-message[3]/div[1]")
    public PageElement contractInfoAndSummarySENT;

    @Find(by = By.XPath, locator ="//o2uk-checkbox//div[@class='o2uk-checkbox-inner-container']//input[@aria-checked='false']")
    public PageElement contractInfoAndSummaryReceivedConfirm;

    @Find(by = By.XPath, locator ="//o2uk-cics-section//button/span[text()=' Confirm and continue ']")
    public PageElement confirmNContinue;

    @Find(by = By.XPath, locator ="//o2uk-registration//div[contains(@class,'checkout-registration__navigate-payment')]//button")
    public PageElement continuetoPayment;




}
