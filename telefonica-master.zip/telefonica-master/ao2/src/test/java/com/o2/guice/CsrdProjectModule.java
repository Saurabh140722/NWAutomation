package com.o2.guice;

import com.google.inject.AbstractModule;
import com.google.inject.Singleton;
import com.o2.acceptancetests.csrd.BrowserUtil;
import com.o2.pages.csrd.*;
import com.o2.core.util.Common;
import com.o2.models.csrd.LoginCsrUserData;
import com.o2.pages.csrd.login.GeneralLoginPage;
import com.o2.pages.csrd.login.LoadingPage;
import com.o2.pages.csrd.login.NttLoginPage;
import com.o2.pages.csrd.navigation.CancelOrder;
import com.o2.pages.csrd.navigation.ContactPage;
import com.o2.stepdefs.csrd.OrderFormSteps;

import io.cucumber.guice.ScenarioScoped;

public final class CsrdProjectModule extends AbstractModule {
    @Override
    public void configure() {
        try {
            // Bindings for classes that are shared for the lifetime of the
            // scenario.
            bind(AccountLandingPage.class).in(ScenarioScoped.class);
            bind(AccountSummaryPage.class).in(ScenarioScoped.class);
            bind(AccountSummaryPage.class).in(ScenarioScoped.class);
            bind(AddressLookupPage.class).in(ScenarioScoped.class);
            bind(AuthenticateCustomerPage.class).in(ScenarioScoped.class);
            bind(BillingAccountFormPage.class).in(ScenarioScoped.class);
            bind(BillingAccountPage.class).in(ScenarioScoped.class);
            bind(CreateAccessForYourTicketPopupPage.class).in(ScenarioScoped.class);
            bind(CreditCheckPage.class).in(ScenarioScoped.class);
            bind(CsrDesktopPage.class).in(ScenarioScoped.class);
            bind(DeactivatePaymentPopupPage.class).in(ScenarioScoped.class);
            bind(LeftNavigationMenuPage.class).in(ScenarioScoped.class);
            bind(OrderBillingAndPaymentPage.class).in(ScenarioScoped.class);
            bind(OrderConfirmationPage.class).in(ScenarioScoped.class);
            bind(OrderDeliveryPage.class).in(ScenarioScoped.class);
            bind(OrderEligibilityCheckFormPage.class).in(ScenarioScoped.class);
            bind(OrderEligibilityCheckPage.class).in(ScenarioScoped.class);
            bind(OrderFormPage.class).in(ScenarioScoped.class);
            bind(OrderNavigationPage.class).in(ScenarioScoped.class);
            bind(OrderPage.class).in(ScenarioScoped.class);
            bind(OrderPhoneAndSpendCapPage.class).in(ScenarioScoped.class);
            bind(OrderReviewPage.class).in(ScenarioScoped.class);
            bind(OrderServicesAndFeaturesPage.class).in(ScenarioScoped.class);
            bind(OrderTariffPage.class).in(ScenarioScoped.class);
            bind(PaymentInstrumentsPage.class).in(ScenarioScoped.class);
            bind(PaymentMandatePage.class).in(ScenarioScoped.class);
            bind(ProcessElements.class).in(ScenarioScoped.class);
            bind(ResidentialAccountIntroPage.class).in(ScenarioScoped.class);
            bind(ResidentialAccountPage.class).in(ScenarioScoped.class);
            bind(SecurityCheckPage.class).in(ScenarioScoped.class);
            bind(SignInContractPage.class).in(ScenarioScoped.class);
            bind(TicketsPage.class).in(ScenarioScoped.class);
            bind(TodoItemPopupPage.class).in(ScenarioScoped.class);

            bind(GeneralLoginPage.class).in(ScenarioScoped.class);
            bind(LoadingPage.class).in(ScenarioScoped.class);
            bind(NttLoginPage.class).in(ScenarioScoped.class);

            bind(AccountLandingPage.class).in(ScenarioScoped.class);

            bind(OrderFormSteps.class).in(ScenarioScoped.class);

            bind(BrowserUtil.class).toInstance(BrowserUtil.instance());
            bind(Common.class).in(Singleton.class);
            bind(LoginCsrUserData.class).in(Singleton.class);
            bind(CancelOrder.class).in(Singleton.class);
            bind(OrderOverviewPage.class).in(Singleton.class);
            bind(ContactPage.class).in(Singleton.class);
        } catch (Exception e) {
            addError(e.getMessage());
        }
    }
}
