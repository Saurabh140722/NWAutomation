package com.o2.pages.ecomm;

import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.nttdata.cinnamon.driver.controls.PageElementCollection;

public class PhonePage extends BasePage{
    @Find(by = By.XPath, locator = "//input[@aria-label='Search']")
    public PageElement searchBox;

    @Find(by = By.XPath, locator = "//button[@aria-label='Start search']//*[@svgid='icon-search']")
    public PageElement searchBtn;

    @Find(by = By.XPath, locator = "//div[contains(@class,'secondary-search__suggestions')]")
    public PageElementCollection searchSuggestions;

    @Find(by = By.XPath, locator = "//h2[contains(@class,'device-card__content-heading')]")
    public PageElementCollection phoneDetails;

    @Find(by = By.XPath, locator = "//h1[contains(@class,'device-details-header__heading')]")
    public PageElement selectedPhoneDetails;

    @Find(by = By.XPath, locator = "//p[contains(@class,'o2uk-stock-availability__info-title')]")
    public PageElement stockAvailability;

    @Find(by = By.XPath, locator ="//span[@class='sr-only' and contains(text(),'Upfront')]")
    public PageElement upfrontPayment;

    @Find(by = By.XPath, locator ="//span[@class='sr-only' and contains(text(),'Monthly')]")
    public PageElement monthlyPayment;



    @Find(by = By.XPath, locator = "//div/a[contains(string(),'Shop')]")
    public PageElement shopButton;

    @Find(by = By.XPath, locator = "//div[@class='global-header__navigation-block']/a[contains(string(),'Phones')]")
    public PageElement phoneButton;

    @Find(by = By.XPath, locator = "//*[@id='portlet_DeviceListTitlePortlet']//h1")
    public PageElement phoneHeader;

    @Find(by = By.XPath, locator = "//device-list-tabs//button[@aria-label='Phone and airtime']")
    public PageElement phoneNAirtimeTab;

    @Find(by = By.XPath, locator = "//device-list-tabs//button[@aria-label='Phone only']")
    public PageElement phoneOnly;

    @Find(by = By.XPath, locator = "//*[@id='listing-search']")
    public PageElement listingSearch;

    @Find(by = By.XPath, locator = "//div[string()='Pay Monthly']")
    public PageElement payMonthlyTab;

    @Find(by = By.XPath, locator = "//div[string()='Pay As You Go']")
    public PageElement payAsYouGoTab;

    @Find(by = By.XPath, locator = "//div[string()='Refurbished']")
    public PageElement refurbishedTab;

    @Find(by = By.XPath, locator = "//div[string()='New']")
    public PageElement newTab;

    @Find(by = By.XPath, locator = "//div[contains(@class,'filters')]//h2[(text()='SORT BY')]")
    public PageElement sortByTab;

    @Find(by = By.XPath, locator = "//button[@class='o2uk-sort-and-filter__filtering']/span[text()=' FILTER BY ']")
    public PageElement filterByTab;

    @Find(by = By.XPath, locator = "//div[@class='filter__expansion-content']//p[text()='Brand']")
    public PageElement filterByBrand;

    @Find(by = By.XPath, locator = "//o2uk-checkbox//input[contains(@aria-label,'Select filter by Apple')]")
    public PageElement filterByBrandApple;

    @Find(by = By.XPath, locator = "//div[(@aria-labelledby='sr-relevance')]//li")
    public PageElement sortByRelevance;

    @Find(by = By.XPath, locator = "//div[(@aria-labelledby='sr-feature-radio')]//li")
    public PageElement sortByFeature;

    @Find(by = By.XPath, locator = "//ul[(@aria-labelledby='sr-cost')]//li")
    public PageElement sortByCost;

    @Find(by = By.XPath, locator = "//button[contains(@class,'sorts-done')]")
    public PageElement sortByTabApply;

    @Find(by = By.XPath, locator = "//button[contains(@class,'filter-done')]")
    public PageElement filterByTabApply;

    @Find(by = By.XPath, locator = "//button/span[text()=' View all phones ']")
    public PageElement viewAllPhonesButton;

    @Find(by = By.XPath, locator = "//device-list-wrapper/div/div/div")
    public PageElementCollection deviceCardItems;

    String deviceCardItemList = "//device-list-wrapper//div[i]";

    @Find(by = By.XPath, locator = "//device-list-wrapper//div/device-card//h2//span[1]")
    public PageElementCollection deviceCardBrandName;

    @Find(by = By.XPath, locator = "//device-list-wrapper//div/device-card//h2//span[2]")
    public PageElementCollection deviceCardBrandModel;

    @Find(by = By.XPath, locator = "//device-list-wrapper//div/device-card//o2uk-price-new[1]/div/span")
    public PageElementCollection devicePriceUpfront;

    @Find(by = By.XPath, locator = "//device-list-wrapper//div/device-card//o2uk-price-new[2]/div/span")
    public PageElementCollection devicePriceUpfrontCost;

    @Find(by = By.XPath, locator = "//device-list-wrapper//div/device-card//span[@class='o2uk-price__amount-sign']")
    public PageElementCollection devicePriceCurrency;

    @Find(by = By.XPath, locator = "//device-list-wrapper//div/device-card//o2uk-amount-info-monthly")
    public PageElementCollection deviceAmountInfoMonthly;

    @Find(by = By.XPath, locator = "//device-list-wrapper//div/device-card//div[contains(@class,'device-card__plan')]/p[1]")
    public PageElementCollection devicePlanMonthly;

    @Find(by = By.XPath, locator = "//device-list-wrapper//div/device-card//div[contains(@class,'device-card__plan')]/p[2]")
    public PageElementCollection devicePlanMonthlyRolling;

    @Find(by = By.XPath, locator = "//device-list-wrapper//div/device-card//compare-button//button")
    public PageElement deviceCardComparebutton1;

    @Find(by = By.XPath, locator = "//o2uk-chips/button[@aria-label='Clear all filters']")
    public PageElement deviceCardFilterClear;

    @Find(by = By.XPath, locator = "//div[2]/div[3]//article//div[4]//div[4]//a/div[1]/div[3]")
    public PageElement deviceCard3;

    @Find(by = By.XPath, locator = "//div[contains(@class,'InStock')]//p[text()='In stock']")
    public PageElement stockStatusInStock;

    @Find(by = By.XPath, locator = "//*[@id='tariffMComponent']//div[2]/div[5]//button")
    public PageElement chooseFistPlan;

    @Find(by = By.XPath, locator = "//button[@aria-label='Confirm Spend Cap']")
    public PageElement confirmSpendCap;

    @Find(by = By.XPath, locator = "//div[contains(@class,'insurance-perk')]/div/div[1]//button")
    public PageElement insuranceAddExtraButton;

    @Find(by = By.XPath, locator = "//button[string()='Confirm']")
    public PageElement insuranceAddExtraConfirm;

    @Find(by = By.XPath, locator = "//button[string()='Go to basket']")
    public PageElement goToBasketButton;

    @Find(by = By.XPath, locator = "//*[@id='shopApp']//div[@class='proceed-checkout']//input")
    public PageElement phoneBasketCheckoutButton;















}
