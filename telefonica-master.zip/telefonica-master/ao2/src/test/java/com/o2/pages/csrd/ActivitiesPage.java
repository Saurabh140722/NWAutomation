package com.o2.pages.csrd;

import com.google.inject.Inject;
import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.nttdata.cinnamon.driver.controls.PageElementCollection;
import com.nttdata.cinnamon.driver.factory.Controls;
import com.o2.core.util.Common;
import com.o2.models.csrd.Sort;
import com.o2.pages.BasePage;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static com.nttdata.cinnamon.wait.ElementConditions.displayed;

public class ActivitiesPage extends BasePage {
    private final Common common;
    @Find(by = By.Id, locator = "label_9136302311313143962_lighttablectrl_1")
    public PageElement title;

    @Find(by = By.XPath, locator = "//button[text()='New To-Do Item']")
    public PageElement newTodoItemButton;

    @Find(by = By.CssSelector, locator = ".TableCtrl.nc-table-content-zebra")
    public PageElement tableRoot;

    @Find(by = By.CssSelector, locator = "tbody")
    public PageElement tableRootBody;

    @Find(by = By.CssSelector, locator = ".ui-pager-gwt")
    public PageElement paginationRoot;

    @Find(by = By.CssSelector, locator = ".sortable.nc-field-html-focusable-content")
    public PageElementCollection sortableColumns;

    @Inject
    public ActivitiesPage(final Common common) {
        this.common = common;
    }

    @Override
    public boolean isPageDisplayed() {
        return title.isDisplayed() && title.getText().equals("Activities");
    }

    public PageElement getTableBody() {
        return tableRoot.waitUntil(displayed).findChild(By.Tag, "tbody");
    }

    public int getTotalNoOfItems() {
        PageElement pagination = this.paginationRoot.findChild(By.CssSelector, ".gwt-HTML");

        Pattern pattern = Pattern.compile("1 - (.*) of (.*),", Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(pagination.getText());
        boolean matchFound = matcher.find();

        if(matchFound) {
            return Integer.parseInt(matcher.group(2));
        }

        this.logger.warn("*** Could not retrieve total no of pages for Activities Table! Will return -1! Is this a negative scenario?");

        return -1;
    }

    // TODO: make this sortBy and pass all table columns that can be used to sort by
    public void sortByDate(Sort sort) {
        if (this.sortableColumns.size() == 0) {
            this.logger.error("Could not find any sortable columns for Activities table!");

            return;
        }

        PageElement column = this.sortableColumns.asList().get(2);
        String ariaLabel = column.getAttribute("aria-label").toLowerCase(Locale.ROOT);

        if (ariaLabel.contains(sort.toString())) return;

        int cnt = 0;
        column.click();
        // There is no process icon so I'll check when the aria-label will change
        while(cnt++ < 4) {
            if (this.sortableColumns.asList().get(2).getAttribute("aria-label").toLowerCase(Locale.ROOT).equals(ariaLabel)) {
                this.logger.warn(
                        MessageFormat.format(">>> Activities table not sorted yet ''{0}''. Waiting to refresh ...",
                                sort.toString()));
                this.common.wait(2);
                continue;
            }

            this.logger.warn(
                    MessageFormat.format(">>> Activities table now sorted ''{0}''!",
                            sort.toString()));
            break;
        }

    }

    // TODO: this method gets only the 1st column. we should probably map the row into an object
    public PageElementCollection getRows() {
        PageElementCollection fullRows = getTableBody().findChildren(By.Tag, "tr");
        List<PageElement> result = new ArrayList<>();

        for(PageElement row : fullRows.asList()) {
            result.add(row.findChild(By.CssSelector, ".nc-table-ingrid-cell-edit-available"));
        }

        return Controls.createAll(result);
    }
}
