package com.o2.pages.csrd;

import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.nttdata.cinnamon.driver.controls.PageElementCollection;
import com.o2.pages.BasePage;

import static com.nttdata.cinnamon.wait.ElementConditions.displayed;

public class OrderNavigationPage extends BasePage {
    @Find(by = By.CssSelector, locator = ".prev_next_box")
    public PageElement paginationContainer;

    @Find(by = By.CssSelector, locator = ".breadcrumbs")
    public PageElement breadcrumbsRoot;

    public PageElement getNextButton() {
        // TODO: if we won't use this in negative scenarios then we can add an assertion here to check buttons are found
        PageElementCollection buttons = this.getNavigationButtons();

        return (buttons != null && buttons.size() >= 1
                ? this.getNavigationButtons().asList().get(1)
                : null);
    }

    public PageElement getPrevButton() {
        // TODO: if we won't use this in negative scenarios then we can add an assertion here to check buttons are found
        PageElementCollection buttons = this.getNavigationButtons();

        return (buttons != null && buttons.size() >= 1
                ? this.getNavigationButtons().asList().get(0)
                : null);
    }

    public PageElementCollection getBreadcrumbs() {
        PageElementCollection breadcrumbs = this.breadcrumbsRoot.findAllBy(By.CssSelector, ".gwt-InlineHyperlink.roe-pathList");

        if (breadcrumbs == null || breadcrumbs.size() == 0) return null;

        return breadcrumbs;
    }

    public void clickOnBreadcrumbByText(String breadcrumText) {
        PageElement breadcrumb = this.browser.findBy(By.XPath, "//a[text()='" + breadcrumText + "']");
        breadcrumb.waitUntil(displayed).click();
        this.logger.info("*** Click on " + breadcrumText + "!\n");
    }

    private PageElementCollection getNavigationButtons() {
        // TODO: if we won't use this in negative scenarios then we can add an assertion here to check buttons are found
        return this.paginationContainer.findChildren(By.Tag, "div");
    }

    private String getSelectedBreadcrumb() {
        PageElementCollection elements = this.getBreadcrumbs();

        if (elements == null) return null;

        return elements.asList().stream()
                .filter(e -> e.getAttribute("aria-selected").equals("true"))
                .map(PageElement::getText)
                .findFirst()
                .orElse(null);
    }
}
