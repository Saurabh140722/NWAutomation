package com.o2.pages.ecomm;

import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;

public class OrderConfirmationPage extends BasePage {

    @Find(by = By.XPath, locator = "//h1[contains(text(),' Your order is complete! ')]")
    public PageElement pageTitle;

    @Find(by = By.XPath, locator = "//div[@class='order-info__order-details-title font font_bold']")
    public PageElement orderNumber;

    @Find(by = By.XPath, locator = "//button[contains(text(),'Download a copy of your order confirmation')]")
    public PageElement orderConfirmationDownloadLink;

    @Override
    public boolean isPageDisplayed() {
        if (!pageTitle.isDisplayed())
            return false;

        return pageTitle.getText().trim().equalsIgnoreCase(" Your order is complete! ");
    }

}
