package com.o2.pages.csrd.navigation;

import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.nttdata.cinnamon.driver.controls.PageElementCollection;
import com.o2.pages.BasePage;

import java.text.MessageFormat;
import java.util.Locale;
import java.util.Objects;

import static org.assertj.core.api.Assertions.assertThat;

public class AccountNavigation extends BasePage {
    @Find(by = By.CssSelector, locator = ".gwt-TabBar")
    public PageElement navigationBar;

    public void navigateTo(String sectionName) {
        assertThat(this.navigationBar.isDisplayed())
                .withFailMessage("Could not find Navigation Bar for Account Navigation!")
                .isTrue();

        PageElementCollection sections = this.navigationBar.findChildren(By.CssSelector, ".gwt-Label");
        assertThat(!sections.asList().isEmpty())
                .withFailMessage("Could not find any navigation sections for Account Navigation!")
                .isTrue();

        PageElement section = sections.asList().stream()
                .filter(e -> e.getText().toLowerCase(Locale.ROOT).contains(sectionName.toLowerCase(Locale.ROOT)))
                .findFirst()
                .orElse(null);
        assertThat(section)
                .withFailMessage(
                        MessageFormat.format(
                                "Could not find a navigation section for Account Navigation whose name is: ''{0}''!",
                                sectionName))
                .isNotNull();
        Objects.requireNonNull(section).click();
    }
}
