package com.o2.models.ecare;

public enum Sort {
    ASCENDING,
    DESCENDING
}
