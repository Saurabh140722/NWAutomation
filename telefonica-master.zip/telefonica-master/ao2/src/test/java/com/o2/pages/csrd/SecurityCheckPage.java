package com.o2.pages.csrd;

import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.o2.pages.BasePage;

public class SecurityCheckPage extends BasePage {
    @Find(by = By.Id, locator = "redeemOtacSection")
    public PageElement securityCheckBlock;

    @Find(by = By.Id, locator = "otac")
    public PageElement otac;

    @Find(by = By.Id, locator = "redeemOtac")
    public PageElement submitButton;

    @Find(by = By.Id, locator = "bankAccountNo")
    public PageElement bankAccount;

    @Find(by = By.Id, locator = "btnSubmit")
    public PageElement submitExtraCheckButton;

    @Find(by = By.Id, locator = "houseNumber")
    public PageElement houseNumber;

    @Find(by = By.Id, locator = "postcodeUK")
    public PageElement postCode;

    @Find(by = By.Id, locator = "btnSubmit")
    public PageElement continueButton;

    @Find(by = By.Id, locator = "ds")
    public PageElement skipPhoneNumber;

    @Override
    public PageElement getPageCheckElement() {
        return this.securityCheckBlock;
    }
}
