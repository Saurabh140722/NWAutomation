package com.o2.stepdefs.ecare;

import com.google.inject.Inject;

import java.sql.Timestamp;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import com.nttdata.cinnamon.cache.Context;
import com.nttdata.cinnamon.driver.Browser;
import com.nttdata.cinnamon.webdriver.util.ReadyState;
import com.o2.pages.ecare.ReturnOrExchangePage;
import com.o2.stepdefs.BaseStep;
import com.o2.util.Common;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.lang.StringUtils;

import static com.nttdata.cinnamon.wait.ElementConditions.displayed;
import static com.nttdata.cinnamon.wait.conditions.Conditions.readyState;
import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

public class ReturnOrExchangeSteps extends BaseStep {

    private final Browser browser;
    private final Common common;
    private final ReturnOrExchangePage returnOrExchangePage;
    private final Context context;


    @Inject
    public ReturnOrExchangeSteps(ReturnOrExchangePage returnOrExchangePage, Browser browser, Common common, Context context1){
        this.returnOrExchangePage=returnOrExchangePage;
        this.browser = browser;
        this.common = common;
        this.context = context1;
    }

    @And("Make a returnPage opens successfully")
    public void make_A_ReturnPage_Opens_Successfully() throws InterruptedException {
//        this.browser.wait(8);
        this.browser.setImplicitWait(20);
        this.browser.waitUntil(readyState(ReadyState.COMPLETE));
        this.returnOrExchangePage.returnReasonSelect.waitUntil(displayed);
    }

    @And("I select {string} from reasonDropdown")
    public void i_Select_Reason_ReturnDropdown(String reasonForReturn) throws InterruptedException {
        returnOrExchangePage.selectReturnOption(reasonForReturn);
        this.context.set("ReasonForReturn",reasonForReturn);
        Thread.sleep(5000);
    }

    @Then("I verify the note text for Return")
    public void i_Verify_The_Note_Text_For_Return() {
        assertThat(returnOrExchangePage.returnNotificationMessageHeader.isDisplayed()).withFailMessage("Return Notification Message Not Displayed");
        assertThat(returnOrExchangePage.returnNotificationMessage1.isDisplayed()).withFailMessage("Return Notification Message Not Displayed");
        assertThat(returnOrExchangePage.returnNotificationMessage2.isDisplayed()).withFailMessage("Return Notification Message Not Displayed");
    }


    @And("I Successfully Retutn the device")
    public void i_Successfully_Retutn_TheDevice() {
        this.browser.setImplicitWait(30);
        this.browser.waitUntil(readyState(ReadyState.COMPLETE));
        returnOrExchangePage.returnContinue.waitUntil(displayed).clickJs();
        returnOrExchangePage.returnContinueNext.waitUntil(displayed).clickJs();
        returnOrExchangePage.returnContinueNext.waitUntil(displayed);
        returnOrExchangePage.returnContinueNext.waitUntil(displayed).clickJs();
        returnOrExchangePage.returnContinue.waitUntil(displayed).clickJs();
        returnOrExchangePage.returnOrExchangeSuccessful.waitUntil(displayed);
    }

    @And("Make a ExchangePage opens successfully")
    public void make_A_ExchangePage_Opens_Successfully() {
        returnOrExchangePage.exchangeDialog.waitUntil(displayed);
        returnOrExchangePage.exchangeADeviceHeader.waitUntil(displayed);
        returnOrExchangePage.exchangeADevice.waitUntil(displayed).clickJs();
        returnOrExchangePage.makeAnexchangePage.waitUntil(displayed);
        returnOrExchangePage.makeAnexchangePageHeader.waitUntil(displayed);
    }

    @And("I Successfully Exchange the device")
    public void i_Successfully_Exchange_The_Device() {
        returnOrExchangePage.returnContinue.waitUntil(displayed).clickJs();
        returnOrExchangePage.returnContinueNext.waitUntil(displayed).clickJs();
        returnOrExchangePage.returnContinueNext.waitUntil(displayed);
        returnOrExchangePage.returnContinueNext.waitUntil(displayed).clickJs();
        returnOrExchangePage.returnContinue.waitUntil(displayed).clickJs();
        returnOrExchangePage.returnContinue.waitUntil(displayed).clickJs();
        returnOrExchangePage.returnOrExchangeSuccessful.waitUntil(displayed);
    }

    @When("I click on Cancel button")
    public void i_Click_On_Cancel_Button() {
        returnOrExchangePage.exchangeDialog.waitUntil(displayed);
        returnOrExchangePage.exchangeADeviceHeader.waitUntil(displayed);
        returnOrExchangePage.cancelExchange.clickJs();
        returnOrExchangePage.returnButton.waitUntil(displayed);
    }

    @Then("I verify the ReturnByDate")
    public void i_Verify_The_ReturnByDate() {
        Format formatter = new SimpleDateFormat("dd-MMM-yy");
        Calendar cal = Calendar.getInstance();
        Date date = new Date();
        returnOrExchangePage.returnContinue.waitUntil(displayed).clickJs();
        returnOrExchangePage.returnContinueNext.waitUntil(displayed).clickJs();
        returnOrExchangePage.returnContinueNext.waitUntil(displayed).clickJs();
        Timestamp ts = common.getSystemDatePLUS14Days();
        int dayCalculated = cal.get(Calendar.DATE);
        int monthCalculated = cal.get(Calendar.MONTH);
        int yearCalculated = cal.get(Calendar.YEAR);
        String ts1 = returnOrExchangePage.returnORExchangeByDate.getText();
        int returnByDay = Integer.valueOf(StringUtils.substringBefore(ts1," "));
        String returnByMonth = StringUtils.substringBetween(ts1," ");
        int returnByYear = Integer.valueOf(StringUtils.substringAfterLast(ts1," "));
        System.out.println(ts+"-----"+ts1);
        int returnByMonth1 = getNumericMonth(returnByMonth);
        System.out.println(dayCalculated+"--"+returnByDay+" :: "+monthCalculated+"--"+returnByMonth+" :: "+yearCalculated +"--"+returnByYear);
        assertThat(dayCalculated==returnByDay).withFailMessage("Days calculated for 14 days is wrong");
        assertThat(monthCalculated==returnByMonth1).withFailMessage("Month calculated is wrong");
        assertThat(yearCalculated==returnByYear).withFailMessage("Year calculated is wrong");
    }

    public int  getNumericMonth(String monthName){
        int monthNum=0;
        switch(monthName) {
            case "January" : monthNum=1; break;
            case "February" : monthNum=2; break;
            case "March" : monthNum=3; break;
            case "April" : monthNum=4; break;
            case "May" : monthNum=5; break;
            case "June" : monthNum=6; break;
            case "July" : monthNum=7; break;
            case "August" : monthNum=8; break;
            case "September" : monthNum=9; break;
            case "October" : monthNum= 0; break;
            case "November" : monthNum=11; break;
            case "December" : monthNum=12; break;
        }
        return monthNum;
    }
}
