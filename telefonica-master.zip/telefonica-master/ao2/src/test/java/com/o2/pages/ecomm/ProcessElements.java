package com.o2.pages.ecomm;

import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;

public class ProcessElements {

    @Find(by = By.CssSelector, locator = ".gwt-PopupPanel.loader")
    public PageElement loadingProgressControl;

    @Find(by = By.CssSelector, locator = ".nc-loading-overlay")
    public PageElement ncLoadingProgressControl;

    @Find(by = By.CssSelector, locator = ".progress-text")
    public PageElement pageNavigationLoading;
}
