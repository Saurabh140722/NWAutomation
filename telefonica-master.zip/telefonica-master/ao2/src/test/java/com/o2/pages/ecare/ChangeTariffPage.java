package com.o2.pages.ecare;

import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.nttdata.cinnamon.driver.controls.PageElementCollection;

public class ChangeTariffPage extends EcareBasePage {

    @Find(by = By.XPath, locator = "//button[@aria-label='Usage summary']")
    public PageElement usageSummaryBtn;

    @Find(by = By.Id, locator = "changetariff")
    public PageElement changeTariffBtn;

    @Find(by = By.XPath, locator = "//span[contains(text(),' Change to this tariff ')]")
    public PageElementCollection changeToThisTariffBtn;


    @Find(by = By.XPath, locator = "//div[@class='o2uk-checkbox-inner-container']")
    public PageElement checkBoxForTermAndCondition;

    @Find(by = By.XPath, locator = "//div[@class='o2uk-review-tariff__confirm-plan-button-wrapper']")
    public PageElement confirmChangeBtn;







}
