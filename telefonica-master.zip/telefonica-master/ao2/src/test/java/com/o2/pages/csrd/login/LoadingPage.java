package com.o2.pages.csrd.login;

import com.google.inject.Inject;
import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.nttdata.cinnamon.logging.Logger;
import com.o2.pages.BasePage;

public class LoadingPage extends BasePage {
    private final Logger logger;

    @Inject
    public LoadingPage(final Logger logger) {
        this.logger = logger;
    }

    @Find(by = By.XPath, locator = "//*[@id=\"app-component\"]/app-navbar/nav/div/div/div/img")
    public PageElement logo;

    public boolean isPageDisplayed() {
        this.logger.info("Check if Landing Page is displayed ...");

        return this.logo.isDisplayed();
    }
}
