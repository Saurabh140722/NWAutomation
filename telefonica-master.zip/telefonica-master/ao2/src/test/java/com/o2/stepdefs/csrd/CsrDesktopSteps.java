package com.o2.stepdefs.csrd;

import com.google.inject.Inject;
import com.nttdata.cinnamon.cache.Context;
import com.nttdata.cinnamon.driver.Browser;
import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.nttdata.cinnamon.driver.controls.PageElementCollection;
import com.nttdata.cinnamon.logging.Logger;
import com.nttdata.cinnamon.modules.selenium.browsers.Chrome;
import com.o2.core.data.UserDataModel;
import com.o2.pages.csrd.CsrDesktopPage;
import com.o2.stepdefs.BaseStep;
import com.o2.util.Common;
import io.cucumber.java.en.When;

import java.text.MessageFormat;
import java.util.Objects;

import static com.nttdata.cinnamon.wait.ElementConditions.displayed;
import static org.assertj.core.api.Assertions.assertThat;

public class CsrDesktopSteps extends BaseStep {
    private final CsrDesktopPage csrDesktopPage;
    private final Logger logger;
    private final Browser browser;
    private final Common common;
    private final Context context;

    @Inject
    public CsrDesktopSteps(final CsrDesktopPage csrDesktopPage,
                           final Logger logger,
                           final Browser browser,
                           final Common common,
                           final Context context) {
        this.csrDesktopPage = csrDesktopPage;
        this.logger = logger;
        this.browser = browser;
        this.common = common;
        this.context = context;
    }

    @When("^I open Residential Account form$")
    public void i_open_residential_account_form() {
        this.logger.info("*** Open Residential Account form ...");
        // FOR AD1
        if(browser.currentUrl().contains("toms-pad-conf-1") || browser.currentUrl().contains("toms-pad-test-1") ) {
            try {
                csrDesktopPage.quickCreateMenu.hover();
            } catch (Exception e) {
                ((Chrome)browser).findBy(By.Id,"nav").hover();
            }
        }
        // For AD2
        else {
            //((Chrome)browser).findBy(By.Id,"nav").hover();
            csrDesktopPage.quickCreateMenu.hover();
        }
        assertThat(this.csrDesktopPage.quickCreateMenu.waitUntil(displayed).isDisplayed())
                .withFailMessage("Quick Menu menu not opened!")
                .isTrue();

        PageElement quickCreateMenuRoot = this.csrDesktopPage.quickCreateMenuRoot.waitUntil(displayed);
        assertThat(quickCreateMenuRoot.waitUntil(displayed).isDisplayed())
                .withFailMessage("Quick Menu menu not opened!")
                .isTrue();

        PageElementCollection submenus = this.csrDesktopPage.quickCreateMenuRoot.findChildren(By.CssSelector, "li");
        PageElement opt_residentialAccount = submenus.asList().stream()
                .filter(el -> el.getText().equalsIgnoreCase("Residential Customer"))
                .findAny()
                .orElse(null);
        assertThat(opt_residentialAccount != null && opt_residentialAccount.isDisplayed())
                .withFailMessage("Could not find 'Residential Account' submenu (has the menu been opened?)!")
                .isTrue();

        Objects.requireNonNull(opt_residentialAccount).click();

        this.logger.info("*** Residential Account form clicked to open!\n");
    }

    @When("^I search for my user by '(.*)' and '(.*)'$")
    public void when_is_search_for_my_user_by(String criteria1, String criteria2) throws InterruptedException {
        this.logger.info(MessageFormat.format("*** Search RCA by: {0}, {1} ...", criteria1, criteria2));

        // TODO: both criteria will be implemented (reflection likely) once we'll need more complex search
        UserDataModel userData = (UserDataModel) this.context.get("residentialUserAccountData");

        this.csrDesktopPage.lastName.waitUntil(displayed).setValue(userData.lastName);
        this.csrDesktopPage.postcode.waitUntil(displayed).setValue(userData.postcode);
        //this.csrDesktopPage.customerAccountNumber.waitUntil(displayed).setValue("10000000017");          
        this.csrDesktopPage.searchButton.click();
        this.common.waitForLoadingToComplete(2, 1);
          this.browser.setImplicitWait(4);
       // this.csrDesktopPage.selectRowByEmailAddress(userData.userEmail);
        Thread.sleep(5000);
        if (this.csrDesktopPage.resultsTable.isDisplayed()) {
            PageElementCollection rows = this.csrDesktopPage.getRows();
         if (rows.size() > 1) { // page will not redirect as I have more than 1 entry
                this.csrDesktopPage.selectRowByEmailAddress(userData.userEmail);
            }
        }

        this.browser.restoreImplicitWait();

        this.logger.info("*** Search complete!\n");
    }
}
