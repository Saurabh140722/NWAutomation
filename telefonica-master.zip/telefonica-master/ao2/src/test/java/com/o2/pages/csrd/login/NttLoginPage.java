package com.o2.pages.csrd.login;

import com.google.inject.Inject;
import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.FindByKey;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.nttdata.cinnamon.driver.controls.PageElementCollection;
import com.o2.core.util.Retry;
import com.o2.pages.BasePage;

import java.util.function.Supplier;

public class NttLoginPage extends BasePage {
    private final Retry retry;

    @Inject
    public NttLoginPage(final Retry retry) {
        this.retry = retry;
    }
    @FindByKey(key ="appSubmitButton")
    public PageElement loginButton;

    @FindByKey(key ="appSubmitButton")
    public PageElement NTUserLoginSubmitButton;
    @Find(by = By.Id, locator = "user")
    public PageElement loginUserName;

    @Find(by = By.Id, locator = "pass")
    public PageElement loginPassword;

    @Find(by = By.XPath, locator = "//input[@value='Log on as NT user']")
    public PageElement loginBtn;

    @FindByKey(key ="loginSearchUserTextBox")
    public PageElement lanId;

    @FindByKey(key ="password")
    public PageElement password;

    @FindByKey(key ="NTUserLogin")
    public PageElement NTUserLogin;

    
    @Find(by = By.Id, locator = "loginSearchUserBtn")
    public PageElement loginNextButton;

    @Find(by = By.CssSelector, locator = ".search-field-container .search-icon")
    public PageElement searchIcon;
    @Find(by = By.Id, locator = "searchField")
    public PageElement searchTextBox;
    @Find(by = By.Id, locator = "CardHeading")
    public PageElementCollection environmentDashboard;



//    CardHeading

    // TODO: Need to refactor this
    @Override
    public boolean isPageDisplayed() {
        Supplier<Boolean> lanId = () -> this.lanId.isDisplayed();
        return this.retry.retryAction(lanId, 12, 1);

//        return this.lanId.isDisplayed();
//        try {
//            Thread.sleep(2000);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//
//        int retries = 20;
//        boolean isDisplayed = false;
//
//        while(retries > 0) {
//            retries--;
//            try {
//                this.logger.warn("Trying #" + retries + " ...");
//                isDisplayed = lanId.isDisplayed();
//                break;
//            } catch (Exception e) {
//                this.logger.warn("Failed. Exception: " + e.getMessage() + "\n");
//                try {
//                    Thread.sleep(2000);
//                } catch (InterruptedException interruptedException) {
//                    interruptedException.printStackTrace();
//                }
//            }
//        }
//
//        return isDisplayed;
//        try {
//        } catch (Exception e) {
//            return false;
//        }
    }
}
