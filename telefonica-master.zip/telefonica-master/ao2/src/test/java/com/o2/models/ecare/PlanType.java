package com.o2.models.ecare;

public enum PlanType {
	CUSTOM_PLAN,
	SIMO_PLAN,
	STAC_PLAN,
	EXTRAS_PLAN,
	ALTERNATE_EMAIL_ADDRESS,
	EXTRAS,
	DEVICE_PLAN
}
