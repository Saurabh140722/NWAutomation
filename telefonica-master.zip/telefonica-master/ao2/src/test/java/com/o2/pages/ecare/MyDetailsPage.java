package com.o2.pages.ecare;

import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.nttdata.cinnamon.driver.controls.PageElementCollection;
import com.o2.models.ecare.EcareUser;

public class MyDetailsPage extends EcareBasePage {
    @Find(by = By.CssSelector, locator = ".o2uk-manage-my-details__title")
    public PageElement myDetailsTitle;

    @Find(by = By.XPath, locator = "//*[@aria-label='Edit Personal details']")
    public PageElement editPersonalDetails;

    @Find(by = By.XPath, locator = "//*[@aria-label='Edit Contact details']")
    public PageElement editContactDetails;

    @Find(by = By.CssSelector, locator = ".o2uk-manage-my-details-card__value")
    public PageElementCollection myDetailsList;

    @Find(by = By.CssSelector, locator = ".text-link")
    public PageElementCollection editBlockLinks;

    @Override
    protected PageElement getPageCheckElement() {
        return this.myDetailsTitle;
    }

    public EcareUser getMyDetailsInformation() {
        if (this.myDetailsList.size() < 9 || this.myDetailsList.size() > 10) {
            return null;
        }

        EcareUser ecareUser = new EcareUser();
        ecareUser.title = this.myDetailsList.asList().get(0).getText();
        ecareUser.firstName = this.myDetailsList.asList().get(1).getText();
        ecareUser.lastName = this.myDetailsList.asList().get(3).getText();
        ecareUser.username = this.myDetailsList.asList().get(6).getText();//TOOD change 5 to 6 for UAT2

        return ecareUser;
    }

    // TODO: these size() checks seem fragile. can we do better?

    public PageElement getEditMyDetailsLink() {
    	// TODO: @Anup: bit confused ... != 4 but we then take get(0). are you sure?
        if (this.editBlockLinks.size() != 5) {
			return null;
		}

        return this.editBlockLinks.asList().get(0);
    }

    public PageElement getYourDetailsValue(String value) {
        return this.browser.findBy(By.XPath, "//*[contains(@class,'o2uk-manage-my-details-card__value') and text()=' " + value + " ']");

    }

    public PageElement getContactDetailsLink() {
		// TODO: @Anup: bit confused ... != 4 but we then take get(0). are you sure?
        if (this.editBlockLinks.size() != 5) {
			return null;
		}

        return this.editBlockLinks.asList().get(3);
    }
}
