package com.o2.models.ecomm;

public enum BankAccountType {
    SAVING_ACCOUNT
}
