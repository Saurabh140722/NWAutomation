package com.o2.models.ecomm;

import com.google.inject.Inject;
import com.nttdata.cinnamon.cache.Context;
import com.nttdata.cinnamon.file.json.JsonParser;
import com.nttdata.cinnamon.file.reader.Reader;
import com.nttdata.cinnamon.logging.Logger;

import java.text.MessageFormat;
import java.util.List;
import java.util.Objects;

import static org.assertj.core.api.Assertions.assertThat;

public class PaymentDetailData {
    private final Logger logger;
    private final List<PaymentDetail> userBankAccountDetail;
    private final Context context;

    @Inject
    public PaymentDetailData(final Logger logger,
                             final Reader reader,
                             final JsonParser jsonParser, Context context) {
        this.logger = logger;
        this.context = context;
        // TODO Move this logic in to common function
        String env = System.getProperty("env");
        this.context.set("env", env);
        String dataLoginFilePath = System.getProperty("user.dir") + "\\src\\test\\resources\\data\\ecomm\\" + env + "\\bank_details.json";
        String data = reader.readFileAsString(dataLoginFilePath, false);
        this.userBankAccountDetail = jsonParser.toObjList(data, PaymentDetail.class);
    }

    public PaymentDetail getPaymentDetails(BankAccountType bankAccountType) {
        PaymentDetail paymentDetail = this.userBankAccountDetail.stream()
                .filter(u -> u.bankAccountType.equals(bankAccountType.toString()))
                .findFirst()
                .orElse(null);

        assertThat(paymentDetail).withFailMessage(
                        MessageFormat.format(
                                "Could not find a bank detail for bank account type: ''{0}''", bankAccountType))
                .isNotNull();

        this.logger.info(MessageFormat.format("Bank detail for bank type: {0}:\n{1}",
                bankAccountType.toString(), Objects.requireNonNull(paymentDetail).toString()));

        return paymentDetail;
    }
}
