package com.o2.pages.ecomm;

import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.nttdata.cinnamon.driver.controls.PageElementCollection;
import com.o2.models.ecomm.TariffPlan;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

public class TariffPlanPage extends EcommBasePage {

    @Find(by = By.XPath, locator = "//h1[text()='O2 Tariffs']")
    public PageElement tariffPlanTitle;

    @Find(by = By.CssSelector, locator = ".genericPromo")
    public PageElementCollection tariffPlanList;

    @Find(by = By.XPath, locator = " //button[contains(text(),'Manage cookies')]")
    public PageElement manageCookiesbtn;

    @Find(by = By.Id, locator = "acceptAll")
    public PageElement acceptAllCookiesbtn;

    @Find(by = By.XPath, locator = "//button[@aria-label='Choose this plan']")
    public PageElementCollection choosePlanBtn;

    @Find(by = By.XPath, locator = "//input[@name='yes-no-iphone']")
    public PageElementCollection deviceTypeYesNoOptionBtn;

    @Find(by = By.XPath, locator = "//input[@name='yes-no-5g-ready']")
    public PageElementCollection deviceType5gYesNoOptionBtn;

    @Find(by = By.CssSelector, locator = ".checkout-btn")
    public PageElement checkoutBtn;

    @Find(by = By.CssSelector, locator = ".sign-in-btn-wrapper a")
    public PageElementCollection o2CustomerAccountBtn;

    @Find(by = By.Id, locator = "email")
    public PageElement email;

    @Find(by = By.Id, locator = "accountsusername")
    public PageElement userName;

    @Find(by = By.Id, locator = "accountspassword")
    public PageElement existingUserpassword;

    @Find(by = By.Id, locator = "signInButton")
    public PageElement signInBtn;

    @Find(by = By.XPath, locator = "//span[@id='titleSelectBoxItArrowContainer']/i")
    public PageElement titleArrow;

    @Find(by = By.Id, locator = "titleSelectBoxItOptions")
    public PageElement titleOptionsParent;

    @Find(by = By.Id, locator = "first-name")
    public PageElement firstName;

    @Find(by = By.Id, locator = "last-name")
    public PageElement lastName;

    @Find(by = By.Id, locator = "contact-number")
    public PageElement contactNbr;

    @Find(by = By.Id, locator = "password")
    public PageElement password;

    @Find(by = By.XPath, locator = " //span[@id='securityQuestionSelectBoxItArrowContainer']/i")
    public PageElement securityQuestionArrow;

    @Find(by = By.Id, locator = "securityQuestionSelectBoxItOptions")
    public PageElement securityQuestionDropDown;

    @Find(by = By.Id, locator = "security-answer")
    public PageElement securityAnswer;

    @Find(by = By.Id, locator = "date-dd-mm-yy")
    public PageElement dob;

    @Find(by = By.CssSelector, locator = ".custom-checkbox")
    public PageElementCollection customCheckBox;

    @Find(by = By.XPath, locator = "//span[contains(text(),'Confirm')]")
    public PageElementCollection confirmBtn;

    @Find(by = By.Id, locator = "housenumber")
    public PageElement houseNbr;

    @Find(by = By.Id, locator = "postcode")
    public PageElement postCode;

    @Find(by = By.XPath, locator = "//span[contains(text(),'Find')]")
    public PageElement findBtn;

    @Find(by = By.XPath, locator = "//span[@id='delivery-address-selectorSelectBoxItArrowContainer']//i")
    public PageElement selectAddressArrow;

    @Find(by = By.Id, locator = "delivery-address-selectorSelectBoxItOptions")
    public PageElement selectAddress;

    @Find(by = By.XPath, locator = "//*[@id='btn-continue-next-section']")
    public PageElement confirmBtnDeliveryAddress;

    @Find(by = By.XPath, locator = "//*[@id='deliverySummaryAddress']")
    public PageElement deliveryAddressSaved;

    @Find(by = By.CssSelector, locator = ".collapseAddress")
    public PageElement collapseAddress;

    @Find(by = By.Id, locator = "btn-continue-next-section")
    public PageElementCollection confirmBtnOnDelivery;

    @Find(by = By.CssSelector, locator = ".have-pacnstac")
    public PageElement pacCodeBtn;

    @Find(by = By.Id, locator = "mnumber")
    public PageElement currentMobileNbr;

    @Find(by = By.XPath, locator = "//input[@name='pacName']")
    public PageElement pacCodeTxtBox;

    @Find(by = By.XPath, locator = "//button[contains(text(),' Go to Payments ')]")
    public PageElement goToPaymentBtn;












    @Override
    public boolean isPageDisplayed() {
        if (!tariffPlanTitle.isDisplayed())
            return false;

        return tariffPlanTitle.getText().trim().equalsIgnoreCase("O2 Tariffs");
    }

    public List<TariffPlan> getAllPlans() {
        if (tariffPlanList == null) {
            this.logger.warn("No Tariff Plan is no Page! Is this a negative scenario?");
            return null;
        }

        List<TariffPlan> allTariffPlan = new ArrayList<>();
        this.logger.info(MessageFormat.format("Found {0} Tariff Plan   on the page. Continue ...",
                (long) tariffPlanList.asList().size()));
        this.browser.setImplicitWait(3);
        for (PageElement tariffPlan : tariffPlanList.asList()) {
            TariffPlan tariffPlans = new TariffPlan(tariffPlan.findChildren(By.CssSelector, ".info h3"));
            allTariffPlan.add(tariffPlans);
        }
        this.browser.restoreImplicitWait();
        return allTariffPlan;
    }
}
