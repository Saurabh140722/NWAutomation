package com.o2.stepdefs.ecare;
import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;

import com.google.inject.Inject;
import com.nttdata.cinnamon.cache.Context;
import com.nttdata.cinnamon.driver.Browser;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.o2.pages.ecare.MakeAReturnPage;
import com.o2.stepdefs.BaseStep;
import com.o2.util.Common;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
public class MakeAReturnSteps extends BaseStep {
    private final MakeAReturnPage makeAReturnPage;
    private final Browser browser;
    private final Common common;
    private final Context context;

    @Inject
    public MakeAReturnSteps(final MakeAReturnPage makeAReturnPage, final Browser browser, final Common common,
                            final Context context) {
        this.makeAReturnPage = makeAReturnPage;
        this.browser = browser;
        this.common = common;
        this.context = context;
    }

    @When("Make a return page opens successfully")
    public void make_a_return_page_opens_successfully() {
        this.logger.info("** Waiting for Make a return page to open ...");

        assertThat(this.makeAReturnPage.isPageDisplayed(90)).withFailMessage("Make a return page not displayed!")
                .isTrue();

        this.logger.info("** Make a return page opens!");
    }

    @When("^I select '(.*)' from reason dropdown$")
    public void i_select_from_reason_dropdown(String dropDownValue) {

        assertThat(this.makeAReturnPage.reasonForReturnDropDown.isDisplayed())
                .withFailMessage("Reason for Return drop down not displayed on Return page!").isTrue();
        this.makeAReturnPage.reasonForReturnDropDown.asSelect().selectByText(dropDownValue);
    }

    @Then("I verify the note text")
    public void i_verify_the_note_text() {
        assertThat(this.makeAReturnPage.messageTitle.getText().toString().trim().equals("Please note"))
                .withFailMessage("Please note title not displayed!").isTrue();

    }

    @When("I verify options present in Reason for return dropdown")
    public void i_verify_options_present_in_reason_for_return_dropdown() {

        assertThat(this.makeAReturnPage.reasonForReturnDropDown.isDisplayed())
                .withFailMessage("Reason for Return drop down not displayed on Return page!").isTrue();
        List<PageElement> dropdownValue = this.makeAReturnPage.reasonForReturnDropDownValues.asList();

        String[] expectedDropDown = { "Change my mind", "The item is faulty" };
        for (int i = 0; i < dropdownValue.size(); i++) {

            assertThat(dropdownValue.get(i).getText().toString().equals(expectedDropDown[i]))
                    .withFailMessage("Reason for Return drop down value not match!").isTrue();

        }

    }

    @Then("I verify IMEI number populated in Confirm IMEI section")
    public void i_verify_imei_number_populated_in_confirm_imei_section() {
        assertThat(this.makeAReturnPage.IMEINumber.isDisplayed()).withFailMessage("IMEI not displayed on Return page!")
                .isTrue();

//        assertThat(this.common.isValidIMEIExpression(this.makeAReturnPage.IMEINumber.getText().toString()))
//                .withFailMessage("IMEI format is not correct on Return page!").isTrue();
    }

    @Then("I verify device plan amount matches with Return amount")
    public void i_verify_device_plan_amount_matches_with_return_amount() {
        String upfrontPaymentValue = (String) this.context.get("UpfrontPaymentValue");
        String returnPaymentValue = this.makeAReturnPage.getReturnAmount().getText().toString();

        assertThat(upfrontPaymentValue.equals(returnPaymentValue))
                .withFailMessage("Upfornt payment value is not match with Return payment value!").isTrue();

    }
}
