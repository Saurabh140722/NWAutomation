package com.o2.pages.csrd.customertickets;

import com.google.inject.Inject;
import com.nttdata.cinnamon.cache.Context;
import com.nttdata.cinnamon.driver.Browser;
import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.nttdata.cinnamon.driver.controls.PageElementCollection;
import com.nttdata.cinnamon.driver.factory.Controls;
import com.o2.core.data.UserDataModel;
import com.o2.core.util.Common;
import com.o2.core.util.Retry;
import com.o2.models.csrd.Sort;
import io.cucumber.datatable.DataTable;
import org.apache.commons.lang3.StringUtils;

import java.text.MessageFormat;
import java.util.*;
import java.util.function.Supplier;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import static com.nttdata.cinnamon.wait.ElementConditions.displayed;
import static org.assertj.core.api.Assertions.assertThat;

public class GeneralRequestsFragment extends CustomerTicketsPage {
    private final Common common;
    private final Retry retry;
    private final Browser browser;
    private final Context context;

    @Inject
    public GeneralRequestsFragment(final Common common,
                                   final Retry retry,
                                   final Browser driver,
                                   final Context context) {
        this.common = common;
        this.retry = retry;
        this.browser = driver;
        this.context = context;
    }

    @Find(by = By.Id, locator = "label_9154756016413149657_cpmsubtypeparctrl_1")
    public PageElementCollection generalRequestsElements;

    @Find(by = By.CssSelector, locator = ".gwt-Button.button_action_id_9154756016413149657_9154756430013150226_cpmsubtypeparctrl_1.TableCtrl-button.TableCtrl-button-icon.Add")
    public PageElement createGeneralRequestButton;

    @Find(by = By.CssSelector, locator = ".gwt-ListBox.nc-field-list-value.nc-field-container")
    public PageElement generalRequestType;

//    @Find(by = By.CssSelector, locator = "input[id^='id_refsel'][id$='_div']")
    @Find(by = By.CssSelector, locator = ".nc-field-reference-selector-container")
    public PageElement categoryRoot;

    @Find(by = By.CssSelector, locator = "input[id^='id_refsel'][id$='_input']")
    public PageElement categoryTextField;

    @Find(by = By.Id, locator = "nc_refsel_list_table")
    public PageElement categoryListRoot;

    @Find(by = By.Id, locator = "9157547489313441700")
    public PageElement requestedDate;

    @Find(by = By.Id, locator = "9157573049213413499")
    public PageElement dateAndTimeOfBreach;

    @Find(by = By.Id, locator = "9157547769013441920")
    public PageElement checkedTheAddress;

    @Find(by = By.Id, locator = "9157547828413442007")
    public PageElement checkedTheEmail;

    @Find(by = By.Id, locator = "9157547487613441700")
    public PageElement detailCustomerRequest;

    @Find(by = By.CssSelector, locator = ".gwt-Button.button_action_id_9154756541513150352_9154756541513150355_compositepopup_1.TableCtrl-button.ParCtrl-editButton")
    public PageElement createButton;

    @Find(by = By.CssSelector, locator = ".ui-pager-gwt")
    public PageElement paginationRoot;

    @Find(by = By.CssSelector, locator = ".sortable.nc-field-html-focusable-content")
    public PageElementCollection sortableColumns;

    @Find(by = By.CssSelector, locator = "img[class^='filter nc-field-html-focusable-content']")
    public PageElementCollection filteringColumns;

    @Find(by = By.CssSelector, locator = ".gwt-TextBox.nc-field-text-input")
    public PageElement filterTextField;

    @Find(by = By.CssSelector, locator = "button[class^='gwt-Button button_action_id_applygwt-uid-'][class$='TableCtrl-button gwt-ParCtrl-btn gwt-ParCtrl-btn-apply']")
    public PageElement filterApplyButton;

    @Find(by = By.CssSelector, locator = ".TableCtrl.nc-table-content-zebra")
    public PageElement tableRoot;

    @Find(by = By.Id, locator = "9157572914813406590")
    public PageElement dataBreachCheckedTheAddress;

    @Find(by = By.Id, locator = "9157572960813406608")
    public PageElement dataBreachCheckedTheEmailAddress;

    @Find(by = By.Id, locator = "9158151687113709881")
    public PageElement paymentMethod;

    @Find(by = By.Id, locator = "9158151756513709949")
    public PageElement cardType;

    @Find(by = By.Id, locator = "9158151830013710180")
    public PageElement nameOnCard;

    @Find(by = By.Id, locator = "9158151915713710129")
    public PageElement exactAmountToBeTraced;

    @Find(by = By.Id, locator = "9158151913113710229")
    public PageElement totalAmountOfPayment;

    @Find(by = By.Id, locator = "9158212875013822616")
    public PageElement reporterType;

    @Find(by = By.Id, locator = "9158274464313046989") //9158205753813791871
    public PageElement typeOfQuery;

    @Find(by = By.CssSelector, locator = ".refsel_single")
    public PageElementCollection specialCaseVerificationInputFields;

    @Find(by = By.Id, locator = "9158205937813792306")
    public PageElement additionalInformation;

    @Find(by = By.Id, locator = "nc_refsel_list")
    public PageElement reportedToForOption;

    @Find(by = By.Id, locator = "9156120169313515081")
    public PageElement amendmentRequired;

    @Find(by = By.Id, locator = "9156120160313515081")
    public PageElement reasonForAmendment;

    @Find(by = By.Id, locator = "9155230127613225471")
    public PageElement amountOfTransaction;

    @Find(by = By.Id, locator = "9155230127613225486")
    public PageElement reasonForTransaction;

    @Find(by = By.CssSelector, locator = ".refsel_arrow")
    public PageElementCollection dropDownArrows;

    @Find(by = By.CssSelector, locator = ".refsel_input")
    public PageElementCollection dropDownTextBoxes;

    @Find(by = By.Id, locator = "nc_refsel_list_table")
    public PageElement optionsRoot;

    @Find(by = By.Id, locator = "9157289023513165740")
    public PageElement typesOfFraud;

    public PageElement getTableBody() {
        return tableRoot.waitUntil(displayed).findChild(By.Tag, "tbody");
    }

    public PageElement getGeneralRequestsTitle() {
        return this.generalRequestsElements.size() > 0
                ? this.generalRequestsElements.asList().get(0)
                : null;
    }

    public PageElement getGeneralRequestsTableRoot() {
        return this.generalRequestsElements.size() > 1
                ? this.generalRequestsElements.asList().get(1)
                : null;
    }

    public PageElement getCategorySelectArrow() {
        assertThat(this.categoryRoot.isDisplayed())
                .withFailMessage("Could not find parent element for select arrow for Category drop down box!")
                .isTrue();

        PageElement element = this.categoryRoot.findChild(By.CssSelector, ".refsel_arrow");

        assertThat(element.isDisplayed())
                .withFailMessage("Could not find select arrow for Category drop down box!")
                .isTrue();

        return element;
    }

    @Override
    public boolean isPageDisplayed() {
        return this.getGeneralRequestsTitle() != null
                && this.getGeneralRequestsTitle().getText().contains("General Requests");
    }

    public int getTotalNoOfItems() {
        this.browser.setImplicitWait(5);
        PageElement pagination = this.paginationRoot.findChild(By.CssSelector, ".gwt-HTML");
        if (!pagination.isDisplayed()) return -1;
        this.browser.restoreImplicitWait();

        Pattern pattern = Pattern.compile("1 - (.*) of (.*),", Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(pagination.getText());
        boolean matchFound = matcher.find();

        if(matchFound) {
            return Integer.parseInt(matcher.group(2));
        }

        this.logger.warn("*** Could not retrieve total no of pages for General Requests Table! Will return -1! Is this a negative scenario?");

        return -1;
    }

    public void filterByName(String value) {
        this.logger.info(
                MessageFormat.format(">>> Filter General Requests table by Name ''{0}'' ...", value));

        if (this.filteringColumns.size() == 0) {
            this.logger.error("Could not find any filtering columns for General Requests table!");

            return;
        }

        PageElement filterByName = this.filteringColumns.asList().get(0);
        filterByName.click();
        this.filterTextField.waitUntil(displayed).setValue(value, true);
        this.filterApplyButton.click();
        this.waitForNcLoadingToComplete();

    }

    // TODO: make this sortBy and pass all table columns that can be used to sort by
    public void sortByName(Sort sort) {
        this.logger.info(
                MessageFormat.format(">>> Sort General Requests table by Name ''{0}'' ...", sort.toString()));

        if (this.sortableColumns.size() == 0) {
            this.logger.error("Could not find any sortable columns for General Requests table!");

            return;
        }

        PageElement column = this.sortableColumns.asList().get(0);
        PageElement sortDirectionElement = column.findChild(By.Tag, "img");
        String currentDirection = sortDirectionElement.getAttribute("alt").toLowerCase(Locale.ROOT);

        if (currentDirection.contains(sort.toString().toLowerCase(Locale.ROOT))) return;

        int cnt = 0;
        column.click();
        this.waitForNcLoadingToComplete();

        // There is no process icon so I'll check when the aria-label will change
        while(cnt++ < 4) {
            column = this.sortableColumns.asList().get(0);
            sortDirectionElement = column.findChild(By.Tag, "img");
            currentDirection = sortDirectionElement.getAttribute("alt").toLowerCase(Locale.ROOT);

            if (!currentDirection.contains(sort.toString().toLowerCase(Locale.ROOT))) {
                this.logger.info(
                        MessageFormat.format(">>> General Requests table not sorted yet ''{0}''. Waiting to refresh ...",
                                sort.toString()));
                this.common.wait(2);
                continue;
            }

            this.logger.warn(
                    MessageFormat.format(">>> General Requests table now sorted ''{0}''!",
                            sort.toString()));
            break;
        }
    }

    public int getGeneralRequestLastSequence(String prefix) {
        PageElementCollection rows = this.getRows();

        if (rows.size() == 0) return -1; // TODO: why -1 and not 0?

        Pattern pattern = Pattern.compile(MessageFormat.format("{0}-A(.*)", prefix), Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(rows.asList().get(0).getText());
        boolean matchFound = matcher.find();

        if(matchFound) {
            return Integer.parseInt(matcher.group(1));
        }

        return -1;
    }

    // TODO: this method gets only the 1st column. we should probably map the row into an object
    public PageElementCollection getRows() {
        this.browser.setImplicitWait(5);
        PageElementCollection fullRows = getTableBody().findChildren(By.Tag, "tr");
        this.browser.restoreImplicitWait();
        List<PageElement> result = new ArrayList<>();

        for(PageElement row : fullRows.asList()) {
            result.add(row.findChild(By.CssSelector, ".nc-field-text-readonly.nc-field-html-focusable-content"));
        }

        return Controls.createAll(result);
    }

    public void selectCategory(String value) {
        this.categoryTextField.waitUntil(displayed).click();
        this.common.wait(5);
        this.getCategorySelectArrow().click();
        this.common.wait(5);
        boolean listDisplayed = this.categoryListRoot.waitUntil(displayed).isDisplayed();
        assertThat(listDisplayed)
                .withFailMessage("Create General Request - Category list not retrieved!")
                .isTrue();

        PageElementCollection elements = this.categoryListRoot.findChildren(By.CssSelector, ".refsel_name");
        PageElement category = elements.asList().stream()
                .filter(e -> e.getText().toLowerCase(Locale.ROOT).contains(value.toLowerCase(Locale.ROOT)))
                .findFirst()
                .orElse(null);

        assertThat(category)
                .withFailMessage(
                        MessageFormat.format("Could not find a category with name: ''{0}''! Existing options are:\n{1}",
                                value,
                                StringUtils.join(elements.asList().stream().map(e -> e.getText()).collect(Collectors.toList()), "\n"))
                )
                .isNotNull();

        Objects.requireNonNull(category).click();
    }

    public void fillInGdprRequest(DataTable table) {
        this.logger.info(">>> Fill in a GDPR request ...");

        List<Map<String, String>> rows = table.asMaps(String.class, String.class);
        this.generalRequestType.asSelect().selectByText(rows.get(0).get("type"));
        this.selectCategory(rows.get(0).get("category"));
        this.requestedDate.waitUntil(displayed).setValue("02/06/2021");
        this.checkedTheAddress.asSelect().selectByText(rows.get(0).get("checked_the_address"));
        this.checkedTheEmail.asSelect().selectByText(rows.get(0).get("checked_the_email"));
        this.detailCustomerRequest.setValue(rows.get(0).get("detail"));
        this.createButton.click();

        this.waitForNcLoadingToComplete();

        assertThat(this.createButton.isDisplayed(1))
                .withFailMessage("General Request Form is still displayed!")
                .isFalse();

        this.logger.info(">>> GDPR form filled in and saved!");
    }

    public void fillInDataBreachRequest(DataTable table) {
        this.logger.info(">>> Fill in a Data Breach request ...");

        List<Map<String, String>> rows = table.asMaps(String.class, String.class);
        this.generalRequestType.asSelect().selectByText(rows.get(0).get("type"));
        this.waitForNcLoadingToComplete();
        this.selectCategory(rows.get(0).get("category"));
        this.dateAndTimeOfBreach.waitUntil(displayed).setValue("02/06/2021 12:34:56");
        this.dataBreachCheckedTheAddress.asSelect().selectByText(rows.get(0).get("checked_the_address"));
        this.dataBreachCheckedTheEmailAddress.asSelect().selectByText(rows.get(0).get("checked_the_email"));
        this.createButton.click();

        this.waitForNcLoadingToComplete();

        assertThat(this.createButton.isDisplayed(1))
                .withFailMessage("General Request Form is still displayed!")
                .isFalse();

        this.logger.info(">>> Data Breach form filled in and saved!");
    }

    public void fraudAccountTakeover(DataTable table) {
        this.logger.info(">>> Fill in a Fraud Account Takeover request ...");

        UserDataModel userDataModel = (UserDataModel) this.context.get("residentialUserAccountData");

        List<Map<String, String>> rows = table.asMaps(String.class, String.class);
        this.generalRequestType.asSelect().selectByText(rows.get(0).get("type"));
        this.selectCategory(rows.get(0).get("category"));
        Supplier<Boolean> action = () -> !this.dropDownTextBoxes.asList().get(0).getValue().equals("");
        this.retry.retryAction(action, 4, 1);

//        PageElementCollection inputFields = this.specialCaseVerificationInputFields;
//        PageElement reportedBy = inputFields.asList().get(1).findChild(By.CssSelector, ".refsel_input");
//        PageElement reportedFor = inputFields.asList().get(2).findChild(By.CssSelector, ".refsel_input");
//
//        reportedBy.click();
//        Supplier<Boolean> action = () -> this.reportedToForOption.waitUntil(displayed).isEnabled();
//        this.retry.retryAction(action, 12, 1);
//        assertThat(this.reportedToForOption.waitUntil(displayed).isEnabled())
//                .withFailMessage("No options displayed for Reported By!")
//                .isTrue();
//        this.reportedToForOption.waitUntil(displayed).click();

        this.dropDownArrows.asList().get(1).waitUntil(displayed).click();
        PageElementCollection options = this.optionsRoot.waitUntil(displayed).findChildren(By.CssSelector, ".refsel_name");
        options.asList().get(0).click();
        action = () -> !this.dropDownTextBoxes.asList().get(1).getValue().equals("");
        this.retry.retryAction(action, 4, 1);

        this.dropDownArrows.asList().get(2).click();
        options = this.optionsRoot.waitUntil(displayed).findChildren(By.CssSelector, ".refsel_name");
        options.asList().get(0).click();
        action = () -> !this.dropDownTextBoxes.asList().get(2).getValue().equals("");
        this.retry.retryAction(action, 4, 1);

        this.dropDownArrows.asList().get(3).click();
        this.waitForNcLoadingToComplete();
        options = this.optionsRoot.waitUntil(displayed).findChildren(By.CssSelector, ".refsel_name");
        options.asList().get(0).click();
        action = () -> !this.dropDownTextBoxes.asList().get(3).getValue().equals("");
        this.retry.retryAction(action, 4, 1);

        this.typesOfFraud.asSelect().selectByText(rows.get(0).get("types_of_fraud"));
        this.createButton.click();

        this.waitForNcLoadingToComplete();

        assertThat(this.createButton.isDisplayed(1))
                .withFailMessage("General Request Form is still displayed!")
                .isFalse();

        this.logger.info(">>> Fraud Account Takeover form filled in and saved!");
    }

    public void fillInCashManagementJournalTransferRequest(DataTable table) {
        this.logger.info(">>> Fill in a Cash Management - Journal Transfer request ...");

        UserDataModel userDataModel = (UserDataModel) this.context.get("residentialUserAccountData");

        List<Map<String, String>> rows = table.asMaps(String.class, String.class);
        this.generalRequestType.asSelect().selectByText(rows.get(0).get("type"));
        this.selectCategory(rows.get(0).get("category"));
        Supplier<Boolean> action = () -> !this.dropDownTextBoxes.asList().get(0).getValue().equals("");
        this.retry.retryAction(action, 4, 1);

        this.dropDownArrows.asList().get(1).click();
        PageElementCollection options = this.optionsRoot.waitUntil(displayed).findChildren(By.CssSelector, ".refsel_name");
        options.asList().get(0).click();
        action = () -> !this.dropDownTextBoxes.asList().get(1).getValue().equals("");
        this.retry.retryAction(action, 4, 1);

        this.dropDownArrows.asList().get(2).click();
        options = this.optionsRoot.waitUntil(displayed).findChildren(By.CssSelector, ".refsel_name");
        options.asList().get(0).click();
        action = () -> !this.dropDownTextBoxes.asList().get(2).getValue().equals("");
        this.retry.retryAction(action, 4, 1);

        this.amountOfTransaction.setValue(rows.get(0).get("amount"));
        this.reasonForTransaction.setValue(rows.get(0).get("reason"));

        this.createButton.click();

        this.waitForNcLoadingToComplete();

        assertThat(this.createButton.isDisplayed(1))
                .withFailMessage("General Request Form is still displayed!")
                .isFalse();

        this.logger.info(">>> Cash Management - Journal Transfer form filled in and saved!");
    }

    public void fillInCashManagementPaymentToTraceRequest(DataTable table) {
        this.logger.info(">>> Fill in a Cash Management - Payment To Trace request ...");

        UserDataModel userDataModel = (UserDataModel) this.context.get("residentialUserAccountData");

        List<Map<String, String>> rows = table.asMaps(String.class, String.class);
        this.generalRequestType.asSelect().selectByText(rows.get(0).get("type"));
        this.selectCategory(rows.get(0).get("category"));
        this.paymentMethod.asSelect().selectByText(rows.get(0).get("payment_method"));
        this.cardType.asSelect().selectByText(rows.get(0).get("card_type"));
        this.nameOnCard.setValue(MessageFormat.format(
                "{0} {1}",
                userDataModel.firstName, userDataModel.lastName));
        this.exactAmountToBeTraced.setValue("10");
        this.totalAmountOfPayment.setValue("10");
        this.createButton.click();

        this.waitForNcLoadingToComplete();

        assertThat(this.createButton.isDisplayed(1))
                .withFailMessage("General Request Form is still displayed!")
                .isFalse();

        this.logger.info(">>> Cash Management - Payment To Trace form filled in and saved!");
    }

    public void fillInSpecialCaseVerificationRequest(DataTable table) {
        this.logger.info(">>> Fill in a Special Case Verification request ...");

        UserDataModel userDataModel = (UserDataModel) this.context.get("residentialUserAccountData");
        String fullName = MessageFormat.format("{0} {1} {2}",
                userDataModel.title,
                userDataModel.firstName,
                userDataModel.lastName);

        List<Map<String, String>> rows = table.asMaps(String.class, String.class);
        this.generalRequestType.asSelect().selectByText(rows.get(0).get("type"));
        this.selectCategory(rows.get(0).get("category"));
        this.reporterType.asSelect().selectByText(rows.get(0).get("reporter_type"));
        this.typeOfQuery.asSelect().selectByText(rows.get(0).get("type_of_query"));

        PageElementCollection inputFields = this.specialCaseVerificationInputFields;
        PageElement reportedBy = inputFields.asList().get(1).findChild(By.CssSelector, ".refsel_input");
        PageElement reportedFor = inputFields.asList().get(2).findChild(By.CssSelector, ".refsel_input");
          this.waitForNcLoadingToComplete();
          this.common.wait(3);
        reportedBy.click();
        Supplier<Boolean> action = () -> this.reportedToForOption.waitUntil(displayed).isEnabled();
        this.retry.retryAction(action, 12, 1);
        assertThat(this.reportedToForOption.waitUntil(displayed).isEnabled())
                .withFailMessage("No options displayed for Reported By!")
                .isTrue();
        this.reportedToForOption.waitUntil(displayed).click();

        reportedFor.click();
        assertThat(this.reportedToForOption.waitUntil(displayed).isDisplayed())
                .withFailMessage("No options displayed for Reported For!")
                .isTrue();
        this.reportedToForOption.waitUntil(displayed).click();

        this.createButton.click();

        this.waitForNcLoadingToComplete();

        assertThat(this.createButton.isDisplayed(1))
                .withFailMessage("General Request Form is still displayed!")
                .isFalse();

        this.logger.info(">>> Special Case Verification form filled in and saved!");
    }

    public void fillInCreditFileRequest(DataTable table) {
        this.logger.info(">>> Fill in a Credit File request ...");

        List<Map<String, String>> rows = table.asMaps(String.class, String.class);
        this.generalRequestType.asSelect().selectByText(rows.get(0).get("type"));
        this.selectCategory(rows.get(0).get("category"));

        this.amendmentRequired.waitUntil(displayed).asSelect().selectByText(rows.get(0).get("amendment_required"));
        this.reasonForAmendment.setValue(rows.get(0).get("reason_for_amendment"));

        this.createButton.click();

        this.waitForNcLoadingToComplete();

        this.browser.setImplicitWait(1);
        assertThat(this.createButton.isDisplayed(1))
                .withFailMessage("General Request Form is still displayed!")
                .isFalse();
        this.browser.restoreImplicitWait();

        this.logger.info(">>> Credit File form filled in and saved!");
    }
}
