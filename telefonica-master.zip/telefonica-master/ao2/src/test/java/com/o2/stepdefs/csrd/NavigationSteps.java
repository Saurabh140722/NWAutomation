package com.o2.stepdefs.csrd;

import com.google.inject.Inject;
import com.nttdata.cinnamon.conf.Env;
import com.nttdata.cinnamon.driver.Browser;
import com.o2.pages.csrd.CsrDesktopPage;
import com.o2.pages.csrd.LeftNavigationMenuPage;
import com.o2.pages.csrd.login.GeneralLoginPage;
import com.o2.pages.csrd.login.NttLoginPage;
import com.o2.pages.csrd.navigation.AccountNavigation;
import com.o2.pages.csrd.navigation.HeaderNavigationFragment;
import com.o2.stepdefs.BaseStep;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

import java.text.MessageFormat;

import static com.nttdata.cinnamon.wait.ElementConditions.displayed;
import static org.assertj.core.api.Assertions.assertThat;

public class NavigationSteps extends BaseStep {
    private final Browser browser;
    private final GeneralLoginPage generalLoginPage;
    private final AccountNavigation accountNavigation;
    private final NttLoginPage nttLoginPage;
    private final HeaderNavigationFragment headerNavigationFragment;
    private final LeftNavigationMenuPage leftNavigationMenuPage;
    private final CsrDesktopPage csrDesktopPage;

    @Inject
    public NavigationSteps(final Browser browser,
                           final CsrDesktopPage csrDesktopPage,
                           final HeaderNavigationFragment  headerNavigationFragment,
                           final LeftNavigationMenuPage leftNavigationMenuPage,
                           final GeneralLoginPage generalLoginPage,
                           final AccountNavigation accountNavigation,
                           final NttLoginPage nttLoginPage) {
        this.browser = browser;
        this.csrDesktopPage = csrDesktopPage;
        this.headerNavigationFragment = headerNavigationFragment;
        this.leftNavigationMenuPage = leftNavigationMenuPage;
        this.generalLoginPage = generalLoginPage;
        this.accountNavigation = accountNavigation;
        this.nttLoginPage = nttLoginPage;
    }

    @Given("^CSR application opens$")
    public void csr_application_opens() {
        this.logger.info("*** Opening CSR application ...");

        this.browser.open(Env.get().envProperty("csrdHost"));

        this.browser.maximise();

        // This was used when app was launched properly. Will keep it a bit longer till we make sure it's been fixed
//        assertThat(this.generalLoginPage.logAsNttButton.waitUntil(displayed).isDisplayed())
//                .withFailMessage("First Login page not loaded!")
//                .isTrue();

//        this.generalLoginPage.logAsNttButton.click();
//
//        assertThat(this.nttLoginPage.lanId.waitUntil(displayed).isDisplayed())
//                .withFailMessage("NTT Loading page not loaded!")
//                .isTrue();

        this.logger.info("*** CSR Application opened!\n");
    }

    @When("^I left navigate to '(.*)'$")
    public void when_i_left_navigate_to(String menuItem) {
        this.logger.info(MessageFormat.format("*** Left navigate to: {0} ...", menuItem));

        this.csrDesktopPage.leftNavigationMenu.waitUntil(displayed).click();

        assertThat(this.leftNavigationMenuPage.isPageDisplayed())
                .withFailMessage("Left menu not displayed!")
                .isTrue();

        this.leftNavigationMenuPage.getLeftMenuItem(menuItem).click();

        this.logger.info("*** Left navigation completed!\n");
    }

    @When("^I navigate to More Links -> '(.*)'$")
    public void i_navigate_to_more_links_submenu(String navigationPath) {
        this.headerNavigationFragment.navigateToMoreLinks(navigationPath);
    }

    @When("^I navigate from Billing Account to '(.*)'$")
    public void i_navigate_from_billing_account_to(String navigationPath) {
        this.accountNavigation.navigateTo(navigationPath);
    }
}
