package com.o2.acceptancetests.csrd.DATA_VOLUME_BDD_TEST_RUNNERS.Discontinued_Devices;

import com.o2.feature_file_appender.config.AppendDataToFeatureFile_Utility;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;

import java.util.function.Predicate;

import static org.junit.Assert.assertTrue;

@RunWith(Cucumber.class)
@CucumberOptions(
        plugin = { "com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:", "summary" },
        glue = { "com.o2.stepdefs", "com.o2.hooks" },
        features = "src/test/resources/features/BDD_TESTS_DATA_VOLUME/Discontinued_Devices_Tab/Data_Vol_Watches_Android.feature",
        tags = "@dd_watches_android"
)
public class DD_Watches_Android_TestRunner {
    private AppendDataToFeatureFile_Utility utility;

    public DD_Watches_Android_TestRunner() {
        utility.readCleanseDataSourceFileInto2DArray("Discontinued_Devices.csv", false);
        String value = "Android Watch";
        Predicate<String> predStringEquals = s -> (s.equalsIgnoreCase(value));
        Object[] args = {  predStringEquals, 0, 1 };
        assertTrue(utility.copyFeatureFile("Watches_Android.feature"));
        assertTrue(utility.appendDataToNewFeatureFile("scenario","filtered_map_by_col", args));
    }

    @BeforeClass
    public static void setup() {
//         Any BeforeAll logic ...
    }

    @AfterClass
    public static void teardown() {
//         DriverUtil.getDriver().close();
//        BrowserUtil.getBrowser().close();
    }
}
