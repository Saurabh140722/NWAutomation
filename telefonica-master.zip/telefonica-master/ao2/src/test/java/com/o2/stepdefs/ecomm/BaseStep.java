package com.o2.stepdefs.ecomm;

import com.google.inject.Inject;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.nttdata.cinnamon.logging.Logger;

public abstract class BaseStep {
    @Inject
    public Logger logger;
    public void closePopUpIfAny(PageElement closePopup) throws InterruptedException {
        this.logger.info(closePopup+" --- displayed");
        this.logger.info(closePopup.getText());
        closePopup.clickJs();
    }

}
