package com.o2.pages.csrd;

import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.o2.pages.BasePage;

public class OrderDeliveryPage extends BasePage {
    @Find(by = By.CssSelector, locator = ".roe-hardware-area-reserve")
    public PageElement reserveLink;

    @Find(by = By.CssSelector, locator = ".roe-hardware-area-reserve.disabled.reserved")
    public PageElement reservedEquipmentStatus;

    @Find(by = By.Id, locator = "gwt-uid-2025")
    public PageElement contactPhoneNumber;

    @Override
    protected PageElement getPageCheckElement() {
        return this.reserveLink;
    }
}
