package com.o2.pages.csrd.customertickets;

import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.o2.pages.BasePage;

public class CustomerTicketsPage extends BasePage {
    @Find(by = By.Id, locator = "label_9141279756413409363_lighttablectrl_3")
    public PageElement customerIncidentTitle;

    @Override
    public boolean isPageDisplayed() {
        return this.customerIncidentTitle.isDisplayed()
                && this.customerIncidentTitle.getText().contains("Customer Incidents");
    }
}
