package com.o2.stepdefs.ecomm;

import com.google.inject.Inject;
import com.nttdata.cinnamon.cache.Context;
import com.nttdata.cinnamon.driver.Browser;
import com.nttdata.cinnamon.webdriver.util.ReadyState;
import com.o2.models.ecomm.EcommUser;
import com.o2.pages.ecomm.CreateAnAccountPage;
import com.o2.pages.ecomm.EcommBasePage;
import com.o2.pages.ecomm.SignInPage;
import com.o2.pages.ecomm.YourBasketPage;
import com.o2.util.Common;
import io.cucumber.java.en.And;
import io.cucumber.java.en.When;
import org.apache.commons.lang.NotImplementedException;
import org.assertj.core.api.Assertions;

import java.text.MessageFormat;

import static com.nttdata.cinnamon.wait.ElementConditions.*;
import static com.nttdata.cinnamon.wait.conditions.Conditions.readyState;
import static org.assertj.core.api.Assertions.assertThat;

public class SignInSteps extends BaseStep {
    private final Context context;
    private final SignInPage signInPage;
    private final EcommBasePage ecommBasePage;
    private final Browser browser;
    private final Common common;
    private final CreateAnAccountPage createAnAccountPage;
    private final YourBasketPage yourBasketPage;

    @Inject
    public SignInSteps(final Context context, final SignInPage signInPage, final EcommBasePage ecommBasePage, final Browser browser, final Common common, final CreateAnAccountPage createAnAccountPage, final YourBasketPage yourBasketPage, BasketSteps basketSteps) {
        this.context = context;
        this.signInPage = signInPage;
        this.ecommBasePage = ecommBasePage;
        this.browser = browser;
        this.common = common;
        this.createAnAccountPage = createAnAccountPage;
        this.yourBasketPage = yourBasketPage;
    }

    @When("^I log into eComm$")
    public void i_log_into_ecomm() {
        //TODO: keep this method for ecomm_test feature file

    }


    public void checkIfAnyPopupDisplayed() {
        this.common.wait(2);
        signInPage.closeChatPopup();
        if (this.signInPage.manageCookiesBtn.isDisplayed()) {
           // this.signInPage.manageCookiesBtn.clickJs();
            this.signInPage.acceptAllCookiesBtn.clickJs();
        }
        this.common.wait(1);

        /*try {
            if (this.signInPage.chatNowPopUp.isDisplayed()) {
                closePopUpIfAny(this.signInPage.chatNowPopUp);
            }
            if (signInPage.manageCookiesBtn.isPresent()) {
                signInPage.acceptAllCookiesBtn.clickJs();
            }
            if (this.signInPage.chatNowPopUp.isDisplayed()) {
                closePopUpIfAny(this.signInPage.chatNowPopUp);
            }
            if (this.signInPage.manageCookiesBtn.isDisplayed()) {
                this.signInPage.manageCookiesBtn.clickJs();
                this.signInPage.acceptAllCookiesBtn.clickJs();
            }
            if (this.signInPage.chatNowPopUp.isDisplayed()) {
                closePopUpIfAny(this.signInPage.chatNowPopUp);
            }
            if (this.signInPage.closePopUp.isDisplayed()) {
                closePopUpIfAny(this.signInPage.closePopUp);
            }

            if (this.signInPage.chatNowRandomPopUp.isDisplayed()) {
                closePopUpIfAny(this.signInPage.chatNowRandomPopUp);
            }

            if (this.signInPage.closeDialog.isDisplayed()) {
                 this.browser.setImplicitWait(5);
                // There is a popup showing up at the beginning of the journey. will wait for 5 sec and attempt to close it
                this.signInPage.closeDialog.click();
                this.browser.restoreImplicitWait();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }*/

    }

    @When("^I log into eComm as '(new|existing)' user$")
    public void i_log_into_eComm_as(String userType) throws InterruptedException {
        logger.info("** Attempt to login into eComm new or exist...");
        EcommUser ecommUser = (EcommUser) context.get("eCommUserData");
        this.common.waitForLoadingToComplete(2, 1);
        this.browser.waitUntil(readyState(ReadyState.COMPLETE));
        checkIfAnyPopupDisplayed();

        switch (userType) {
            case "existing":
                this.browser.restoreImplicitWait();
                this.signInPage.signIn.waitUntil(displayed.and(enabled)).clickJs();
                this.signInPage.email.waitUntil(displayed).setValue(ecommUser.username);
                this.signInPage.continueButton.click();
                this.signInPage.password.waitUntil(displayed).setValue(ecommUser.password);
                this.signInPage.continueButton.click();
                this.browser.waitUntil(readyState(ReadyState.COMPLETE));

                if (signInPage.phoneNumberCancel.isDisplayed()) {
                    signInPage.phoneNumberCancel.clickJs();
                }
                browser.setImplicitWait(2);
                Assertions.assertThat(signInPage.signOutLink.isDisplayed()).withFailMessage(
                                "Could not able to Login to eComm application..")
                        .isNotNull().isTrue();

                Assertions.assertThat(this.ecommBasePage.hiUserName.getText().trim()).
                        isEqualTo(MessageFormat.format("Hi {0}", ecommUser.firstName));

                this.logger.info("** Login into ecomm complete!");
                this.logger.info("***Attempt to delete all the items from basket before start the journey...");

                int basketItem=yourBasketPage.getBasketCount();
                if(basketItem >0) {
                    yourBasketPage.basketBtn.waitUntil(displayed.and(enabled).and(clickable)).clickJs();
                    this.browser.waitUntil(readyState(ReadyState.COMPLETE));
                    common.wait(5);

                logger.info("basket text:" + yourBasketPage.pageTitle.getText().trim());

                    if (yourBasketPage.orderInProgressPopup.isDisplayed(2)) {
                        yourBasketPage.emptyBasketAndcancelLink.clickJs();
                    }
                    if (yourBasketPage.emptyBasketButton.isDisplayed()) {
                        yourBasketPage.emptyBasketButton.clickJs();
                        yourBasketPage.waitForjustaMomentLoadingToComplete(20, 2, 5);
                    }
                    if (yourBasketPage.emptyBasketLink.isDisplayed(2)) {
                        yourBasketPage.emptyBasketLink.waitUntil(displayed.and(enabled).and(clickable)).clickJs();
                        yourBasketPage.waitForjustaMomentLoadingToComplete(20, 2, 5);

                            if(yourBasketPage.cancelOrderBtn.isDisplayed(2)) {
                                yourBasketPage.cancelOrderBtn.waitUntil(clickable).clickJs();
                            }
                        if(yourBasketPage.cancelMyOrderBtn.isDisplayed(2)) {
                            yourBasketPage.cancelMyOrderBtn.waitUntil(clickable).clickJs();
                        }
                    }


                    yourBasketPage.waitForjustaMomentLoadingToComplete(20, 2, 5);
                    browser.refresh();
                    browser.setImplicitWait(2);
                    browser.waitUntil(readyState(ReadyState.COMPLETE));
                    Assertions.assertThat(this.yourBasketPage.pageTitle.getText().trim().equals("Your basket is empty")).withFailMessage(
                                    "Cannot deleted all items from basket.")
                            .isTrue();
                    this.logger.info("***Successfully deleted all the items from basket...");
                }
                break;

            case "new":
                this.createAnAccountPage.registerLink.waitUntil(displayed.and(enabled)).clickJs();
                this.createAnAccountPage.newToO2Btton.waitUntil(displayed.and(enabled)).clickJs();
                this.browser.waitUntil(readyState(ReadyState.COMPLETE));
                this.createAnAccountPage.email.waitUntil(displayed.and(enabled).and(present)).setValue(ecommUser.email);
                this.createAnAccountPage.password.waitUntil(displayed).setValue(ecommUser.password);
                this.createAnAccountPage.RegisterButton.hover().clickJs();

                String username = ecommUser.email.substring(0, ecommUser.email.indexOf("@"));
                Assertions.assertThat(signInPage.signOutLink.isDisplayed()).withFailMessage(
                                "Could not able to Login to eComm application..")
                        .isNotNull().isTrue();

                Assertions.assertThat(this.ecommBasePage.hiUserName.getText()).
                        isEqualTo(MessageFormat.format("Hi {0}", username));
                this.logger.info("** Login as new user into ecomm application complete!\n");
                this.browser.waitUntil(readyState(ReadyState.COMPLETE));
                break;

            default:
                throw new NotImplementedException(MessageFormat
                        .format("Option ''{0}'' for eComm login details has not been implemented yet!", userType));
        }
    }

    @And("^I logout from eComm$")
    public void i_logout_from_ecomm() {
        this.logger.info("** Attemp to logout from eComm!");
        Assertions.assertThat(signInPage.signOutLink.isDisplayed()).withFailMessage(
                        "Logout link is not displayed..")
                .isTrue();
        signInPage.signOutLink.waitUntil(enabled.and(clickable)).clickJs();
        signInPage.waitForProcessLoadingToComplete(20, 2, 2);

        Assertions.assertThat(signInPage.signOutPageTitle.getText().trim())
                .withFailMessage(
                        "**Logout page is not displayed..")
                .isEqualTo("Sign out");

        Assertions.assertThat(signInPage.goToHomepage.isDisplayed()).withFailMessage(
                        "Logout page is not displayed..")
                .isTrue();
        this.logger.info("** Successfully logout from eComm!");
    }
}
