package com.o2.models.ecomm;

import com.nttdata.cinnamon.driver.controls.PageElement;

public class AccessoriesSelectedDetail {
    public PageElement deviceTitle;
    public String deviceName;
    public String devicePrice;
    public String availability;
    public PageElement image;
    public String colour;

    public AccessoriesSelectedDetail(PageElement deviceTitle, String deviceName, String devicePrice, String availability, PageElement image, String colour) {
        this.deviceTitle = deviceTitle;
        this.deviceName = deviceName;
        this.devicePrice = devicePrice;
        this.availability = availability;
        this.image = image;
        this.colour = colour;
    }

    @Override
    public boolean equals(Object classobject) {
        if (classobject == this)
            return true;
        if (!(classobject instanceof AccessoriesSelectedDetail))
            return false;

        AccessoriesSelectedDetail accessoriesSelectedDetail = (AccessoriesSelectedDetail) classobject;
        return accessoriesSelectedDetail.deviceTitle.equals(this.deviceTitle);

    }
}
