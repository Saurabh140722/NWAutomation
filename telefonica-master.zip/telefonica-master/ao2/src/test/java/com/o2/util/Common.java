package com.o2.util;

import com.google.inject.Inject;
import com.nttdata.cinnamon.driver.Browser;
import com.nttdata.cinnamon.logging.Logger;
import com.o2.pages.csrd.ProcessElements;
import org.apache.commons.lang.StringUtils;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

import java.sql.Timestamp;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.Calendar;
import java.util.Date;

import static org.assertj.core.api.Assertions.assertThat;

public class Common {
    private final Logger logger;
    private final Browser browser;
    private final ProcessElements processElements;

    @Inject
    public Common(final Logger logger,
                  final Browser browser,
                  final ProcessElements processElements) {
        this.logger = logger;
        this.browser = browser;
        this.processElements = processElements;
    }

    public List<String> getAllEcarePages() throws IOException {
        List<String> pages = new ArrayList<>();

        Files.walk(Paths.get(System.getProperty("user.dir") + "\\src\\test\\java\\com\\o2\\pages\\ecare"))
                .filter(Files::isRegularFile)
                .forEach(p -> pages.add(
                        p.toString()
                                .replace(System.getProperty("user.dir") + "\\src\\test\\java\\", "")
                                .replace("\\", ".")
                                .replace(".java", "")));

        return pages;
    }

    public List<String> getAllCsrdPages() throws IOException {
        List<String> pages = new ArrayList<>();

        Files.walk(Paths.get(System.getProperty("user.dir") + "\\src\\test\\java\\com\\o2\\pages\\csrd"))
                .filter(Files::isRegularFile)
                .forEach(p -> pages.add(
                        p.toString()
                                .replace(System.getProperty("user.dir") + "\\src\\test\\java\\", "")
                                .replace("\\", ".")
                                .replace(".java", "")));

        return pages;
    }

    public void wait(int seconds) {
        try {
            this.logger.warn(
                    MessageFormat.format(
                            "Waiter is called for {0} second(s)! Please make sure this is not a hardcoded waiter!",
                            seconds));

            Thread.sleep(seconds * 1000L);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public boolean waitForLoadingToComplete() {
        return waitForLoadingToComplete(5, 2);
    }

    public boolean waitForLoadingToComplete(int maxRetries, int pollingInterval) {
        return waitForLoadingToComplete(maxRetries, pollingInterval, false);
    }

    public boolean waitForNavigationLoadingToComplete(int maxRetries, int pollingInterval, boolean withAssertion) {
        this.browser.setImplicitWait(3);
        boolean loadingComplete = false;
        int origMaxRetries = maxRetries;

        this.logger.info(">>> Check if Navigation Loading process element is displayed ...");

        while (maxRetries > 0 && !loadingComplete) {
            maxRetries--;

            if (this.processElements.pageNavigationLoading.isDisplayed()) {
                this.logger.info(MessageFormat.format(
                        ">>> Navigation Loading process element found. Waiting to complete #{0}...",
                        maxRetries));
                this.wait(pollingInterval);
                continue;
            }

            this.logger.info(">>> Navigation Loading process element not found. Loading is complete, continue ...");
            loadingComplete = true;
        }

        this.browser.restoreImplicitWait();

        if (withAssertion) {
            assertThat(loadingComplete)
                    .withFailMessage(MessageFormat.format(
                            "Navigation Loading process element is still displayed after ''{0}'' retries with ''{1}'' polling interval!",
                            origMaxRetries, pollingInterval))
                    .isTrue();
        } else {
            if (!loadingComplete) {
                this.logger.warn(MessageFormat.format(
                        ">>> Navigation Loading process element is still displayed after ''{0}'' retries with ''{1}'' polling interval!",
                        origMaxRetries, pollingInterval));
            }
        }

        return loadingComplete;
    }

    public boolean waitForLoadingToComplete(int maxRetries, int pollingInterval, boolean withAssertion) {
        this.browser.setImplicitWait(2);
        boolean loadingComplete = false;
        int origMaxRetries = maxRetries;

        this.logger.info("*** Check if Loading process element is displayed ...");

        while (maxRetries > 0 && !loadingComplete) {
            maxRetries--;

            String loadingStyle = "";
            try {
                loadingStyle = this.processElements.ncLoadingProgressControl.getAttribute("style");
            } catch (Exception e) {
                this.logger.warn("Could not find style for loading/process element! Has loading/processing been completed?");
            }

            if (loadingStyle.contains("display: block")) {
                this.logger.info(MessageFormat.format(
                        "Loading process element found. Waiting to complete #{0}...",
                        maxRetries));
                this.wait(pollingInterval);
                continue;
            }

            this.logger.info("*** Loading process element not found. Loading is complete, continue ...");
            loadingComplete = true;
        }

        this.browser.restoreImplicitWait();

        if (withAssertion) {
            assertThat(loadingComplete)
                    .withFailMessage(MessageFormat.format(
                            "Loading process element is still displayed after ''{0}'' retries with ''{1}'' polling interval!",
                            origMaxRetries, pollingInterval))
                    .isTrue();
        } else {
            if (!loadingComplete) {
                this.logger.warn(MessageFormat.format(
                        "Loading process element is still displayed after ''{0}'' retries with ''{1}'' polling interval!",
                        origMaxRetries, pollingInterval));
            }
        }

        return loadingComplete;
    }

    public String generateYopMail(){
        String randomYopMail="SanityePOSAuto",mailDotCom="@yopmail.com";
        Timestamp timestamp = new Timestamp(System.currentTimeMillis());
        Date date = new Date();
        Timestamp timestamp2 = new Timestamp(date.getTime());
        Timestamp ts = Timestamp.from(Instant.now());
        String date1 = StringUtils.substringBefore(ts.toString()," ").replace("-","");
        String time = StringUtils.substringAfter(ts.toString()," ").replace(":","");
        String time1 = StringUtils.substringBefore(time,".");
        randomYopMail = randomYopMail+date1+"_"+time1+mailDotCom;
        return randomYopMail;
    }

    public Timestamp getSystemDatePLUS14Days(){
        Calendar cal = Calendar.getInstance();
        Format formatter = new SimpleDateFormat("dd MMM yyyy");
        Timestamp timestamp = new Timestamp(System.currentTimeMillis());
        Date date = new Date();
        Timestamp ts = Timestamp.from(Instant.now());
        cal.setTime(ts);
        cal.add(Calendar.DAY_OF_WEEK, 14);
        ts =new Timestamp(cal.getTime().getTime());
        String date1 = StringUtils.substringBefore(ts.toString()," ");
        return ts;
    }
}
