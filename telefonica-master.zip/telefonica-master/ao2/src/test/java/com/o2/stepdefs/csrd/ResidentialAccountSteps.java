package com.o2.stepdefs.csrd;

import com.google.inject.Inject;
import com.nttdata.cinnamon.cache.Context;
import com.nttdata.cinnamon.driver.Browser;
import com.o2.core.data.UserDataModel;
import com.o2.pages.csrd.AddressLookupPage;
import com.o2.pages.csrd.ResidentialAccountIntroPage;
import com.o2.pages.csrd.ResidentialAccountPage;
import com.o2.pages.csrd.ResidentialCustomerAccountEditPage;
import com.o2.stepdefs.BaseStep;
import com.o2.util.Common;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.When;

import java.text.MessageFormat;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static com.nttdata.cinnamon.wait.ElementConditions.displayed;
import static org.assertj.core.api.Assertions.assertThat;

public class ResidentialAccountSteps extends BaseStep {
    private final Browser browser;
    private final Common common;
    private final com.o2.core.util.Common commonTef;
    private final ResidentialAccountIntroPage residentialAccountIntroPage;
    private final ResidentialAccountPage residentialAccountPage;
    private final ResidentialCustomerAccountEditPage residentialCustomerAccountEditPage;
    private final AddressLookupPage addressLookupPage;
    private final Context context;

    @Inject
    public ResidentialAccountSteps(final Browser browser,
                                   final Common common,
                                   final com.o2.core.util.Common commonTef,
                                   final ResidentialAccountIntroPage residentialAccountIntroPage,
                                   final ResidentialAccountPage residentialAccountPage,
                                   final ResidentialCustomerAccountEditPage residentialCustomerAccountEditPage,
                                   final AddressLookupPage addressLookupPage,
                                   final Context context) {
        this.browser = browser;
        this.common = common;
        this.commonTef = commonTef;
        this.residentialAccountIntroPage = residentialAccountIntroPage;
        this.residentialAccountPage = residentialAccountPage;
        this.residentialCustomerAccountEditPage = residentialCustomerAccountEditPage;
        this.addressLookupPage = addressLookupPage;
        this.context = context;
    }

    @When("^I create a Residential Account$")
    public void i_create_residential_account() {
        this.logger.info("*** Create residential account ...");

        UserDataModel userData = (UserDataModel) this.context.get("residentialUserAccountData");
        this.residentialAccountIntroPage.email.waitUntil(displayed).setValue(userData.userEmail);
        this.residentialAccountIntroPage.reEnterEmail.waitUntil(displayed).setValue(userData.userEmail);
        this.residentialAccountIntroPage.continueButton.click();
        /*
         No loading icon or anything. Once continue is clicked will check if page is loading again.
         once it's been completed then I'll check if I have an error message
         setting first implicit wait to 1 so it's not staying longer on first discovery
         */
        this.browser.setImplicitWait(1);
        assertThat(this.residentialAccountIntroPage.errorMessage.isDisplayed(2))
                .withFailMessage("Error processing the email!")
                .isFalse();
        this.browser.restoreImplicitWait();

        assertThat(this.residentialAccountPage.dialogWindowTitle.waitUntil(displayed).isDisplayed())
                .withFailMessage("Residential Account form page not loaded!")
                .isTrue();
        assertThat(this.residentialAccountPage.dialogWindowTitle.getText())
                .isEqualTo("New Residential Customer Account");

        this.residentialAccountPage.title.asSelect().selectByText(userData.title);
        this.residentialAccountPage.getFirstName().setValue(userData.firstName);
        this.residentialAccountPage.getLastName().setValue(userData.lastName);
        this.residentialAccountPage.mobileContainer.click(); // Need this extra click as this field is a trouble maker
        this.residentialAccountPage.mobile.waitUntil(displayed).setValue(userData.contactMobile.replace(" ", ""));
        this.residentialAccountPage.dob.setValue("11/10/1990"); // TODO: can add DOB to UserData

        this.residentialAccountPage.addAddressButton.click();
        assertThat(this.addressLookupPage.isPageDisplayed())
                .withFailMessage("Address Lookup form page not loaded!")
                .isTrue();

        this.addressLookupPage.getPostcode().setValue(userData.postcode);
        this.addressLookupPage.streetNo.waitUntil(displayed).setValue("567");
        // TODO: can add street no to UserData
        this.common.wait(2);
        this.addressLookupPage.addressLookupButton.click();
        this.common.wait(4);
        assertThat(addressLookupPage.addresses.isDisplayed(90))
                .withFailMessage("Address list has not been loaded!")
                .isTrue();

        try {
            this.addressLookupPage.addresses.asSelect().selectByIndex(5);
            userData.address = this.addressLookupPage.addresses.asSelect().getSelectedValue();
        } catch (Exception e) {
            this.addressLookupPage.addresses.asSelect().selectByIndex(5);
            userData.address = this.addressLookupPage.addresses.asSelect().getSelectedValue();
        }
        this.addressLookupPage.confirmAddressButton.click();

        int cnt = 8;
        while(cnt > 0) {
            cnt--;
            this.browser.setImplicitWait(1);
            try {
                if (this.addressLookupPage.getPostcode().isDisplayed()) {
                    Thread.sleep(1000);
                    continue;
                }
            } catch (Exception e) {
                this.browser.restoreImplicitWait();
                break;
            }
            this.browser.restoreImplicitWait();
            break;
        }

        cnt = 4;
        this.logger.info("Attempt to save the form ...");
        while (--cnt > 0) {
            this.logger.info(MessageFormat.format("Retry #{0} ...", cnt));

            this.logger.info("Click Create button ...");
            this.residentialAccountPage.createButton.waitUntil(displayed).click();
            this.common.waitForLoadingToComplete(60, 2, true);

            this.browser.setImplicitWait(1);
            if (!this.residentialAccountPage.title.isDisplayed(2)) {
                this.logger.info("Form saved and closed!");
                break;
            }
            this.logger.warn("Clicked Create button but windows has not been closed yet! Retry ...");
            this.common.wait(2);
        }

        this.browser.setImplicitWait(1);
        assertThat(this.residentialAccountPage.title.isDisplayed(2))
                .withFailMessage("Residential Account Create form still displayed!")
                .isFalse();

        this.browser.restoreImplicitWait();

        this.context.set("residentialUserAccountData", userData);

        this.logger.info("*** Residential Account created!\n");
    }

    // Edit account steps
    @When("^I edit residential account and set the following flags:$")
    public void i_edit_residential_account_and_set_the_following_flags(DataTable table) throws InterruptedException {
        this.logger.info("*** Edit Residential Customer Account ...");

        List<Map<String, String>> rows = table.asMaps(String.class, String.class);
        // Store original values to make sure any flag which is not changed keeps its value
        Map<String, Boolean> flags = this.residentialCustomerAccountEditPage.getFlags()
                .entrySet()
                .stream()
                .collect(Collectors.toMap(
                        Map.Entry::getKey,
                        e -> e.getValue().getAttribute("checked") != null
                ));
        // and update those based on what flag are passed from test
        for(Map<String, String> row : rows) {
            assertThat(flags.containsKey(row.get("flag")))
                    .withFailMessage(
                            MessageFormat.format(
                                    "Could not find a flag define with name: ''{0}''! Check if the flag is spelled correct and if it is defined in the page object!",
                                    row.get("flag")))
                    .isTrue();

            flags.put(row.get("flag"), Boolean.valueOf(row.get("activate")));
        }

        this.context.set("expectedFlags", flags);
        // ---

        assertThat(this.residentialCustomerAccountEditPage.isPageDisplayed())
                .withFailMessage("Residential Customer Account page not displayed!")
                .isTrue();

        this.residentialCustomerAccountEditPage.editResidentialAccountButton.click();
        this.residentialCustomerAccountEditPage.setFlags(rows);
        this.residentialCustomerAccountEditPage.saveButton.click();
        this.common.waitForLoadingToComplete(60, 1, true);

            this.logger.info("*** Residential Customer Account edited!\n");
    }

    @When("^all flags are updated$")
    public void all_customer_segmentation_information_is_updated() {
        this.logger.info("*** Check if Customer Segmentation has been updated ...");
          this.common.waitForLoadingToComplete(3,1);
        Map<String, Boolean> expectedFlags = (Map<String, Boolean>) this.context.get("expectedFlags");
        String reasonableAdjustmentDetails = (String) this.context.get("reasonableAdjustmentDetails");

        Map<String, Boolean> currentFlags = this.residentialCustomerAccountEditPage.getFlags()
                .entrySet()
                .stream()
                .collect(Collectors.toMap(
                        Map.Entry::getKey,
                        e -> e.getValue().getAttribute("checked") != null
                ));

//        assertThat(this.commonTef.areEqual(expectedFlags, currentFlags))
//                .withFailMessage("Customer Segmentation information has not been updated! Check logs for full details!")
//                .isTrue();

        if (expectedFlags.get("Reasonable Adjustment")) {
            String expected = this.residentialCustomerAccountEditPage.getReasonableAdjustmentDetails();

            assertThat(reasonableAdjustmentDetails)
                    .withFailMessage(
                            MessageFormat.format(
                                    "Reasonable Adjustment Details value is wrong! Expected: ''{0}'' but was: ''{1}''!",
                                    expected, reasonableAdjustmentDetails)).contains(expected);
        }
        this.logger.info("*** Customer Segmentation check complete!\n");
    }

}
