package com.o2.acceptancetests.csrd.DATA_VOLUME_BDD_TEST_RUNNERS.Insurance_Offering_Config;

import com.o2.feature_file_appender.config.AppendDataToFeatureFile_Utility;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;

import java.util.function.Predicate;

import static org.junit.Assert.assertTrue;

@RunWith(Cucumber.class)
@CucumberOptions(
        plugin = { "com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:", "summary" },
        glue = { "com.o2.stepdefs", "com.o2.hooks" },
        features = "src/test/resources/features/BDD_TESTS_DATA_VOLUME/Insurance_Offering_Config_Tab/Data_Vol_Tablets_Windows.feature",
        tags = "@ioc_tablets_windows"
)
public class IOC_Tablets_Windows_TestRunner {
    private AppendDataToFeatureFile_Utility ioc_utility;

    public IOC_Tablets_Windows_TestRunner() {
        ioc_utility = new AppendDataToFeatureFile_Utility();;
        ioc_utility.setExcelTab("Insurance_Offering_Config_Tab");
        ioc_utility.readCleanseDataSourceFileInto2DArray_AllSimPlans("Insurance_Offering_Config.csv", true);
        Predicate<String> predStringEquals = s -> (s.contains("Ideapad") || s.contains("Surface Pro"));
        Object[] args = {predStringEquals, 1, 0, 2};
        assertTrue(ioc_utility.copyFeatureFile("Tablets_Windows.feature"));
        assertTrue(ioc_utility.appendDataToNewFeatureFile("outline", "filtered_map_by_colrange", args));
    }

    @BeforeClass
    public static void setup() {
        //         Any BeforeAll logic ...
    }

    @AfterClass
    public static void teardown() {
//         DriverUtil.getDriver().close();
//        BrowserUtil.getBrowser().close();
    }
}
