package com.o2.stepdefs.ecomm;

import com.google.inject.Inject;
import com.nttdata.cinnamon.cache.Context;
import com.o2.pages.ecomm.OrderConfirmationPage;
import io.cucumber.java.en.Then;
import org.assertj.core.api.Assertions;

import java.util.logging.Logger;

import static org.assertj.core.api.Assertions.assertThat;

public class OrderConfirmationSteps extends BaseStep {

    private final Logger logger;
    private final OrderConfirmationPage orderConfirmationPage;
    private final Context context;

    @Inject
    public OrderConfirmationSteps(final Logger logger, final OrderConfirmationPage orderConfirmationPage, final Context context) {
        this.logger = logger;
        this.orderConfirmationPage = orderConfirmationPage;
        this.context = context;
    }

    @Then("^I can see order confirmation Page$")
    public void i_verify_order_confirmation() {
        logger.info("** Order Confirmation Page is opened...");
        orderConfirmationPage.waitForProcessLoadingToComplete(30, 2, 2);
        Assertions.assertThat(orderConfirmationPage.orderNumber.isDisplayed())
                .withFailMessage("Order Number not displayed!")
                .isTrue();
        logger.info("Order number: " + orderConfirmationPage.orderNumber.getText());
        Assertions.assertThat(orderConfirmationPage.orderConfirmationDownloadLink.isDisplayed())
                .withFailMessage("Download copy of Order link not displayed!")
                .isTrue();
    }
}
