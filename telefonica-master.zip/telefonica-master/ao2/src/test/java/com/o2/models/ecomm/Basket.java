package com.o2.models.ecomm;

import java.util.Map;

public class Basket {
    public String simPlan;
    public String tariffName;
    public String tariffPrice;
    public Map<String, String> extras;
    public String upfrontCost;
    public String monthlyCost;

    public Basket(String simPlan, String tariffName, String tariffPrice, Map<String, String> extras, String upfrontCost, String monthlyCost) {
        this.simPlan = simPlan;
        this.tariffName = tariffName;
        this.tariffPrice = tariffPrice;
        this.extras = extras;
        this.upfrontCost = upfrontCost;
        this.monthlyCost = monthlyCost;
    }

}
