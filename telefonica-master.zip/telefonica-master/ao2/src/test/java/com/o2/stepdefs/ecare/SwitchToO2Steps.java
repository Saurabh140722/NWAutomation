package com.o2.stepdefs.ecare;

import static com.nttdata.cinnamon.wait.ElementConditions.displayed;
import static org.assertj.core.api.Assertions.assertThat;

import com.google.inject.Inject;
import com.nttdata.cinnamon.driver.Browser;
import com.o2.pages.ecare.SwitchToO2Page;
import com.o2.stepdefs.BaseStep;
import com.o2.core.util.Common;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class SwitchToO2Steps extends BaseStep {
    private final SwitchToO2Page switchToO2Page;
    private final Browser browser;
    private final Common common;

    @Inject
    public SwitchToO2Steps(final SwitchToO2Page switchToO2Page, final Browser browser, final Common common) {
        this.switchToO2Page = switchToO2Page;
        this.browser = browser;
        this.common = common;
    }

    @Then("Switch to O2  page opens successfully")
    public void switch_to_o2_page_opens_successfully() {
        this.logger.info("** Waiting for Switch to O2 page to open ...");
        assertThat(this.switchToO2Page.isPageDisplayed(90)).withFailMessage("Switch to O2 page not displayed!")
                .isTrue();
        this.logger.info("** Switch to O2 page opens!");
    }

    @When("I select {string} from drop down")
    public void i_select_from_drop_down(String dropDownValue) throws InterruptedException {

        assertThat(this.switchToO2Page.movingFromAnotherProviderDropdown.isDisplayed(5))
                .withFailMessage("Movoing from Another provider drop down not displayed!").isTrue();
       // switchToO2Page.movingFromAnotherProviderDropdown.asSelect().
      //  switchToO2Page.movingFromAnotherProviderDropdown.asSelect().selectByText(dropDownValue);
        switchToO2Page.selectingmovingFromAnotherProviderDropdown.click();
        common.wait(5);
        switchToO2Page.numberYouWantToCanceldropdownvalue.waitUntil(displayed).click();

    }

    @Then("The number you want to cancel text box displays")
    public void the_number_you_want_to_cancel_text_box_displays() {
        assertThat(this.switchToO2Page.numberYouWantToCancelTextbox.isDisplayed(5))
                .withFailMessage("Movoing from Another provider drop down not displayed!").isTrue();
    }

    @Then("I verify the error message for invalid mobile number")
    public void i_verify_the_error_message_for_invalid_mobile_number() {
        String[] invalidMobileNumber = {"01", "07111"};

        for (int i = 0; i < invalidMobileNumber.length; i++) {
            switchToO2Page.numberYouWantToCancelTextbox.click();
            switchToO2Page.numberYouWantToCancelTextbox.setValue(invalidMobileNumber[i]);
            switchToO2Page.stacCodeTextbox.click();
            assertThat(this.switchToO2Page.mobileNumberErrorMessage.getText()
                    .equals("The mobile number should start with 07 and be 11 digits long")).withFailMessage(
                    "The mobile number should start with 07 and be 11 digits long error message not displayed!").isTrue();
        }
    }

    @Then("I enter valid mobile number")
    public void i_enter_valid_mobile_number() {
        switchToO2Page.numberYouWantToCancelTextbox.setValue("07111111111");
    }

    @Then("I verify the error message for invalid STAC code")
    public void i_verify_the_error_message_for_invalid_stac_code() {
        assertThat(this.switchToO2Page.stacCodeTextbox.isDisplayed(5))
                .withFailMessage("STAC code text box not displayed!").isTrue();

        this.switchToO2Page.stacCodeTextbox.setValue("222DFS");
        this.switchToO2Page.numberYouWantToCancelTextbox.click();

        assertThat(this.switchToO2Page.stacCodeErrorMessage.getText().equals("Please enter a valid STAC."))
                .withFailMessage("Please enter a valid STAC error message not displayed!").isTrue();

    }

    @When("I enter expired STAC code")
    public void i_enter_expired_stac_code() {
        this.switchToO2Page.stacCodeTextbox.click();
        this.switchToO2Page.stacCodeTextbox.setValue("222333PRU");
    }

    @Then("I verify the error message for expired STAC code")
    public void i_verify_the_error_message_for_expired_stac_code() {
        assertThat(this.switchToO2Page.validateYourCodeErrorMessageTitle.getText().toString().trim()
                .equals("Unable to validate your code")).withFailMessage("Unable to validate your code message not displayed!").isTrue();

        assertThat(this.switchToO2Page.validateYourCodeErrorMessageText.getText().toString().trim().equals(
                "We couldn't validate your code due to a problem on our side. You can try again, or transfer your number later."))
                .withFailMessage("We couldn't validate your code due to a problem on our side. You can try again, or transfer your number later message not displayed!").isTrue();
    }
}
