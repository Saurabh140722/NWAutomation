package com.o2.pages.ecare;

import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.nttdata.cinnamon.driver.controls.PageElementCollection;
import com.o2.pages.BasePage;

public class ReturnOrExchangePage extends BasePage {

    @Find(by = By.XPath, locator = ".o2uk-return-or-exchange")
    public PageElement returnORExchangePag;

    @Find(by = By.XPath, locator = "//o2uk-return-or-exchange//o2uk-return-details-card/o2uk-card//div[contains(@class,'summary-return-date')]/div")
    public PageElement returnORExchangeByDate;

    @Find(by = By.XPath, locator = "//*[@role='button']//*[text()=' Return ']")
    public PageElement returnButton;

    @Find(by = By.XPath, locator = "//o2uk-select")
    public PageElement returnReasonSelect;

    @Find(by = By.XPath, locator = "//o2uk-option")
    public PageElementCollection returnReasonOption;

    @Find(by = By.XPath, locator = "//o2uk-return-details-card/o2uk-card//button")
    public PageElement returnContinue;

    @Find(by = By.XPath, locator = "//o2uk-return-details-card/o2uk-card//button")
    public PageElement returnContinueNext;

    @Find(by = By.XPath, locator = "//o2uk-return-details-card/o2uk-card//o2uk-notification-message//h4")
    public PageElement returnNotificationMessageHeader;

    @Find(by = By.XPath, locator = "//o2uk-return-details-card/o2uk-card//o2uk-notification-message//p[1]")
    public PageElement returnNotificationMessage1;

    @Find(by = By.XPath, locator = "//o2uk-return-details-card/o2uk-card//o2uk-notification-message//p[1]")
    public PageElement returnNotificationMessage2;

    @Find(by = By.XPath, locator = "//o2uk-device-plan//o2uk-device-order-actions//button[2]")
    public PageElement exchangeButton;

    @Find(by = By.XPath, locator = "//o2uk-common-dialog")
    public PageElement exchangeDialog;

    @Find(by = By.XPath, locator = "//o2uk-common-dialog//h3[text()='Exchanging a device?']")
    public PageElement exchangeADeviceHeader;

    @Find(by = By.XPath, locator = "//o2uk-dialog-actions/button[2]")
    public PageElement exchangeADevice;

    @Find(by = By.XPath, locator = "//o2uk-return-or-exchange")
    public PageElement makeAnexchangePage;

    @Find(by = By.XPath, locator = "//o2uk-return-or-exchange//h1[text()=' Make an exchange ']")
    public PageElement makeAnexchangePageHeader;

    @Find(by = By.XPath, locator = "//o2uk-return-or-exchange/o2uk-unsuccessful-info//h1")
    public PageElement returnOrExchangeUnSuccessful;

    @Find(by = By.XPath, locator = "//o2uk-return-or-exchange/o2uk-successful-info//h1")
    public PageElement returnOrExchangeSuccessful;

    @Find(by = By.XPath, locator = "//o2uk-common-dialog//o2uk-dialog-actions/button[1]")
    public PageElement cancelExchange;

    @Find(by = By.XPath, locator = "//o2uk-return-or-exchange//o2uk-link/button")
    public PageElement goBackFromReturn;


    public void selectReturnOption(String returnReason) throws InterruptedException {
        this.browser.setImplicitWait(30);
        returnReasonSelect.clickJs();
        Thread.sleep(8000);
        returnReasonOption.asList().size();
        returnReasonOption.asList().stream().forEach(p->this.logger.info(p.getText()));
        if(returnReasonOption.asList().size()>0){
            PageElement pe = returnReasonOption.asList().stream()
                    .filter(p->p.getText().trim().contains(returnReason))
                    .findFirst()
                    .orElse(null);
            pe.scrollIntoView();
            pe.clickJs();
            Thread.sleep(5000);
        }
    }




}
