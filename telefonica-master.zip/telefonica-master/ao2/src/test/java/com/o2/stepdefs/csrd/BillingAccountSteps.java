package com.o2.stepdefs.csrd;

import com.google.inject.Inject;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.nttdata.cinnamon.logging.Logger;
import com.o2.core.util.Retry;
import com.o2.pages.csrd.AccountLandingPage;
import com.o2.pages.csrd.BillingAccountFormPage;
import com.o2.pages.csrd.BillingAccountPage;
import com.o2.stepdefs.BaseStep;
import io.cucumber.java.en.When;

import java.util.function.Supplier;

import static com.nttdata.cinnamon.wait.ElementConditions.displayed;
import static org.assertj.core.api.Assertions.assertThat;

public class BillingAccountSteps extends BaseStep {
    private final Logger logger;
    private final Retry retry;
    private final AccountLandingPage accountLandingPage;
    private final BillingAccountPage billingAccountPage;
    private final BillingAccountFormPage billingAccountFormPage;

    @Inject
    public BillingAccountSteps(final Logger logger,
                               final Retry retry,
                               final AccountLandingPage accountLandingPage,
                               final BillingAccountPage billingAccountPage,
                               final BillingAccountFormPage billingAccountFormPage) {
        this.logger = logger;
        this.retry = retry;
        this.accountLandingPage = accountLandingPage;
        this.billingAccountPage = billingAccountPage;
        this.billingAccountFormPage = billingAccountFormPage;
    }

    @When("^I add a Billing Address$")
    public void i_add_a_billing_address() {
        this.logger.info("*** Adding a Billing Address ...");

        // TODO: add assertions for pages/forms/popups to be displayed
        this.accountLandingPage.billingAccounts.waitUntil(displayed).click();
        Supplier<PageElement> processIcon = () -> this.billingAccountFormPage.processIconElement;
        Boolean result = this.retry.untilNotDisplayed(processIcon, 12, 1);
        assertThat(result)
                .withFailMessage("Process icon still displayed after selecting a phone number!")
                .isTrue();

        this.billingAccountPage.newBillingAccountButton.waitUntil(displayed).click();
        result = this.retry.untilNotDisplayed(processIcon, 12, 1);
        assertThat(result)
                .withFailMessage("Process icon still displayed after selecting a phone number!")
                .isTrue();

//        this.billingAccountFormPage.accountName.waitUntil(displayed).click();
        this.billingAccountFormPage.confirmButton.click();
        result = this.retry.untilNotDisplayed(processIcon, 12, 1);
        assertThat(result)
                .withFailMessage("Process icon still displayed after selecting a phone number!")
                .isTrue();

        this.billingAccountFormPage.confirmPopupButton.waitUntil(displayed).click();
        result = this.retry.untilNotDisplayed(processIcon, 12, 1);
        assertThat(result)
                .withFailMessage("Process icon still displayed after selecting a phone number!")
                .isTrue();

        this.logger.info("*** Billing Address added!\n");
    }
}
