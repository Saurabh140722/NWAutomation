package com.o2.stepdefs.ecare;

import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.nttdata.cinnamon.driver.controls.PageElementCollection;
import com.o2.pages.BasePage;

public class VerifyPage extends BasePage {
    @Find(by = By.Id, locator = "otacDigitOne")
    public PageElement digitOne;

    @Find(by = By.Id, locator = "continueButton")
    public PageElement continueButton;

    @Find(by = By.CssSelector, locator = "#header")
    public PageElement pageTitle;

    @Find(by = By.CssSelector, locator = "#msisdnListSelectBoxItText")
    public PageElement phoneNumberDropDown;

    @Find(by = By.CssSelector, locator = "#msisdnListSelectBoxItArrowContainer")
    public PageElement phoneNumberDropDownArrow;

    @Find(by = By.XPath, locator = "//li[@role='option']")
    public PageElementCollection phoneNumberList;

    public boolean isPhoneSelected(String phoneNumber) {
        PageElement mobileNumber = this.browser.findBy(By.XPath, "//*[text()='" + phoneNumber + "']");
        mobileNumber.hover().clickJs();

        return phoneNumberDropDown.getText().trim().equalsIgnoreCase(phoneNumber);
    }

    @Override
    public boolean isPageDisplayed() {
        if (!pageTitle.isDisplayed()) return false;

        return pageTitle.getText().equalsIgnoreCase("We need to verify this number is yours");
    }

    @Override
    protected PageElement getPageCheckElement() {
        return this.digitOne;
    }
}
