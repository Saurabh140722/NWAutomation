package com.o2.pages.ecare;

import com.nttdata.cinnamon.driver.By;
import com.nttdata.cinnamon.driver.Find;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.nttdata.cinnamon.driver.controls.PageElementCollection;

public class OrderDetailPage extends EcareBasePage{
    @Find(by = By.XPath, locator = "//h1[@class='o2uk-header-curve__text-title ng-star-inserted']")
    public PageElement orderDetailTitle;
    @Find(by = By.CssSelector, locator = "o2uk-card card-order-details")
    public PageElementCollection orderDetailContainer;

}
