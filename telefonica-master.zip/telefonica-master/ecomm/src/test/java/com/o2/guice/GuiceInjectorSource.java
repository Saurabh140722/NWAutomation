package com.o2.guice;

import com.google.inject.Guice;
import com.google.inject.Injector;
import com.nttdata.cinnamon.guice.ApiModule;
import com.nttdata.cinnamon.guice.CinnamonModule;
import com.nttdata.cinnamon.guice.DriverModule;
import com.o2.core.guice.CoreModule;
import io.cucumber.guice.CucumberModules;
import io.cucumber.guice.InjectorSource;

public class GuiceInjectorSource implements InjectorSource {

    @Override
    public Injector getInjector() {
        return Guice.createInjector(
                CucumberModules.createScenarioModule(),
                new CinnamonModule(),
                new ApiModule(),
                new DriverModule(),
                new CoreModule(),
                new ProjectModule());
    }
}