package com.o2.hooks;

import com.aventstack.extentreports.service.ExtentService;
import com.google.inject.Inject;
import com.nttdata.cinnamon.conf.Env;
import com.nttdata.cinnamon.db.Db;
import com.nttdata.cinnamon.driver.Browser;
import com.nttdata.cinnamon.logging.Logger;
import com.o2.core.driver.Init;
import com.o2.core.util.Common;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.BeforeStep;
import io.cucumber.java.Scenario;

import org.openqa.selenium.Capabilities;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.text.MessageFormat;

public class Hooks {
    private final Browser browser;
    private final Db db;
    private final Logger logger;
    private final Common common;
    private final Init init;

    @Inject
    public Hooks(final Browser browser,
                 final Db db,
                 final Logger logger,
                 final Common common,
                 final Init init) {
        this.browser = browser;
        this.db = db;
        this.logger = logger;
        this.common = common;
        this.init = init;
    }

    @Before("@web")
    public void before(Scenario scenario) {
        logger.info("*** Before Web hook ...");

        org.junit.Assume.assumeFalse(MessageFormat
                        .format("Scenario ''{0}'' is in 'Work In Progress' status so it will be ignored!", scenario.getName()),
                scenario.getSourceTagNames().contains("@wip"));
        this.db.connect(this.common.createSqliteConnectionString(Env.get().settingsProperty("db_connection")));
       // TODO: all this logic should be put in Core
        db.connect(common.createSqliteConnectionString(Env.get().settingsProperty("db_connection")));
        init.initialiseDriver();

        Capabilities cap=((RemoteWebDriver)browser.getWebDriver(WebDriver.class)).getCapabilities();
        ExtentService.getInstance().setSystemInfo("Environment",System.getProperty("env"));
        ExtentService.getInstance().setSystemInfo("Browser",cap.getBrowserName());
        ExtentService.getInstance().setSystemInfo("OS",System.getProperty("os.name"));

        logger.info("*** Before hook complete!\n");
    }

    @BeforeStep("@web")
    public void beforeStep() {
        this.logger.info("\n*** Before step hook: Restore implicit wait ...");
        this.browser.restoreImplicitWait();
        this.logger.info("*** Before step hook complete!\n");
    }


    @After("@web")
    public void after(Scenario scenario) {
        logger.info("\n*** After hook ...");

        if (scenario.isFailed()) {
            TakesScreenshot ts = (TakesScreenshot) browser.getWebDriver(WebDriver.class);
            byte[] screenshot = ts.getScreenshotAs(OutputType.BYTES);
            scenario.log("Test: " + scenario.getName() + " has failed!");
            scenario.attach(screenshot, "image/png", scenario.getName());
        }
        browser.quit();
        logger.info("*** After hook complete!\n");
    }

}