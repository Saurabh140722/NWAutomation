package com.o2.guice;

import com.google.inject.AbstractModule;
import io.cucumber.guice.ScenarioScoped;

public final class ProjectModule extends AbstractModule {
    @Override
    public void configure() {
        try {
            // Bindings for classes that are shared for the lifetime of the
            // scenario.
            bind(EcommBasePage.class).in(ScenarioScoped.class);
            bind(SignInPage.class).in(ScenarioScoped.class);
            bind(ProcessElements.class).in(ScenarioScoped.class);
            bind(BasketPage.class).in(ScenarioScoped.class);
            bind(PhonePage.class).in(ScenarioScoped.class);
            bind(CreateAnAccountPage.class).in(ScenarioScoped.class);

        } catch (Exception e) {
            addError(e.getMessage());
        }
    }
}
