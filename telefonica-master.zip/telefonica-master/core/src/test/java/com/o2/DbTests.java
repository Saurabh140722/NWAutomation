package com.o2;

import org.apache.commons.lang3.NotImplementedException;
import org.junit.Test;

public class DbTests {
    @Test
    public void dbConnectTest() {
        throw new NotImplementedException();
    }
}
