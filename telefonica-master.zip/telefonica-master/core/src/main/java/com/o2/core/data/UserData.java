package com.o2.core.data;

import com.google.inject.Inject;
import com.nttdata.cinnamon.data.UserGenerator;
import com.nttdata.cinnamon.db.DbResult;

import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

public class UserData {
    private final UserGenerator userGenerator;
    private final UserPaymentData userPaymentData;
    public final UserDataModel userDataModel;

    @Inject
    public UserData(final UserGenerator userGenerator,
                    final UserPaymentData userPaymentData,
                    final UserDataModel userDataModel) {
        this.userGenerator = userGenerator;
        this.userPaymentData = userPaymentData;
        this.userDataModel = userDataModel;
    }

    public UserData generate() {
        this.userGenerator.generate();

        this.userDataModel.firstName = this.userGenerator.getFirstName();
        this.userDataModel.lastName = this.userGenerator.getLastName();
        this.userDataModel.userEmail = MessageFormat.format("{0}.{1}_{2}@example.com",
                this.userDataModel.firstName,
                this.userDataModel.lastName,
                new SimpleDateFormat("yyyyMMddhhmmss").format(new Date())
                );
        this.userDataModel.password = this.userGenerator.getPassword();
        this.userDataModel.contactMobile = this.userGenerator.getMobile();

        return this;
    }

    public UserData generate(final String pathToPaymentData) {
        this.generate();
        this.userPaymentData.generate(pathToPaymentData);
        this.userDataModel.userPaymentModel = this.userPaymentData.getPaymentDetailsByName("Default");

        return this;
    }

    public UserPaymentModel getPaymentDataByName(String name) {
        return this.userPaymentData.getPaymentDetailsByName(name);
    }

    public UserData generate(final DbResult dbResult) {
        Map<String, String> data = dbResult.get().get(0);
        this.userGenerator.generate();

        this.userDataModel.firstName = data.get("first_name");
        this.userDataModel.lastName = data.get("last_name");
        this.userDataModel.userEmail = data.get("email");
        this.userDataModel.password = data.get("password");
        this.userDataModel.contactMobile = this.userGenerator.getMobile(); // Duplicated as forgot to add entry for mobile

        this.userDataModel.userPaymentModel.bankAccount = data.get("bank_account");
        this.userDataModel.userPaymentModel.bankSortCode = data.get("bank_sortcode");
        this.userDataModel.userPaymentModel.cardPan = data.get("card_pan");
        this.userDataModel.userPaymentModel.cardExpiryMonth = data.get("card_expiry_month");
        this.userDataModel.userPaymentModel.cardExpiryYear = data.get("card_expiry_year");
        this.userDataModel.userPaymentModel.cardCvv = data.get("card_cvv");

        return this;
    }

    @Override
    public String toString() {
        return MessageFormat.format(
                "User data:\n\tTitle:\t\t\t\t:{0}\n\tFirst Name:\t\t\t{1}\n\tLast Name:\t\t\t{2}" +
                        "\n\tEmail:\t\t\t\t{3}\n\tPassword:\t\t\t{4}\n\tMobile:\t\t\t\t{5}\n\tPostcode:\t\t\t{6}" +
                        "\n\tPhone Number:\t\t{7}" +
                        "\n\tBank Account:\t\t{8}\n\tBank Sort Code:\t\t{9}\n\tCard PAN:\t\t\t{10}" +
                        "\n\tCard Expiry Date:\t{11}\n\tCard CVV:\t\t\t{12}" +
                        "\n\tContract Number:\t{13}" +
                        "\n\tOrder number:\t\t{14}",
                this.userDataModel.title,
                this.userDataModel.firstName,
                this.userDataModel.lastName,
                this.userDataModel.userEmail,
                this.userDataModel.password,
                this.userDataModel.contactMobile,
                this.userDataModel.postcode,
                this.userDataModel.phoneNumber,
                this.userDataModel.userPaymentModel.bankAccount,
                this.userDataModel.userPaymentModel.bankSortCode,
                this.userDataModel.userPaymentModel.cardPan,
                MessageFormat.format(
                        "{0}/{1}",
                        this.userDataModel.userPaymentModel.cardExpiryMonth,
                        this.userDataModel.userPaymentModel.cardExpiryYear),
                this.userDataModel.userPaymentModel.cardCvv,
                this.userDataModel.contractNo,
                this.userDataModel.orderNo);
    }
}
