package com.o2.core.data;

public class UserPaymentModel {
    public String name;
    public String bankAccount;
    public String bankSortCode;
    public String cardPan;
    public String cardExpiryMonth;
    public String cardExpiryYear;
    public String cardCvv;
}
