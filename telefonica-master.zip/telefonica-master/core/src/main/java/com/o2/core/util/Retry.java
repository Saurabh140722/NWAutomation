package com.o2.core.util;

import com.google.inject.Inject;
import com.nttdata.cinnamon.driver.Browser;
import com.nttdata.cinnamon.driver.controls.PageElement;
import com.nttdata.cinnamon.logging.Logger;

import java.text.MessageFormat;
import java.util.function.Supplier;

public class Retry {
    private final Logger logger;
    private final Common common;
    private final Browser browser;

    @Inject
    public Retry(final Logger logger,
                 final Common common,
                 final Browser browser) {
        this.logger = logger;
        this.common = common;
        this.browser = browser;
    }

    public <T> boolean retryAction(Supplier<T> function, int maxRetries, int pollingInterval) {
        int retryCounter = 0;
        this.browser.setImplicitWait(1);
        while (retryCounter++ < maxRetries) {
            try {
                this.logger.info("Retry action ...");
                boolean result = (boolean) function.get();

                if (result) {
                    this.logger.info("retryAction - action completed!");
                    return true;
                }

                this.logger.warn("Retry action failed ...");
                this.common.wait(pollingInterval);
            } catch (Exception ex) {
                // the way isDisplayed() is built this branch won't be reached so it's not needed
                this.logger.info(
                        MessageFormat.format(
                                "retryAction - exception thrown while executing action! Exception:\n{0}",
                                ex.getMessage()));
                this.common.wait(pollingInterval);
            }
        }

        this.browser.restoreImplicitWait();

        return false;
    }

    public <T> boolean untilNotDisplayed(Supplier<T> function, int maxRetries, int pollingInterval) throws RuntimeException {
        return untilNotDisplayed(function, maxRetries, pollingInterval, 1);
    }

    // TODO: have this method more generic instead of just "untilNotDisplayed"
    // TODO: clean this method
    public <T> boolean untilNotDisplayed(Supplier<T> function, int maxRetries, int pollingInterval, int implicitWait) throws RuntimeException {
        int retryCounter = 0;
        this.browser.setImplicitWait(implicitWait);
        boolean result = false;

        while (retryCounter < maxRetries) {
            try {
                this.logger.info("Executing untilNotDisplayed ...");
                PageElement element = (PageElement) function.get();

                if (!element.isDisplayed()) {
                    result = true;
                    break;
                }

                retryCounter++;

                this.logger.warn(MessageFormat.format("Retry #{0} for ''{1}''", retryCounter, function));

                Thread.sleep(pollingInterval * 1000L);

                if (retryCounter >= maxRetries) {
                    this.logger.warn("Max retries reached and retry has failed!");
                    this.browser.restoreImplicitWait();

                    return false;
                }
            } catch (Exception ex) {
                // the way isDisplayed() is built this branch won't be reached so it's not needed
                this.logger.info("untilNotDisplayed - condition has been met!");
                this.browser.restoreImplicitWait();

                return true;
            }
        }

        this.browser.restoreImplicitWait();

        return result;
    }
}
