package com.o2.core.driver;

import com.google.inject.Inject;
import com.nttdata.cinnamon.conf.Env;
import com.nttdata.cinnamon.driver.Browser;
import com.nttdata.cinnamon.logging.Logger;

import java.net.URISyntaxException;
import java.nio.file.Paths;

public class Init {
    private final Browser browser;
    private final Logger logger;

    @Inject
    public Init(final Browser browser, Logger logger) {
        this.browser = browser;
        this.logger = logger;
    }

    public void initialiseDriver() {
        //browser.executeScript("window.localStorage.clear();");
        //browser.executeScript("window.sessionStorage.clear();");
        //browser.cookies().deleteAllCookies();
        // Get proxy preferences and init browser behind proxy
        String proxy = System.getProperty("proxy") == null ? "local" : System.getProperty("proxy");
        String setupDriver = System.getProperty("setup-driver") == null ? "auto" : System.getProperty("setup-driver");
        if (setupDriver.equals("auto")) {
            // TODO: we need also to treat the situation of No Proxy - in which case will simply call this.browser.init()
            String proxyServer = Env.get().settingsProperty("proxy_details." + proxy + "_proxy");
            browser.init(proxyServer);
        } else {
            try {
                // TODO: need to take this path as param and not hardcoded
                if (System.getProperty("os.name").contains("Windows")) {
                    browser.init(Paths.get(Init.class.getClassLoader().getResource("driver\\windows\\chromedriver.exe").toURI()));
                } else {
                    browser.init(Paths.get(Init.class.getClassLoader().getResource("driver/windows/chromedriver.exe").toURI()));
                }
            } catch (URISyntaxException e) {
                e.printStackTrace();
            }
        }
    }
}