package com.o2.core.data;

import com.google.inject.Inject;

import java.text.MessageFormat;

public class UserDataModel {
    public String title = "Dr"; // Keep it here till we decide if this will change or not
    public String firstName;
    public String lastName;
    public String userEmail;
    public String password;
    public String contactMobile;
    public String phoneNumber;
    public String postcode = "B338TH"; // Keep it here till we decide if this will change or not
    public String address;
    public UserPaymentModel userPaymentModel;
    public String contractNo;
    public String orderNo;

    @Inject
    public UserDataModel(final UserPaymentModel userPaymentModel) {
        this.userPaymentModel = userPaymentModel;
    }

    public String getName() {
        return MessageFormat.format("{0} {1}",
                this.firstName, this.lastName);
    }
}
