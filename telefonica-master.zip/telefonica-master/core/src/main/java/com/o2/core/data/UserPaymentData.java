package com.o2.core.data;

import com.google.inject.Inject;
import com.nttdata.cinnamon.conf.Env;
import com.nttdata.cinnamon.file.json.JsonParser;

import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class UserPaymentData {
    private final JsonParser jsonParser;
    private final List<UserPaymentModel> userPayments = new ArrayList<>();

    @Inject
    public UserPaymentData(final JsonParser jsonParser) {
        this.jsonParser = jsonParser;
    }

    public void generate() {
        String pathToBankDetails = Paths.get(
                System.getProperty("user.dir"),
                Env.get().settingsProperty("bank_details"))
                .toString();

        generate(pathToBankDetails);
    }

    public void generate(final String pathToJson) {
        List<UserPaymentModel> userPaymentDataList = this.jsonParser.toObjList(Paths.get(pathToJson), UserPaymentModel.class);

        this.userPayments.addAll(userPaymentDataList);
    }

    public UserPaymentModel getPaymentDetailsByName(String name) {
        if (this.userPayments.size() == 0) generate();

        return this.userPayments.stream()
                .filter(p -> p.name.equalsIgnoreCase(name))
                .findFirst()
                .orElse(null);
    }
}
