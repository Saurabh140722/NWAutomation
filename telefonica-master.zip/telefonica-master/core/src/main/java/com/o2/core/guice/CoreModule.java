package com.o2.core.guice;

import com.google.inject.AbstractModule;
import com.google.inject.Singleton;
import com.o2.core.data.UserData;

public class CoreModule extends AbstractModule {
    @Override
    protected void configure() {
        bind(UserData.class).in(Singleton.class);
    }
}
