package com.o2.core.util;

import com.google.inject.Inject;
import com.nttdata.cinnamon.logging.Logger;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.Map;

public class Common {
    private final Logger logger;

    @Inject
    public Common(final Logger logger) {
        this.logger = logger;
    }

    public void wait(int seconds) {
        try {
            this.logger.warn(
                    MessageFormat.format(
                            "Waiter is called for {0} second(s)! Please make sure this is not a hardcoded waiter!",
                            seconds));

            Thread.sleep(seconds * 1000L);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public int randomInt(int min, int max) {
        return (int) ((Math.random() * (max - min)) + min);
    }

    public String stringToFieldName(String str) {
        String thisStr = str.replace(" ", "");

        return MessageFormat.format("{0}{1}",
                thisStr.substring(0, 1).toLowerCase(),
                thisStr.substring(1));
    }

    public String getCurrentDateTime(String dateTimeFormat) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(dateTimeFormat);
        Date date = new Date(System.currentTimeMillis());

        return simpleDateFormat.format(date);
    }

    public DateTime stringToDateTime(String dateAsString, String dateFormat) {
        DateTimeFormatter format = DateTimeFormat.forPattern(dateFormat);

        return format.parseDateTime(dateAsString);
    }

    public String getCurrentDateTime() {
        return getCurrentDateTime("dd-MM-yyyy HH:mm:ss");
    }

    // TODO: make this generic
    public boolean areEqual(Map<String, Boolean> first, Map<String, Boolean> second) {
        this.logger.info(">>> Assert 2 maps are equal ...");

        this.logger.info(MessageFormat.format("\nMap #1: {0}\nMap #2: {1}",
                Collections.singletonList(first), Collections.singletonList(second)));

        if (first.size() != second.size()) {
            this.logger.error(
                    MessageFormat.format(
                            "Size of Map #1: ''{0}'' does not match the size of Map #2: ''{1}''!",
                            first.size(), second.size()));
            return false;
        }

        boolean result = first.entrySet().stream()
                .allMatch(e -> e.getValue().equals(second.get(e.getKey())));
        if (result) {
            this.logger.info(">>> Maps are equal!");
        } else {
            this.logger.error(">>> Maps are NOT equal!");
        }

        this.logger.info(">>> Assert complete!");

        return result;
    }

    public boolean areEqual(DateTime first, DateTime second) {
        return areEqual(first, second, 0);
    }

    public boolean areEqual(DateTime first, DateTime second, int offset) {
        int diff = first.getSecondOfDay() - second.getSecondOfDay();

        return diff <= offset;
    }

    /*
    TODO: remove once DB will be hosted on VM
    This is a temporary solution so the whole team can use a same, pre-agreed path to Sqlite db file:
        C:\Users\WIN_USER\Documents\sqlite\ao2.db
    The method will take the path and will combine it with the user system
     */
    public String createSqliteConnectionString(String pathToDbFile) {
        return MessageFormat.format("jdbc:sqlite:C:\\Users\\{0}\\{1}",
                System.getProperty("user.name"),
                pathToDbFile.replace("jdbc:sqlite:", ""));
    }
}
